from __future__ import annotations

import os
import re
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from math import isfinite
from pathlib import Path
from typing import Any

import pandas as pd
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles

from longbridge_stock import clickhouse_realtime
from longbridge_stock.config import load_data_config, load_experiment_config
from longbridge_stock.holding_swing_status import build_holding_swing_status_map
from longbridge_stock.limit_up import (
    fetch_limit_up_candidates,
    predict_limit_up_candidates,
    refresh_limit_up_events,
    summary_to_dict,
    train_limit_up_model_from_db,
)
from longbridge_stock.long_term_stock_report import (
    DEFAULT_CONFIG_PATH,
    DEFAULT_OUTPUT_DIR,
    build_long_term_report,
    fetch_quote,
    find_report_history_record,
    load_report_config,
    load_report_history,
    normalize_symbol,
    normalize_report_config,
    record_report_history,
    render_report_image,
    report_history_path,
    resend_report_history_record,
    save_report_config,
    send_email_report,
    write_report_artifacts,
)
from longbridge_stock.pool_gain import fetch_pool_gain_predictions
from longbridge_stock.qlib_native import (
    QlibWorkflowSpec,
    RemoteQlibRunSummary,
    list_remote_qrun_runs,
    qlib_capability_registry,
    qlib_core_steps,
    qlib_environment_status,
    save_qlib_workflow_config,
    start_local_qrun,
)
from longbridge_stock.realtime_analysis import fetch_realtime_model_pool
from longbridge_stock.realtime_profit import fetch_realtime_profit_predictions
from longbridge_stock.research import build_stock_research
from longbridge_stock.scoring import DEFAULT_SCORE_WEIGHTS
from longbridge_stock.stock_tags import build_stock_tags
from longbridge_stock.sync_monitor import _fallback_overview
from longbridge_stock.ui.services import default_score_dsn, latest_market_scores, refresh_stock_scores_table, stock_score_detail

app = FastAPI(title="Longbridge Quant API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:19911",
        "http://localhost:19911",
        "http://192.168.10.23:19911",
        "http://192.168.10.23:1820",
        "http://192.168.10.23",
    ],
    allow_methods=["*"],
    allow_headers=["*"],
)

ASIA_SHANGHAI = timezone(timedelta(hours=8))
_API_CACHE: dict[tuple[Any, ...], tuple[float, Any]] = {}
_LONG_TERM_REPORT_JOBS: dict[str, dict[str, Any]] = {}
_LONG_TERM_REPORT_JOBS_LOCK = threading.Lock()
_LONG_TERM_REPORT_GENERATION_LOCK = threading.Lock()


def _cache_get(key: tuple[Any, ...], ttl_seconds: int) -> Any | None:
    if os.getenv("PYTEST_CURRENT_TEST"):
        return None
    item = _API_CACHE.get(key)
    if not item:
        return None
    expires_at, value = item
    if expires_at <= time.monotonic():
        _API_CACHE.pop(key, None)
        return None
    return value


def _cache_set(key: tuple[Any, ...], value: Any, ttl_seconds: int = 60) -> None:
    if os.getenv("PYTEST_CURRENT_TEST"):
        return
    if len(_API_CACHE) > 512:
        now = time.monotonic()
        for cache_key, (expires_at, _) in list(_API_CACHE.items()):
            if expires_at <= now:
                _API_CACHE.pop(cache_key, None)
    _API_CACHE[key] = (time.monotonic() + ttl_seconds, value)


FACTOR_META = [
    ("trend_score", "趋势分", "中期趋势强弱，主要来自半年涨跌幅。"),
    ("momentum_score", "动量分", "短期价格动能，综合 5 日和 10 日涨跌。"),
    ("volume_score", "量能分", "资金活跃度，结合换手率和量比。"),
    ("risk_score", "风险分", "波动、负债和杠杆越低，风险分越高。"),
    ("valuation_score", "估值分", "PE、PB、PS 越便宜，估值分越高。"),
    ("quality_score", "质量分", "盈利质量，主要看 ROE、ROA 和净利率。"),
    ("model_score", "模型分", "来自 Qlib 预测分，缺失时使用规则代理分。"),
]

EARLY_SIGNAL_FACTOR_META = [
    ("early_volume_signal", "量能异动", "换手率和量比开始活跃，表示资金可能提前进入。", 0.22),
    ("early_ten_day_turn", "10日温和转强", "10日涨幅接近温和启动区间，避免短期过热追高。", 0.18),
    ("early_low_position", "低位修复", "半年涨幅不夸张，偏向低位平台刚开始修复。", 0.18),
    ("early_five_day_turn", "5日拐点", "最近5日刚开始转强，但还没有明显冲高。", 0.14),
    ("early_valuation_support", "估值支撑", "估值不贵时更适合提前埋伏。", 0.10),
    ("early_risk_control", "风险控制", "波动、负债和杠杆较低时，假突破风险更小。", 0.08),
    ("early_quality_support", "质量支撑", "盈利质量用于过滤基本面太弱的股票。", 0.05),
    ("early_model_support", "模型辅助", "现有 Qlib 预测分只作为辅助确认。", 0.05),
    ("early_chase_penalty", "追高惩罚", "半年或短期涨幅过猛会扣分，避免追在高位。", -0.10),
]

TREND_COMPOUNDER_FACTOR_META = [
    ("compounder_trend_structure", "趋势结构", "中期上涨趋势已经成立，短期动量仍保持正向。", 0.25),
    ("compounder_relative_strength", "相对强度", "相对市场横截面更强，综合分、模型分和半年表现靠前。", 0.20),
    ("compounder_not_overheated", "未过热空间", "短期和半年涨幅没有进入极端追高区。", 0.15),
    ("compounder_volume_health", "量能健康", "量比和量能活跃但不过度异常。", 0.10),
    ("compounder_quality_support", "财报质量", "质量分、盈利和净资产表现提供基本面支撑。", 0.15),
    ("compounder_valuation_tolerance", "估值容忍", "强成长股允许一定估值溢价，但过高会影响分数。", 0.05),
    ("compounder_model_confirm", "模型确认", "Qlib 模型分用于辅助确认趋势延续概率。", 0.10),
]

VOLUME_BREAKOUT_FACTOR_META = [
    ("breakout_observation_score", "放量突破观察分", "只作为观察池评分，综合新突破、量能、K线质量、流动性和追高风险。", 0.30),
    ("volume_breakout_score", "放量突破分", "突破前高并由量能确认的综合分。", 0.35),
    ("breakout_layer", "突破层级", "60日突破为基础，120日和250日突破提供强度加分。", 0.25),
    ("breakout_volume_ratio_20", "成交量放大", "当天成交量相对前20日均量的放大倍数。", 0.15),
    ("breakout_turnover_ratio_20", "成交额放大", "当天成交额相对前20日均成交额的放大倍数。", 0.15),
    ("breakout_price_gap_60", "突破幅度", "最新价相对前60日高点的突破幅度。", 0.10),
    ("breakout_trade_activity_score", "交易活跃分", "换手率、量比、成交量和成交额放大后的活跃度。", 0.12),
    ("breakout_kline_quality_score", "K线质量分", "收盘位置、实体强度、上影线压力共同衡量突破质量。", 0.12),
    ("breakout_liquidity_score", "流动性分", "成交额和成交额/市值用于过滤太冷门或不易成交的标的。", 0.08),
    ("breakout_chase_risk_score", "追高风险分", "涨幅、突破幅度、长上影和极端放量越高，风险分越低。", 0.08),
]

QLIB_REMOTE_HOST = "192.168.10.28"
QLIB_REMOTE_USER = "alwin"
QLIB_RUN_ROOT = Path("/home/alwin/data/longbridge/qlib_runs")
QLIB_CONFIG_ROOT = Path("/home/alwin/data/longbridge/qlib_action_configs")
MARKET_CONFIGS = {
    "hk": ("configs/data.yaml", "configs/experiment_market_hk.yaml"),
    "us": ("configs/data.yaml", "configs/experiment_market_us.yaml"),
    "cn": ("configs/data.yaml", "configs/experiment_market_cn.yaml"),
}


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/api/workbench")
def workbench(
    market: str = Query(default="all", pattern="^(all|hk|us|cn)$"),
    limit: int = Query(default=50, ge=1, le=500),
    strategy: str = Query(default="trend_follow", pattern="^(trend_follow|early_signal|trend_compounder|limit_up|volume_breakout|my_holdings)$"),
    symbol: str | None = None,
    include_detail: bool = Query(default=False, alias="includeDetail"),
) -> dict[str, Any]:
    cache_key = ("workbench", market, limit, strategy, symbol or "", include_detail)
    cached = _cache_get(cache_key, ttl_seconds=45)
    if cached is not None:
        return cached
    frame = _holding_score_frame(market=market, limit=limit) if strategy == "my_holdings" else latest_market_scores(market=market, limit=limit, strategy=strategy)
    stocks = [_stock_row(row, strategy=strategy) for row in frame.to_dict("records")]
    selected_symbol = symbol or (stocks[0]["symbol"] if stocks else None)
    detail = None
    if include_detail and selected_symbol:
        detail = _holding_detail(selected_symbol, frame) if strategy == "my_holdings" else stock_score_detail(selected_symbol)
    payload = {
        "metrics": _metrics(frame),
        "stocks": stocks,
        "selectedSymbol": selected_symbol,
        "selectedDetail": _stock_detail(detail, strategy=strategy, include_klines=False) if detail else None,
        "workflow": _workflow(),
        "factors": _factors(),
        "strategy": strategy,
    }
    _cache_set(cache_key, payload)
    return payload


@app.get("/api/stocks/{symbol}")
def stock_detail(
    symbol: str,
    strategy: str = Query(default="trend_follow", pattern="^(trend_follow|early_signal|trend_compounder|limit_up|volume_breakout|my_holdings)$"),
    include_klines: bool = Query(default=False, alias="includeKlines"),
) -> dict[str, Any]:
    cache_key = ("stock_detail", symbol.strip().upper(), strategy, include_klines)
    cached = _cache_get(cache_key, ttl_seconds=45)
    if cached is not None:
        return cached
    if strategy == "my_holdings":
        frame = _holding_score_frame(market="all", limit=500)
        detail = _holding_detail(symbol.strip().upper(), frame)
        if detail is None:
            raise HTTPException(status_code=404, detail=f"Stock holding not found: {symbol}")
        payload = _stock_detail(detail, strategy=strategy, include_klines=include_klines)
        _cache_set(cache_key, payload)
        return payload
    detail = stock_score_detail(symbol)
    if detail is None:
        raise HTTPException(status_code=404, detail=f"Stock score not found: {symbol}")
    payload = _stock_detail(detail, strategy=strategy, include_klines=include_klines)
    _cache_set(cache_key, payload)
    return payload


@app.get("/api/stocks/{symbol}/klines")
def stock_klines(
    symbol: str,
    period: str = Query(default="day", pattern="^(day|week|month|1m|5m|15m|30m|60m)$"),
    limit: int = Query(default=260, ge=20, le=1200),
) -> dict[str, Any]:
    normalized_symbol = symbol.strip().upper()
    cache_key = ("stock_klines", normalized_symbol, period, limit)
    cached = _cache_get(cache_key, ttl_seconds=30 if period.endswith("m") else 600)
    if cached is not None:
        return cached
    payload = {
        "symbol": normalized_symbol,
        "period": period,
        "bars": stock_kline_bars(normalized_symbol, period=period, limit=limit),
    }
    _cache_set(cache_key, payload)
    return payload


@app.get("/api/account/executions")
def account_executions(
    symbol: str | None = Query(default=None, max_length=24),
    days: int = Query(default=90, ge=1, le=365),
    limit: int = Query(default=20, ge=1, le=100),
) -> dict[str, Any]:
    cache_key = ("account_executions", (symbol or "").strip().upper(), days, limit)
    cached = _cache_get(cache_key, ttl_seconds=120)
    if cached is not None:
        return cached
    payload = _fetch_account_executions(symbol=symbol, days=days, limit=limit)
    _cache_set(cache_key, payload)
    return payload


@app.post("/api/scores/refresh")
def refresh_scores() -> dict[str, Any]:
    summary = refresh_stock_scores_table()
    return {
        "scoreDate": str(getattr(summary, "score_date", "")),
        "total": int(getattr(summary, "total", 0)),
        "byMarket": dict(getattr(summary, "by_market", {}) or {}),
    }


@app.get("/api/realtime/model-pool")
def realtime_model_pool(
    market: str = Query(default="cn", pattern="^(all|hk|us|cn)$"),
    pool: str = Query(default="all", pattern="^(all|score_pool|early_signal|trend_compounder|limit_up|volume_breakout)$"),
    limit: int = Query(default=50, ge=1, le=300),
) -> dict[str, Any]:
    rows = fetch_realtime_model_pool(default_score_dsn(), market=market, pool=pool, limit=limit)
    quote_minutes = [row.get("quoteMinute") for row in rows if row.get("quoteMinute")]
    capital_minutes = [row.get("capitalMinute") for row in rows if row.get("capitalMinute")]
    return {
        "market": market,
        "pool": pool,
        "total": len(rows),
        "quoteMinute": max(quote_minutes) if quote_minutes else None,
        "capitalMinute": max(capital_minutes) if capital_minutes else None,
        "stocks": rows,
    }


@app.get("/api/realtime/profit")
def realtime_profit_predictions(
    market: str = Query(default="hk", pattern="^(all|hk|us)$"),
    limit: int = Query(default=50, ge=1, le=300),
) -> dict[str, Any]:
    rows = fetch_realtime_profit_predictions(dsn=default_score_dsn(), market=market, limit=limit)
    predicted_at = [row.get("predicted_at") for row in rows if row.get("predicted_at")]
    return {
        "market": market,
        "total": len(rows),
        "predictedAt": _iso_value(max(predicted_at)) if predicted_at else None,
        "rows": [_realtime_profit_row(row) for row in rows],
    }


@app.get("/api/realtime/profit/series")
def realtime_profit_series(
    symbol: str = Query(..., min_length=3, max_length=24),
    limit: int = Query(default=360, ge=1, le=2000),
) -> dict[str, Any]:
    normalized_symbol = symbol.strip().upper()
    cache_key = ("realtime_profit_series", normalized_symbol, limit)
    cached = _cache_get(cache_key, ttl_seconds=20)
    if cached is not None:
        return cached
    rows = fetch_realtime_profit_series(default_score_dsn(), symbol=normalized_symbol, limit=limit)
    payload = {
        "symbol": normalized_symbol,
        "total": len(rows),
        "points": [_realtime_profit_series_row(row) for row in rows],
    }
    _cache_set(cache_key, payload)
    return payload


@app.get("/api/realtime/capital/latest")
def realtime_capital_latest(symbol: str = Query(..., min_length=3, max_length=24)) -> dict[str, Any]:
    return _fetch_realtime_capital_latest(default_score_dsn(), symbol)


@app.post("/api/stock-tags")
def stock_tags(payload: dict[str, Any]) -> dict[str, Any]:
    symbols = payload.get("symbols")
    if not isinstance(symbols, list) or not symbols:
        raise HTTPException(status_code=400, detail="symbols must be a non-empty list")
    normalized_symbols = [str(symbol).strip().upper() for symbol in symbols if str(symbol).strip()]
    if not normalized_symbols:
        raise HTTPException(status_code=400, detail="symbols must contain at least one valid symbol")
    if len(normalized_symbols) > 100:
        raise HTTPException(status_code=400, detail="symbols supports at most 100 items")
    lookback_days = int(payload.get("lookbackDays") or payload.get("lookback_days") or 60)
    try:
        return build_stock_tags(normalized_symbols, lookback_days=lookback_days)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get("/api/sync/overview")
def sync_overview() -> dict[str, Any]:
    payload = _fallback_overview("数据大屏实时统计已暂停，避免盘中扫描 ClickHouse 大表。")
    payload["disabled"] = True
    payload["disabledReason"] = "data_screen_clickhouse_queries_paused"
    return payload


@app.post("/api/limit-up/refresh-events")
def limit_up_refresh_events(payload: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = payload or {}
    try:
        summary = refresh_limit_up_events(
            dsn=default_score_dsn(),
            start_date=payload.get("startDate"),
            end_date=payload.get("endDate"),
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    return summary_to_dict(summary)


@app.post("/api/limit-up/train")
def limit_up_train(payload: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = payload or {}
    try:
        summary = train_limit_up_model_from_db(
            dsn=default_score_dsn(),
            validation_ratio=float(payload.get("validationRatio", 0.2)),
            min_events=int(payload.get("minEvents", 20)),
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    return summary_to_dict(summary)


@app.post("/api/limit-up/predict")
def limit_up_predict(payload: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = payload or {}
    try:
        summary = predict_limit_up_candidates(
            dsn=default_score_dsn(),
            event_date=payload.get("eventDate"),
            limit=int(payload.get("limit", 50)),
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    return summary_to_dict(summary)


@app.get("/api/limit-up/candidates")
def limit_up_candidates(
    event_date: str | None = None,
    limit: int = Query(default=50, ge=1, le=200),
) -> dict[str, Any]:
    try:
        frame = fetch_limit_up_candidates(dsn=default_score_dsn(), event_date=event_date, limit=limit)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    candidates = [_limit_up_row(row) for row in frame.to_dict("records")]
    resolved_date = event_date or (str(frame["event_date"].max()) if not frame.empty and "event_date" in frame else None)
    return {
        "eventDate": resolved_date,
        "total": len(candidates),
        "candidates": candidates,
    }


@app.get("/api/pool-gain/candidates")
def pool_gain_candidates(
    as_of_date: str | None = None,
    market: str = Query(default="all", pattern="^(all|hk|us|cn)$"),
    limit: int = Query(default=50, ge=1, le=500),
) -> dict[str, Any]:
    try:
        fetch_limit = 500 if market != "all" else limit
        frame = fetch_pool_gain_predictions(dsn=default_score_dsn(), as_of_date=as_of_date, limit=fetch_limit)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    if market != "all" and not frame.empty:
        frame = frame[frame["market"].astype(str).str.lower() == market].copy()
    candidates = [_pool_gain_row(row) for row in frame.head(limit).to_dict("records")]
    resolved_date = as_of_date or (str(frame["as_of_date"].max()) if not frame.empty and "as_of_date" in frame else None)
    return {
        "asOfDate": resolved_date,
        "market": market,
        "total": len(candidates),
        "candidates": candidates,
    }


@app.get("/api/qlib/capabilities")
def qlib_capabilities() -> dict[str, Any]:
    status = qlib_environment_status()
    host = f"{QLIB_REMOTE_USER}@{QLIB_REMOTE_HOST}" if status.host == "local" else status.host
    return {
        "environment": {
            "host": host,
            "ready": bool(status.ready),
            "pyqlibInstalled": bool(status.pyqlib_installed),
            "lightgbmInstalled": bool(status.lightgbm_installed),
            "qrunAvailable": bool(status.qrun_available),
        },
        "coreSteps": [_core_step_payload(step) for step in qlib_core_steps()],
        "capabilities": [_capability_payload(capability) for capability in qlib_capability_registry()],
    }


@app.get("/api/qlib/templates")
def qlib_templates() -> dict[str, list[str]]:
    return {
        "handlers": ["Alpha158", "Alpha360"],
        "models": ["LGBModel", "LinearModel", "XGBModel", "CatBoostModel"],
        "strategies": ["TopkDropoutStrategy", "SoftTopkStrategy"],
        "records": ["SignalRecord", "SigAnaRecord", "PortAnaRecord", "MultiPassPortAnaRecord"],
        "advanced": ["online_prediction", "reinforcement_learning", "rd_agent"],
    }


@app.get("/api/qlib/runs")
def qlib_runs(limit: int = Query(default=20, ge=1, le=100)) -> dict[str, Any]:
    try:
        runs = _list_qrun_runs(limit)
    except Exception as exc:
        return {"runs": [], "error": str(exc)}
    return {"runs": [_run_payload(run) for run in runs], "error": None}


@app.post("/api/qlib/run")
def qlib_run_action(payload: dict[str, Any]) -> dict[str, Any]:
    market = _safe_choice(str(payload.get("market", "hk")).lower(), {"hk", "us", "cn"}, "hk")
    handler = _safe_choice(str(payload.get("handler", "Alpha158")), {"Alpha158", "Alpha360"}, "Alpha158")
    model = _safe_choice(
        str(payload.get("model", "LGBModel")),
        {"LGBModel", "LinearModel", "XGBModel", "CatBoostModel"},
        "LGBModel",
    )
    strategy = _safe_choice(
        str(payload.get("strategy", "TopkDropoutStrategy")),
        {"TopkDropoutStrategy", "SoftTopkStrategy"},
        "TopkDropoutStrategy",
    )
    prediction_only = bool(payload.get("predictionOnly", False))
    data_config_path, experiment_config_path = MARKET_CONFIGS[market]
    data_config = load_data_config(data_config_path)
    experiment = load_experiment_config(experiment_config_path)
    spec = QlibWorkflowSpec(handler=handler, model=model, strategy=strategy, prediction_only=prediction_only)
    run_id = f"qlib_{market}_{handler.lower()}_{model.lower()}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    config_path = QLIB_CONFIG_ROOT / f"{run_id}.yaml"
    saved_config = save_qlib_workflow_config(config_path, data_config, experiment, spec)
    run = start_local_qrun(saved_config, local_root=QLIB_RUN_ROOT, experiment_name=run_id)
    return {
        "runId": run.run_id,
        "pid": run.pid,
        "market": market,
        "handler": handler,
        "model": model,
        "strategy": strategy,
        "predictionOnly": prediction_only,
        "remoteDir": run.remote_dir,
        "configPath": run.config_path,
        "logPath": run.log_path,
    }


@app.get("/api/portfolio/preview")
def portfolio_preview(
    market: str = Query(default="hk", pattern="^(hk|us|cn|all)$"),
    topk: int = Query(default=30, ge=1, le=100),
) -> dict[str, Any]:
    frame = latest_market_scores(market=market, limit=topk)
    rows = frame.to_dict("records")
    holding_count = len(rows)
    weight = round(1 / holding_count, 4) if holding_count else 0
    holdings = [
        {
            **_stock_row(row),
            "weight": weight,
            "reason": _text(row.get("explanation")) or _portfolio_reason(row),
        }
        for row in rows
    ]
    return {
        "market": market,
        "topk": topk,
        "summary": {
            "estimatedPositions": holding_count,
            "weightMethod": "equal_weight",
            "rebalance": "weekly",
        },
        "holdings": holdings,
    }


@app.get("/api/long-term-reports/config")
def long_term_reports_config() -> dict[str, Any]:
    config = _load_long_term_config()
    return {
        "configPath": str(_long_term_config_path()),
        "historyPath": str(report_history_path(config.get("output_dir") or DEFAULT_OUTPUT_DIR)),
        "config": config,
    }


@app.put("/api/long-term-reports/config")
def update_long_term_reports_config(payload: dict[str, Any]) -> dict[str, Any]:
    config_payload = payload.get("config") if isinstance(payload.get("config"), dict) else payload
    try:
        config = save_report_config(config_payload, _long_term_config_path())
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {
        "configPath": str(_long_term_config_path()),
        "historyPath": str(report_history_path(config.get("output_dir") or DEFAULT_OUTPUT_DIR)),
        "config": config,
    }


@app.post("/api/long-term-reports/validate-symbols")
def validate_long_term_report_symbols(payload: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = payload or {}
    raw_symbols = payload.get("symbols") or payload.get("text") or []
    if isinstance(raw_symbols, str):
        raw_symbols = [item.strip() for item in raw_symbols.replace("\n", ",").replace(";", ",").split(",") if item.strip()]
    symbols = [str(item).strip() for item in raw_symbols if str(item).strip()]
    seen: set[str] = set()
    results = []
    for raw in symbols:
        normalized = normalize_symbol(raw)
        if normalized in seen:
            continue
        seen.add(normalized)
        try:
            quote = fetch_quote(normalized)
        except Exception as exc:
            quote = {}
            error = str(exc)
        else:
            error = ""
        name = str(quote.get("name") or quote.get("symbolName") or quote.get("display_name") or "")
        if not name:
            try:
                names = clickhouse_realtime.fetch_eastmoney_company_names([normalized])
            except Exception:
                names = {}
            name = str(names.get(normalized) or name)
        results.append(
            {
                "input": raw,
                "symbol": normalized,
                "valid": bool(quote or name),
                "name": name,
                "market": normalized.rsplit(".", 1)[-1] if "." in normalized else "",
                "error": "" if quote or name else (error or "quote_not_found"),
            }
        )
    return {
        "total": len(results),
        "valid": [item for item in results if item["valid"]],
        "invalid": [item for item in results if not item["valid"]],
        "results": results,
    }


@app.post("/api/long-term-reports/generate")
def generate_long_term_reports(payload: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = payload or {}
    if not bool(payload.get("wait", False)) and not bool(payload.get("asyncJob", False)):
        raise HTTPException(status_code=409, detail="前端版本过旧，请刷新页面后重新生成报告。")
    if not bool(payload.get("wait", False)):
        return _start_long_term_report_job(payload)
    return _generate_long_term_reports_sync(payload)


@app.get("/api/long-term-reports/jobs")
def long_term_report_jobs(limit: int = Query(default=20, ge=1, le=100)) -> dict[str, Any]:
    with _LONG_TERM_REPORT_JOBS_LOCK:
        jobs = sorted(_LONG_TERM_REPORT_JOBS.values(), key=lambda item: str(item.get("createdAt") or ""), reverse=True)
        return {"total": len(jobs), "jobs": [dict(item) for item in jobs[:limit]]}


@app.get("/api/long-term-reports/jobs/{job_id}")
def long_term_report_job_status(job_id: str) -> dict[str, Any]:
    with _LONG_TERM_REPORT_JOBS_LOCK:
        job = _LONG_TERM_REPORT_JOBS.get(job_id)
        if not job:
            raise HTTPException(status_code=404, detail=f"Report job not found: {job_id}")
        return dict(job)


def _start_long_term_report_job(payload: dict[str, Any]) -> dict[str, Any]:
    with _LONG_TERM_REPORT_JOBS_LOCK:
        active = next((job for job in _LONG_TERM_REPORT_JOBS.values() if job.get("status") in {"queued", "running"}), None)
        if active:
            return {
                "jobId": active["jobId"],
                "status": active["status"],
                "message": "A long-term report generation job is already running.",
            }
        job_id = f"ltr_job_{datetime.now(ASIA_SHANGHAI).strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
        symbols = payload.get("symbols") or _load_long_term_config().get("symbols") or []
        if isinstance(symbols, str):
            symbols = [item.strip() for item in symbols.replace("\n", ",").split(",") if item.strip()]
        symbols = [str(item).strip() for item in symbols if str(item).strip()]
        if not symbols:
            raise HTTPException(status_code=400, detail="No symbols configured")
        job = {
            "jobId": job_id,
            "status": "queued",
            "createdAt": datetime.now(ASIA_SHANGHAI).isoformat(timespec="seconds"),
            "startedAt": None,
            "finishedAt": None,
            "symbols": symbols,
            "total": len(symbols),
            "completed": 0,
            "currentSymbol": "",
            "record": None,
            "error": "",
        }
        _LONG_TERM_REPORT_JOBS[job_id] = job
    thread = threading.Thread(target=_run_long_term_report_job, args=(job_id, dict(payload)), daemon=True)
    thread.start()
    return {"jobId": job_id, "status": "queued", "total": len(symbols), "symbols": symbols}


def _run_long_term_report_job(job_id: str, payload: dict[str, Any]) -> None:
    acquired = _LONG_TERM_REPORT_GENERATION_LOCK.acquire(blocking=False)
    if not acquired:
        _update_long_term_report_job(job_id, status="failed", finishedAt=datetime.now(ASIA_SHANGHAI).isoformat(timespec="seconds"), error="Another report generation job is running.")
        return
    try:
        _update_long_term_report_job(job_id, status="running", startedAt=datetime.now(ASIA_SHANGHAI).isoformat(timespec="seconds"))
        record = _generate_long_term_reports_sync(payload, job_id=job_id)
        _update_long_term_report_job(
            job_id,
            status="succeeded",
            finishedAt=datetime.now(ASIA_SHANGHAI).isoformat(timespec="seconds"),
            completed=len(record.get("symbols") or []),
            currentSymbol="",
            record=record,
        )
    except Exception as exc:
        _update_long_term_report_job(
            job_id,
            status="failed",
            finishedAt=datetime.now(ASIA_SHANGHAI).isoformat(timespec="seconds"),
            error=str(getattr(exc, "detail", "") or exc),
        )
    finally:
        _LONG_TERM_REPORT_GENERATION_LOCK.release()


def _update_long_term_report_job(job_id: str, **updates: Any) -> None:
    with _LONG_TERM_REPORT_JOBS_LOCK:
        if job_id in _LONG_TERM_REPORT_JOBS:
            _LONG_TERM_REPORT_JOBS[job_id].update(updates)


def _generate_long_term_reports_sync(payload: dict[str, Any], *, job_id: str | None = None) -> dict[str, Any]:
    config = _load_long_term_config()
    symbols = payload.get("symbols") or config.get("symbols") or []
    if isinstance(symbols, str):
        symbols = [item.strip() for item in symbols.replace("\n", ",").split(",") if item.strip()]
    symbols = [str(item).strip() for item in symbols if str(item).strip()]
    if not symbols:
        raise HTTPException(status_code=400, detail="No symbols configured")
    as_of_text = str(payload.get("asOf") or payload.get("as_of") or date.today().isoformat())
    try:
        as_of_date = date.fromisoformat(as_of_text)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="asOf must be YYYY-MM-DD") from exc
    output_dir = str(payload.get("outputDir") or config.get("output_dir") or DEFAULT_OUTPUT_DIR)
    workers = _long_term_report_parallelism(payload, config, len(symbols))
    artifacts_by_index: dict[int, Any] = {}
    completed = 0
    if workers <= 1 or len(symbols) == 1:
        for index, symbol in enumerate(symbols):
            try:
                if job_id:
                    _update_long_term_report_job(job_id, currentSymbol=symbol)
                artifacts_by_index[index] = _build_long_term_report_artifact(symbol, as_of_date=as_of_date, config=config, output_dir=output_dir, no_image=bool(payload.get("noImage")))
                completed += 1
                if job_id:
                    _update_long_term_report_job(job_id, completed=completed)
            except Exception as exc:
                raise HTTPException(status_code=500, detail=f"{symbol}: {exc}") from exc
    else:
        if job_id:
            _update_long_term_report_job(job_id, currentSymbol=f"并行生成中：{workers} 路")
        with ThreadPoolExecutor(max_workers=workers) as executor:
            future_map = {
                executor.submit(_build_long_term_report_artifact, symbol, as_of_date=as_of_date, config=config, output_dir=output_dir, no_image=bool(payload.get("noImage"))): (index, symbol)
                for index, symbol in enumerate(symbols)
            }
            for future in as_completed(future_map):
                index, symbol = future_map[future]
                try:
                    artifacts_by_index[index] = future.result()
                except Exception as exc:
                    raise HTTPException(status_code=500, detail=f"{symbol}: {exc}") from exc
                completed += 1
                if job_id:
                    _update_long_term_report_job(job_id, completed=completed, currentSymbol=f"并行生成中：{completed}/{len(symbols)}")
    artifacts = [artifacts_by_index[index] for index in range(len(symbols))]
    email_result = None
    if bool(payload.get("sendEmail", config.get("send_email"))):
        try:
            email_result = send_email_report(
                artifacts,
                mail_config=config.get("mail") or {},
                dry_run=bool(payload.get("dryRunEmail", False)),
            )
        except Exception as exc:
            email_result = {"sent": False, "error": str(exc), "stage": "email"}
    record = record_report_history(artifacts, output_dir=output_dir, as_of=as_of_text, email_result=email_result)
    return _long_term_history_record_payload(record, include_content=True)


def _build_long_term_report_artifact(
    symbol: str,
    *,
    as_of_date: date,
    config: dict[str, Any],
    output_dir: str,
    no_image: bool,
) -> Any:
    report = build_long_term_report(
        symbol,
        as_of=as_of_date,
        lookback_start=str(config.get("lookback_start") or "2023-01-01"),
        news_limit=int(config.get("news_limit", 8)),
        llm_enabled=bool((config.get("llm") or {}).get("enabled", True)),
    )
    return write_report_artifacts(report, output_dir=output_dir, image=not no_image)


def _long_term_report_parallelism(payload: dict[str, Any], config: dict[str, Any], symbol_count: int) -> int:
    raw = payload.get("parallelism", payload.get("maxWorkers", config.get("max_workers", config.get("parallelism", os.getenv("LONG_TERM_REPORT_MAX_WORKERS", 2)))))
    try:
        workers = int(raw)
    except (TypeError, ValueError):
        workers = 2
    return max(1, min(workers, symbol_count, 8))


@app.get("/api/long-term-reports/history")
def long_term_reports_history(limit: int = Query(default=50, ge=1, le=500)) -> dict[str, Any]:
    config = _load_long_term_config()
    rows = load_report_history(config.get("output_dir") or DEFAULT_OUTPUT_DIR, limit=limit)
    return {
        "historyPath": str(report_history_path(config.get("output_dir") or DEFAULT_OUTPUT_DIR)),
        "total": len(rows),
        "records": [_long_term_history_record_payload(item, include_content=False) for item in rows],
    }


@app.get("/api/long-term-reports/history/{record_id}")
def long_term_reports_history_detail(record_id: str) -> dict[str, Any]:
    config = _load_long_term_config()
    record = find_report_history_record(record_id, config.get("output_dir") or DEFAULT_OUTPUT_DIR)
    if record is None:
        raise HTTPException(status_code=404, detail=f"Report history not found: {record_id}")
    return _long_term_history_record_payload(record, include_content=True)


@app.post("/api/long-term-reports/history/{record_id}/resend")
def resend_long_term_report(record_id: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = payload or {}
    config = _load_long_term_config()
    try:
        result = resend_report_history_record(
            record_id,
            output_dir=config.get("output_dir") or DEFAULT_OUTPUT_DIR,
            mail_config=config.get("mail") or {},
            dry_run=bool(payload.get("dryRunEmail", False)),
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=f"Report history not found: {record_id}") from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    return _long_term_history_record_payload(result["record"], include_content=True)


@app.get("/api/long-term-reports/history/{record_id}/markdown")
def long_term_report_markdown(record_id: str, symbol: str = Query(..., min_length=3, max_length=24)) -> PlainTextResponse:
    config = _load_long_term_config()
    record = find_report_history_record(record_id, config.get("output_dir") or DEFAULT_OUTPUT_DIR)
    if record is None:
        raise HTTPException(status_code=404, detail=f"Report history not found: {record_id}")
    artifact = _long_term_artifact(record, symbol)
    content = artifact.get("content")
    if not content and artifact.get("markdown"):
        path = Path(str(artifact["markdown"]))
        if path.exists():
            content = path.read_text(encoding="utf-8")
    return PlainTextResponse(str(content or ""))


@app.get("/api/long-term-reports/history/{record_id}/image")
def long_term_report_image(record_id: str, symbol: str = Query(..., min_length=3, max_length=24)) -> FileResponse:
    config = _load_long_term_config()
    record = find_report_history_record(record_id, config.get("output_dir") or DEFAULT_OUTPUT_DIR)
    if record is None:
        raise HTTPException(status_code=404, detail=f"Report history not found: {record_id}")
    artifact = _long_term_artifact(record, symbol)
    image_path = Path(str(artifact.get("image") or ""))
    if not image_path.exists():
        markdown = artifact.get("content")
        markdown_path = Path(str(artifact.get("markdown") or ""))
        if not markdown and markdown_path.exists():
            markdown = markdown_path.read_text(encoding="utf-8")
        if not markdown:
            raise HTTPException(status_code=404, detail="Report image not found")
        image_path = markdown_path.with_suffix(".png")
        render_report_image(str(markdown), image_path)
    return FileResponse(str(image_path), media_type="image/png", filename=image_path.name)


def _long_term_config_path() -> Path:
    return Path(os.getenv("LONG_TERM_STOCK_REPORT_CONFIG", str(DEFAULT_CONFIG_PATH)))


def _load_long_term_config() -> dict[str, Any]:
    path = _long_term_config_path()
    if path.exists():
        return normalize_report_config(load_report_config(path))
    return normalize_report_config({})


def _long_term_history_record_payload(record: dict[str, Any], *, include_content: bool) -> dict[str, Any]:
    artifacts = []
    for item in record.get("artifacts") or []:
        payload = dict(item)
        if not include_content:
            payload.pop("content", None)
        artifacts.append(payload)
    return {
        "id": record.get("id"),
        "templateVersion": record.get("template_version"),
        "asOf": record.get("as_of"),
        "generatedAt": record.get("generated_at"),
        "symbols": record.get("symbols") or [],
        "artifacts": artifacts,
        "email": record.get("email"),
        "resendHistory": record.get("resend_history") or [],
    }


def _long_term_artifact(record: dict[str, Any], symbol: str) -> dict[str, Any]:
    normalized = symbol.strip().upper()
    for item in record.get("artifacts") or []:
        if str(item.get("symbol") or "").upper() == normalized:
            return item
    raise HTTPException(status_code=404, detail=f"Report artifact not found: {symbol}")


def _metrics(frame: pd.DataFrame) -> dict[str, Any]:
    if frame.empty:
        return {
            "modelCoverage": "0 / 0",
            "limitUpCoverage": "0 / 0",
            "limitUpEventDate": "-",
            "bestScore": None,
            "scoreDate": "-",
            "dataExceptions": 0,
            "totalStocks": 0,
        }
    model_status = frame.get("model_status", pd.Series([], dtype="object")).fillna("")
    score_date = frame.get("score_date", pd.Series([], dtype="object"))
    limit_up_scores = frame.get("limit_up_score", pd.Series([], dtype="object"))
    limit_up_events = frame.get("limit_up_event_date", pd.Series([], dtype="object"))
    limit_up_count = int(limit_up_scores.notna().sum()) if not limit_up_scores.empty else 0
    limit_up_event_date = "-"
    if limit_up_count and not limit_up_events.empty:
        valid_limit_up_events = limit_up_events.dropna()
        if not valid_limit_up_events.empty:
            limit_up_event_date = _date_string(max(valid_limit_up_events, key=lambda value: str(value)))
    return {
        "modelCoverage": f"{int((model_status == 'qlib').sum())} / {int(len(frame))}",
        "limitUpCoverage": f"{limit_up_count} / {int(len(frame))}",
        "limitUpEventDate": limit_up_event_date,
        "bestScore": _number(frame["total_score"].max()) if "total_score" in frame else None,
        "scoreDate": _date_string(score_date.max()) if not score_date.empty else "-",
        "dataExceptions": int(model_status.isin(["no_kline", "insufficient_history"]).sum()),
        "totalStocks": int(len(frame)),
    }


def _core_step_payload(step: Any) -> dict[str, str]:
    return {
        "key": step.key,
        "title": step.title,
        "component": step.component,
        "purpose": step.purpose,
        "output": step.output,
    }


def _capability_payload(capability: Any) -> dict[str, str]:
    return {
        "key": capability.key,
        "title": capability.title,
        "category": capability.category,
        "component": capability.component,
        "status": capability.status,
        "purpose": capability.purpose,
        "output": capability.output,
        "nextAction": capability.next_action,
    }


def _run_payload(run: Any) -> dict[str, Any]:
    return {
        "runId": run.run_id,
        "host": run.host,
        "running": bool(run.running),
        "pid": run.pid,
        "remoteDir": run.remote_dir,
    }


def _list_qrun_runs(limit: int) -> list[RemoteQlibRunSummary]:
    if QLIB_RUN_ROOT.exists():
        runs: list[RemoteQlibRunSummary] = []
        directories = sorted(
            [path for path in QLIB_RUN_ROOT.iterdir() if path.is_dir() and path.name.startswith("qlib_")],
            key=lambda path: path.stat().st_mtime,
            reverse=True,
        )
        for directory in directories[:limit]:
            pid_path = directory / "qrun.pid"
            pid = pid_path.read_text(encoding="utf-8").strip() if pid_path.exists() else ""
            running = False
            if pid:
                try:
                    import os

                    os.kill(int(pid), 0)
                    running = True
                except (OSError, ValueError):
                    running = False
            runs.append(
                RemoteQlibRunSummary(
                    run_id=directory.name,
                    host="local",
                    running=running,
                    pid=pid or None,
                    remote_dir=str(directory),
                )
            )
        return runs
    return list_remote_qrun_runs(remote_host=QLIB_REMOTE_HOST, remote_user=QLIB_REMOTE_USER, limit=limit)


def _safe_choice(value: str, allowed: set[str], default: str) -> str:
    return value if value in allowed else default


def _portfolio_reason(row: dict[str, Any]) -> str:
    decision = _text(row.get("decision")) or "候选"
    score = _number(row.get("total_score"))
    score_text = f"综合分 {score:.2f}" if score is not None else "综合分待确认"
    return f"{score_text}，当前建议为{decision}，纳入组合预览等待复核。"


def _holding_score_frame(market: str, limit: int) -> pd.DataFrame:
    payload = _fetch_account_stock_positions()
    positions = payload.get("positions") if isinstance(payload, dict) else []
    holding_symbols = [
        _text(position.get("symbol"))
        for position in positions
        if isinstance(position, dict) and _text(position.get("symbol")) and not _is_option_symbol(_text(position.get("symbol")))
    ] if isinstance(positions, list) else []
    swing_status_by_symbol = build_holding_swing_status_map(holding_symbols)
    rows: list[dict[str, Any]] = []
    for position in positions if isinstance(positions, list) else []:
        symbol = _text(position.get("symbol"))
        if not symbol or _is_option_symbol(symbol):
            continue
        position_market = _normalize_market(_text(position.get("market")) or _market_from_symbol(symbol))
        if market != "all" and position_market != market:
            continue
        detail = stock_score_detail(symbol) or {}
        row = _merge_holding_with_score(position, detail, position_market)
        if symbol in swing_status_by_symbol:
            row["swing_status"] = swing_status_by_symbol[symbol]
        rows.append(row)
    rows.sort(key=lambda row: (_number(row.get("total_score")) if _number(row.get("total_score")) is not None else -1), reverse=True)
    return pd.DataFrame(rows[:limit])


def _holding_detail(symbol: str, frame: pd.DataFrame) -> dict[str, Any] | None:
    if frame.empty:
        return None
    matches = frame[frame["symbol"].astype(str) == symbol]
    if matches.empty:
        return None
    row = matches.iloc[0].to_dict()
    detail = stock_score_detail(symbol) or {}
    return {**row, **detail, **{key: value for key, value in row.items() if key in HOLDING_FIELDS}}


HOLDING_FIELDS = {
    "quantity",
    "available_quantity",
    "cost_price",
    "currency",
    "account_channel",
    "holding_available",
    "holding_reason",
    "swing_status",
}


def _merge_holding_with_score(position: dict[str, Any], detail: dict[str, Any], market: str) -> dict[str, Any]:
    symbol = _text(position.get("symbol"))
    name = _text(detail.get("name")) or _text(position.get("name")) or _text(position.get("symbolName")) or symbol
    return {
        **detail,
        "symbol": symbol,
        "name": name,
        "market": _text(detail.get("market")) or market,
        "decision": _text(detail.get("decision")) or "holding",
        "model_status": _text(detail.get("model_status")) or "holding",
        "model_reason": _text(detail.get("model_reason")) or "Longbridge current holding",
        "quantity": position.get("quantity"),
        "available_quantity": position.get("availableQuantity") if "availableQuantity" in position else position.get("available_quantity"),
        "cost_price": position.get("costPrice") if "costPrice" in position else position.get("cost_price"),
        "currency": _text(position.get("currency")),
        "account_channel": _text(position.get("accountChannel") or position.get("account_channel")),
        "holding_available": True,
        "holding_reason": "Longbridge current holding",
    }


def _stock_row(row: dict[str, Any], strategy: str = "trend_follow") -> dict[str, Any]:
    strategy_score_key = {
        "early_signal": "early_signal_score",
        "trend_compounder": "trend_compounder_score",
        "limit_up": "limit_up_score",
        "volume_breakout": "breakout_observation_score",
        "my_holdings": "total_score",
    }.get(strategy, "total_score")
    strategy_score = _number(row.get(strategy_score_key))
    if strategy_score is None and strategy == "trend_compounder":
        strategy_score = _trend_compounder_strategy_score(row)
    if strategy_score is None and strategy == "volume_breakout":
        strategy_score = _number(row.get("volume_breakout_score"))
    decision = _limit_up_decision_label(row.get("limit_up_decision")) if strategy == "limit_up" else _text(row.get("decision"))
    return {
        "symbol": _text(row.get("symbol")),
        "name": _text(row.get("name")) or "-",
        "market": _text(row.get("market")).upper(),
        "totalScore": _number(row.get("total_score")),
        "strategyScore": strategy_score,
        "strategy": strategy,
        "rank": _int(row.get("rank_in_market")),
        "decision": decision,
        "status": _limit_up_status(row) if strategy == "limit_up" else _status(row),
        "modelStatus": _text(row.get("model_status")),
        "modelReason": _text(row.get("model_reason")),
        "modelPredDate": _text(row.get("model_pred_date")),
        "lastDone": _number(row.get("last_done")),
        "deepPrediction": _deep_prediction_signal(row),
        "limitUp": _limit_up_signal(row),
        "breakout": _breakout_signal(row),
        "quantity": _number(row.get("quantity")),
        "availableQuantity": _number(row.get("available_quantity")),
        "costPrice": _number(row.get("cost_price")),
        "currency": _text(row.get("currency")),
        "accountChannel": _text(row.get("account_channel")),
        "swingRegime": _swing_regime(row.get("swing_status")),
    }


def _deep_prediction_signal(row: dict[str, Any]) -> dict[str, Any] | None:
    if row.get("deep_model_run_id") is None and row.get("deep_return_p50") is None:
        return None
    return {
        "modelRunId": _text(row.get("deep_model_run_id")),
        "modelName": _text(row.get("deep_model_name")) or "PTFT + VSSM",
        "expectedReturn5d": _raw_number(row.get("deep_expected_return_5d")),
        "returnP10": _raw_number(row.get("deep_return_p10")),
        "returnP50": _raw_number(row.get("deep_return_p50")),
        "returnP90": _raw_number(row.get("deep_return_p90")),
        "upsideProbability": _raw_number(row.get("deep_upside_probability")),
        "var5": _raw_number(row.get("deep_var_5")),
        "cvar5": _raw_number(row.get("deep_cvar_5")),
        "regime": _text(row.get("deep_regime")),
        "confidence": _raw_number(row.get("deep_confidence")),
        "signal": _text(row.get("deep_signal")),
        "explanation": _text(row.get("deep_explanation")),
        "updatedAt": _date_string(row.get("deep_updated_at")),
    }


def _limit_up_signal(row: dict[str, Any]) -> dict[str, Any] | None:
    if row.get("limit_up_model_run_id") is None and row.get("limit_up_score") is None:
        return None
    return {
        "modelRunId": _text(row.get("limit_up_model_run_id")),
        "eventDate": _date_string(row.get("limit_up_event_date")),
        "probability": _number(row.get("limit_up_probability")),
        "score": _number(row.get("limit_up_score")),
        "decision": _text(row.get("limit_up_decision")),
        "reason": _text(row.get("limit_up_reason")),
        "pctChange": _number(row.get("limit_up_pct_change")),
        "closePrice": _number(row.get("limit_up_close_price")),
        "targetOpenBuy": row.get("limit_up_target_open_buy") if row.get("limit_up_target_open_buy") is not None else None,
    }


def _breakout_signal(row: dict[str, Any]) -> dict[str, Any] | None:
    if row.get("volume_breakout_score") is None and row.get("breakout_over_60") is None:
        return None
    return {
        "score": _number(row.get("volume_breakout_score")),
        "observationScore": _number(row.get("breakout_observation_score")),
        "fresh60": _bool(row.get("fresh_breakout_over_60")),
        "fresh120": _bool(row.get("fresh_breakout_over_120")),
        "fresh250": _bool(row.get("fresh_breakout_over_250")),
        "ageDays": _number(row.get("breakout_age_days")),
        "over60": _bool(row.get("breakout_over_60")),
        "over120": _bool(row.get("breakout_over_120")),
        "over250": _bool(row.get("breakout_over_250")),
        "prevHigh60": _number(row.get("prev_high_60")),
        "prevHigh120": _number(row.get("prev_high_120")),
        "prevHigh250": _number(row.get("prev_high_250")),
        "priceGap60": _number(row.get("breakout_price_gap_60")),
        "volumeRatio20": _number(row.get("breakout_volume_ratio_20")),
        "turnoverRatio20": _number(row.get("breakout_turnover_ratio_20")),
        "tradeActivityScore": _number(row.get("breakout_trade_activity_score")),
        "klineQualityScore": _number(row.get("breakout_kline_quality_score")),
        "liquidityScore": _number(row.get("breakout_liquidity_score")),
        "chaseRiskScore": _number(row.get("breakout_chase_risk_score")),
    }


def _swing_regime(status: Any) -> dict[str, Any] | None:
    if not isinstance(status, dict) or not status.get("phase"):
        return None
    return {
        "phase": _text(status.get("phase")),
        "phaseLabel": _text(status.get("phase_label")),
        "asOf": _text(status.get("as_of")),
        "latestClose": _number(status.get("latest_close")),
        "anchorDate": _text(status.get("anchor_date")),
        "anchorPrice": _number(status.get("anchor_price")),
        "elapsedDays": _int(status.get("elapsed_days")),
        "typicalDays": _int(status.get("typical_days")),
        "remainingDays": _int(status.get("remaining_days")),
        "bias": _text(status.get("bias")),
        "biasLabel": _text(status.get("bias_label")),
        "drawdown": _number(status.get("drawdown")),
        "legReturn": _number(status.get("leg_return")),
    }


def _limit_up_row(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "symbol": _text(row.get("symbol")),
        "eventDate": _date_string(row.get("event_date")),
        "modelRunId": _text(row.get("model_run_id")),
        "probability": _number(row.get("open_buy_probability")),
        "score": _number(row.get("open_buy_score")),
        "decision": _text(row.get("decision")),
        "reason": _text(row.get("reason")),
        "pctChange": _number(row.get("pct_change")),
        "closePrice": _number(row.get("close_price")),
        "nextOpen": _number(row.get("next_open")),
        "maxReturn5d": _number(row.get("max_return_5d")),
        "maxDrawdown5d": _number(row.get("max_drawdown_5d")),
        "targetOpenBuy": row.get("target_open_buy") if row.get("target_open_buy") is not None else None,
    }


def _pool_gain_row(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "symbol": _text(row.get("symbol")),
        "market": _text(row.get("market")),
        "name": _text(row.get("name")),
        "asOfDate": _date_string(row.get("as_of_date")),
        "modelRunId": _text(row.get("model_run_id")),
        "modelType": _text(row.get("model_type")),
        "poolTags": list(row.get("pool_tags") or []),
        "probability": _number(row.get("probability")),
        "score": _number(row.get("score")),
        "riskScore": _number(row.get("risk_score")),
        "expectedMaxReturn5d": _number(row.get("expected_max_return_5d")),
        "suggestedEntry": _text(row.get("suggested_entry")),
        "reason": _text(row.get("reason")),
    }


def _stock_detail(row: dict[str, Any], strategy: str = "trend_follow", include_klines: bool = False) -> dict[str, Any]:
    symbol = _text(row.get("symbol"))
    snapshot = stock_research_snapshot(symbol) if symbol else None
    research = build_stock_research(row, snapshot)
    return {
        **_stock_row(row, strategy=strategy),
        "scoreDate": _date_string(row.get("score_date")),
        "factorScores": _factor_scores(row, strategy),
        "explanations": _explanations(row, strategy),
        "research": research,
        "klines": stock_kline_bars(symbol) if symbol and include_klines else [],
    }


def stock_kline_bars(symbol: str, period: str = "day", limit: int = 160) -> list[dict[str, Any]]:
    symbols = _symbol_variants(symbol)
    if period in {"day", "week", "month"}:
        sdk_bars = _stock_sdk_kline_bars(symbols, period=period, limit=limit)
        if sdk_bars:
            return sdk_bars
    if period in {"week", "month"}:
        return _stock_aggregated_daily_bars(symbols, period=period, limit=limit)
    if period in {"1m", "5m", "15m", "30m", "60m"}:
        db_bars = _stock_intraday_bars(symbols, period=period, limit=limit)
        if _has_today_intraday_bars(db_bars):
            return db_bars
        sdk_bars = _stock_sdk_intraday_bars(symbols, limit=limit) if period == "1m" else []
        return sdk_bars or db_bars
    try:
        import psycopg

        with psycopg.connect(default_score_dsn()) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    select trade_date, open, high, low, close, volume, turnover
                    from lb_daily_bars
                    where symbol = any(%s)
                    order by trade_date desc
                    limit %s
                    """,
                    [symbols, limit],
                )
                rows = cur.fetchall()
    except Exception:
        return []
    bars = [
        {
            "date": _date_string(row[0]),
            "open": _number(row[1]),
            "high": _number(row[2]),
            "low": _number(row[3]),
            "close": _number(row[4]),
            "volume": _number(row[5]),
            "turnover": _number(row[6]),
        }
        for row in rows
    ]
    bars.reverse()
    return bars


def fetch_realtime_profit_series(dsn: str, symbol: str, limit: int = 360) -> list[dict[str, Any]]:
    symbols = _symbol_variants(symbol)
    market = _normalize_market(_market_from_symbol(symbol))
    try:
        model_rows = clickhouse_realtime.fetch_latest_realtime_profit_model_runs(market=market, limit=1)
        if not model_rows:
            return []
        rows = clickhouse_realtime.fetch_realtime_profit_validation_series(
            symbols,
            model_run_id=str(model_rows[0].get("model_run_id") or ""),
            market=market,
            limit=limit,
        )
    except Exception:
        return []
    rows.reverse()
    return rows


def _stock_sdk_kline_bars(symbols: list[str], period: str, limit: int) -> list[dict[str, Any]]:
    try:
        from longbridge_stock.sdk_client import LongbridgeSdkClient

        _ensure_longbridge_env()
        client = LongbridgeSdkClient(rate_limit_per_second=10)
        rows: list[dict[str, Any]] = []
        for symbol in symbols:
            rows = client.kline_no_adjust(symbol, count=limit, period=period)
            if rows:
                break
    except Exception:
        return []
    bars = [_kline_row_from_sdk(row) for row in rows]
    bars = [bar for bar in bars if bar.get("date")]
    bars.sort(key=lambda item: str(item.get("date") or ""))
    return bars[-limit:]


def _stock_sdk_intraday_bars(symbols: list[str], limit: int) -> list[dict[str, Any]]:
    selected_symbol = ""
    try:
        from longbridge_stock.sdk_client import LongbridgeSdkClient

        _ensure_longbridge_env()
        client = LongbridgeSdkClient(rate_limit_per_second=10)
        rows: list[dict[str, Any]] = []
        for symbol in symbols:
            rows = client.intraday(symbol)
            if rows:
                selected_symbol = symbol
                break
    except Exception:
        return []
    if selected_symbol and rows:
        _persist_sdk_intraday_rows(selected_symbol, rows)
    bars = [_intraday_line_row_from_sdk(row) for row in rows]
    bars = [bar for bar in bars if bar.get("time") and _number(bar.get("close")) is not None]
    bars.sort(key=lambda item: str(item.get("time") or ""))
    return bars[-limit:]


def _persist_sdk_intraday_rows(symbol: str, rows: list[dict[str, Any]]) -> None:
    try:
        from longbridge_stock.postgres_store import LongbridgePostgresStore

        LongbridgePostgresStore(default_score_dsn()).upsert_intraday_lines(symbol, rows, datetime.now(ASIA_SHANGHAI))
    except Exception:
        return


def _intraday_line_row_from_sdk(row: dict[str, Any]) -> dict[str, Any]:
    timestamp = row.get("timestamp") or row.get("time") or row.get("date")
    price = _number(row.get("price") or row.get("close") or row.get("last"))
    return {
        "time": _datetime_string(timestamp),
        "date": _datetime_string(timestamp),
        "open": price,
        "high": price,
        "low": price,
        "close": price,
        "volume": _number(row.get("volume")),
        "turnover": _number(row.get("turnover")),
        "avgPrice": _number(row.get("avg_price") or row.get("avgPrice")),
        "source": "longbridge_sdk_intraday",
    }


def _kline_row_from_sdk(row: dict[str, Any]) -> dict[str, Any]:
    timestamp = row.get("timestamp") or row.get("time") or row.get("date")
    return {
        "date": _date_string(timestamp),
        "open": _number(row.get("open")),
        "high": _number(row.get("high")),
        "low": _number(row.get("low")),
        "close": _number(row.get("close") or row.get("last")),
        "volume": _number(row.get("volume")),
        "turnover": _number(row.get("turnover")),
        "adjusted": False,
        "source": "longbridge_sdk",
    }


def _stock_aggregated_daily_bars(symbols: list[str], period: str, limit: int) -> list[dict[str, Any]]:
    bucket_expr = "date_trunc('week', trade_date::timestamp)::date" if period == "week" else "date_trunc('month', trade_date::timestamp)::date"
    try:
        import psycopg

        with psycopg.connect(default_score_dsn()) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"""
                    with base as (
                      select {bucket_expr} as bucket, trade_date, open, high, low, close, volume, turnover
                      from lb_daily_bars
                      where symbol = any(%s)
                    ),
                    ranked as (
                      select *,
                             first_value(open) over (partition by bucket order by trade_date asc) as bucket_open,
                             first_value(close) over (partition by bucket order by trade_date desc) as bucket_close
                      from base
                    )
                    select bucket, max(bucket_open), max(high), min(low), max(bucket_close), sum(volume), sum(turnover)
                    from ranked
                    group by bucket
                    order by bucket desc
                    limit %s
                    """,
                    [symbols, limit],
                )
                rows = cur.fetchall()
    except Exception:
        return []
    bars = [
        {
            "date": _date_string(row[0]),
            "open": _number(row[1]),
            "high": _number(row[2]),
            "low": _number(row[3]),
            "close": _number(row[4]),
            "volume": _number(row[5]),
            "turnover": _number(row[6]),
        }
        for row in rows
    ]
    bars.reverse()
    return bars


def _has_today_intraday_bars(bars: list[dict[str, Any]]) -> bool:
    today = datetime.now(ASIA_SHANGHAI).date().isoformat()
    return sum(1 for bar in bars if str(bar.get("time") or bar.get("date") or "").startswith(today) and _number(bar.get("close")) is not None) >= 2


def _stock_intraday_bars(symbols: list[str], period: str, limit: int) -> list[dict[str, Any]]:
    try:
        return clickhouse_realtime.fetch_intraday_bars(symbols, period=period, limit=limit)
    except Exception:
        return []


def _fetch_account_executions(symbol: str | None, days: int, limit: int) -> dict[str, Any]:
    normalized_symbol = _symbol_variants(symbol.strip().upper())[0] if symbol else None
    try:
        from longbridge import openapi as sdk

        _ensure_longbridge_env()
        ctx = sdk.TradeContext(sdk.Config.from_env())
        today_rows = ctx.today_executions(symbol=normalized_symbol) if normalized_symbol else ctx.today_executions()
        start_at = datetime.now() - timedelta(days=days)
        history_rows = ctx.history_executions(symbol=normalized_symbol, start_at=start_at, end_at=datetime.now()) if normalized_symbol else ctx.history_executions(start_at=start_at, end_at=datetime.now())
        records = [_execution_row(item) for item in [*list(today_rows or []), *list(history_rows or [])]]
        records = [item for item in records if item.get("symbol")]
        records.sort(key=lambda item: str(item.get("tradeDoneAt") or ""), reverse=True)
        return {
            "available": True,
            "symbol": normalized_symbol,
            "records": records[:limit],
        }
    except Exception as exc:
        return {
            "available": False,
            "symbol": normalized_symbol,
            "reason": str(exc),
            "records": [],
        }


def _fetch_account_stock_positions() -> dict[str, Any]:
    try:
        from longbridge import openapi as sdk

        _ensure_longbridge_env()
        ctx = sdk.TradeContext(sdk.Config.from_env())
        payload = ctx.stock_positions()
        positions: list[dict[str, Any]] = []
        for channel in list(getattr(payload, "channels", []) or []):
            account_channel = _text(getattr(channel, "account_channel", ""))
            for item in list(getattr(channel, "positions", []) or []):
                row = _position_row(item)
                row["accountChannel"] = row.get("accountChannel") or account_channel
                if row.get("symbol"):
                    positions.append(row)
        return {"available": True, "positions": positions}
    except Exception as exc:
        return {"available": False, "reason": str(exc), "positions": []}


def _position_row(item: Any) -> dict[str, Any]:
    data = item.to_dict() if hasattr(item, "to_dict") else dict(vars(item)) if hasattr(item, "__dict__") else {}
    get = data.get if data else lambda key, default=None: getattr(item, key, default)
    symbol = _text(get("symbol"))
    return {
        "symbol": symbol,
        "name": _text(get("symbol_name") or get("name")),
        "market": _normalize_market(_text(get("market")) or _market_from_symbol(symbol)),
        "quantity": _number(get("quantity")),
        "availableQuantity": _number(get("available_quantity")),
        "currency": _text(get("currency")),
        "costPrice": _number(get("cost_price")),
    }


def _ensure_longbridge_env() -> None:
    if os.getenv("LONGBRIDGE_APP_KEY"):
        return
    candidates = [
        Path(".longbridge-openapi.env"),
        Path("/home/alwin/apps/longbridge-stock/.longbridge-openapi.env"),
    ]
    for path in candidates:
        if not path.exists():
            continue
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip() or line.lstrip().startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip().strip("'\""))
        if os.getenv("LONGBRIDGE_APP_KEY"):
            return


def _symbol_variants(symbol: str) -> list[str]:
    normalized = symbol.strip().upper()
    variants = [normalized]
    if normalized.endswith(".HK"):
        code = normalized.removesuffix(".HK")
        stripped = code.lstrip("0") or "0"
        padded = code.zfill(5)
        variants.extend([f"{stripped}.HK", f"{padded}.HK"])
    return list(dict.fromkeys(variants))


def _market_from_symbol(symbol: str) -> str:
    suffix = symbol.rsplit(".", 1)[-1].lower() if "." in symbol else ""
    if suffix in {"sh", "sz"}:
        return "cn"
    return suffix or "-"


def _normalize_market(market: str) -> str:
    normalized = market.strip().lower()
    if normalized.startswith("market."):
        normalized = normalized.split(".", 1)[1]
    if normalized in {"sh", "sz"}:
        return "cn"
    return normalized


def _is_option_symbol(symbol: str) -> bool:
    code = symbol.rsplit(".", 1)[0].upper()
    return bool(re.search(r"\d{6}[CP]\d+$", code))


def _execution_row(item: Any) -> dict[str, Any]:
    data = item.to_dict() if hasattr(item, "to_dict") else dict(vars(item)) if hasattr(item, "__dict__") else {}
    return {
        "orderId": _text(data.get("order_id")),
        "tradeId": _text(data.get("trade_id")),
        "symbol": _text(data.get("symbol")),
        "side": _text(data.get("side") or data.get("trade_side")),
        "tradeDoneAt": _datetime_string(data.get("trade_done_at") or data.get("trade_time") or data.get("created_at")),
        "quantity": _number(data.get("quantity") or data.get("executed_quantity")),
        "price": _number(data.get("price") or data.get("executed_price")),
    }


def stock_research_snapshot(symbol: str) -> dict[str, Any] | None:
    try:
        import psycopg

        with psycopg.connect(default_score_dsn()) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    select as_of, financial_summary, news_items, hotspots, llm_summary, sources, payload
                    from lb_stock_research_snapshots
                    where symbol = %s
                    order by as_of desc, updated_at desc
                    limit 1
                    """,
                    [symbol],
                )
                row = cur.fetchone()
                if not row:
                    return None
                columns = [item.name for item in cur.description]
    except Exception:
        return None

    data = dict(zip(columns, row))
    payload = data.get("payload") if isinstance(data.get("payload"), dict) else {}
    as_of = data.get("as_of")
    return {
        **payload,
        "asOf": _datetime_string(as_of) or _text(payload.get("asOf")),
        "financialSummary": data.get("financial_summary") or payload.get("financialSummary"),
        "newsItems": data.get("news_items") or payload.get("newsItems") or [],
        "hotspots": data.get("hotspots") or payload.get("hotspots") or [],
        "llmSummary": data.get("llm_summary") or payload.get("llmSummary"),
        "sources": data.get("sources") or payload.get("sources") or [],
    }


def _factor_scores(row: dict[str, Any], strategy: str) -> list[dict[str, Any]]:
    if strategy == "early_signal":
        return _early_signal_factor_scores(row)
    if strategy == "trend_compounder":
        return _trend_compounder_factor_scores(row)
    if strategy == "limit_up":
        return _limit_up_factor_scores(row)
    if strategy == "volume_breakout":
        return _volume_breakout_factor_scores(row)
    return [
            {
                "key": key,
                "label": label,
                "description": description,
                "value": _number(row.get(key)),
                "weight": DEFAULT_SCORE_WEIGHTS.get(key, 0),
            }
            for key, label, description in FACTOR_META
    ]


def _early_signal_factor_scores(row: dict[str, Any]) -> list[dict[str, Any]]:
    five_day = _number(row.get("five_day_change_rate")) or 0
    ten_day = _number(row.get("ten_day_change_rate")) or 0
    half_year = _number(row.get("half_year_change_rate")) or 0
    volume_score = _number(row.get("volume_score")) or 50
    valuation_score = _number(row.get("valuation_score")) or 50
    risk_score = _number(row.get("risk_score")) or 50
    quality_score = _number(row.get("quality_score")) or 50
    model_score = _number(row.get("model_score")) or 50
    moderate_short_momentum = max(0, min(100, 100 - abs(ten_day - 6) * 4))
    early_turn = max(0, min(100, 100 - abs(five_day - 2) * 8))
    low_position = max(0, min(100, 100 - abs(half_year - 5) * 1.4))
    chase_penalty = min(35, max(0, half_year - 45) * 1.2 + max(0, ten_day - 18) * 2)
    values = {
        "early_volume_signal": volume_score,
        "early_ten_day_turn": moderate_short_momentum,
        "early_low_position": low_position,
        "early_five_day_turn": early_turn,
        "early_valuation_support": valuation_score,
        "early_risk_control": risk_score,
        "early_quality_support": quality_score,
        "early_model_support": model_score,
        "early_chase_penalty": 100 - chase_penalty,
    }
    return [
        {"key": key, "label": label, "description": description, "value": round(values[key], 2), "weight": weight}
        for key, label, description, weight in EARLY_SIGNAL_FACTOR_META
    ]


def _explanations(row: dict[str, Any], strategy: str = "trend_follow") -> list[dict[str, str]]:
    if strategy == "early_signal":
        return _early_signal_explanations(row)
    if strategy == "trend_compounder":
        return _trend_compounder_explanations(row)
    if strategy == "limit_up":
        return _limit_up_explanations(row)
    if strategy == "volume_breakout":
        return _volume_breakout_explanations(row)
    explanation = _text(row.get("explanation"))
    return [
        {"title": "结论", "text": explanation or "暂无解释，等待评分服务生成。"},
        {"title": "主要优势", "text": _advantage_text(row)},
        {"title": "主要短板", "text": _weakness_text(row)},
        {"title": "模型说明", "text": _model_text(row)},
    ]


def _trend_compounder_factor_scores(row: dict[str, Any]) -> list[dict[str, Any]]:
    five_day = _number(row.get("five_day_change_rate")) or 0
    ten_day = _number(row.get("ten_day_change_rate")) or 0
    half_year = _number(row.get("half_year_change_rate")) or 0
    trend_score = _number(row.get("trend_score")) or 50
    momentum_score = _number(row.get("momentum_score")) or 50
    volume_score = _number(row.get("volume_score")) or 50
    quality_score = _number(row.get("quality_score")) or 50
    valuation_score = _number(row.get("valuation_score")) or 50
    model_score = _number(row.get("model_score")) or 50
    volume_ratio = _number(row.get("volume_ratio")) or 1

    medium_trend_fit = max(0, min(100, 100 - abs(half_year - 65) * 0.7))
    trend_structure = (trend_score + momentum_score + medium_trend_fit) / 3
    relative_strength = (trend_score + model_score + max(0, min(100, half_year))) / 3
    not_overheated = max(0, min(100, 100 - max(0, five_day - 12) * 4 - max(0, ten_day - 25) * 2 - max(0, half_year - 120) * 0.8))
    healthy_volume_ratio = max(0, min(100, 100 - abs(volume_ratio - 2.5) * 10))
    volume_health = (volume_score + healthy_volume_ratio) / 2
    values = {
        "compounder_trend_structure": trend_structure,
        "compounder_relative_strength": relative_strength,
        "compounder_not_overheated": not_overheated,
        "compounder_volume_health": volume_health,
        "compounder_quality_support": quality_score,
        "compounder_valuation_tolerance": valuation_score,
        "compounder_model_confirm": model_score,
    }
    return [
        {"key": key, "label": label, "description": description, "value": round(values[key], 2), "weight": weight}
        for key, label, description, weight in TREND_COMPOUNDER_FACTOR_META
    ]


def _trend_compounder_strategy_score(row: dict[str, Any]) -> float:
    factors = _trend_compounder_factor_scores(row)
    score = sum((factor.get("value") or 0) * (factor.get("weight") or 0) for factor in factors)
    return round(max(0, min(100, score)), 2)


def _limit_up_factor_scores(row: dict[str, Any]) -> list[dict[str, Any]]:
    probability = _number(row.get("limit_up_probability"))
    pct_change = _number(row.get("limit_up_pct_change"))
    return [
        {
            "key": "limit_up_score",
            "label": "涨停模型分",
            "description": "涨停或涨幅大于等于10%后，评估次日开盘是否适合买入的综合分。",
            "value": _number(row.get("limit_up_score")),
            "weight": 0.45,
        },
        {
            "key": "limit_up_probability",
            "label": "开盘可买概率",
            "description": "模型预测次日开盘买入后满足目标收益和回撤约束的概率。",
            "value": round(probability * 100, 2) if probability is not None else None,
            "weight": 0.35,
        },
        {
            "key": "limit_up_pct_change",
            "label": "当日涨幅",
            "description": "触发涨停模型的当日涨幅，用来确认事件强度。",
            "value": round(pct_change * 100, 2) if pct_change is not None else None,
            "weight": 0.1,
        },
        {
            "key": "limit_up_volume_context",
            "label": "量能背景",
            "description": "复用普通评分里的成交量分，判断涨停事件是否有量能支撑。",
            "value": _number(row.get("volume_score")),
            "weight": 0.1,
        },
    ]


def _volume_breakout_factor_scores(row: dict[str, Any]) -> list[dict[str, Any]]:
    layer = 0
    if _bool(row.get("breakout_over_60")):
        layer += 60
    if _bool(row.get("breakout_over_120")):
        layer += 25
    if _bool(row.get("breakout_over_250")):
        layer += 15
    values = {
        "volume_breakout_score": _number(row.get("volume_breakout_score")),
        "breakout_layer": layer,
        "breakout_volume_ratio_20": _number(row.get("breakout_volume_ratio_20")),
        "breakout_turnover_ratio_20": _number(row.get("breakout_turnover_ratio_20")),
        "breakout_price_gap_60": _number(row.get("breakout_price_gap_60")),
        "breakout_trade_activity_score": _number(row.get("breakout_trade_activity_score")),
        "breakout_kline_quality_score": _number(row.get("breakout_kline_quality_score")),
        "breakout_liquidity_score": _number(row.get("breakout_liquidity_score")),
        "breakout_chase_risk_score": _number(row.get("breakout_chase_risk_score")),
        "breakout_observation_score": _number(row.get("breakout_observation_score")),
    }
    return [
        {"key": key, "label": label, "description": description, "value": values.get(key), "weight": weight}
        for key, label, description, weight in VOLUME_BREAKOUT_FACTOR_META
    ]


def _limit_up_explanations(row: dict[str, Any]) -> list[dict[str, str]]:
    signal = _limit_up_signal(row)
    if not signal:
        return [{"title": "结论", "text": "当前股票没有匹配到最新涨停模型预测。"}]
    decision_label = {
        "strong_candidate": "强候选",
        "candidate": "候选",
        "watch": "观察",
        "avoid": "回避",
    }.get(signal.get("decision"), "观察")
    score = signal.get("score")
    score_text = f"{score:.2f}" if isinstance(score, (int, float)) else "-"
    probability = signal.get("probability")
    probability_text = f"{probability * 100:.2f}%" if isinstance(probability, (int, float)) else "-"
    pct_change = signal.get("pctChange")
    pct_text = f"{pct_change * 100:.2f}%" if isinstance(pct_change, (int, float)) else "-"
    return [
        {
            "title": "结论",
            "text": f"涨停模型分 {score_text}，决策为{decision_label}。事件日 {signal.get('eventDate') or '-'}，次日开盘可买概率 {probability_text}。",
        },
        {
            "title": "触发条件",
            "text": f"当日涨幅 {pct_text}，收盘价 {signal.get('closePrice') if signal.get('closePrice') is not None else '-'}。",
        },
        {"title": "模型原因", "text": signal.get("reason") or "暂无模型原因。"},
        {"title": "模型批次", "text": signal.get("modelRunId") or "-"},
    ]


def _trend_compounder_explanations(row: dict[str, Any]) -> list[dict[str, str]]:
    score = _number(row.get("trend_compounder_score")) or _number(row.get("strategyScore")) or _trend_compounder_strategy_score(row)
    score_text = f"强趋势回调分 {score:.2f}" if score is not None else "强趋势回调分待计算"
    five_day = _number(row.get("five_day_change_rate"))
    ten_day = _number(row.get("ten_day_change_rate"))
    half_year = _number(row.get("half_year_change_rate"))
    quality = _number(row.get("quality_score"))
    model = _number(row.get("model_score"))
    return [
        {"title": "结论", "text": f"{score_text}。这类股票已经处于上涨过程中，重点寻找趋势成立但短期未极端过热、仍有主升浪跟随空间的候选。"},
        {"title": "趋势与买点", "text": f"当前5日涨幅 {five_day if five_day is not None else '-'}，10日涨幅 {ten_day if ten_day is not None else '-'}，半年涨幅 {half_year if half_year is not None else '-'}；如果短期涨幅过猛或半年涨幅极端，会被过热因子压低。"},
        {"title": "财报与稀缺性", "text": f"质量分 {quality if quality is not None else '-'}。第一版用财报质量、行业属性和后续 LLM 备注判断龙头、核心技术、稀缺资源等特征。"},
        {"title": "模型确认", "text": f"模型分 {model if model is not None else '-'}；{_model_text(row)}"},
    ]


def _volume_breakout_explanations(row: dict[str, Any]) -> list[dict[str, str]]:
    signal = _breakout_signal(row)
    if not signal:
        return [{"title": "结论", "text": "当前股票没有匹配到放量突破信号。"}]
    layers = []
    if signal["over60"]:
        layers.append("60日")
    if signal["over120"]:
        layers.append("120日")
    if signal["over250"]:
        layers.append("250日")
    layer_text = "、".join(layers) if layers else "-"
    return [
        {"title": "结论", "text": f"放量突破分 {signal.get('score') if signal.get('score') is not None else '-'}，突破层级：{layer_text}。"},
        {"title": "量能确认", "text": f"20日量比 {signal.get('volumeRatio20') if signal.get('volumeRatio20') is not None else '-'}，成交额比 {signal.get('turnoverRatio20') if signal.get('turnoverRatio20') is not None else '-'}。"},
        {"title": "突破位置", "text": f"前60日高点 {signal.get('prevHigh60') if signal.get('prevHigh60') is not None else '-'}，突破幅度 {signal.get('priceGap60') if signal.get('priceGap60') is not None else '-'}。"},
    ]


def _early_signal_explanations(row: dict[str, Any]) -> list[dict[str, str]]:
    score = _number(row.get("early_signal_score")) or _number(row.get("strategyScore"))
    score_text = f"启动预警分 {score:.2f}" if score is not None else "启动预警分待计算"
    five_day = _number(row.get("five_day_change_rate"))
    ten_day = _number(row.get("ten_day_change_rate"))
    half_year = _number(row.get("half_year_change_rate"))
    return [
        {"title": "结论", "text": f"{score_text}。这套维度不是追已经创新高的强势股，而是寻找量能变活跃、短期刚转强、半年涨幅还不夸张的候选。"},
        {"title": "主要优势", "text": "优先看量能异动、5日/10日温和转强、低位修复和估值支撑，适合做提前观察池。"},
        {"title": "追高过滤", "text": f"当前5日涨幅 {five_day if five_day is not None else '-'}，10日涨幅 {ten_day if ten_day is not None else '-'}，半年涨幅 {half_year if half_year is not None else '-'}；涨幅过猛会被追高惩罚扣分。"},
        {"title": "模型说明", "text": _model_text(row)},
    ]


def _advantage_text(row: dict[str, Any]) -> str:
    scores = [(label, _number(row.get(key))) for key, label, _ in FACTOR_META]
    valid = [(label, value) for label, value in scores if value is not None]
    if not valid:
        return "暂无可比较的因子分。"
    valid.sort(key=lambda item: item[1], reverse=True)
    return "、".join(label for label, _ in valid[:2]) + "相对靠前，是当前评分的主要支撑。"


def _weakness_text(row: dict[str, Any]) -> str:
    scores = [(label, _number(row.get(key))) for key, label, _ in FACTOR_META]
    valid = [(label, value) for label, value in scores if value is not None]
    if not valid:
        return "暂无可比较的短板项。"
    valid.sort(key=lambda item: item[1])
    return f"{valid[0][0]}相对偏弱，需要结合行业位置和基本面继续复核。"


def _model_text(row: dict[str, Any]) -> str:
    status = _text(row.get("model_status")) or "unknown"
    reason = _text(row.get("model_reason")) or "暂无模型说明"
    pred_date = _text(row.get("model_pred_date")) or "-"
    return f"{_model_status_label(status)}；预测日 {pred_date}；{reason}。"


def _workflow() -> list[dict[str, str]]:
    return [
        {"title": "数据", "description": "长桥行情、估值、财务"},
        {"title": "因子", "description": "生成、评估、筛选"},
        {"title": "模型", "description": "Alpha158 + LightGBM"},
        {"title": "评分", "description": "规则分 + 模型分"},
        {"title": "解释", "description": "推荐原因与风险"},
    ]


def _factors() -> list[dict[str, Any]]:
    trend_factors = [
        {"key": key, "name": label, "description": description, "weight": DEFAULT_SCORE_WEIGHTS.get(key, 0), "strategy": "trend_follow"}
        for key, label, description in FACTOR_META
    ]
    early_factors = [
        {"key": key, "name": label, "description": description, "weight": weight, "strategy": "early_signal"}
        for key, label, description, weight in EARLY_SIGNAL_FACTOR_META
    ]
    compounder_factors = [
        {"key": key, "name": label, "description": description, "weight": weight, "strategy": "trend_compounder"}
        for key, label, description, weight in TREND_COMPOUNDER_FACTOR_META
    ]
    limit_up_factors = [
        {"key": item["key"], "name": item["label"], "description": item["description"], "weight": item["weight"], "strategy": "limit_up"}
        for item in _limit_up_factor_scores({})
    ]
    breakout_factors = [
        {"key": key, "name": label, "description": description, "weight": weight, "strategy": "volume_breakout"}
        for key, label, description, weight in VOLUME_BREAKOUT_FACTOR_META
    ]
    return trend_factors + early_factors + compounder_factors + limit_up_factors + breakout_factors


def _status(row: dict[str, Any]) -> str:
    if _text(row.get("model_status")) in {"no_kline", "insufficient_history"}:
        return "blocked"
    decision = _text(row.get("decision"))
    if decision in {"入池", "候选"}:
        return "candidate"
    if decision == "观察":
        return "watch"
    return "blocked"


def _limit_up_status(row: dict[str, Any]) -> str:
    decision = _text(row.get("limit_up_decision"))
    if decision in {"strong_candidate", "candidate"}:
        return "candidate"
    if decision == "watch":
        return "watch"
    return "blocked"


def _limit_up_decision_label(decision: object) -> str:
    return {
        "strong_candidate": "强候选",
        "candidate": "候选",
        "watch": "观察",
        "avoid": "回避",
    }.get(str(decision or ""), "观察")


def _realtime_profit_row(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "symbol": row.get("symbol"),
        "market": str(row.get("market") or "").upper(),
        "name": row.get("name"),
        "predictedAt": _iso_value(row.get("predicted_at")),
        "horizonMinutes": _int(row.get("horizon_minutes")),
        "targetReturn": _raw_number(row.get("target_return")),
        "profitProbability": _raw_number(row.get("profit_probability")),
        "expectedReturn": _raw_number(row.get("expected_return")),
        "riskScore": _number(row.get("risk_score")),
        "decision": row.get("decision"),
        "featureSnapshot": row.get("feature_snapshot") or {},
    }


def _realtime_profit_series_row(row: dict[str, Any]) -> dict[str, Any]:
    entry_price = _raw_number(row.get("entry_price"))
    expected_return = _raw_number(row.get("expected_return"))
    predicted_price = entry_price * (1 + expected_return) if entry_price is not None and expected_return is not None else None
    return {
        "modelRunId": row.get("model_run_id"),
        "predictedAt": _iso_value(row.get("predicted_at")),
        "symbol": row.get("symbol"),
        "market": str(row.get("market") or "").upper(),
        "name": row.get("name"),
        "horizonMinutes": _int(row.get("horizon_minutes")),
        "targetReturn": _raw_number(row.get("target_return")),
        "entryPrice": entry_price,
        "profitProbability": _raw_number(row.get("profit_probability")),
        "expectedReturn": expected_return,
        "predictedPrice": _raw_number(predicted_price),
        "riskScore": _number(row.get("risk_score")),
        "decision": row.get("decision"),
        "validationDueAt": _iso_value(row.get("validation_due_at")),
        "actualReturn": _raw_number(row.get("actual_return")),
        "actualHit": row.get("actual_hit"),
        "actualPrice": _raw_number(row.get("actual_price")),
        "actualHigh": _raw_number(row.get("actual_high")),
        "actualLow": _raw_number(row.get("actual_low")),
        "actualObservedUntil": _iso_value(row.get("actual_observed_until")),
    }


def _model_status_label(status: str) -> str:
    return {
        "qlib": "Qlib 真实模型",
        "proxy": "规则代理模型分",
        "no_kline": "无日线数据",
        "insufficient_history": "历史数据不足",
    }.get(status, status)


def _text(value: Any) -> str:
    if value is None or pd.isna(value):
        return ""
    return str(value)


def _number(value: Any) -> float | None:
    if value is None or pd.isna(value):
        return None
    if isinstance(value, Decimal):
        value = float(value)
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return round(number, 2) if isfinite(number) else None


def _raw_number(value: Any) -> float | None:
    if value is None or pd.isna(value):
        return None
    if isinstance(value, Decimal):
        value = float(value)
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if isfinite(number) else None


def _iso_value(value: Any) -> str | None:
    return value.isoformat() if hasattr(value, "isoformat") else (str(value) if value is not None else None)


def _int(value: Any) -> int | None:
    number = _number(value)
    return int(number) if number is not None else None


def _bool(value: Any) -> bool:
    if value is None or pd.isna(value):
        return False
    if isinstance(value, str):
        return value.lower() in {"true", "t", "1", "yes"}
    return bool(value)


def _date_string(value: Any) -> str:
    if value is None or pd.isna(value):
        return "-"
    if isinstance(value, (date, datetime)):
        return value.isoformat()[:10]
    return str(value)[:10]


def _datetime_string(value: Any) -> str:
    if value is None or pd.isna(value):
        return ""
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    return str(value)


def _fetch_realtime_capital_latest(dsn: str, symbol: str) -> dict[str, Any]:
    normalized_symbol = symbol.strip().upper()
    try:
        clickhouse_payload = clickhouse_realtime.fetch_latest_capital_snapshot(normalized_symbol)
    except Exception:
        clickhouse_payload = None
    if clickhouse_payload:
        return _realtime_capital_latest_payload(normalized_symbol, clickhouse_payload)
    return {"symbol": normalized_symbol, "available": False}


def _realtime_capital_latest_payload(normalized_symbol: str, payload: dict[str, Any]) -> dict[str, Any]:
    large_net = _number(payload.get("large_net"))
    total_net = _number(payload.get("total_net"))
    inflow = _number(payload.get("inflow"))
    signal = _capital_signal(large_net, total_net, inflow)
    return {
        "symbol": normalized_symbol,
        "market": str(payload.get("market") or "").upper(),
        "available": True,
        "snapshotMinute": _datetime_string(payload.get("snapshot_minute") or payload.get("capital_minute")),
        "flowTime": _datetime_string(payload.get("flow_time")),
        "largeIn": _number(payload.get("large_in")),
        "largeOut": _number(payload.get("large_out")),
        "largeNet": large_net,
        "mediumNet": _number(payload.get("medium_net")),
        "smallNet": _number(payload.get("small_net")),
        "totalIn": _number(payload.get("total_in")),
        "totalOut": _number(payload.get("total_out")),
        "totalNet": total_net,
        "largeNetRatio": _number(payload.get("large_net_ratio")),
        "smallNetRatio": _number(payload.get("small_net_ratio")),
        "latestInflow": inflow,
        "capitalUpdatedAt": _datetime_string(payload.get("updated_at") or payload.get("capital_updated_at")),
        "signal": signal,
        "signalLabel": _capital_signal_label(signal),
    }


def _capital_signal(large_net: float | None, total_net: float | None, inflow: float | None) -> str:
    if large_net is not None and total_net is not None and large_net > 0 and total_net > 0:
        return "capital_accumulation"
    if large_net is not None and total_net is not None and large_net < 0 and total_net < 0:
        return "main_fund_outflow"
    if inflow is not None and inflow > 0:
        return "minute_inflow"
    if inflow is not None and inflow < 0:
        return "minute_outflow"
    return "watch"


def _capital_signal_label(signal: str) -> str:
    return {
        "capital_accumulation": "资金增强",
        "main_fund_outflow": "主力流出",
        "minute_inflow": "分时流入",
        "minute_outflow": "分时流出",
        "watch": "观察",
    }.get(signal, "观察")


_FRONTEND_DIST = Path(__file__).resolve().parents[2] / "frontend" / "dist"
if _FRONTEND_DIST.exists():
    app.mount("/", StaticFiles(directory=str(_FRONTEND_DIST), html=True), name="frontend")

from __future__ import annotations

import json
import pickle
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd


FEATURE_NAMES = [
    "change_pct",
    "turnover_10k",
    "total_net",
    "large_net",
    "medium_net",
    "small_net",
    "large_net_share",
    "small_net_share",
    "net_turnover_ratio",
    "flow_15m",
    "flow_30m",
    "flow_today",
    "flow_delta",
    "flow_drop_from_peak",
    "intraday_position",
    "price_to_avg_pct",
    "depth_imbalance",
    "small_trade_ratio",
    "repeated_second_ratio",
]

CAPITAL_ONLY_FEATURE_NAMES = [
    "total_net",
    "large_net",
    "medium_net",
    "small_net",
    "large_net_share",
    "small_net_share",
]


@dataclass(frozen=True)
class CapitalStructurePrediction:
    state: str
    label: str
    cluster: int
    confidence: float
    bias: str
    risk_level: str
    distance: float
    nearest_distance: float
    features: dict[str, float]
    evidence: list[str]


@dataclass(frozen=True)
class CapitalStructureTrainingSummary:
    model_type: str
    trained_at: str
    samples: int
    clusters: int
    feature_names: list[str]
    cluster_profiles: dict[int, dict[str, Any]]
    metrics: dict[str, Any]


@dataclass
class CapitalStructureModel:
    estimator: Any
    scaler: Any
    feature_names: list[str]
    cluster_profiles: dict[int, dict[str, Any]]
    trained_at: str
    model_type: str = "sklearn_kmeans_capital_structure"

    def predict_one(self, row: dict[str, Any]) -> CapitalStructurePrediction:
        frame = build_feature_frame([row], feature_names=self.feature_names)
        if frame.empty:
            raise ValueError("no usable capital structure features")
        matrix = frame[self.feature_names].to_numpy(dtype="float64")
        scaled = self.scaler.transform(matrix)
        cluster = int(self.estimator.predict(scaled)[0])
        distances = self.estimator.transform(scaled)[0]
        nearest = float(np.min(distances)) if len(distances) else 0.0
        distance = float(distances[cluster]) if len(distances) > cluster else nearest
        second = float(np.partition(distances, 1)[1]) if len(distances) > 1 else distance
        confidence = _confidence_from_distances(distance, second)
        profile = self.cluster_profiles.get(cluster, _neutral_profile(cluster, frame.iloc[0].to_dict()))
        features = {name: float(frame.iloc[0][name]) for name in self.feature_names}
        return CapitalStructurePrediction(
            state=str(profile.get("state") or "neutral"),
            label=str(profile.get("label") or "资金结构中性"),
            cluster=cluster,
            confidence=confidence,
            bias=str(profile.get("bias") or "neutral"),
            risk_level=str(profile.get("risk_level") or "low"),
            distance=distance,
            nearest_distance=nearest,
            features=features,
            evidence=[str(item) for item in profile.get("evidence", [])][:6],
        )

    def predict(self, rows: Iterable[dict[str, Any]]) -> list[CapitalStructurePrediction]:
        return [self.predict_one(row) for row in rows]

    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        _dump_model(self, path)


def train_capital_structure_model(
    rows: Iterable[dict[str, Any]] | pd.DataFrame,
    *,
    n_clusters: int = 7,
    random_state: int = 42,
    min_samples: int = 30,
    feature_names: list[str] | None = None,
) -> tuple[CapitalStructureModel, CapitalStructureTrainingSummary]:
    names = list(feature_names or FEATURE_NAMES)
    frame = build_feature_frame(rows, feature_names=names)
    if len(frame) < min_samples:
        raise ValueError(f"not enough samples for capital structure model: {len(frame)}")
    clusters = max(2, min(int(n_clusters), len(frame)))

    from sklearn.cluster import KMeans
    from sklearn.metrics import silhouette_score
    from sklearn.preprocessing import StandardScaler

    scaler = StandardScaler()
    matrix = frame[names].to_numpy(dtype="float64")
    scaled = scaler.fit_transform(matrix)
    estimator = KMeans(n_clusters=clusters, n_init=20, random_state=random_state)
    labels = estimator.fit_predict(scaled)
    profiles = _build_cluster_profiles(frame, labels, clusters, names)
    trained_at = datetime.now().isoformat(timespec="seconds")
    model = CapitalStructureModel(
        estimator=estimator,
        scaler=scaler,
        feature_names=names,
        cluster_profiles=profiles,
        trained_at=trained_at,
    )
    metrics: dict[str, Any] = {"inertia": float(estimator.inertia_)}
    if clusters > 1 and len(set(labels)) > 1:
        metrics["silhouette"] = float(silhouette_score(scaled, labels))
    summary = CapitalStructureTrainingSummary(
        model_type=model.model_type,
        trained_at=trained_at,
        samples=len(frame),
        clusters=clusters,
        feature_names=names,
        cluster_profiles=profiles,
        metrics=metrics,
    )
    return model, summary


def load_capital_structure_model(path: str | Path) -> CapitalStructureModel:
    model = _load_model(Path(path))
    if not isinstance(model, CapitalStructureModel):
        raise TypeError(f"unsupported capital structure model payload: {type(model)!r}")
    return model


def build_feature_frame(
    rows: Iterable[dict[str, Any]] | pd.DataFrame,
    *,
    feature_names: list[str] | None = None,
) -> pd.DataFrame:
    if isinstance(rows, pd.DataFrame):
        raw_rows = rows.to_dict("records")
    else:
        raw_rows = list(rows)
    features = [_feature_row(row) for row in raw_rows]
    frame = pd.DataFrame(features)
    names = feature_names or FEATURE_NAMES
    if frame.empty:
        return pd.DataFrame(columns=names)
    for name in names:
        if name not in frame:
            frame[name] = 0.0
    frame = frame[names].replace([np.inf, -np.inf], np.nan).fillna(0.0)
    return frame


def prediction_to_dict(value: CapitalStructurePrediction) -> dict[str, Any]:
    return {
        "state": value.state,
        "label": value.label,
        "cluster": value.cluster,
        "confidence": round(value.confidence, 4),
        "bias": value.bias,
        "riskLevel": value.risk_level,
        "distance": round(value.distance, 6),
        "nearestDistance": round(value.nearest_distance, 6),
        "features": value.features,
        "evidence": value.evidence,
    }


def summary_to_dict(value: CapitalStructureTrainingSummary) -> dict[str, Any]:
    return json.loads(json.dumps(value, default=lambda item: item.__dict__, ensure_ascii=False))


def _feature_row(row: dict[str, Any]) -> dict[str, float]:
    total_net = _num(row, "total_net", "totalNet")
    large_net = _num(row, "large_net", "largeNet")
    medium_net = _num(row, "medium_net", "mediumNet")
    small_net = _num(row, "small_net", "smallNet")
    total_in = _num(row, "total_in", "totalIn")
    total_out = _num(row, "total_out", "totalOut")
    turnover = _num(row, "turnover", "turnover_hkd")
    flow_15m = _num(row, "flow_15m", "flow15m")
    flow_30m = _num(row, "flow_30m", "flow30m")
    flow_today = _num(row, "flow_today", "flowToday")
    flow_delta = _num(row, "flow_delta", "flowDelta", "flow_last30_delta")
    flow_drop = _num(row, "flow_drop_from_peak", "flowDropFromPeak")
    turnover_10k = turnover / 10_000 if turnover and turnover > 0 else 0.0
    denominator = (total_in or 0.0) + (total_out or 0.0)
    return {
        "change_pct": _num(row, "change_pct", "changePct", "change_percentage") or 0.0,
        "turnover_10k": turnover_10k,
        "total_net": total_net or 0.0,
        "large_net": large_net or 0.0,
        "medium_net": medium_net or 0.0,
        "small_net": small_net or 0.0,
        "large_net_share": (large_net or 0.0) / denominator if denominator > 0 else 0.0,
        "small_net_share": (small_net or 0.0) / denominator if denominator > 0 else 0.0,
        "net_turnover_ratio": (total_net or 0.0) / turnover_10k * 100 if turnover_10k > 0 else 0.0,
        "flow_15m": flow_15m or 0.0,
        "flow_30m": flow_30m or 0.0,
        "flow_today": flow_today if flow_today is not None else (total_net or 0.0),
        "flow_delta": flow_delta or 0.0,
        "flow_drop_from_peak": flow_drop or 0.0,
        "intraday_position": _clip(_num(row, "intraday_position", "intradayPosition", "intra_pos"), 0.0, 1.0, 0.5),
        "price_to_avg_pct": _num(row, "price_to_avg_pct", "priceToAvgPct", "intra_vs_avg_pct") or 0.0,
        "depth_imbalance": _clip(_num(row, "depth_imbalance", "depthImbalance"), -1.0, 1.0, 0.0),
        "small_trade_ratio": _clip(_num(row, "trade_small_count_ratio", "smallTradeRatio"), 0.0, 1.0, 0.0),
        "repeated_second_ratio": _clip(_num(row, "trade_repeated_second_ratio", "repeatedSecondRatio"), 0.0, 1.0, 0.0),
    }


def _build_cluster_profiles(frame: pd.DataFrame, labels: np.ndarray, clusters: int, feature_names: list[str]) -> dict[int, dict[str, Any]]:
    profiles: dict[int, dict[str, Any]] = {}
    for cluster in range(clusters):
        part = frame[labels == cluster]
        if part.empty:
            profiles[cluster] = _neutral_profile(cluster, {})
            continue
        center = {name: float(part[name].median()) for name in feature_names}
        profiles[cluster] = _interpret_cluster(cluster, center, int(len(part)))
    return profiles


def _interpret_cluster(cluster: int, center: dict[str, float], count: int) -> dict[str, Any]:
    total_net = center.get("total_net", 0.0)
    large_net = center.get("large_net", 0.0)
    change_pct = center.get("change_pct", 0.0)
    flow_delta = center.get("flow_delta", 0.0)
    flow_drop = center.get("flow_drop_from_peak", 0.0)
    intraday_position = center.get("intraday_position", 0.5)
    price_to_avg_pct = center.get("price_to_avg_pct", 0.0)
    small_trade_ratio = center.get("small_trade_ratio", 0.0)
    repeated_second_ratio = center.get("repeated_second_ratio", 0.0)
    depth_imbalance = center.get("depth_imbalance", 0.0)

    programmatic = small_trade_ratio >= 0.6 or repeated_second_ratio >= 0.45
    evidence = [
        f"cluster samples={count}",
        f"median totalNet={total_net:.0f}, largeNet={large_net:.0f}",
        f"median change={change_pct:+.2f}%, intradayPosition={intraday_position:.2f}",
    ]
    if flow_drop < 0:
        evidence.append(f"flow drop from peak={flow_drop:.0f}")
    if depth_imbalance:
        evidence.append(f"depth imbalance={depth_imbalance:.2f}")

    if total_net > 0 and large_net > 0 and change_pct >= 0:
        state = "programmatic_accumulation" if programmatic else "accumulation"
        label = "程序化主力流入" if programmatic else "主力流入"
        return _profile(cluster, state, label, "bullish", "low", center, evidence)
    if total_net < 0 and large_net < 0:
        state = "programmatic_distribution" if programmatic else "distribution"
        label = "程序化减仓/压盘" if programmatic else "主力流出"
        return _profile(cluster, state, label, "bearish", "high", center, evidence)
    if total_net > 0 and large_net < 0:
        state = "programmatic_small_absorb" if programmatic else "small_absorb"
        label = "程序化小单承接大单流出" if programmatic else "小单承接大单流出"
        return _profile(cluster, state, label, "caution", "medium", center, evidence)
    if change_pct < 0 and total_net > 0:
        state = "programmatic_support" if programmatic else "support"
        label = "程序化护盘/低位承接" if programmatic else "护盘/低位承接"
        return _profile(cluster, state, label, "watch", "medium", center, evidence)
    if flow_delta < 0 or flow_drop < -3000 or price_to_avg_pct < -0.5:
        state = "programmatic_fading" if programmatic else "fading"
        label = "程序化资金转弱" if programmatic else "资金转弱"
        return _profile(cluster, state, label, "bearish", "medium", center, evidence)
    return _profile(cluster, "neutral", "资金结构中性", "neutral", "low", center, evidence)


def _profile(
    cluster: int,
    state: str,
    label: str,
    bias: str,
    risk_level: str,
    center: dict[str, float],
    evidence: list[str],
) -> dict[str, Any]:
    return {
        "cluster": cluster,
        "state": state,
        "label": label,
        "bias": bias,
        "risk_level": risk_level,
        "center": center,
        "evidence": evidence[:6],
    }


def _neutral_profile(cluster: int, center: dict[str, Any]) -> dict[str, Any]:
    return _profile(cluster, "neutral", "资金结构中性", "neutral", "low", {k: float(v or 0) for k, v in center.items()}, ["cluster is neutral"])


def _confidence_from_distances(distance: float, second: float) -> float:
    if second <= 0:
        return 0.5
    margin = max(0.0, second - distance)
    return max(0.35, min(0.98, 0.45 + margin / (second + 1e-9)))


def _num(row: dict[str, Any], *names: str) -> float | None:
    for name in names:
        value = row.get(name)
        if value in (None, ""):
            continue
        try:
            number = float(value)
        except (TypeError, ValueError):
            continue
        if np.isfinite(number):
            return number
    return None


def _clip(value: float | None, low: float, high: float, default: float) -> float:
    if value is None:
        return default
    return max(low, min(high, value))


def _dump_model(model: CapitalStructureModel, path: Path) -> None:
    try:
        import joblib  # type: ignore
    except ImportError:
        with path.open("wb") as handle:
            pickle.dump(model, handle)
        return
    joblib.dump(model, path)


def _load_model(path: Path) -> CapitalStructureModel:
    try:
        import joblib  # type: ignore
    except ImportError:
        with path.open("rb") as handle:
            return pickle.load(handle)
    return joblib.load(path)

from __future__ import annotations

import threading
import time
import os
from datetime import datetime, timezone
from typing import Any

from longbridge_stock import clickhouse_realtime


DATASET_LABELS = {
    "profile": "基础档案",
    "daily_bar": "日K数据",
    "realtime_quote": "实时行情",
    "capital_distribution": "资金分布",
    "capital_flow": "资金流分时",
    "intraday_line": "分时走势",
    "trade_tick": "逐笔成交",
    "order_book_depth": "盘口深度",
    "market_temperature": "市场温度",
    "model_feature": "模型特征",
    "limit_up": "涨停数据",
    "company_profile": "公司资料",
}

MARKET_LABELS = {"cn": "A股", "hk": "港股", "us": "美股"}


_OVERVIEW_CACHE: dict[str, Any] = {"expires_at": 0.0, "data": None}
_OVERVIEW_CACHE_LOCK = threading.Lock()
_OVERVIEW_CACHE_SECONDS = 15.0

IGNORED_REALTIME_SYMBOLS = {
    "174.HK",
    "1741.HK",
    "1762.HK",
    "1766.HK",
    "2457.HK",
    "4332.HK",
    "4333.HK",
    "4336.HK",
    "4337.HK",
    "4338.HK",
}

ALL_MARKET_DATASETS = {
    "profile",
    "daily_bar",
    "realtime_quote",
    "capital_distribution",
    "capital_flow",
    "intraday_line",
    "model_feature",
    "limit_up",
    "company_profile",
}


def fetch_sync_overview(dsn: str) -> dict[str, Any]:
    now_ts = time.monotonic()
    cached = _OVERVIEW_CACHE.get("data")
    if cached is not None and now_ts < float(_OVERVIEW_CACHE.get("expires_at") or 0):
        return cached
    if not _OVERVIEW_CACHE_LOCK.acquire(blocking=False):
        if cached is not None:
            return cached
        with _OVERVIEW_CACHE_LOCK:
            cached = _OVERVIEW_CACHE.get("data")
            if cached is not None:
                return cached
            return _fetch_sync_overview_uncached(dsn)
    else:
        try:
            return _fetch_sync_overview_uncached(dsn)
        finally:
            _OVERVIEW_CACHE_LOCK.release()


def _fetch_sync_overview_uncached(dsn: str) -> dict[str, Any]:
    psycopg = _load_psycopg()
    try:
        with psycopg.connect(dsn) as conn:
            overview = _fetch_monitor_overview(conn)
            _OVERVIEW_CACHE["data"] = overview
            _OVERVIEW_CACHE["expires_at"] = time.monotonic() + _OVERVIEW_CACHE_SECONDS
            return overview
    except Exception as exc:
        fallback = _OVERVIEW_CACHE.get("data") or _fallback_overview(error=str(exc))
        _OVERVIEW_CACHE["data"] = fallback
        _OVERVIEW_CACHE["expires_at"] = time.monotonic() + 3.0
        return fallback


def _fetch_monitor_overview(conn: Any) -> dict[str, Any]:
    now = _now_iso()
    markets = _market_rows(conn)
    task_summary = _task_summary(conn)
    return {
        "updatedAt": now,
        "overall": _overall_summary(markets, task_summary),
        "markets": markets,
        "taskPipeline": _task_pipeline(conn, task_summary),
        "tasks": _tasks(conn),
        "gapPriority": _gap_priority(conn, markets),
        "logs": _logs(conn),
    }


def _market_rows(conn: Any) -> list[dict[str, Any]]:
    status_rows = _try_query(
        conn,
        """
        select distinct on (market, dataset_key)
               market, dataset_key, expected_count, collected_count, fresh_count, latest_data_at
        from lb_monitor.dataset_coverage
        order by market, dataset_key, snapshot_at desc
        """,
    )
    if status_rows:
        markets = _apply_market_expected_overrides(conn, _markets_from_monitor(status_rows))
        return _apply_running_capital_progress(conn, markets)

    monitor_rows = _try_query(
        conn,
        """
        select distinct on (market, dataset_key)
               market, dataset_key, expected_count, collected_count, fresh_count, latest_data_at
        from lb_monitor.dataset_coverage
        order by market, dataset_key, snapshot_at desc
        """,
    )
    if monitor_rows:
        markets = _apply_market_expected_overrides(conn, _markets_from_monitor(monitor_rows))
        return _apply_running_capital_progress(conn, markets)

    universe = _count_by_market(conn, _symbol_universe_count_sql())
    daily = _count_by_market(conn, "select lower(market) as market, count(distinct symbol) as count from lb_daily_bars group by lower(market)")
    quotes = _ch_today_symbol_counts("lb_realtime_quotes", "snapshot_minute")
    capital = _ch_today_symbol_counts("lb_realtime_capital", "snapshot_minute")
    capital_flow = _ch_today_symbol_counts("lb_realtime_capital_flow", "flow_time")
    scores = _count_by_market(
        conn,
        """
        select lower(market) as market, count(distinct symbol) as count
        from lb_stock_scores
        where score_date = (select max(score_date) from lb_stock_scores)
        group by lower(market)
        """,
    )
    profiles = _count_by_market(
        conn,
        """
        select lower(sym.market) as market, count(distinct p.symbol) as count
        from lb_company_profiles p
        left join lb_symbols sym on sym.symbol = p.symbol
        group by lower(sym.market)
        """,
    )
    limit_up = _count_by_market(
        conn,
        """
        select 'cn' as market, count(distinct symbol) as count
        from lb_limit_up_predictions
        where event_date = ((now() at time zone 'Asia/Shanghai')::date - 1)
        """,
    )
    markets = []
    for market in ["cn", "hk", "us"]:
        expected = int(universe.get(market, 0) or 0)
        dataset_counts = {
            "profile": universe.get(market, 0),
            "daily_bar": daily.get(market, 0),
            "realtime_quote": quotes.get(market, 0),
            "capital_distribution": capital.get(market, 0),
            "capital_flow": capital_flow.get(market, 0),
            "model_feature": scores.get(market, 0),
            "limit_up" if market == "cn" else "company_profile": limit_up.get(market, 0) if market == "cn" else profiles.get(market, 0),
        }
        datasets = [_dataset_payload(key, value, expected) for key, value in dataset_counts.items()]
        markets.append(_market_payload(market, expected, datasets))
    return markets


def _markets_from_monitor(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        market = str(row.get("market") or "").lower()
        grouped.setdefault(market, []).append(
            _dataset_payload(
                str(row.get("dataset_key") or ""),
                int(row.get("collected_count") or 0),
                int(row.get("expected_count") or 0),
                int(row.get("fresh_count") or 0),
                row.get("latest_data_at"),
            )
        )
    return [_market_payload(market, max((item["expected"] for item in items), default=0), items) for market, items in grouped.items()]


def _apply_market_expected_overrides(conn: Any, markets: list[dict[str, Any]]) -> list[dict[str, Any]]:
    universe = _count_by_market(conn, _symbol_universe_count_sql())
    for market_row in markets:
        market = str(market_row.get("market") or "").lower()
        expected = int(universe.get(market, 0) or 0)
        if expected <= 0:
            continue
        datasets = []
        for dataset in market_row.get("datasets", []):
            item = dict(dataset)
            key = str(item.get("key") or "")
            if key not in ALL_MARKET_DATASETS:
                datasets.append(item)
                continue
            item["expected"] = expected
            collected = min(int(item.get("collected") or 0), expected)
            item["collected"] = collected
            item["fresh"] = min(int(item.get("fresh") or collected), expected)
            item["progress"] = round(min(max(collected / expected, 0), 1), 4)
            datasets.append(item)
        market_row.update(_market_payload(market, expected, datasets))
    return markets


def _apply_live_dataset_overrides(conn: Any, markets: list[dict[str, Any]]) -> list[dict[str, Any]]:
    count_overrides: dict[str, dict[str, int]] = {
        "profile": _count_by_market(conn, _symbol_universe_count_sql()),
    }
    latest_overrides: dict[str, dict[str, dict[str, Any]]] = {
        "daily_bar": _daily_bar_freshness_by_market(conn, ["cn", "hk", "us"]),
        "realtime_quote": _ch_latest_counts_by_market("lb_realtime_quotes", "snapshot_minute"),
        "capital_distribution": _ch_latest_counts_by_market("lb_realtime_capital", "snapshot_minute"),
        "capital_flow": _ch_latest_counts_by_market("lb_realtime_capital_flow", "flow_time"),
        "intraday_line": _ch_latest_counts_by_market("lb_intraday_lines", "line_time"),
    }
    for market_row in markets:
        market = str(market_row.get("market") or "").lower()
        expected = int(market_row.get("expected") or 0)
        changed = False
        for dataset in market_row.get("datasets", []):
            key = str(dataset.get("key") or "")
            if key in count_overrides and market in count_overrides[key]:
                collected = min(int(count_overrides[key].get(market) or 0), expected)
                dataset["collected"] = collected
                dataset["fresh"] = collected
                dataset["progress"] = round(min(max(collected / expected if expected else 0, 0), 1), 4)
                changed = True
            latest = latest_overrides.get(key, {}).get(market)
            if latest:
                collected = min(int(latest.get("collected") or 0), expected)
                dataset["collected"] = collected
                dataset["fresh"] = collected
                dataset["latestDataAt"] = _iso(latest.get("latest"))
                dataset["progress"] = round(min(max(collected / expected if expected else 0, 0), 1), 4)
                changed = True
        if changed:
            market_row.update(_market_payload(market, expected, market_row.get("datasets", [])))
    return markets


def _apply_running_capital_progress(conn: Any, markets: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows = _try_query(
        conn,
        """
        select task_key, status, rows_written, last_write_at, heartbeat_at, runtime
        from lb_monitor.task_heartbeats
        where task_key in (
          'realtime_capital_priority',
          'capital_flow_delayed',
          'realtime_capital_hk_full',
          'realtime_capital_us_full',
          'realtime_capital_us',
          'realtime_intraday_cn_full',
          'realtime_intraday_hk_full',
          'realtime_intraday_us_full'
        )
        """,
    )
    if not rows:
        return markets
    updates: dict[tuple[str, str], dict[str, Any]] = {}
    for row in rows:
        task_key = str(row.get("task_key") or "")
        status = str(row.get("status") or "").lower()
        if status != "running":
            continue
        runtime = row.get("runtime") if isinstance(row.get("runtime"), dict) else {}
        input_by_market = runtime.get("input_by_market") if isinstance(runtime.get("input_by_market"), dict) else {}
        rows_written = int(row.get("rows_written") or 0)
        latest = row.get("last_write_at") or row.get("heartbeat_at")
        if task_key == "realtime_capital_priority":
            for market in input_by_market or {"cn": rows_written}:
                updates[(str(market).lower(), "capital_distribution")] = {
                    "collected": rows_written,
                    "expected": int(input_by_market.get(market) or 0),
                    "latest": latest,
                }
        elif task_key == "capital_flow_delayed":
            for market in input_by_market or {"cn": rows_written}:
                updates[(str(market).lower(), "capital_flow")] = {
                    "collected": rows_written,
                    "expected": int(input_by_market.get(market) or 0),
                    "latest": latest,
                }
        elif task_key == "realtime_capital_hk_full":
            for dataset_key in ("capital_distribution", "capital_flow"):
                updates[("hk", dataset_key)] = {
                    "collected": rows_written,
                    "expected": int(input_by_market.get("hk") or 0),
                    "latest": latest,
                }
        elif task_key == "realtime_capital_us_full":
            for dataset_key in ("capital_distribution", "capital_flow"):
                updates[("us", dataset_key)] = {
                    "collected": rows_written,
                    "expected": int(input_by_market.get("us") or 0),
                    "latest": latest,
                }
        elif task_key == "realtime_capital_us":
            updates[("us", "capital_distribution")] = {
                "collected": rows_written,
                "expected": int(input_by_market.get("us") or 0),
                "latest": latest,
            }
        elif task_key == "realtime_intraday_cn_full":
            updates[("cn", "intraday_line")] = {
                "collected": rows_written,
                "expected": int(input_by_market.get("cn") or 0),
                "latest": latest,
            }
        elif task_key == "realtime_intraday_hk_full":
            updates[("hk", "intraday_line")] = {
                "collected": rows_written,
                "expected": int(input_by_market.get("hk") or 0),
                "latest": latest,
            }
        elif task_key == "realtime_intraday_us_full":
            updates[("us", "intraday_line")] = {
                "collected": rows_written,
                "expected": int(input_by_market.get("us") or 0),
                "latest": latest,
            }

    markets_by_key = {str(item.get("market") or "").lower(): item for item in markets}
    for (market, _dataset_key), update in updates.items():
        if market not in markets_by_key:
            expected = int(update.get("expected") or 0)
            markets_by_key[market] = _market_payload(market, expected, [])
            markets.append(markets_by_key[market])

    for market_row in markets:
        market = str(market_row.get("market") or "").lower()
        expected = int(market_row.get("expected") or 0)
        for (update_market, dataset_key), update in updates.items():
            if update_market != market:
                continue
            if any(str(item.get("key") or "") == dataset_key for item in market_row.get("datasets", [])):
                continue
            dataset_expected = expected or int(update.get("expected") or 0)
            if dataset_expected > expected:
                expected = dataset_expected
                market_row["expected"] = expected
            market_row.setdefault("datasets", []).append(_dataset_payload(dataset_key, 0, dataset_expected))
        changed = False
        for dataset in market_row.get("datasets", []):
            key = str(dataset.get("key") or "")
            update = updates.get((market, key))
            if not update:
                continue
            dataset_expected = expected or int(update.get("expected") or 0)
            current_collected = int(update.get("collected") or 0)
            coverage_collected = int(dataset.get("collected") or 0)
            if dataset_expected > expected:
                expected = dataset_expected
                market_row["expected"] = expected
            dataset["expected"] = expected
            current_collected = min(current_collected, expected)
            coverage_collected = min(coverage_collected, expected)
            dataset["collected"] = coverage_collected
            dataset["fresh"] = coverage_collected
            dataset["latestDataAt"] = _iso(update.get("latest"))
            dataset["progress"] = round(min(max(coverage_collected / expected if expected else 0, 0), 1), 4)
            dataset["currentRun"] = {
                "collected": current_collected,
                "expected": expected,
                "remaining": max(expected - current_collected, 0),
                "progress": round(min(max(current_collected / expected if expected else 0, 0), 1), 4),
                "latestDataAt": _iso(update.get("latest")),
            }
            changed = True
        if changed:
            market_row.update(_market_payload(market, expected, market_row.get("datasets", [])))
    return markets


def _latest_counts_by_market(conn: Any, table: str, time_column: str) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    ignored_sql = _ignored_symbols_sql()
    for market in ["cn", "hk", "us"]:
        rows = _try_query(
            conn,
            f"""
            with latest as (
              select {time_column} as latest_at
              from {table}
              where market = '{market}'
              order by {time_column} desc
              limit 1
            )
            select latest.latest_at, count(distinct t.symbol) as collected
            from latest
            left join {table} t
              on t.market = '{market}'
             and t.{time_column} = latest.latest_at
             and t.symbol not in ({ignored_sql})
            group by latest.latest_at
            """,
        )
        if rows and rows[0].get("latest_at") is not None:
            result[market] = {
                "latest": rows[0].get("latest_at"),
                "collected": int(rows[0].get("collected") or 0),
            }
    return result


def _symbol_presence_by_market(
    conn: Any,
    table: str,
    time_column: str,
    markets: list[str],
) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    safe_markets = [market.lower() for market in markets if market and market.isalpha()]
    if not safe_markets:
        return result
    market_sql = ", ".join(f"'{market}'" for market in safe_markets)
    rows = _try_query(
        conn,
        f"""
        select symbols.market as market,
               count(*) as collected,
               (
                 select max(latest.{time_column})
                 from {table} latest
                 where latest.market = symbols.market
               ) as latest
        from lb_symbols symbols
        where symbols.market in ({market_sql})
          and symbols.symbol not in ({_ignored_symbols_sql()})
          and exists (
            select 1
            from {table} data
            where data.market = symbols.market
              and data.symbol = symbols.symbol
          )
        group by symbols.market
        """,
    )
    for row in rows:
        market = str(row.get("market") or "").lower()
        if market:
            result[market] = {
                "latest": row.get("latest"),
                "collected": int(row.get("collected") or 0),
            }
    return result


def _intraday_line_freshness_by_market(conn: Any, markets: list[str]) -> dict[str, dict[str, Any]]:
    return {market: row for market, row in _ch_latest_counts_by_market("lb_intraday_lines", "line_time").items() if market in markets}


def _ch_today_symbol_counts(table: str, time_column: str) -> dict[str, int]:
    database = _ch_database()
    rows = _ch_query_json_each_row(
        f"""
        select market, countDistinct(symbol) as count
        from {database}.{table}
        where {time_column} >= toStartOfDay(now('Asia/Shanghai'))
          and {time_column} < toStartOfDay(now('Asia/Shanghai')) + interval 1 day
        group by market
        """
    )
    return {str(row.get("market") or "").lower(): int(row.get("count") or 0) for row in rows}


def _ch_latest_counts_by_market(table: str, time_column: str) -> dict[str, dict[str, Any]]:
    database = _ch_database()
    rows = _ch_query_json_each_row(
        f"""
        with latest_by_market as (
          select market, max({time_column}) as latest
          from {database}.{table}
          group by market
        )
        select l.market, l.latest, countDistinct(t.symbol) as collected
        from latest_by_market l
        left join {database}.{table} t
          on t.market = l.market
         and t.{time_column} >= l.latest - interval 30 minute
         and t.{time_column} <= l.latest
        group by l.market, l.latest
        """
    )
    return {
        str(row.get("market") or "").lower(): {
            "latest": row.get("latest"),
            "collected": int(row.get("collected") or 0),
        }
        for row in rows
        if row.get("market")
    }


def _ch_latest_timestamp(table: str, time_column: str, market: str) -> Any:
    database = _ch_database()
    rows = _ch_query_json_each_row(
        f"""
        select max({time_column}) as latest
        from {database}.{table}
        where market = '{market.lower()}'
        """
    )
    return rows[0].get("latest") if rows else None


def _ch_latest_symbol_count(table: str, time_column: str, markets: list[str], count_symbols: bool = True) -> dict[str, Any] | None:
    safe_markets = [market.lower() for market in markets if market and market.isalpha()]
    if not safe_markets:
        return None
    database = _ch_database()
    market_sql = ", ".join(f"'{market}'" for market in safe_markets)
    count_expr = "countDistinct(symbol)" if count_symbols else "count()"
    rows = _ch_query_json_each_row(
        f"""
        with latest as (
          select max({time_column}) as latest
          from {database}.{table}
          where market in ({market_sql})
        )
        select latest.latest as latest, {count_expr} as collected
        from {database}.{table}, latest
        where market in ({market_sql})
          and {time_column} >= latest.latest - interval 30 minute
          and {time_column} <= latest.latest
        group by latest.latest
        """
    )
    if not rows:
        return None
    row = rows[0]
    latest = row.get("latest")
    collected = int(row.get("collected") or 0)
    return {
        "latest": latest,
        "last_write_at": latest,
        "lag_seconds": _seconds_since(latest),
        "rows_written": collected,
        "status": "running" if collected else "pending",
        "error": "",
    }


def _ch_query_json_each_row(sql: str) -> list[dict[str, Any]]:
    previous_timeout = os.environ.get("CLICKHOUSE_READ_TIMEOUT_SECONDS")
    os.environ["CLICKHOUSE_READ_TIMEOUT_SECONDS"] = os.getenv("SYNC_MONITOR_CLICKHOUSE_TIMEOUT_SECONDS", "1.2")
    try:
        return clickhouse_realtime._query_json_each_row(sql)
    except Exception:
        return []
    finally:
        if previous_timeout is None:
            os.environ.pop("CLICKHOUSE_READ_TIMEOUT_SECONDS", None)
        else:
            os.environ["CLICKHOUSE_READ_TIMEOUT_SECONDS"] = previous_timeout


def _ch_database() -> str:
    value = clickhouse_realtime._database()
    return value if value.replace("_", "").isalnum() else "longbridge"


def _daily_bar_freshness_by_market(conn: Any, markets: list[str]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    ignored_sql = _ignored_symbols_sql()
    for market in [item.lower() for item in markets if item and item.isalpha()]:
        rows = _try_query(
            conn,
            f"""
            with target as (
              select max(trade_date) as trade_date
              from lb_daily_bars
              where market = '{market}'
            )
            select target.trade_date as latest,
                   count(distinct bars.symbol) as collected
            from target
            left join lb_daily_bars bars
              on bars.market = '{market}'
             and bars.trade_date = target.trade_date
             and bars.symbol not in ({ignored_sql})
            group by target.trade_date
            """,
        )
        if rows and rows[0].get("latest") is not None:
            result[market] = {
                "latest": rows[0].get("latest"),
                "collected": int(rows[0].get("collected") or 0),
            }
    return result


def _ignored_symbols_sql() -> str:
    return ", ".join(f"'{symbol}'" for symbol in sorted(IGNORED_REALTIME_SYMBOLS))


def _symbol_universe_count_sql() -> str:
    return f"""
        select lower(market) as market, count(*) as count
        from lb_symbols
        where symbol not in ({_ignored_symbols_sql()})
        group by lower(market)
    """


def _apply_hk_runtime_overrides(conn: Any, markets: list[dict[str, Any]]) -> list[dict[str, Any]]:
    overrides = {
        "capital_distribution": _ch_latest_counts_by_market("lb_realtime_capital", "snapshot_minute").get("hk"),
        "capital_flow": _ch_latest_counts_by_market("lb_realtime_capital_flow", "flow_time").get("hk"),
    }
    hk_market = next((item for item in markets if item.get("market") == "hk"), None)
    if not hk_market:
        return markets
    changed = False
    for dataset in hk_market.get("datasets", []):
        override = overrides.get(str(dataset.get("key") or ""))
        if not override:
            continue
        dataset["collected"] = override["collected"]
        dataset["fresh"] = override["collected"]
        dataset["latestDataAt"] = _iso(override["latest"])
        expected = int(dataset.get("expected") or 0)
        dataset["progress"] = round(min(max(override["collected"] / expected if expected else 0, 0), 1), 4)
        changed = True
    if changed:
        hk_market.update(_market_payload("hk", int(hk_market.get("expected") or 0), hk_market.get("datasets", [])))
    return markets


def _market_payload(market: str, expected: int, datasets: list[dict[str, Any]]) -> dict[str, Any]:
    usable = [item for item in datasets if item["expected"] > 0]
    progress = sum(item["progress"] for item in usable) / len(usable) if usable else 0
    collected = min(max((item["collected"] for item in datasets), default=0), expected) if expected else 0
    return {
        "market": market,
        "label": MARKET_LABELS.get(market, market.upper()),
        "expected": expected,
        "collected": collected,
        "progress": round(progress, 4),
        "datasets": datasets,
    }


def _dataset_payload(key: str, collected: int, expected: int, fresh: int | None = None, latest: Any = None) -> dict[str, Any]:
    progress = (collected / expected) if expected else 0
    return {
        "key": key,
        "label": DATASET_LABELS.get(key, key),
        "expected": expected,
        "collected": collected,
        "fresh": fresh if fresh is not None else collected,
        "progress": round(min(max(progress, 0), 1), 4),
        "latestDataAt": _iso(latest),
    }


def _task_summary(conn: Any) -> dict[str, int]:
    rows = _try_query(
        conn,
        """
        select
          count(*) as total,
          count(*) filter (where h.status in ('running','collecting','writing')) as running,
          count(*) filter (where h.status in ('ok','success','running','collecting','writing')) as normal,
          count(*) filter (where h.status in ('error','failed','limited','stale')) as failed
        from lb_monitor.sync_tasks t
        left join lb_monitor.task_heartbeats h on h.task_key = t.task_key
        where t.enabled
        """,
    )
    if rows:
        row = rows[0]
        return {key: int(row.get(key) or 0) for key in ["total", "running", "normal", "failed"]}
    return {"total": 16, "running": 5, "normal": 14, "failed": 2}


def _task_pipeline(conn: Any, summary: dict[str, int]) -> dict[str, Any]:
    total = max(summary.get("total", 0), 1)
    running = summary.get("running", 0)
    failed = summary.get("failed", 0)
    success = summary.get("normal", 0)
    pending = max(total - running - success - failed, 0)
    stages = [
        {"key": "pending", "label": "待执行", "count": pending, "progress": pending / total},
        {"key": "running", "label": "执行中", "count": running, "progress": running / total},
        {"key": "success", "label": "本轮成功", "count": success, "progress": success / total},
        {"key": "failed", "label": "失败", "count": failed, "progress": failed / total},
    ]
    return {
        "total": total,
        "running": running,
        "normal": success,
        "failed": failed,
        "normalRate": success / total,
        "runningRate": running / total,
        "stages": stages,
    }


def _tasks(conn: Any) -> list[dict[str, Any]]:
    rows = _try_query(
        conn,
        """
        select
          t.task_key,
          t.task_name,
          t.task_group,
          t.priority,
          t.dataset_scope,
          t.schedule_text,
          t.expected_interval_seconds,
          t.owner_service,
          coalesce(h.status, 'unknown') as status,
          h.heartbeat_at,
          h.last_write_at,
          h.rows_written,
          h.rows_failed,
          h.retry_count,
          h.queue_depth,
          h.lag_seconds,
          h.latest_error_code,
          h.latest_error_message
        from lb_monitor.sync_tasks t
        left join lb_monitor.task_heartbeats h on h.task_key = t.task_key
        where t.enabled
        order by
          case t.priority when 'P0' then 0 when 'P1' then 1 when 'P2' then 2 else 9 end,
          t.task_key
        """,
    )
    if rows:
        tasks = [_task_payload(row) for row in rows]
        live_metrics = _live_task_metrics(conn)
        if live_metrics:
            tasks = [_merge_live_task_metrics(task, live_metrics.get(task.get("taskKey"))) for task in tasks]
        hk_task = _hk_full_capital_task(conn)
        if hk_task and not any(task.get("taskKey") == hk_task.get("taskKey") for task in tasks):
            tasks.append(hk_task)
        us_task = _us_full_capital_task(conn)
        if us_task and not any(task.get("taskKey") == us_task.get("taskKey") for task in tasks):
            tasks.append(us_task)
        return tasks
    return [
        {
            "taskKey": "realtime_quotes_priority",
            "taskName": "实时行情优先池",
            "dataset": "lb_realtime_quotes",
            "status": "running",
            "statusLabel": "运行中",
            "priority": "P0 模型池",
            "frequency": "60秒",
            "lastWrite": "09:48:00",
            "lag": "0m",
            "action": "查看",
            "tone": "green",
        },
        {
            "taskKey": "realtime_capital_priority",
            "taskName": "资金分布优先池",
            "dataset": "lb_realtime_capital",
            "status": "running",
            "statusLabel": "运行中",
            "priority": "P0 自选股",
            "frequency": "180秒",
            "lastWrite": "09:47:10",
            "lag": "1m",
            "action": "查看",
            "tone": "green",
        },
    ]


def _hk_full_capital_task(conn: Any) -> dict[str, Any] | None:
    rows = _try_query(
        conn,
        """
        select
          max(collected_count) filter (where dataset_key = 'capital_distribution') as cap_symbols,
          max(collected_count) filter (where dataset_key = 'capital_flow') as flow_symbols,
          coalesce(max(expected_count), 2776) as expected_count
        from lb_monitor.dataset_coverage
        where market = 'hk'
          and dataset_key in ('capital_distribution', 'capital_flow')
        """,
    )
    if not rows:
        return None
    row = rows[0]
    cap_latest = _ch_latest_timestamp("lb_realtime_capital", "snapshot_minute", "hk")
    flow_latest = _ch_latest_timestamp("lb_realtime_capital_flow", "flow_time", "hk")
    latest = _latest_datetime(cap_latest, flow_latest)
    cap_symbols = int(row.get("cap_symbols") or 0)
    flow_symbols = int(row.get("flow_symbols") or 0)
    if not latest and cap_symbols == 0 and flow_symbols == 0:
        return None
    lag_seconds = _seconds_since(latest)
    status = "running" if cap_symbols else "pending"
    expected = int(row.get("expected_count") or 2776)
    return {
        "taskKey": "realtime_capital_hk_full",
        "taskName": "港股全量资金+分时",
        "dataset": "capital_distribution, capital_flow",
        "status": status,
        "statusLabel": _task_status_label(status),
        "priority": "P1 全量港股",
        "frequency": "3600秒",
        "lastWrite": _time(latest),
        "lag": _lag_label(lag_seconds),
        "action": "查看",
        "tone": _task_tone(status),
        "rowsWritten": cap_symbols + flow_symbols,
        "rowsFailed": 0,
        "retryCount": 0,
        "queueDepth": max(expected - min(cap_symbols, flow_symbols or 0), 0),
        "ownerService": "sync-realtime-capital",
        "error": "" if flow_symbols else "资金流分时等待首轮写入",
    }


def _us_full_capital_task(conn: Any) -> dict[str, Any] | None:
    rows = _try_query(
        conn,
        """
        select
          max(collected_count) filter (where dataset_key = 'capital_distribution') as cap_symbols,
          max(collected_count) filter (where dataset_key = 'capital_flow') as flow_symbols,
          coalesce(max(expected_count), 2007) as expected_count
        from lb_monitor.dataset_coverage
        where market = 'us'
          and dataset_key in ('capital_distribution', 'capital_flow')
        """,
    )
    if not rows:
        return None
    row = rows[0]
    cap_latest = _ch_latest_timestamp("lb_realtime_capital", "snapshot_minute", "us")
    flow_latest = _ch_latest_timestamp("lb_realtime_capital_flow", "flow_time", "us")
    latest = _latest_datetime(cap_latest, flow_latest)
    cap_symbols = int(row.get("cap_symbols") or 0)
    flow_symbols = int(row.get("flow_symbols") or 0)
    if not latest and cap_symbols == 0 and flow_symbols == 0:
        return None
    lag_seconds = _seconds_since(latest)
    status = "running" if cap_symbols else "pending"
    expected = int(row.get("expected_count") or 2007)
    return {
        "taskKey": "realtime_capital_us_full",
        "taskName": "美股资金全量采集",
        "dataset": "capital_distribution, capital_flow",
        "status": status,
        "statusLabel": _task_status_label(status),
        "priority": "P1 全量美股",
        "frequency": "3600秒",
        "lastWrite": _time(latest),
        "lag": _lag_label(lag_seconds),
        "action": "查看",
        "tone": _task_tone(status),
        "rowsWritten": cap_symbols + flow_symbols,
        "rowsFailed": 0,
        "retryCount": 0,
        "queueDepth": max(expected - min(cap_symbols, flow_symbols or 0), 0),
        "ownerService": "sync-realtime-capital",
        "error": "" if flow_symbols else "资金流分时等待首轮写入",
    }


def _live_task_metrics(conn: Any) -> dict[str, dict[str, Any]]:
    metrics: dict[str, dict[str, Any]] = {}
    def safe_latest(table: str, time_column: str, markets: list[str], count_symbols: bool = True) -> dict[str, Any] | None:
        try:
            return _ch_latest_symbol_count(table, time_column, markets, count_symbols=count_symbols)
        except Exception:
            return None

    quotes = safe_latest("lb_realtime_quotes", "snapshot_minute", ["cn", "hk"])
    if quotes:
        metrics["realtime_quotes_priority"] = quotes
    capital = safe_latest("lb_realtime_capital", "snapshot_minute", ["cn"])
    if capital:
        metrics["realtime_capital_priority"] = capital
    flow = safe_latest("lb_realtime_capital_flow", "flow_time", ["cn"], count_symbols=False)
    if flow:
        metrics["capital_flow_delayed"] = flow
    us_capital = safe_latest("lb_realtime_capital", "snapshot_minute", ["us"])
    if us_capital:
        metrics["realtime_capital_us"] = us_capital
        metrics["realtime_capital_us_full"] = us_capital
    return metrics


def _merge_live_task_metrics(task: dict[str, Any], metrics: dict[str, Any] | None) -> dict[str, Any]:
    if not metrics:
        return task
    merged = dict(task)
    latest_at = metrics.get("last_write_at")
    heartbeat_at = task.get("heartbeatAtRaw")
    latest_dt = _parse_datetime(latest_at)
    heartbeat_dt = _parse_datetime(heartbeat_at)
    current_rows = int(task.get("rowsWritten") or 0)
    metric_rows = int(metrics.get("rows_written") or 0) if metrics.get("rows_written") is not None else None
    is_partial_snapshot = metric_rows is not None and current_rows > 0 and metric_rows < current_rows
    is_newer = latest_dt is not None and (heartbeat_dt is None or latest_dt >= heartbeat_dt)
    if latest_at is not None and not is_partial_snapshot and is_newer:
        merged["lastWrite"] = _time(latest_at)
        merged["lag"] = _lag_label(metrics.get("lag_seconds"))
    if metric_rows is not None and not is_partial_snapshot:
        merged["rowsWritten"] = metric_rows
    return merged


def _latest_datetime(*values: Any) -> Any:
    candidates = [value for value in values if value is not None]
    if not candidates:
        return None
    return max(candidates, key=lambda value: _parse_datetime(value) or datetime.min.replace(tzinfo=timezone.utc))


def _task_payload(row: dict[str, Any]) -> dict[str, Any]:
    status = str(row.get("status") or "unknown").lower()
    task_key = str(row.get("task_key") or "")
    priority = str(row.get("priority") or "")
    dataset_scope = row.get("dataset_scope") or []
    dataset = dataset_scope[0] if isinstance(dataset_scope, list) and dataset_scope else _dataset_from_task_key(task_key)
    lag_seconds = row.get("lag_seconds")
    error = row.get("latest_error_message") or row.get("latest_error_code") or ""
    heartbeat_at = row.get("heartbeat_at")
    display_time = heartbeat_at if status in {"running", "collecting", "writing"} else row.get("last_write_at") or heartbeat_at
    return {
        "taskKey": task_key,
        "taskName": _task_name(task_key),
        "dataset": dataset,
        "status": status,
        "statusLabel": _task_status_label(status),
        "priority": _task_priority_label(priority, task_key),
        "frequency": _frequency_label(row.get("expected_interval_seconds"), row.get("schedule_text")),
        "lastWrite": _time(display_time),
        "lastWriteAtRaw": display_time,
        "heartbeatAtRaw": heartbeat_at,
        "lag": _lag_label(lag_seconds),
        "action": _task_action_label(status, task_key),
        "tone": _task_tone(status),
        "rowsWritten": int(row.get("rows_written") or 0),
        "rowsFailed": int(row.get("rows_failed") or 0),
        "retryCount": int(row.get("retry_count") or 0),
        "queueDepth": int(row.get("queue_depth") or 0),
        "ownerService": str(row.get("owner_service") or ""),
        "error": str(error),
    }


def _dataset_from_task_key(task_key: str) -> str:
    if "quote" in task_key:
        return "lb_realtime_quotes"
    if "intraday" in task_key:
        return "lb_intraday_lines"
    if "capital_flow" in task_key:
        return "lb_realtime_capital_flow"
    if "capital" in task_key:
        return "lb_realtime_capital"
    if "kline" in task_key:
        return "lb_daily_bars"
    if "limit" in task_key:
        return "limit_up_event"
    return task_key


def _task_status_label(status: str) -> str:
    return {
        "running": "运行中",
        "collecting": "运行中",
        "writing": "运行中",
        "ok": "完成",
        "success": "完成",
        "limited": "限流",
        "stale": "延迟",
        "queued": "排队",
        "pending": "排队",
        "outside_trading_time": "\u975e\u4ea4\u6613\u65f6\u6bb5",
        "error": "异常",
        "failed": "异常",
    }.get(status, "未知")


def _task_tone(status: str) -> str:
    if status in {"running", "collecting", "writing", "ok", "success"}:
        return "green"
    if status in {"queued", "pending", "stale"}:
        return "amber"
    if status in {"error", "failed", "limited"}:
        return "red"
    return "blue"


def _task_priority_label(priority: str, task_key: str) -> str:
    if priority == "P0" and "capital" in task_key:
        return "P0 自选股"
    if priority == "P0":
        return "P0 模型池"
    if priority == "P1" and "flow" in task_key:
        return "P1 延时"
    if priority == "P1" and "limit" in task_key:
        return "P1 模型"
    if priority == "P1":
        return "P1 补充"
    if priority == "P2":
        return "P2 慢任务"
    return priority or "-"


def _task_action_label(status: str, task_key: str) -> str:
    if status in {"limited", "error", "failed"}:
        return "恢复"
    if status in {"queued", "pending", "stale"}:
        return "加速"
    if "limit" in task_key:
        return "重跑"
    return "查看"


def _frequency_label(interval: Any, schedule: Any) -> str:
    seconds = int(interval or 0)
    if seconds:
        if seconds < 3600:
            return f"{seconds}秒"
        return "收盘后" if seconds >= 86400 else f"{seconds // 3600}小时"
    return str(schedule or "-")


def _lag_label(seconds: Any) -> str:
    if seconds is None:
        return "-"
    seconds = int(seconds or 0)
    if seconds < 60:
        return "0m"
    if seconds < 86400:
        return f"{seconds // 60}m"
    return f"{seconds // 86400}d"


def _seconds_since(value: Any) -> int | None:
    parsed = _parse_datetime(value)
    if parsed is None:
        return None
    try:
        current = datetime.now(parsed.tzinfo) if parsed.tzinfo else datetime.now()
        return max(0, int((current - parsed).total_seconds()))
    except Exception:
        return None
    return None


def _parse_datetime(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    text = str(value).strip()
    if not text:
        return None
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
    except ValueError:
        pass
    for fmt in ("%Y-%m-%d %H:%M:%S%z", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            parsed = datetime.strptime(text, fmt)
            return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return None


def _gap_priority(conn: Any, markets: list[dict[str, Any]]) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for market in markets:
        for dataset in market["datasets"]:
            if dataset["progress"] < 0.85:
                items.append(
                    {
                        "market": market["market"],
                        "label": f"{market['label']}{dataset['label']}",
                        "progress": dataset["progress"],
                    }
                )
    return sorted(items, key=lambda item: item["progress"])[:4]


def _logs(conn: Any) -> list[dict[str, Any]]:
    task_rows = _task_activity_logs(conn)
    if task_rows:
        return task_rows
    rows = _try_query(
        conn,
        """
        select event_at, severity, coalesce(task_key, '-') as task_key, message
        from lb_monitor.sync_task_events
        order by event_at desc
        limit 20
        """,
    )
    if rows:
        return [
            {
                "time": _log_time(row.get("event_at")),
                "level": str(row.get("severity") or "INFO").upper(),
                "task": str(row.get("task_key") or "-"),
                "message": str(row.get("message") or ""),
            }
            for row in reversed(rows)
        ]
    heartbeat_rows = _heartbeat_activity_logs(conn)
    if heartbeat_rows:
        return heartbeat_rows
    return [
        {"time": "09:48:22", "level": "INFO", "task": "quote", "message": "write rows=1428 lag=0m"},
        {"time": "09:47:12", "level": "INFO", "task": "capital", "message": "running symbols=486 queue=64"},
        {"time": "09:42:00", "level": "WARN", "task": "flow", "message": "queue delayed market=cn,hk"},
        {"time": "08:31:44", "level": "ERROR", "task": "kline", "message": "429002 rate limited; paused"},
        {"time": "08:31:45", "level": "INFO", "task": "scheduler", "message": "p2 jobs suspended for 30m"},
        {"time": "08:32:01", "level": "INFO", "task": "monitor", "message": "heartbeat ok tasks=14/16"},
    ]


def _task_activity_logs(conn: Any) -> list[dict[str, Any]]:
    task_rows = _tasks(conn)
    if not task_rows:
        return []

    def status_level(task: dict[str, Any]) -> str:
        status = str(task.get("status") or "").lower()
        if status in {"error", "failed", "limited"}:
            return "ERROR"
        if status in {"queued", "pending", "stale", "unknown"}:
            return "WARN"
        return "INFO"

    def sort_key(task: dict[str, Any]) -> str:
        return str(task.get("lastWriteAtRaw") or task.get("heartbeatAtRaw") or task.get("lastWrite") or "0000-00-00 00:00:00")

    logs: list[dict[str, Any]] = []
    selected_rows = sorted(task_rows, key=sort_key)[-20:]
    for task in selected_rows:
        status = str(task.get("statusLabel") or task.get("status") or "-")
        rows_written = int(task.get("rowsWritten") or 0)
        lag = str(task.get("lag") or "-")
        queue_depth = int(task.get("queueDepth") or 0)
        task_name = str(task.get("taskName") or task.get("taskKey") or "-")
        logs.append(
            {
                "time": _log_time(task.get("lastWriteAtRaw") or task.get("heartbeatAtRaw") or task.get("lastWrite")),
                "level": status_level(task),
                "task": task_name,
                "message": _log_message(task_name, status, rows_written, queue_depth, lag, str(task.get("error") or "")),
            }
        )
    return logs


def _log_message(task_name: str, status: str, rows_written: int, queue_depth: int, lag: str, error: str) -> str:
    if error:
        return f"{task_name}：{status}，{error}"
    if queue_depth > 0:
        return f"{task_name}：{status}，本轮已处理 {rows_written} 只，剩余约 {queue_depth} 只。"
    return f"{task_name}：{status}，最近写入 {rows_written} 条，延迟 {lag}。"


def _heartbeat_activity_logs(conn: Any) -> list[dict[str, Any]]:
    rows = _try_query(
        conn,
        """
        select
          case when status in ('running','collecting','writing') then heartbeat_at else coalesce(last_write_at, heartbeat_at) end as event_at,
          task_key,
          status,
          rows_written,
          lag_seconds,
          latest_error_message
        from lb_monitor.task_heartbeats
        order by coalesce(last_write_at, heartbeat_at) desc nulls last
        limit 20
        """,
    )
    logs: list[dict[str, Any]] = []
    for row in rows:
        status = str(row.get("status") or "unknown").lower()
        level = "ERROR" if status in {"error", "failed", "limited"} else "INFO"
        message = str(row.get("latest_error_message") or "")
        if not message:
            message = _log_message(
                _task_name(str(row.get("task_key") or "-")),
                _task_status_label(status),
                int(row.get("rows_written") or 0),
                0,
                _lag_label(row.get("lag_seconds")),
                "",
            )
        logs.append(
            {
                "time": _log_time(row.get("event_at")),
                "level": level,
                "task": _task_name(str(row.get("task_key") or "-")),
                "message": message,
            }
        )
    return list(reversed(logs))


def _task_name(task_key: str) -> str:
    return {
        "realtime_quotes_priority": "实时行情全量采集",
        "realtime_capital_priority": "A股资金分布全量采集",
        "capital_flow_delayed": "A股资金流分时采集",
        "realtime_capital_hk_full": "港股资金全量采集",
        "realtime_capital_us": "美股资金分布采集",
        "realtime_capital_us_full": "美股资金全量采集",
        "realtime_intraday_cn_full": "A股分时走势全量采集",
        "realtime_intraday_hk_full": "港股分时走势全量采集",
        "realtime_intraday_us_full": "美股分时走势全量采集",
        "realtime_microstructure_priority": "优先池微观交易数据采集",
        "market_temperature_sync": "市场温度采集",
        "daily_kline_backfill": "日K补全",
        "eastmoney_external": "东方财富补充数据",
        "limit_up_pipeline": "涨停模型更新",
    }.get(task_key, task_key)


def _realtime_activity_logs(conn: Any) -> list[dict[str, Any]]:
    checks = [
        (
            "realtime_quotes",
            "INFO",
            "lb_realtime_quotes",
            "snapshot_minute",
            "minute quote snapshot",
        ),
        (
            "realtime_capital",
            "INFO",
            "lb_realtime_capital",
            "snapshot_minute",
            "capital distribution snapshot",
        ),
        (
            "capital_flow_series",
            "INFO",
            "lb_realtime_capital_flow",
            "flow_time",
            "capital flow series",
        ),
    ]

    logs: list[dict[str, Any]] = []
    for task, level, table, time_column, label in checks:
        event_at = _ch_latest_timestamp(table, time_column, "hk") or _ch_latest_timestamp(table, time_column, "cn")
        if event_at is None:
            continue
        logs.append(
            {
                "time": _log_time(event_at),
                "level": level,
                "task": task,
                "message": f"{label} latest={_log_time(event_at)}",
            }
        )

    if logs:
        latest_time = logs[0]["time"]
        logs.insert(
            0,
            {
                "time": latest_time,
                "level": "INFO",
                "task": "monitor",
                "message": "live database activity from realtime tables",
            },
        )
    return logs[:6]


def _overall_summary(markets: list[dict[str, Any]], task_summary: dict[str, int]) -> dict[str, Any]:
    total_expected = sum(item["expected"] for item in markets)
    progress = (
        sum(item["progress"] * item["expected"] for item in markets) / total_expected
        if total_expected
        else 0
    )
    total_collected = round(total_expected * progress)
    by_market = {item["market"]: item["progress"] for item in markets}
    total_tasks = max(task_summary.get("total", 0), 1)
    return {
        "totalExpected": total_expected,
        "totalCollected": total_collected,
        "progress": round(progress, 4),
        "marketProgress": by_market,
        "taskNormalRate": round(task_summary.get("normal", 0) / total_tasks, 4),
        "taskRunningRate": round(task_summary.get("running", 0) / total_tasks, 4),
    }


def _try_query(conn: Any, query: str) -> list[dict[str, Any]]:
    try:
        with conn.cursor() as cur:
            cur.execute("set local statement_timeout = '2500ms'")
            cur.execute(query)
            rows = cur.fetchall()
            columns = [desc.name for desc in cur.description]
            return [dict(zip(columns, row)) for row in rows]
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        return []


def _count_by_market(conn: Any, query: str) -> dict[str, int]:
    return {str(row.get("market") or "").lower(): int(row.get("count") or 0) for row in _try_query(conn, query)}


def _fallback_overview(error: str | None = None) -> dict[str, Any]:
    markets = [
        _market_payload("cn", 5374, [_dataset_payload("profile", 5159, 5374), _dataset_payload("daily_bar", 4890, 5374), _dataset_payload("realtime_quote", 4675, 5374), _dataset_payload("capital_distribution", 3654, 5374), _dataset_payload("capital_flow", 1827, 5374), _dataset_payload("model_feature", 4407, 5374), _dataset_payload("limit_up", 5267, 5374)]),
        _market_payload("hk", 2945, [_dataset_payload("profile", 2592, 2945), _dataset_payload("daily_bar", 2474, 2945), _dataset_payload("realtime_quote", 2327, 2945), _dataset_payload("capital_distribution", 1237, 2945), _dataset_payload("capital_flow", 648, 2945), _dataset_payload("model_feature", 2238, 2945), _dataset_payload("company_profile", 2032, 2945)]),
        _market_payload("us", 5523, [_dataset_payload("profile", 3424, 5523), _dataset_payload("daily_bar", 3203, 5523), _dataset_payload("realtime_quote", 2430, 5523), _dataset_payload("capital_distribution", 0, 5523), _dataset_payload("capital_flow", 0, 5523), _dataset_payload("model_feature", 2982, 5523), _dataset_payload("company_profile", 2264, 5523)]),
    ]
    summary = {"total": 16, "running": 5, "normal": 14, "failed": 2}
    payload = {
        "updatedAt": _now_iso(),
        "overall": _overall_summary(markets, summary),
        "markets": markets,
        "taskPipeline": _task_pipeline(None, summary),
        "gapPriority": _gap_priority(None, markets),
        "logs": _logs(None),
    }
    if error:
        payload["warning"] = error
    return payload


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _iso(value: Any) -> str | None:
    if value is None:
        return None
    return value.isoformat() if hasattr(value, "isoformat") else str(value)


def _time(value: Any) -> str:
    if value is None:
        return "--:--:--"
    if hasattr(value, "strftime"):
        return value.strftime("%H:%M:%S")
    return str(value)[11:19] if len(str(value)) >= 19 else str(value)


def _log_time(value: Any) -> str:
    if value is None:
        return "---- --:--:--"
    if hasattr(value, "strftime"):
        return value.strftime("%m-%d %H:%M:%S")
    text = str(value)
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00")).strftime("%m-%d %H:%M:%S")
    except ValueError:
        if len(text) >= 19 and text[4] == "-" and text[7] == "-":
            return text[5:19]
        return text


def _load_psycopg():
    try:
        import psycopg
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("psycopg is required for sync monitoring") from exc
    return psycopg

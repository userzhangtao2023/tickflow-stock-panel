from __future__ import annotations

import json
import os
import tempfile
from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Any

from longbridge_stock.experiment_tracking import extract_numeric_metrics
from longbridge_stock.model_registry import list_models


DEFAULT_EXPERIMENT = "longbridge-model-registry-sync"
DEFAULT_REGISTERED_MODEL_PREFIX = "longbridge"
SYNC_TAG = "longbridge_gateway_sync"


def sync_registry_to_mlflow(
    *,
    registry_path: str | Path | None = None,
    tracking_uri: str | None = None,
    experiment_name: str = DEFAULT_EXPERIMENT,
    registered_model_prefix: str = DEFAULT_REGISTERED_MODEL_PREFIX,
    max_artifacts_per_algorithm: int = 1000,
    dry_run: bool = False,
    mlflow_module: Any | None = None,
    client: Any | None = None,
) -> dict[str, Any]:
    models = [
        model
        for model in list_models(registry_path=registry_path, max_artifacts_per_algorithm=max_artifacts_per_algorithm)
        if model.get("artifactExists")
    ]
    if dry_run:
        return {
            "dry_run": True,
            "models_seen": len(models),
            "model_ids": [model["modelId"] for model in models],
        }
    mlflow = mlflow_module if mlflow_module is not None else _load_mlflow()
    if mlflow is None:
        return {"enabled": False, "reason": "mlflow_not_installed", "models_seen": len(models)}
    if tracking_uri:
        mlflow.set_tracking_uri(str(tracking_uri))
    mlflow_client = client or mlflow.tracking.MlflowClient()
    experiment_id = _ensure_experiment(mlflow_client, experiment_name)

    created_runs = 0
    reused_runs = 0
    created_registered_models = 0
    reused_registered_models = 0
    created_versions = 0
    reused_versions = 0
    errors: list[dict[str, str]] = []

    for model in models:
        try:
            run_id, run_created = _ensure_run(mlflow_client, experiment_id, model)
            created_runs += int(run_created)
            reused_runs += int(not run_created)
            model_name = registered_model_name(model, prefix=registered_model_prefix)
            registered_created = _ensure_registered_model(mlflow_client, model_name, model)
            created_registered_models += int(registered_created)
            reused_registered_models += int(not registered_created)
            version_created = _ensure_model_version(mlflow_client, model_name, model, run_id)
            created_versions += int(version_created)
            reused_versions += int(not version_created)
        except Exception as exc:  # keep syncing the rest of the inventory
            errors.append({"model_id": str(model.get("modelId") or ""), "error": str(exc)})

    return {
        "enabled": True,
        "tracking_uri": str(tracking_uri or ""),
        "experiment_name": experiment_name,
        "models_seen": len(models),
        "created_runs": created_runs,
        "reused_runs": reused_runs,
        "created_registered_models": created_registered_models,
        "reused_registered_models": reused_registered_models,
        "created_versions": created_versions,
        "reused_versions": reused_versions,
        "errors": errors,
    }


def registered_model_name(model: Mapping[str, Any], *, prefix: str = DEFAULT_REGISTERED_MODEL_PREFIX) -> str:
    model_id = str(model.get("modelId") or model.get("algorithmId") or "model")
    return ".".join(part for part in [prefix.strip("."), _safe_name(model_id)] if part)


def _ensure_experiment(client: Any, experiment_name: str) -> str:
    experiment = client.get_experiment_by_name(experiment_name)
    if experiment is not None:
        return str(experiment.experiment_id)
    return str(client.create_experiment(experiment_name))


def _ensure_run(client: Any, experiment_id: str, model: Mapping[str, Any]) -> tuple[str, bool]:
    existing = client.search_runs(
        [experiment_id],
        filter_string=f"tags.gateway_model_id = {_mlflow_filter_string(str(model.get('modelId') or ''))}",
        max_results=1,
    )
    if existing:
        return str(existing[0].info.run_id), False
    tags = _model_tags(model)
    run = client.create_run(str(experiment_id), tags=tags, run_name=str(model.get("modelId") or model.get("name") or "model"))
    run_id = str(run.info.run_id)
    for key, value in _model_params(model).items():
        client.log_param(run_id, key, _truncate(value, 500))
    for key, value in extract_numeric_metrics(model.get("metrics") or {}, max_metrics=100).items():
        client.log_metric(run_id, _safe_metric_key(key), float(value))
    _log_model_summary_artifact(client, run_id, model)
    client.set_terminated(run_id, "FINISHED")
    return run_id, True


def _ensure_registered_model(client: Any, model_name: str, model: Mapping[str, Any]) -> bool:
    try:
        client.get_registered_model(model_name)
        _set_registered_model_tags(client, model_name, model)
        return False
    except Exception:
        client.create_registered_model(model_name, tags=_registered_model_tags(model))
        return True


def _ensure_model_version(client: Any, model_name: str, model: Mapping[str, Any], run_id: str) -> bool:
    model_id = str(model.get("modelId") or "")
    existing = client.search_model_versions(f"name = {_mlflow_filter_string(model_name)}")
    for version in existing:
        tags = getattr(version, "tags", {}) or {}
        if tags.get("gateway_model_id") == model_id:
            return False
    source = f"runs:/{run_id}/gateway_model.json"
    created = client.create_model_version(name=model_name, source=source, run_id=run_id)
    version_number = str(created.version)
    for key, value in _model_version_tags(model).items():
        client.set_model_version_tag(model_name, version_number, key, value)
    if model.get("latest"):
        _try_set_alias(client, model_name, "latest", version_number)
    return True


def _set_registered_model_tags(client: Any, model_name: str, model: Mapping[str, Any]) -> None:
    for key, value in _registered_model_tags(model).items():
        try:
            client.set_registered_model_tag(model_name, key, value)
        except Exception:
            pass


def _try_set_alias(client: Any, model_name: str, alias: str, version_number: str) -> None:
    try:
        client.set_registered_model_alias(model_name, alias, version_number)
    except Exception:
        pass

def _model_tags(model: Mapping[str, Any]) -> dict[str, str]:
    tags = {
        "gateway_model_id": str(model.get("modelId") or ""),
        "algorithm_id": str(model.get("algorithmId") or ""),
        "model_family": str(model.get("family") or ""),
        "model_status": str(model.get("status") or ""),
        "framework": str(model.get("framework") or ""),
        "serving_backend": str(model.get("servingBackend") or ""),
        "gateway_artifact_path": str(model.get("artifactPath") or ""),
        SYNC_TAG: "true",
    }
    if model.get("latest"):
        tags["gateway_latest"] = "true"
    return {key: _truncate(value, 5000) for key, value in tags.items() if value}


def _registered_model_tags(model: Mapping[str, Any]) -> dict[str, str]:
    return {
        "gateway_model_id": str(model.get("modelId") or ""),
        "algorithm_id": str(model.get("algorithmId") or ""),
        "model_family": str(model.get("family") or ""),
        "model_status": str(model.get("status") or ""),
        SYNC_TAG: "true",
    }


def _model_version_tags(model: Mapping[str, Any]) -> dict[str, str]:
    tags = _model_tags(model)
    tags["run_id"] = str(model.get("runId") or "")
    tags["created_at"] = str(model.get("createdAt") or "")
    return tags


def _model_params(model: Mapping[str, Any]) -> dict[str, str]:
    return {
        "model_id": str(model.get("modelId") or ""),
        "algorithm_id": str(model.get("algorithmId") or ""),
        "run_id": str(model.get("runId") or ""),
        "name": str(model.get("name") or ""),
        "family": str(model.get("family") or ""),
        "status": str(model.get("status") or ""),
        "framework": str(model.get("framework") or ""),
        "serving_backend": str(model.get("servingBackend") or ""),
        "artifact_path": str(model.get("artifactPath") or ""),
        "latest": str(bool(model.get("latest"))).lower(),
        "purpose": str(model.get("purpose") or ""),
        "feature_count": str(len(model.get("featureNames") or [])),
    }


def _log_model_summary_artifact(client: Any, run_id: str, model: Mapping[str, Any]) -> None:
    summary = {
        key: model.get(key)
        for key in [
            "modelId",
            "algorithmId",
            "runId",
            "name",
            "family",
            "status",
            "framework",
            "servingBackend",
            "purpose",
            "artifactPath",
            "artifactExists",
            "latest",
            "createdAt",
            "metrics",
            "featureNames",
        ]
    }
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "gateway_model.json"
        path.write_text(json.dumps(summary, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        client.log_artifact(run_id, str(path))


def _safe_name(value: str) -> str:
    output = []
    for ch in value:
        if ch.isalnum() or ch in {"_", ".", "-"}:
            output.append(ch)
        elif ch in {":", "/", "\\", " "}:
            output.append(".")
    name = "".join(output).strip(".")
    while ".." in name:
        name = name.replace("..", ".")
    return name or "model"


def _safe_metric_key(value: str) -> str:
    return "".join(ch if ch.isalnum() or ch in {"_", "-", ".", "/"} else "_" for ch in value)[:250]


def _mlflow_filter_string(value: str) -> str:
    return "'" + value.replace("\\", "\\\\").replace("'", "\\'") + "'"


def _truncate(value: Any, limit: int) -> str:
    text = str(value)
    return text if len(text) <= limit else text[: limit - 3] + "..."


def _load_mlflow() -> Any | None:
    try:
        import mlflow  # type: ignore
    except Exception:
        return None
    return mlflow

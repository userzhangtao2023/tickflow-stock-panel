from __future__ import annotations

import json
import time
import os
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Iterable

from longbridge_stock import clickhouse_realtime
from longbridge_stock.market_sessions import SHANGHAI_TZ, is_trading_time
from longbridge_stock.realtime_alerts import AlertState, OpenClawNotifier, RealtimeAlert, build_default_notifier
from longbridge_stock.stock_tags import build_stock_tags

DEFAULT_DSN = os.getenv("POSTGRES_DSN") or os.getenv("LONGBRIDGE_PG_DSN") or "dbname=longbridge_stock user=alwin host=/var/run/postgresql"
DEFAULT_STATE_PATH = "/home/alwin/data/longbridge/us_fast_alert_state.json"


@dataclass(frozen=True)
class USFastAlertConfig:
    profile: str = "us_fast_15"
    min_probability: float = 0.70
    sell_probability: float = 0.60
    limit: int = 100
    max_alerts_per_run: int = 5
    stop_loss_return: float = -0.006
    trailing_pullback: float = 0.006
    execution_lookback_days: int = 10


@dataclass(frozen=True)
class ExecutionLot:
    symbol: str
    quantity: float
    price: float
    time: str


class USFastAlertMonitor:
    def __init__(
        self,
        dsn: str,
        config: USFastAlertConfig,
        notifier: OpenClawNotifier,
        state: AlertState,
    ) -> None:
        self.dsn = dsn
        self.config = config
        self.notifier = notifier
        self.state = state

    def run_once(self, now: datetime | None = None) -> dict[str, Any]:
        current = now or datetime.now(SHANGHAI_TZ)
        if not _is_us_regular_trading_time(current):
            return {"status": "outside_regular_trading_time", "checked": 0, "alerts": 0, "sent": 0, "skipped": 0, "errors": []}
        try:
            with _connect(self.dsn) as conn:
                rows = fetch_us_fast_prediction_rows(conn, profile=self.config.profile, limit=self.config.limit)
        except Exception as exc:
            return {
                "status": "error",
                "checked": 0,
                "alerts": 0,
                "sent": 0,
                "skipped": 0,
                "deferred": 0,
                "errors": [f"database: {exc}"],
            }
        _drop_expired_positions_without_latest_quote(self.state, rows, current)
        positions = _active_positions(self.state)
        execution_errors: list[str] = []
        try:
            recent_lots = get_recent_execution_lots([str(position.get("symbol") or "") for position in positions], self.config.execution_lookback_days)
        except Exception as exc:
            recent_lots = {}
            execution_errors.append(f"recent_lots: {exc}")
        sell_alerts = build_us_fast_sell_alerts(positions, rows, now=current, config=self.config, recent_lots=recent_lots)
        buy_alerts = build_us_fast_buy_alerts(rows, self.config)
        alerts = sell_alerts + buy_alerts
        alerts.sort(key=lambda alert: alert.score if alert.score is not None else 0.0, reverse=True)
        trade_date = current.astimezone(SHANGHAI_TZ).date().isoformat()
        sent = 0
        skipped = 0
        deferred = 0
        attempted = 0
        errors: list[str] = execution_errors[:]
        for alert in alerts:
            if not self.state.should_send(alert, trade_date):
                skipped += 1
                continue
            if attempted >= self.config.max_alerts_per_run:
                deferred += 1
                continue
            attempted += 1
            try:
                self.notifier.send(alert.message)
            except Exception as exc:
                errors.append(f"{alert.dedupe_key}: {exc}")
                continue
            self.state.mark_sent(alert, trade_date)
            _apply_alert_state(self.state, alert, rows, current, self.config)
            sent += 1
        return {
            "status": "ok",
            "checked": len(rows),
            "alerts": len(alerts),
            "sent": sent,
            "skipped": skipped,
            "deferred": deferred,
            "errors": errors,
        }

    def run_forever(self, interval_seconds: int) -> None:
        if interval_seconds <= 0:
            raise ValueError("interval_seconds must be positive")
        while True:
            started = time.monotonic()
            result = self.run_once()
            print(result, flush=True)
            time.sleep(max(0, interval_seconds - (time.monotonic() - started)))


def fetch_us_fast_prediction_rows(conn: Any, *, profile: str, limit: int) -> list[dict[str, Any]]:
    candidate_rows = fetch_us_fast_candidate_pool_rows(conn, limit=limit)
    if candidate_rows:
        rows = _apply_symbol_metadata(conn, candidate_rows)
        return _apply_intraday_context(rows)

    return fetch_us_fast_model_prediction_rows(conn, profile=profile, limit=limit)


def fetch_us_fast_model_prediction_rows(conn: Any, *, profile: str, limit: int) -> list[dict[str, Any]]:
    model_row = clickhouse_realtime.fetch_latest_realtime_profit_model_run(market="us", profile=profile)
    if not model_row:
        return []
    model_run_id = str(model_row.get("model_run_id") or "")
    rows = clickhouse_realtime.fetch_latest_us_fast_profit_prediction_rows(model_run_id=model_run_id, limit=limit)
    rows = _apply_symbol_metadata(conn, rows)
    return _apply_intraday_context(rows)


def fetch_us_fast_candidate_pool_rows(conn: Any, *, limit: int) -> list[dict[str, Any]]:
    try:
        rows = conn.execute(
            """
            with latest as (
              select max(run_time) as run_time
              from lb_us_fast_candidate_pool
              where trade_date = (now() at time zone 'Asia/Shanghai')::date
            )
            select p.symbol,
                   p.name,
                   p.score,
                   p.output_stage,
                   p.decision,
                   p.risk_score,
                   p.profit_probability,
                   p.expected_return,
                   p.entry_price,
                   p.run_time,
                   p.status,
                   p.payload
            from lb_us_fast_candidate_pool p
            join latest l on p.run_time = l.run_time
            where p.trade_date = (now() at time zone 'Asia/Shanghai')::date
            order by p.rank asc
            limit %s
            """,
            (limit,),
        ).fetchall()
    except Exception:
        rollback = getattr(conn, "rollback", None)
        if callable(rollback):
            rollback()
        return []

    output: list[dict[str, Any]] = []
    for symbol, name, score, output_stage, decision, risk_score, probability, expected_return, entry_price, run_time, status, payload in rows:
        item = _payload_dict(payload)
        item.update(
            {
                "symbol": str(symbol),
                "market": "us",
                "name": str(name or symbol),
                "score": _number(score),
                "output_stage": str(output_stage or ""),
                "decision": str(decision or item.get("decision") or ""),
                "risk_score": _number(risk_score),
                "profit_probability": _number(probability),
                "expected_return": _number(expected_return),
                "entry_price": _number(entry_price),
                "candidate_run_time": run_time,
                "status": str(status or ""),
            }
        )
        output.append(item)
    return output


def build_us_fast_buy_alerts(rows: Iterable[dict[str, Any]], config: USFastAlertConfig) -> list[RealtimeAlert]:
    alerts: list[RealtimeAlert] = []
    eligible_rows = list(_eligible_us_fast_buy_rows(rows, config))
    tag_summaries = _fetch_stock_tag_summaries([str(row.get("symbol") or "") for row in eligible_rows])
    for row in eligible_rows:
        symbol = str(row.get("symbol") or "")
        name = str(row.get("name") or symbol)
        probability = _number(row.get("profit_probability"))
        entry = _number(row.get("entry_price"))
        ma5 = _number(row.get("ma5"))
        ma60 = _number(row.get("ma60"))
        if probability is None or entry is None or ma5 is None:
            continue
        display_name = _display_symbol_name(symbol, name)
        target_return = _number(row.get("target_return")) or 0.02
        take_profit = entry * (1 + target_return) if entry is not None else None
        risk_line = entry * (1 + config.stop_loss_return) if entry is not None else None
        shape = _trade_shape(row, entry=entry, ma5=ma5)
        title = f"美股Fast盘中助手 {shape} {display_name}"
        message = "\n".join(
            [
                f"【美股Fast盘中助手｜{shape}】{display_name}",
                *_recommendation_lines(row, tag_summaries.get(symbol), probability=probability, entry=entry, ma5=ma5, ma60=ma60, target_return=target_return, risk_line=risk_line, shape=shape),
            ]
        )
        alerts.append(
            RealtimeAlert(
                alert_type="us_fast_buy",
                symbol=symbol,
                market="US",
                name=name,
                title=title,
                message=message,
                score=probability,
                signal="us_fast_15",
            )
        )
    return alerts


def _eligible_us_fast_buy_rows(rows: Iterable[dict[str, Any]], config: USFastAlertConfig) -> Iterable[dict[str, Any]]:
    for row in rows:
        if str(row.get("market") or "").lower() != "us":
            continue
        output_stage = str(row.get("output_stage") or "")
        if output_stage and output_stage not in {"buy_point", "watch", "technical_breakout_watch"}:
            continue
        probability = _number(row.get("profit_probability"))
        decision = str(row.get("decision") or "")
        allowed_decisions = {"buy_zone", "watch", "candidate"} if output_stage else {"buy_zone"}
        if decision not in allowed_decisions or probability is None or probability < config.min_probability:
            continue
        symbol = str(row.get("symbol") or "")
        name = str(row.get("name") or symbol)
        if _is_excluded_us_fast_instrument(symbol, name):
            continue
        entry = _number(row.get("entry_price"))
        ma5 = _number(row.get("ma5"))
        ma60 = _number(row.get("ma60"))
        if entry is None or ma5 is None or entry <= ma5:
            continue
        yield row


def _is_us_regular_trading_time(now: datetime) -> bool:
    return is_trading_time(now, ["us"])


def _apply_symbol_metadata(conn: Any, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    symbols = sorted({str(row.get("symbol") or "") for row in rows if row.get("symbol")})
    if not symbols:
        return rows
    metadata = _load_symbol_metadata(conn, symbols)
    trend = _load_trend_context(conn, symbols)
    fundamentals = _load_fundamental_contexts(conn, symbols)
    contexts = _load_industry_contexts(sorted({item["industry"] for item in metadata.values() if item.get("industry")}))
    enriched: list[dict[str, Any]] = []
    for row in rows:
        symbol = str(row.get("symbol") or "")
        current_name = str(row.get("name") or "")
        item = metadata.get(symbol, {})
        name = item.get("name")
        industry = item.get("industry")
        updated = dict(row)
        if name and (not current_name or current_name.upper() == symbol.upper()):
            updated["name"] = name
        if industry:
            updated["industry"] = industry
            updated.update(contexts.get(industry, {}))
        updated.update(trend.get(symbol, {}))
        updated.update(fundamentals.get(symbol, {}))
        if item.get("company_profile"):
            updated["company_profile"] = item["company_profile"]
        enriched.append(updated)
    return enriched


def _apply_intraday_context(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    symbols = [str(row.get("symbol") or "").strip().upper() for row in rows if row.get("symbol")]
    if not symbols:
        return rows
    try:
        contexts = clickhouse_realtime.fetch_realtime_signal_rows(symbols, now=datetime.now(SHANGHAI_TZ), max_quote_age_minutes=90)
    except Exception:
        return rows
    fields = (
        "change_pct",
        "large_in",
        "large_out",
        "large_net",
        "total_in",
        "total_out",
        "total_net",
        "large_net_ratio",
        "small_net_ratio",
        "flow_15m",
        "flow_30m",
        "flow_today",
        "last_flow_time",
    )
    enriched: list[dict[str, Any]] = []
    for row in rows:
        updated = dict(row)
        context = contexts.get(str(row.get("symbol") or "").strip().upper()) or {}
        for field in fields:
            value = context.get(field)
            if value is not None:
                updated[field] = value
        enriched.append(updated)
    return enriched


def _load_symbol_metadata(conn: Any, symbols: list[str]) -> dict[str, dict[str, str]]:
    metadata: dict[str, dict[str, str]] = {}
    try:
        rows = conn.execute(
            """
            select symbol, name
            from lb_symbols
            where symbol = any(%s)
              and nullif(trim(name), '') is not null
            """,
            (symbols,),
        ).fetchall()
        for symbol, name in rows:
            metadata.setdefault(str(symbol), {})["name"] = str(name)
    except Exception:
        pass
    try:
        rows = conn.execute(
            """
            select distinct on (symbol) symbol, company_name_en, industry, company_profile
            from lb_eastmoney_f10_profiles
            where symbol = any(%s)
            order by symbol, updated_at desc
            """,
            (symbols,),
        ).fetchall()
        for symbol, company_name, industry, profile in rows:
            item = metadata.setdefault(str(symbol), {})
            if company_name and not item.get("name"):
                item["name"] = str(company_name)
            if industry:
                item["industry"] = str(industry)
            if profile:
                item["company_profile"] = str(profile)
    except Exception:
        pass
    return metadata


def _load_fundamental_contexts(conn: Any, symbols: list[str]) -> dict[str, dict[str, Any]]:
    contexts: dict[str, dict[str, Any]] = {symbol: {} for symbol in symbols}
    try:
        rows = conn.execute(
            """
            select distinct on (symbol) symbol, financial_summary, news_items, llm_summary, sources, payload
            from lb_stock_research_snapshots
            where symbol = any(%s)
            order by symbol, as_of desc, updated_at desc
            """,
            (symbols,),
        ).fetchall()
        for symbol, financial_summary, news_items, llm_summary, sources, payload in rows:
            item = contexts.setdefault(str(symbol), {})
            if financial_summary:
                item["research_financial_summary"] = str(financial_summary)
            item["research_news_items"] = _json_list(news_items)
            if llm_summary:
                item["research_llm_summary"] = str(llm_summary)
            item["research_sources"] = _json_list(sources)
            item["research_payload"] = _payload_dict(payload)
    except Exception:
        pass

    try:
        rows = conn.execute(
            """
            select symbol, report_period, name, value::float8, yoy, currency, fp_end
            from (
              select symbol, report_period, name, value, yoy, currency, fp_end, fiscal_year, updated_at,
                     row_number() over (
                       partition by symbol
                       order by fp_end desc nulls last, fiscal_year desc nulls last, updated_at desc
                     ) as rn
              from lb_financial_report
              where symbol = any(%s)
                and market = 'us'
                and name is not null
            ) ranked
            where rn <= 24
            order by symbol, fp_end desc nulls last, name
            """,
            (symbols,),
        ).fetchall()
        for symbol, period, name, value, yoy, currency, fp_end in rows:
            contexts.setdefault(str(symbol), {}).setdefault("financial_facts", []).append(
                {
                    "period": str(period or ""),
                    "name": str(name or ""),
                    "value": _number(value),
                    "yoy": str(yoy) if yoy not in (None, "") else "",
                    "currency": str(currency or ""),
                    "fp_end": str(fp_end or ""),
                }
            )
    except Exception:
        pass

    try:
        rows = conn.execute(
            """
            select distinct on (symbol) symbol, description, ex_date, payment_date
            from lb_dividends
            where symbol = any(%s)
              and market = 'us'
            order by symbol, ex_date desc nulls last, updated_at desc
            """,
            (symbols,),
        ).fetchall()
        for symbol, description, ex_date, payment_date in rows:
            text = str(description or "").strip()
            if ex_date:
                text = f"{text} 除权日{ex_date}".strip()
            if payment_date:
                text = f"{text} 派息日{payment_date}".strip()
            if text:
                contexts.setdefault(str(symbol), {})["dividend_summary"] = text
    except Exception:
        pass

    return contexts


def _load_trend_context(conn: Any, symbols: list[str]) -> dict[str, dict[str, float]]:
    if not symbols:
        return {}
    try:
        rows = conn.execute(
            """
            with ranked as (
              select symbol,
                     close::float8 as close,
                     row_number() over (partition by symbol order by trade_date desc) as rn
              from lb_daily_bars
              where symbol = any(%s)
                and market = 'us'
                and close is not null
            )
            select symbol,
                   avg(close) filter (where rn <= 5) as ma5,
                   avg(close) filter (where rn <= 60) as ma60,
                   count(*) filter (where rn <= 60) as sample_count
            from ranked
            where rn <= 60
            group by symbol
            """,
            (symbols,),
        ).fetchall()
    except Exception:
        return {}
    output: dict[str, dict[str, float]] = {}
    for symbol, ma5, ma60, sample_count in rows:
        if sample_count is not None and int(sample_count) >= 60 and ma5 is not None and ma60 is not None:
            output[str(symbol)] = {"ma5": float(ma5), "ma60": float(ma60)}
    return output


def _load_industry_contexts(industries: list[str]) -> dict[str, dict[str, Any]]:
    contexts: dict[str, dict[str, Any]] = {}
    for industry in industries:
        peers = _load_industry_symbols(industry)
        if not peers:
            continue
        rows = _fetch_industry_quote_rows(peers)
        changes = [_number(row.get("change_pct")) for row in rows if _number(row.get("change_pct")) is not None]
        if not changes:
            continue
        avg_change = sum(changes) / len(changes)
        up_ratio = len([value for value in changes if value > 0]) / len(changes)
        contexts[industry] = {
            "industry_change_pct": avg_change,
            "industry_up_ratio": up_ratio,
            "industry_sample_count": len(changes),
            "industry_linkage": _classify_industry_linkage(avg_change, up_ratio, len(changes)),
        }
    return contexts


def _classify_industry_linkage(avg_change: float, up_ratio: float, sample_count: int) -> str:
    if sample_count < 5:
        return "insufficient_samples"
    if avg_change >= 1.0 and up_ratio >= 0.60:
        return "sector_up_linkage"
    if avg_change <= -1.0 and up_ratio <= 0.40:
        return "sector_down_linkage"
    if avg_change > 0 and up_ratio >= 0.50:
        return "mild_sector_support"
    return "stock_specific_or_mixed"


def _load_industry_symbols(industry: str, *, limit: int = 300) -> list[str]:
    try:
        import psycopg

        with psycopg.connect(DEFAULT_DSN) as conn:
            rows = conn.execute(
                """
                select symbol
                from lb_eastmoney_f10_profiles
                where market = 'us'
                  and industry = %s
                order by updated_at desc
                limit %s
                """,
                (industry, limit),
            ).fetchall()
    except Exception:
        return []
    return [str(row[0]) for row in rows]


def _recommendation_lines(
    row: dict[str, Any],
    tag_summary: dict[str, Any] | None,
    *,
    probability: float,
    entry: float,
    ma5: float,
    ma60: float | None,
    target_return: float,
    risk_line: float | None,
    shape: str,
) -> list[str]:
    risk_score = _number(row.get("risk_score"))
    trade_horizon = _trade_horizon_text(
        probability=probability,
        expected_return=_number(row.get("expected_return")),
        target_return=target_return,
        risk_score=risk_score,
    )
    return [
        "|\u9879\u76ee|\u5185\u5bb9|",
        "|---|---|",
        f"|\u5f62\u6001|{shape}|",
        f"|类型|{trade_horizon}|",
        f"|\u73b0\u4ef7|{_fmt(entry)}|",
        f"|\u4f4d\u7f6e|{_price_short(entry=entry, ma5=ma5, ma60=ma60)}|",
        f"|\u80dc\u7387|{probability * 100:.1f}%; \u76ee\u6807\u662f3\u4e2a\u4ea4\u6613\u65e5\u5185+{target_return * 100:.1f}%|",
        f"|\u57fa\u672c\u9762|{_fundamental_short(row)}|",
        f"|\u8d44\u91d1|{_capital_short(row)}|",
        f"|\u6280\u672f|{_technical_short(row, tag_summary)}|",
        f"|\u677f\u5757|{_sector_short(row)}|",
        f"|\u98ce\u63a7|\u8dcc\u7834{_fmt(risk_line)}\u6216\u6982\u7387\u56de\u843d, \u5148\u9000\u51fa\u3002|",
    ]


def _trade_horizon_text(
    *,
    probability: float,
    expected_return: float | None,
    target_return: float,
    risk_score: float | None,
) -> str:
    if probability >= 0.85 and (expected_return is None or expected_return >= target_return) and (risk_score is None or risk_score <= 45):
        return "可持有型：概率和预期收益共振，允许按 1-3 日波段跟踪"
    return "短线冲高型：达到 +2% 或冲高回落要及时兑现，不默认持有三天"


def _trade_shape(row: dict[str, Any], *, entry: float, ma5: float) -> str:
    if str(row.get("output_stage") or "") == "technical_breakout_watch":
        return "技术突破观察"
    if _breakout_text(row):
        return "\u7a81\u7834\u8ddf\u968f\u4e70\u5165"
    if ma5 > 0 and entry / ma5 <= 1.035:
        return "\u4f4e\u5438\u4e70\u5165"
    return "\u8d8b\u52bf\u8ddf\u968f\u89c2\u5bdf"


def _decision_text(probability: float, expected_return: float | None, target_return: float, risk_score: float | None) -> str:
    if probability >= 0.85 and (expected_return is None or expected_return >= target_return) and (risk_score is None or risk_score <= 45):
        return "\u53ef\u4ee5\u4e70, \u4f46\u53ea\u6309\u8ba1\u5212\u4e70; \u4e0d\u662f\u8ffd\u9ad8\u65e0\u8111\u4e70"
    if probability >= 0.75:
        return "\u504f\u4e70\u5165\u89c2\u5bdf, \u5c0f\u4ed3\u4f4d\u66f4\u5408\u9002"
    return "\u8fbe\u5230\u63d0\u9192\u7ebf, \u5148\u89c2\u5bdf\u627f\u63a5"


def _capital_short(row: dict[str, Any]) -> str:
    total_net = _row_number(row, "total_net", "totalNet")
    large_net = _row_number(row, "large_net", "largeNet")
    flow_30m = _row_number(row, "flow_30m", "flow30m")
    buy_ratio = _feature_number(row, "trade_buy_ratio_5m")
    if total_net is not None and large_net is not None:
        if total_net > 0 and large_net > 0:
            text = f"\u603b\u8d44\u91d1{_flow_text(total_net)}, \u5927\u5355{_flow_text(large_net)}, \u8d44\u91d1\u914d\u5408"
        elif total_net > 0 and large_net <= 0:
            text = f"\u603b\u8d44\u91d1{_flow_text(total_net)}, \u4f46\u5927\u5355{_flow_text(large_net)}, \u529b\u5ea6\u4e00\u822c"
        elif total_net <= 0 and large_net > 0:
            text = f"\u5927\u5355{_flow_text(large_net)}, \u4f46\u603b\u8d44\u91d1{_flow_text(total_net)}, \u8fd8\u6709\u5206\u6b67"
        else:
            text = f"\u603b\u8d44\u91d1{_flow_text(total_net)}, \u5927\u5355{_flow_text(large_net)}, \u8d44\u91d1\u4e0d\u652f\u6301"
    else:
        text = "\u8d44\u91d1\u91d1\u989d\u6682\u7f3a, \u4e3b\u8981\u770b\u6a21\u578b\u548c\u4ef7\u683c\u7ed3\u6784"
    extras = []
    if flow_30m is not None:
        extras.append(f"30\u5206\u949f{_flow_text(flow_30m)}")
    if buy_ratio is not None:
        extras.append(f"\u4e3b\u52a8\u4e70\u5165\u5360\u6bd4{_fmt_pct(buy_ratio)}")
    return text + ("; " + ", ".join(extras) if extras else "")


def _technical_short(row: dict[str, Any], tag_summary: dict[str, Any] | None = None) -> str:
    labels = tag_summary.get("labels") if isinstance(tag_summary, dict) and isinstance(tag_summary.get("labels"), dict) else {}
    intraday = tag_summary.get("intraday") if isinstance(tag_summary, dict) and isinstance(tag_summary.get("intraday"), dict) else {}
    intraday_tags = intraday.get("tags") if isinstance(intraday.get("tags"), dict) else {}
    parts = []
    macd = _text_value(row, "macd", "macd_state", "macdState") or str(labels.get("macd") or intraday_tags.get("macdState") or "").strip()
    kdj = _text_value(row, "kdj", "kdj_state", "kdjState") or str(labels.get("kdj") or "").strip()
    rsi = _text_value(row, "rsi", "rsi_state", "rsiState") or str(labels.get("rsi") or "").strip()
    boll = _text_value(row, "boll", "boll_state", "bollState") or str(labels.get("boll") or "").strip()
    volume = _text_value(row, "volume_signal", "volume_state", "volumeState") or str(labels.get("volume") or "").strip()
    breakout = _breakout_text(row)
    for item in (macd, kdj, rsi, boll, breakout, volume):
        if item and "\u6570\u636e\u4e0d\u8db3" not in item:
            parts.append(item)
    if not parts:
        return "\u6280\u672f\u6570\u636e\u4e0d\u8db3, \u4e0d\u4f5c\u4e3a\u52a0\u5206; \u6709\u6570\u636e\u540e\u91cd\u70b9\u590d\u6838MACD/KDJ/RSI/BOLL\u548c\u91cf\u80fd\u7a81\u7834"
    return "\u77ed\u7ebf\u52a8\u80fd\u8f6c\u5f3a, \u7ad9\u4e0a\u5173\u952e\u5747\u7ebf, \u653e\u91cf\u7a81\u7834\u524d\u9ad8; RSI\u672a\u660e\u663e\u8fc7\u70ed, \u5f62\u6001\u652f\u6301\u5c0f\u4ed3\u8bd5\u4e70"


def _fundamental_short(row: dict[str, Any]) -> str:
    facts = row.get("financial_facts") if isinstance(row.get("financial_facts"), list) else []
    revenue = _financial_fact(facts, "营业收入", "revenue")
    net_profit = _financial_fact(facts, "净利润", "net income", "net profit")
    eps = _financial_fact(facts, "每股收益", "eps")
    fcf = _financial_fact(facts, "自由现金流", "free cash flow")
    ocf = _financial_fact(facts, "经营现金流", "operating cash flow")
    dividend = _compact_text(row.get("dividend_summary"), max_chars=28)
    news = _latest_news_title(row)

    if not any([revenue, net_profit, eps, fcf, ocf, row.get("research_financial_summary")]):
        parts = ["财报数据不足，不作基本面加分"]
        parts.append(f"分红:{dividend}" if dividend else "分红无记录")
        if news:
            parts.append(f"新闻:{news}")
        return "; ".join(parts)

    if _fact_value(net_profit) is not None and _fact_value(net_profit) < 0:
        verdict = "仍在亏损，只适合短线观察"
    elif _fact_value(eps) is not None and _fact_value(eps) < 0:
        verdict = "EPS为负，先按交易机会看"
    elif (_fact_value(fcf) is not None and _fact_value(fcf) < 0) or (_fact_value(ocf) is not None and _fact_value(ocf) < 0):
        verdict = "盈利质量有压力，小仓更合适"
    elif _fact_value(net_profit) is not None and _fact_value(net_profit) > 0:
        verdict = "盈利为正，可结合技术小仓"
    else:
        verdict = "基本面未确认，不作强买入依据"

    details = []
    if revenue:
        details.append(f"营收{_fact_money(revenue)}{_fact_yoy(revenue)}")
    if net_profit:
        details.append(f"净利{_fact_money(net_profit)}{_fact_yoy(net_profit)}")
    elif eps:
        details.append(f"EPS{_fact_money(eps)}{_fact_yoy(eps)}")
    if fcf and _fact_value(fcf) is not None and _fact_value(fcf) < 0:
        details.append("自由现金流为负")
    elif ocf and _fact_value(ocf) is not None and _fact_value(ocf) < 0:
        details.append("经营现金流为负")
    if dividend:
        details.append(f"分红:{dividend}")
    else:
        details.append("分红无记录")
    if news:
        details.append(f"新闻:{news}")
    return _compact_text(f"{verdict}; {'; '.join(details)}", max_chars=128)


def _financial_fact(facts: list[Any], *keywords: str) -> dict[str, Any] | None:
    lowered = [keyword.lower() for keyword in keywords]
    for fact in facts:
        if not isinstance(fact, dict):
            continue
        name = str(fact.get("name") or "").lower()
        if "/" in name or "／" in name:
            continue
        if any(keyword in name for keyword in lowered):
            return fact
    return None


def _fact_value(fact: dict[str, Any] | None) -> float | None:
    if not fact:
        return None
    return _number(fact.get("value"))


def _fact_money(fact: dict[str, Any]) -> str:
    value = _fact_value(fact)
    if value is None:
        return "-"
    unit = str(fact.get("currency") or "").strip()
    prefix = ""
    if value < 0:
        prefix = "-"
    number = abs(value)
    if number >= 100_000_000:
        text = f"{prefix}{number / 100_000_000:.2f}亿"
    elif number >= 10_000:
        text = f"{prefix}{number / 10_000:.2f}万"
    else:
        text = f"{value:.2f}"
    return f"{text}{unit}" if unit and number < 10_000 else text


def _fact_yoy(fact: dict[str, Any]) -> str:
    value = _number(fact.get("yoy"))
    if value is None:
        return ""
    return f"(同比{value:+.1f}%)"


def _latest_news_title(row: dict[str, Any]) -> str:
    news_items = row.get("research_news_items")
    if not isinstance(news_items, list):
        return ""
    for item in news_items:
        if isinstance(item, dict):
            title = _compact_text(item.get("title"), max_chars=26)
            if title:
                return title
    return ""


def _sector_short(row: dict[str, Any]) -> str:
    industry = str(row.get("industry") or "").strip()
    if not industry:
        return "\u677f\u5757\u6570\u636e\u4e0d\u8db3"
    industry_line = _industry_context_line(row).replace("\u884c\u4e1a\u8054\u52a8\uff1a", "")
    return f"{industry}; {industry_line}" if industry_line else industry


def _breakout_text(row: dict[str, Any]) -> str:
    ratio = _number(row.get("breakout_volume_ratio_20") or row.get("volume_ratio_20") or row.get("volume_ratio"))
    if _truthy(row.get("breakout_over_60")) or _truthy(row.get("fresh_breakout_over_60")):
        if ratio is not None and ratio >= 1.5:
            return f"\u653e\u91cf\u7a81\u783460\u65e5\u524d\u9ad8, \u91cf\u6bd4{ratio:.1f}\u500d"
        return "\u7a81\u783460\u65e5\u524d\u9ad8"
    if ratio is not None and ratio >= 1.5:
        return f"\u653e\u91cf{ratio:.1f}\u500d"
    return ""


def _truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def _text_value(row: dict[str, Any], *names: str) -> str:
    for name in names:
        value = row.get(name)
        if value not in (None, ""):
            return str(value).strip()
    return ""


def _price_short(*, entry: float, ma5: float, ma60: float | None) -> str:
    parts = [f"\u7ad9\u4e0aMA5 {((entry / ma5 - 1) * 100):+.1f}%"]
    if ma60 is not None and ma60 > 0:
        parts.append(f"\u8f83MA60 {((entry / ma60 - 1) * 100):+.1f}%")
    return ", ".join(parts) + "; \u7ed3\u6784\u504f\u5f3a, \u4f46\u9760\u8fd1\u98ce\u63a7\u7ebf\u6267\u884c"


def _row_number(row: dict[str, Any], *names: str) -> float | None:
    for name in names:
        value = _number(row.get(name))
        if value is not None:
            return value
    return None


def _feature_number(row: dict[str, Any], name: str) -> float | None:
    snapshot = row.get("feature_snapshot")
    if isinstance(snapshot, dict):
        return _number(snapshot.get(name))
    return None


def _flow_text(value: float) -> str:
    return f"\u51c0\u6d41\u5165{_money_text(value)}" if value >= 0 else f"\u51c0\u6d41\u51fa{_money_text(abs(value))}"


def _money_text(value: float) -> str:
    number = abs(float(value))
    if number >= 100_000_000:
        return f"{number / 100_000_000:.2f}\u4ebf"
    if number >= 10_000:
        return f"{number / 10_000:.2f}\u4e07"
    return f"{number:.2f}"


def _context_lines(row: dict[str, Any]) -> list[str]:
    lines: list[str] = []
    industry = str(row.get("industry") or "").strip()
    if industry:
        lines.append(f"行业：{industry}")
    industry_line = _industry_context_line(row)
    if industry_line:
        lines.append(industry_line)
    profile = _compact_text(row.get("company_profile"), max_chars=56)
    if profile:
        lines.append(f"简介：{profile}")
    return lines


def _industry_context_line(row: dict[str, Any]) -> str:
    industry = str(row.get("industry") or "").strip()
    if not industry:
        return ""
    change_pct = _number(row.get("industry_change_pct"))
    up_ratio = _number(row.get("industry_up_ratio"))
    sample_count = row.get("industry_sample_count")
    linkage = str(row.get("industry_linkage") or "")
    if change_pct is None or up_ratio is None or sample_count in (None, ""):
        return "行业联动：暂无足够实时样本"
    linkage_text = {
        "sector_up_linkage": "行业整体上涨联动",
        "sector_down_linkage": "行业整体下跌联动",
        "mild_sector_support": "行业有一定支撑",
        "stock_specific_or_mixed": "偏个股异动",
        "insufficient_samples": "行业样本较少",
    }.get(linkage, "行业联动不明")
    return f"行业联动：{linkage_text}，均涨 {_fmt_signed(change_pct)}%，上涨占比 {_fmt_pct(up_ratio)}，样本 {sample_count} 只"


def _compact_text(value: Any, *, max_chars: int) -> str:
    text = " ".join(str(value or "").split())
    if not text:
        return ""
    return text if len(text) <= max_chars else f"{text[:max_chars]}..."


def _expected_return_note(value: Any) -> str:
    number = _number(value)
    if number is None:
        return ""
    if number < 0:
        return "（冲高回落风险）"
    return ""


def _fetch_industry_quote_rows(symbols: list[str], *, max_quote_age_minutes: int = 30) -> list[dict[str, Any]]:
    if not symbols:
        return []
    database = clickhouse_realtime._ident(clickhouse_realtime._database())
    min_quote_time = (datetime.now(SHANGHAI_TZ) - timedelta(minutes=max_quote_age_minutes)).strftime("%Y-%m-%d %H:%M:%S")
    try:
        return clickhouse_realtime._query_json_each_row(
            f"""
            select
              symbol,
              argMax(
                if(
                  change_percentage is not null,
                  change_percentage,
                  if(prev_close > 0, (last_done - prev_close) / prev_close * 100, null)
                ),
                snapshot_minute
              ) as change_pct
            from {database}.lb_realtime_quotes
            where symbol in {clickhouse_realtime._symbol_tuple(symbols)}
              and snapshot_minute >= parseDateTime64BestEffort('{min_quote_time}', 3, 'Asia/Shanghai')
              and (change_percentage is not null or (prev_close > 0 and last_done > 0))
            group by symbol
            """
        )
    except Exception:
        return []


def build_us_fast_sell_alerts(
    positions: Iterable[dict[str, Any]],
    latest_rows: Iterable[dict[str, Any]],
    *,
    now: datetime,
    config: USFastAlertConfig,
    recent_lots: dict[str, list[ExecutionLot]] | None = None,
) -> list[RealtimeAlert]:
    latest = {str(row.get("symbol")): row for row in latest_rows}
    alerts: list[RealtimeAlert] = []
    recent_lots = recent_lots or {}
    for position in positions:
        symbol = str(position.get("symbol") or "")
        row = latest.get(symbol, {})
        if not row:
            continue
        current_price = _number(row.get("entry_price"))
        probability = _number(row.get("profit_probability"))
        entry_price = _number(position.get("entry_price"))
        risk_line = _number(position.get("risk_line"))
        take_profit = _number(position.get("take_profit"))
        high_price = max(_number(position.get("high_price")) or 0.0, current_price or 0.0)
        expires_at = _parse_datetime(position.get("expires_at"))
        alert_type: str | None = None
        reason: str | None = None
        lot_alert = _build_us_fast_lot_rebound_exit_alert(position, row, recent_lots.get(symbol, []))
        if current_price is not None and take_profit is not None and current_price >= take_profit:
            alert_type = "us_fast_sell_take_profit"
            reason = "触及止盈价"
        elif current_price is not None and risk_line is not None and current_price <= risk_line:
            alert_type = "us_fast_sell_stop_loss"
            reason = "跌破风控线"
        elif lot_alert is not None:
            alerts.append(lot_alert)
            continue
        elif current_price is not None and high_price > 0 and current_price <= high_price * (1 - config.trailing_pullback):
            alert_type = "us_fast_sell_trailing_pullback"
            reason = "高位回撤触发"
        elif expires_at is not None and now >= expires_at:
            alert_type = "us_fast_sell_expired"
            reason = "3日观察窗口到期"
        if alert_type is None:
            continue
        name = str(position.get("name") or row.get("name") or symbol)
        display_name = _display_symbol_name(symbol, name)
        message = "\n".join(
            [
                f"【美股Fast风险/减仓提醒】{display_name}",
                f"原因：{reason}",
                f"入场价：{_fmt(entry_price)}",
                f"当前价：{_fmt(current_price)}",
                f"止盈价：{_fmt(take_profit)}",
                f"风控线：{_fmt(risk_line)}",
                f"当前概率：{_fmt_pct(probability)}",
                "处理：按风控减仓/退出观察，不当作做空信号。",
            ]
        )
        alerts.append(
            RealtimeAlert(
                alert_type=alert_type,
                symbol=symbol,
                market="US",
                name=name,
                title=f"美股Fast风险/减仓提醒 {display_name}",
                message=message,
                score=probability if probability is not None else 0.0,
                signal="us_fast_15",
            )
        )
    return alerts


def _build_us_fast_lot_rebound_exit_alert(
    position: dict[str, Any],
    row: dict[str, Any],
    lots: list[ExecutionLot],
) -> RealtimeAlert | None:
    symbol = str(position.get("symbol") or row.get("symbol") or "").strip().upper()
    if not symbol or not lots:
        return None
    current_price = _number(row.get("entry_price"))
    entry_price = _number(position.get("entry_price"))
    probability = _number(row.get("profit_probability"))
    if current_price is None or current_price <= 0:
        return None
    actionable_lots = [
        lot
        for lot in lots
        if lot.symbol == symbol and lot.quantity > 0 and lot.price > 0 and current_price >= lot.price * 0.995
    ]
    if not actionable_lots:
        return None
    weak_context = (
        (entry_price is not None and current_price < entry_price)
        or (probability is not None and probability < 0.70)
        or str(row.get("decision") or "") != "buy_zone"
    )
    if not weak_context:
        return None
    name = str(position.get("name") or row.get("name") or symbol)
    display_name = _display_symbol_name(symbol, name)
    lot_text = ", ".join(f"{lot.price:.2f} x{lot.quantity:g}" for lot in sorted(actionable_lots, key=lambda item: item.price))
    pnl_text = "-" if entry_price is None else f"{(current_price / entry_price - 1) * 100:+.2f}%"
    message = "\n".join(
        [
            f"[US Fast lot rebound exit] {display_name}",
            f"Current: {_fmt(current_price)}  tracked entry: {_fmt(entry_price)}  tracked P/L: {pnl_text}",
            f"Near breakeven lots: {lot_text}",
            f"Current probability: {_fmt_pct(probability)}",
            "Action: trim these rebound lots first; do not average down until the model and price structure recover.",
        ]
    )
    return RealtimeAlert(
        alert_type="us_fast_sell_lot_rebound_exit",
        symbol=symbol,
        market="US",
        name=name,
        title=f"美股Fast批次减亏 {display_name}",
        message=message,
        score=0.84 if probability is None else min(0.84, probability),
        signal="us_fast_15",
    )


def get_recent_execution_lots(symbols: Iterable[str], lookback_days: int) -> dict[str, list[ExecutionLot]]:
    if lookback_days <= 0:
        return {}
    wanted = {str(symbol).strip().upper() for symbol in symbols if str(symbol).strip()}
    if not wanted:
        return {}
    from longbridge import openapi as sdk

    _ensure_longbridge_env()
    ctx = sdk.TradeContext(sdk.Config.from_env())
    now = datetime.now()
    start_at = now - timedelta(days=lookback_days)
    rows = [*list(ctx.today_executions() or []), *list(ctx.history_executions(start_at=start_at, end_at=now) or [])]
    lots: dict[str, list[ExecutionLot]] = {symbol: [] for symbol in wanted}
    seen: set[tuple[str, str, str, float, float]] = set()
    for item in rows:
        lot = execution_lot_from_sdk(item)
        if lot is None or lot.symbol not in wanted:
            continue
        dedupe_key = (lot.symbol, lot.time, str(getattr(item, "trade_id", "")), lot.quantity, lot.price)
        if dedupe_key in seen:
            continue
        seen.add(dedupe_key)
        lots.setdefault(lot.symbol, []).append(lot)
    for symbol_lots in lots.values():
        symbol_lots.sort(key=lambda lot: lot.time, reverse=True)
    return {symbol: symbol_lots for symbol, symbol_lots in lots.items() if symbol_lots}


def execution_lot_from_sdk(item: Any) -> ExecutionLot | None:
    data = item if isinstance(item, dict) else item.to_dict() if hasattr(item, "to_dict") else dict(vars(item)) if hasattr(item, "__dict__") else {}

    def value(name: str) -> Any:
        return data.get(name) if data else getattr(item, name, None)

    symbol = str(value("symbol") or "").strip().upper()
    side = str(value("side") or value("trade_side") or "").lower()
    if not symbol or "buy" not in side:
        return None
    quantity = _number(value("quantity") or value("executed_quantity"))
    price = _number(value("price") or value("executed_price"))
    if quantity is None or price is None or quantity <= 0 or price <= 0:
        return None
    trade_time = value("trade_done_at") or value("trade_time") or value("created_at")
    time_text = trade_time.isoformat() if hasattr(trade_time, "isoformat") else str(trade_time or "")
    return ExecutionLot(symbol=symbol, quantity=quantity, price=price, time=time_text)


def _ensure_longbridge_env() -> None:
    if os.getenv("LONGBRIDGE_APP_KEY"):
        return
    candidates = [
        Path(".longbridge-openapi.env"),
        Path("/home/alwin/apps/longbridge-stock/.longbridge-openapi.env"),
    ]
    for path in candidates:
        if not path.exists():
            continue
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip() or line.lstrip().startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip().strip("'\""))
        if os.getenv("LONGBRIDGE_APP_KEY"):
            return


def _active_positions(state: AlertState) -> list[dict[str, Any]]:
    positions = getattr(state, "_data", {}).get("us_fast_positions", {})
    if not isinstance(positions, dict):
        return []
    return [position for position in positions.values() if isinstance(position, dict) and position.get("source") == "actual_holding"]


def _fetch_stock_tag_summaries(symbols: Iterable[str]) -> dict[str, dict[str, Any]]:
    symbol_list = [str(symbol).strip().upper() for symbol in symbols if str(symbol).strip()]
    if not symbol_list:
        return {}
    try:
        payload = build_stock_tags(symbol_list, lookback_days=60)
    except Exception:
        return {}
    items = payload.get("items") if isinstance(payload, dict) else []
    return {
        str(item.get("symbol") or "").strip().upper(): item
        for item in items if isinstance(item, dict) and str(item.get("symbol") or "").strip()
    }


def _stock_tag_lines(item: dict[str, Any] | None) -> list[str]:
    if not item:
        return []
    advice = item.get("tradeAdvice") if isinstance(item.get("tradeAdvice"), dict) else {}
    intraday = item.get("intraday") if isinstance(item.get("intraday"), dict) else {}
    capital = item.get("capitalFlow") if isinstance(item.get("capitalFlow"), dict) else {}
    price_zone = advice.get("priceZone") if isinstance(advice.get("priceZone"), dict) else {}
    technical = _compact_tag_technical(intraday)
    action = str(advice.get("action") or "-")
    confidence = advice.get("confidence", "-")
    capital_state = str(capital.get("state") or intraday.get("intradayCapital") or "-")
    risk_line = _fmt(price_zone.get("riskLine"))
    reason = str(advice.get("reason") or "-")
    return [
        f"标签：{action}｜置信度 {confidence}｜资金 {capital_state}｜技术 {technical}",
        f"标签原因：{reason}｜风险线 {risk_line}",
    ]


def _compact_tag_technical(intraday: dict[str, Any]) -> str:
    tags = intraday.get("tags") if isinstance(intraday.get("tags"), dict) else {}
    macd = str(tags.get("macdState") or "")
    trend = str(intraday.get("intradayTrendState") or "")
    parts = [part for part in [macd, trend] if part and part != "MACD数据不足"]
    return "，".join(parts) if parts else "-"


def _display_symbol_name(symbol: str, name: str) -> str:
    normalized_symbol = symbol.strip()
    normalized_name = name.strip()
    if not normalized_name or normalized_name.upper() == normalized_symbol.upper():
        return normalized_symbol
    return f"{normalized_symbol} {normalized_name}"


def _is_excluded_us_fast_instrument(symbol: str, name: str) -> bool:
    text = f"{symbol} {name}".upper()
    leveraged_terms = (
        "DIREXION",
        "PROSHARES ULTRA",
        "ULTRAPRO",
        "2X",
        "3X",
        "BULL 2X",
        "BULL 3X",
        "BEAR 2X",
        "BEAR 3X",
        "LEVERAGED",
        "INVERSE",
    )
    return any(term in text for term in leveraged_terms)


def _drop_expired_positions_without_latest_quote(state: AlertState, rows: Iterable[dict[str, Any]], now: datetime) -> None:
    latest_symbols = {str(row.get("symbol") or "") for row in rows if row.get("symbol")}
    data = getattr(state, "_data", {})
    positions = data.get("us_fast_positions", {})
    if not isinstance(positions, dict):
        return
    removed = False
    for symbol, position in list(positions.items()):
        if str(symbol) in latest_symbols:
            continue
        expires_at = _parse_datetime(position.get("expires_at")) if isinstance(position, dict) else None
        if expires_at is not None and now >= expires_at:
            positions.pop(symbol, None)
            removed = True
    if removed:
        state._save()


def _apply_alert_state(
    state: AlertState,
    alert: RealtimeAlert,
    rows: Iterable[dict[str, Any]],
    now: datetime,
    config: USFastAlertConfig,
) -> None:
    data = getattr(state, "_data", {})
    positions = data.setdefault("us_fast_positions", {})
    if alert.alert_type == "us_fast_buy":
        return
    elif alert.alert_type.startswith("us_fast_sell_"):
        positions.pop(alert.symbol, None)
    save = getattr(state, "_save", None)
    if callable(save):
        save()


def _connect(dsn: str):
    import psycopg

    conn = psycopg.connect(dsn)
    conn.execute("set statement_timeout = '10s'")
    conn.execute("set lock_timeout = '3s'")
    return conn


def _parse_datetime(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        return value
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=SHANGHAI_TZ)


def _to_iso(value: Any) -> str | None:
    if isinstance(value, datetime):
        return value.isoformat()
    return str(value) if value is not None else None


def _number(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _payload_dict(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return dict(value)
    if not value:
        return {}
    try:
        parsed = json.loads(str(value))
    except (TypeError, ValueError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _json_list(value: Any) -> list[Any]:
    if isinstance(value, list):
        return value
    if not value:
        return []
    try:
        parsed = json.loads(str(value))
    except (TypeError, ValueError):
        return []
    return parsed if isinstance(parsed, list) else []


def _fmt(value: Any) -> str:
    number = _number(value)
    return "-" if number is None else f"{number:.2f}"


def _fmt_signed(value: Any) -> str:
    number = _number(value)
    return "-" if number is None else f"{number:+.2f}"


def _fmt_pct(value: Any, *, digits: int = 1) -> str:
    number = _number(value)
    return "-" if number is None else f"{number * 100:.{digits}f}%"


def build_default_us_fast_monitor(
    *,
    dsn: str,
    config: USFastAlertConfig,
    state_path: str = DEFAULT_STATE_PATH,
    targets: str | None = None,
) -> USFastAlertMonitor:
    return USFastAlertMonitor(
        dsn=dsn,
        config=config,
        notifier=build_default_notifier(targets),
        state=AlertState(state_path),
    )

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from math import isfinite
from typing import Any

import pandas as pd


def build_stock_research(row: dict[str, Any], snapshot: dict[str, Any] | None = None) -> dict[str, Any]:
    snapshot = snapshot or {}
    symbol = _text(row.get("symbol")) or "-"
    name = _text(row.get("name")) or symbol
    as_of = _text(snapshot.get("asOf")) or _date_string(row.get("score_date"))
    news_items = _list(snapshot.get("newsItems"))
    hotspots = [_text(item) for item in _list(snapshot.get("hotspots")) if _text(item)]

    is_llm = bool(_text(snapshot.get("llmSummary")))
    sections = [
        {"key": "companyProfile", "title": "公司画像", "text": _company_profile_text(row, name, snapshot)},
        {"key": "whySelected", "title": "为什么入选", "text": _why_selected_text(row, name)},
        {"key": "financials", "title": "财报支持", "text": _financial_text(row, snapshot)},
        {"key": "newsHotspots", "title": "最近新闻/热点", "text": _news_hotspot_text(news_items, hotspots)},
        {"key": "technical", "title": "技术走势", "text": _technical_text(row)},
        {"key": "risks", "title": "主要风险", "text": _risk_text(row)},
    ]
    if not is_llm:
        sections.append({"key": "conclusion", "title": "结论", "text": _conclusion_text(row, name, snapshot)})

    return {
        "asOf": as_of,
        "summary": _summary_text(row, name, snapshot),
        "sections": sections,
        "sources": _sources(news_items, _list(snapshot.get("sources"))),
        "symbol": symbol,
        "source": "llm" if is_llm else "fallback",
    }


def _summary_text(row: dict[str, Any], name: str, snapshot: dict[str, Any]) -> str:
    summary = _text(snapshot.get("llmSummary"))
    if summary:
        return summary
    symbol = _text(row.get("symbol")) or name
    market = (_text(row.get("market")) or "未知市场").upper()
    business = _business_text(snapshot)
    leadership = _leadership_text(row, snapshot)
    return f"{symbol} 是 {market} 市场股票。{business}。{leadership}。当前还没有完整 LLM 财报、新闻和热点报告，以下先用公司画像、财务指标和量化模型信号做第一层判断。"


def _company_profile_text(row: dict[str, Any], name: str, snapshot: dict[str, Any]) -> str:
    market = (_text(row.get("market")) or "未知市场").upper()
    symbol = _text(row.get("symbol")) or name
    business = _business_text(snapshot)
    leadership = _leadership_text(row, snapshot)
    moat = _text(snapshot.get("moat")) or _text(snapshot.get("competitiveAdvantage"))
    if not moat:
        quality = _number(row.get("quality_score"))
        model_score = _number(row.get("model_score"))
        if quality is not None and quality >= 70:
            moat = "质量分较高，说明盈利质量或经营稳定性在当前股票池里相对靠前。"
        elif model_score is not None and model_score >= 70:
            moat = "模型分较高，说明 Qlib 当前对其后续相对收益给出较强信号。"
        else:
            moat = "稀缺性和核心技术能力暂未被结构化资料确认，需要继续补充财报、公告和行业新闻。"
    return f"{name}（{symbol}）是一家 {market} 市场上市公司。主营业务：{business}。行业地位：{leadership}。核心能力/稀缺性：{moat}"


def _business_text(snapshot: dict[str, Any]) -> str:
    for key in ("business", "mainBusiness", "businessSummary", "companyBusiness"):
        value = _text(snapshot.get(key))
        if value:
            return value
    profile = snapshot.get("companyProfile")
    if isinstance(profile, dict):
        for key in ("business", "mainBusiness", "description"):
            value = _text(profile.get(key))
            if value:
                return value
    return "主营业务资料尚未补齐，系统需要继续抓取公司简介、财报和公告来确认具体业务结构"


def _leadership_text(row: dict[str, Any], snapshot: dict[str, Any]) -> str:
    for key in ("leadership", "industryPosition", "marketPosition"):
        value = _text(snapshot.get(key))
        if value:
            return value
    profile = snapshot.get("companyProfile")
    if isinstance(profile, dict):
        for key in ("leadership", "industryPosition", "marketPosition"):
            value = _text(profile.get(key))
            if value:
                return value
    total = _number(row.get("total_score"))
    quality = _number(row.get("quality_score"))
    market_value = _number(row.get("market_value"))
    if market_value is not None and market_value >= 100_000_000_000:
        return "市值规模较大，具备龙头候选线索，但仍需结合行业份额和财报验证"
    if total is not None and total >= 80:
        return "综合评分靠前，具备重点观察价值，但不能直接等同于行业龙头"
    if quality is not None and quality >= 75:
        return "质量分较高，具备优质公司候选线索，但龙头地位仍需外部资料确认"
    return "是否为龙头企业暂未被结构化资料确认，需要继续补充行业排名、市场份额和核心产品信息"


def _unused_legacy_summary_text(row: dict[str, Any], name: str, snapshot: dict[str, Any]) -> str:
    score = _number(row.get("total_score"))
    score_text = f"综合分 {score:g}" if score is not None else "综合分待确认"
    return f"{name} 当前入选主要来自模型分、趋势结构和基本面质量的共同确认，{score_text}。"


def _why_selected_text(row: dict[str, Any], name: str) -> str:
    score = _number(row.get("total_score"))
    strategy_score = _number(row.get("trend_compounder_score")) or _number(row.get("early_signal_score")) or score
    decision = _text(row.get("decision")) or "候选"
    parts = [f"{name} 当前状态为{decision}"]
    if score is not None:
        parts.append(f"综合分 {score:g}")
    if strategy_score is not None and strategy_score != score:
        parts.append(f"策略分 {strategy_score:g}")
    return "，".join(parts) + "。这部分先回答“为什么它会被系统选出来”，后面再拆成财报、热点、走势和风险。"


def _financial_text(row: dict[str, Any], snapshot: dict[str, Any]) -> str:
    summary = _text(snapshot.get("financialSummary"))
    if summary:
        return summary

    metrics: list[str] = []
    for key, label, suffix in [
        ("pe", "PE", ""),
        ("pb", "PB", ""),
        ("roe", "ROE", "%"),
        ("net_margin", "净利率", "%"),
        ("liabilities_assets", "资产负债率", "%"),
    ]:
        value = _number(row.get(key))
        if value is not None:
            metrics.append(f"{label} {value:g}{suffix}")
    market_value = _number(row.get("market_value"))
    if market_value is not None:
        metrics.append(f"市值约 {_human_money(market_value)}")
    quality = _number(row.get("quality_score"))
    valuation = _number(row.get("valuation_score"))
    if quality is not None:
        metrics.append(f"质量分 {quality:g}")
    if valuation is not None:
        metrics.append(f"估值分 {valuation:g}")
    if not metrics:
        return "当前没有缓存的财报摘要，系统先用质量分、估值分和行情模型做第一层判断，建议后续补充最新年报/季报。"
    return "当前可用财务指标：" + "，".join(metrics) + "。需要结合最近一期财报正文继续确认收入增长、盈利能力和现金流质量。"


def _news_hotspot_text(news_items: list[Any], hotspots: list[str]) -> str:
    summaries = []
    for item in news_items[:3]:
        if isinstance(item, dict):
            text = _text(item.get("summary")) or _text(item.get("title"))
            if text:
                summaries.append(text)
    hotspot_text = "、".join(hotspots[:5])
    if summaries and hotspot_text:
        return "；".join(summaries) + f"。当前关联热点：{hotspot_text}。"
    if summaries:
        return "；".join(summaries)
    if hotspot_text:
        return f"当前关联热点：{hotspot_text}。暂无缓存新闻正文，需要补充最近公告、媒体报道和行业催化。"
    return "暂无缓存新闻和热点，当前解释主要来自财报指标、行情走势和模型信号；建议补充最近公告和行业新闻后再复核。"


def _technical_text(row: dict[str, Any]) -> str:
    five_day = _number(row.get("five_day_change_rate"))
    ten_day = _number(row.get("ten_day_change_rate"))
    half_year = _number(row.get("half_year_change_rate"))
    model_score = _number(row.get("model_score"))
    model_reason = _text(row.get("model_reason")) or "暂无模型说明"
    pieces = [
        f"5日涨幅 {_fmt(five_day)}",
        f"10日涨幅 {_fmt(ten_day)}",
        f"半年涨幅 {_fmt(half_year)}",
    ]
    if model_score is not None:
        pieces.append(f"模型分 {model_score:g}")
    return "，".join(pieces) + f"。模型备注：{model_reason}。"


def _risk_text(row: dict[str, Any]) -> str:
    risks: list[str] = []
    half_year = _number(row.get("half_year_change_rate"))
    five_day = _number(row.get("five_day_change_rate"))
    valuation = _number(row.get("valuation_score"))
    liabilities = _number(row.get("liabilities_assets"))
    if half_year is not None and half_year > 80:
        risks.append("半年涨幅偏高，追高风险需要重点控制")
    if five_day is not None and five_day > 12:
        risks.append("短线涨幅过快，容易出现回撤")
    if valuation is not None and valuation < 45:
        risks.append("估值分偏低，说明安全边际不足")
    if liabilities is not None and liabilities > 65:
        risks.append("资产负债率偏高")
    if not risks:
        risks.append("目前没有触发明显的量化风险红灯，但仍需关注财报兑现、行业景气和市场波动")
    return "；".join(risks) + "。"


def _conclusion_text(row: dict[str, Any], name: str, snapshot: dict[str, Any]) -> str:
    if _text(snapshot.get("llmSummary")):
        return f"{name} 可以进入观察或候选池，但买点仍要结合日K形态、成交量和最新消息确认。"
    return f"{name} 的第一层结论来自量化评分。由于新闻和财报摘要还不完整，当前更适合作为观察对象，不建议只凭分数直接追入。"


def _sources(news_items: list[Any], sources: list[Any]) -> list[dict[str, str]]:
    result: list[dict[str, str]] = []
    for item in news_items:
        if not isinstance(item, dict):
            continue
        title = _text(item.get("title"))
        if not title:
            continue
        result.append(
            {
                "title": title,
                "url": _text(item.get("url")),
                "source": _text(item.get("source")),
                "publishedAt": _text(item.get("publishedAt")),
                "type": "news",
            }
        )
    for item in sources:
        if not isinstance(item, dict):
            continue
        title = _text(item.get("title"))
        if not title:
            continue
        result.append(
            {
                "title": title,
                "url": _text(item.get("url")),
                "source": _text(item.get("source")),
                "publishedAt": _text(item.get("publishedAt")),
                "type": _text(item.get("type")) or "source",
            }
        )
    return result


def _list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except (TypeError, ValueError):
        pass
    return str(value)


def _number(value: Any) -> float | None:
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(value, Decimal):
        value = float(value)
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return round(number, 2) if isfinite(number) else None


def _fmt(value: float | None) -> str:
    return "-" if value is None else f"{value:g}"


def _date_string(value: Any) -> str:
    if value is None:
        return "-"
    try:
        if pd.isna(value):
            return "-"
    except (TypeError, ValueError):
        pass
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    return str(value)


def _human_money(value: float) -> str:
    abs_value = abs(value)
    if abs_value >= 100_000_000:
        return f"{value / 100_000_000:.2f}亿"
    if abs_value >= 10_000:
        return f"{value / 10_000:.2f}万"
    return f"{value:g}"

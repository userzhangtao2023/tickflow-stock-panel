from __future__ import annotations

import dataclasses
import time
from datetime import date, datetime
from decimal import Decimal
from enum import Enum
from typing import Any

from longbridge_stock.longbridge_sync import RateLimiter


_SDK_OBJECT_FIELDS: dict[str, tuple[str, ...]] = {
    "SecurityQuote": (
        "symbol",
        "last_done",
        "prev_close",
        "prev_close_price",
        "open",
        "high",
        "low",
        "timestamp",
        "volume",
        "turnover",
        "trade_status",
        "pre_market_quote",
        "post_market_quote",
    ),
    "CapitalDistributionResponse": ("timestamp", "capital_in", "capital_out"),
    "CapitalDistribution": ("large", "medium", "small"),
    "CapitalFlowLine": ("timestamp", "time", "inflow"),
    "SecurityDepth": ("asks", "bids"),
    "Depth": ("position", "price", "volume", "order_num"),
    "SecurityBrokers": ("ask_brokers", "bid_brokers"),
    "Brokers": ("position", "broker_ids"),
    "Trade": ("price", "volume", "timestamp", "trade_type", "direction", "trade_session"),
    "IntradayLine": ("price", "timestamp", "volume", "turnover", "avg_price"),
    "Candlestick": ("close", "open", "low", "high", "volume", "turnover", "timestamp"),
}


class LongbridgeSdkClient:
    """Thin adapter around the official Longbridge Python SDK.

    The rest of the project stores plain dictionaries from the old CLI client.
    This adapter keeps that boundary stable so sync jobs can migrate one by one.
    """

    def __init__(self, rate_limit_per_second: float = 5.0, config: Any | None = None, ctx: Any | None = None) -> None:
        self.rate_limiter = RateLimiter(rate_limit_per_second)
        if ctx is not None:
            self.ctx = ctx
            self._sdk = None
            return
        try:
            from longbridge import openapi as sdk
        except ImportError as exc:  # pragma: no cover - depends on runtime package install
            raise RuntimeError("longbridge SDK is not installed; run `pip install longbridge`.") from exc
        self._sdk = sdk
        self.ctx = sdk.QuoteContext(config or _sdk_config_from_env(sdk))
        self.http = sdk.HttpClient.from_env() if hasattr(sdk, "HttpClient") else None

    def quote(self, symbol: str) -> Any:
        rows = self.quote_many([symbol])
        return rows[0] if isinstance(rows, list) and len(rows) == 1 else rows

    def quote_many(self, symbols: list[str]) -> list[dict[str, Any]]:
        if not symbols:
            return []
        self.rate_limiter.wait()
        return _normalize_payload(self.ctx.quote(symbols))

    def kline(self, symbol: str, count: int, period: str = "day", adjust: str = "forward") -> list[dict[str, Any]]:
        self.rate_limiter.wait()
        sdk = self._sdk
        if sdk is None:
            return _normalize_payload(self.ctx.candlesticks(symbol, period, count, adjust))
        sdk_period = _sdk_period(sdk, period)
        sdk_adjust = _sdk_adjust_type(sdk, adjust)
        rows = self.ctx.candlesticks(symbol, sdk_period, count, sdk_adjust)
        return _normalize_payload(rows)

    def kline_no_adjust(self, symbol: str, count: int, period: str = "day") -> list[dict[str, Any]]:
        return self.kline(symbol, count=count, period=period, adjust="none")

    def kline_forward_adjust(self, symbol: str, count: int, period: str = "day") -> list[dict[str, Any]]:
        return self.kline(symbol, count=count, period=period, adjust="forward")

    def static(self, symbol: str) -> Any:
        self.rate_limiter.wait()
        rows = _normalize_payload(self.ctx.static_info([symbol]))
        return rows[0] if isinstance(rows, list) and len(rows) == 1 else rows

    def capital(self, symbol: str) -> dict[str, Any]:
        self.rate_limiter.wait()
        return _normalize_payload(self.ctx.capital_distribution(symbol))

    def capital_flow(self, symbol: str) -> list[dict[str, Any]]:
        self.rate_limiter.wait()
        return _normalize_payload(self.ctx.capital_flow(symbol))

    def depth(self, symbol: str) -> dict[str, Any]:
        self.rate_limiter.wait()
        return _normalize_payload(self.ctx.depth(symbol))

    def trades(self, symbol: str, count: int = 100) -> list[dict[str, Any]]:
        self.rate_limiter.wait()
        return _normalize_payload(self.ctx.trades(symbol, count))

    def intraday(self, symbol: str) -> list[dict[str, Any]]:
        self.rate_limiter.wait()
        return _normalize_payload(self.ctx.intraday(symbol))

    def market_temperature(self, market: str) -> dict[str, Any]:
        if self.http is None:
            raise RuntimeError("longbridge SDK HttpClient is not available.")
        self.rate_limiter.wait()
        return _normalize_payload(self.http.request("GET", f"/v1/quote/market_temperature?market={market.upper()}"))


def _sdk_period(sdk: Any, period: str) -> Any:
    period_key = period.lower()
    mapping = {
        "day": ("Day", "DAY"),
        "week": ("Week", "WEEK"),
        "month": ("Month", "MONTH"),
        "1m": ("Min_1", "Min1", "MIN_1"),
        "5m": ("Min_5", "Min5", "MIN_5"),
        "15m": ("Min_15", "Min15", "MIN_15"),
        "30m": ("Min_30", "Min30", "MIN_30"),
        "60m": ("Min_60", "Min60", "MIN_60"),
    }
    for name in mapping.get(period_key, ("Day", "DAY")):
        value = getattr(sdk.Period, name, None)
        if value is not None:
            return value
    return getattr(sdk.Period, "Day", getattr(sdk.Period, "DAY", period))


def _sdk_adjust_type(sdk: Any, adjust: str) -> Any:
    if adjust.lower() in {"none", "no", "no_adjust", "noadjust"}:
        return getattr(sdk.AdjustType, "NoAdjust", None)
    return (
        getattr(sdk.AdjustType, "ForwardAdjust", None)
        or getattr(sdk.AdjustType, "Forward", None)
        or getattr(sdk.AdjustType, "NoAdjust", None)
    )


def _normalize_payload(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, Enum):
        return value.name
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, (time.struct_time,)):
        return time.strftime("%Y-%m-%d %H:%M:%S", value)
    if dataclasses.is_dataclass(value):
        return {key: _normalize_payload(val) for key, val in dataclasses.asdict(value).items()}
    if isinstance(value, dict):
        return {str(key): _normalize_payload(val) for key, val in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_normalize_payload(item) for item in value]
    if hasattr(value, "to_dict"):
        return _normalize_payload(value.to_dict())
    if hasattr(value, "__dict__"):
        return {key: _normalize_payload(val) for key, val in vars(value).items() if not key.startswith("_")}
    attrs = _public_object_attrs(value)
    if attrs:
        return attrs
    return str(value)


def _public_object_attrs(value: Any) -> dict[str, Any]:
    """Extract fields from SDK extension objects that expose attributes only."""
    field_names = _SDK_OBJECT_FIELDS.get(type(value).__name__)
    if field_names is None:
        return {}
    attrs: dict[str, Any] = {}
    for key in field_names:
        try:
            attr = getattr(value, key)
        except Exception:
            continue
        if callable(attr):
            continue
        attrs[key] = _normalize_payload(attr)
    return attrs


def _sdk_config_from_env(sdk: Any) -> Any:
    if hasattr(sdk.Config, "from_apikey_env"):
        return sdk.Config.from_apikey_env()
    if hasattr(sdk.Config, "from_env"):
        return sdk.Config.from_env()
    raise RuntimeError("longbridge SDK Config does not support environment-based initialization.")

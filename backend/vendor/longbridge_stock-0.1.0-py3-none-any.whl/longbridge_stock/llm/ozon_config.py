from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any
from urllib.request import urlopen


DEFAULT_MODEL_CONFIG_BASE_URL = "http://192.168.10.23:1820/wm-api"
DEFAULT_RUNTIME_PRESETS_URL = "http://192.168.10.23:8800/api/model-presets"


@dataclass(frozen=True)
class ModelPreset:
    id: str
    label: str
    model: str
    provider: str
    base_url: str
    has_api_key: bool


@dataclass(frozen=True)
class OzonOptimizationModelConfig:
    text_base_url: str
    text_model: str
    text_preset_id: str
    text_api_key_configured: bool
    image_base_url: str
    image_model: str
    image_preset_id: str
    image_mode: str
    image_api_key_configured: bool
    presets: list[ModelPreset]


class OzonModelConfigClient:
    """Read the shared model configuration from the Ozon operations backend.

    The backend intentionally returns masked API key status only, not the raw key.
    Use this client for model/base-url/preset reuse. Actual LLM calls still need
    a local API key env var or a future backend proxy endpoint.
    """

    def __init__(
        self,
        base_url: str = DEFAULT_MODEL_CONFIG_BASE_URL,
        timeout: float = 10.0,
        runtime_presets_url: str | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.runtime_presets_url = runtime_presets_url or os.getenv("MODEL_PRESETS_URL") or DEFAULT_RUNTIME_PRESETS_URL

    def load(self) -> OzonOptimizationModelConfig:
        config_payload = self._get_json("/api/ozon/optimization/model-config")
        presets_payload = self._get_json("/api/ozon/optimization/model-presets")
        config = config_payload.get("config") or {}
        text = config.get("text") or {}
        image = config.get("image") or {}
        return OzonOptimizationModelConfig(
            text_base_url=str(text.get("base_url") or config.get("base_url") or ""),
            text_model=str(text.get("model") or ""),
            text_preset_id=str(text.get("preset_id") or ""),
            text_api_key_configured=bool((text.get("api_key") or {}).get("configured")),
            image_base_url=str(image.get("base_url") or config.get("base_url") or ""),
            image_model=str(image.get("model") or ""),
            image_preset_id=str(image.get("preset_id") or ""),
            image_mode=str(image.get("mode") or "generations"),
            image_api_key_configured=bool((image.get("api_key") or {}).get("configured")),
            presets=[_preset_from_raw(item) for item in presets_payload.get("presets", [])],
        )

    def _get_json(self, path: str) -> dict[str, Any]:
        with urlopen(f"{self.base_url}{path}", timeout=self.timeout) as response:
            payload = response.read().decode("utf-8")
        data = json.loads(payload)
        if not isinstance(data, dict):
            raise ValueError(f"Unexpected response from {path}")
        return data

    def runtime_api_key(self, preset_id: str) -> str:
        if not preset_id:
            return ""
        with urlopen(self.runtime_presets_url, timeout=self.timeout) as response:
            payload = response.read().decode("utf-8")
        data = json.loads(payload)
        presets = data.get("presets", data) if isinstance(data, dict) else data
        if not isinstance(presets, list):
            return ""
        for item in presets:
            if not isinstance(item, dict):
                continue
            if str(item.get("id") or "") == preset_id:
                return str(item.get("apiKey") or item.get("api_key") or "")
        return ""


def _preset_from_raw(raw: dict[str, Any]) -> ModelPreset:
    return ModelPreset(
        id=str(raw.get("id") or ""),
        label=str(raw.get("label") or raw.get("model") or ""),
        model=str(raw.get("model") or ""),
        provider=str(raw.get("provider") or ""),
        base_url=str(raw.get("baseUrl") or raw.get("base_url") or ""),
        has_api_key=bool(raw.get("hasApiKey") or raw.get("has_api_key")),
    )

from __future__ import annotations

import os
from dataclasses import dataclass
import json
from typing import Any
from urllib import request

from longbridge_stock.llm.ozon_config import OzonModelConfigClient


@dataclass(frozen=True)
class LLMConfig:
    model: str = os.getenv("LONG_BRIDGE_STOCK_LLM_MODEL", "gpt-5.5")
    base_url: str | None = os.getenv("OPENAI_BASE_URL") or None
    api_key: str | None = os.getenv("OPENAI_API_KEY") or None
    timeout_seconds: float = float(os.getenv("LONG_BRIDGE_STOCK_LLM_TIMEOUT_SECONDS", "120"))


class LLMClient:
    """Small OpenAI-compatible wrapper reserved for factor generation workflows."""

    def __init__(self, config: LLMConfig | None = None, fallback_configs: list[LLMConfig] | None = None) -> None:
        self.config = config or LLMConfig()
        self.fallback_configs = fallback_configs or []

    @classmethod
    def from_ozon_config(cls, api_key: str | None = None) -> "LLMClient":
        """Create a text LLM client from the shared Ozon model settings.

        The Ozon config endpoint does not expose the raw API key, so callers
        should pass one explicitly or provide OPENAI_API_KEY in the environment.
        """
        ozon = OzonModelConfigClient()
        shared = ozon.load()
        resolved_api_key = api_key or os.getenv("OPENAI_API_KEY") or None
        if not resolved_api_key and shared.text_preset_id and shared.text_api_key_configured:
            resolved_api_key = ozon.runtime_api_key(shared.text_preset_id) or None
        primary = LLMConfig(
            model=shared.text_model or os.getenv("LONG_BRIDGE_STOCK_LLM_MODEL", "gpt-5.5"),
            base_url=shared.text_base_url or None,
            api_key=resolved_api_key,
        )
        fallback_configs = _ozon_fallback_configs(
            ozon,
            shared.presets,
            primary=primary,
        )
        return cls(primary, fallback_configs=fallback_configs)

    def complete(self, prompt: str) -> str:
        configs = [self.config, *self.fallback_configs]
        errors: list[str] = []
        for index, config in enumerate(configs):
            try:
                return _complete_once(config, prompt)
            except Exception as exc:
                errors.append(f"{config.model}@{config.base_url or 'default'}: {exc}")
                if index == len(configs) - 1:
                    raise RuntimeError("LLM request failed: " + " | ".join(errors)) from exc
        return ""


def _ozon_fallback_configs(
    ozon: OzonModelConfigClient,
    presets: list[Any],
    *,
    primary: LLMConfig,
) -> list[LLMConfig]:
    preferred = [
        item.strip()
        for item in os.getenv(
            "LONG_BRIDGE_STOCK_LLM_FALLBACK_PRESETS",
            "gpt-5.4-mini,NewAPI-gpt-5.4,deepseek-v4-flash,NewAPI-gpt-5.5",
        ).split(",")
        if item.strip()
    ]
    by_id = {str(getattr(item, "id", "") or ""): item for item in presets}
    fallback_configs: list[LLMConfig] = []
    seen = {(primary.model, (primary.base_url or "").rstrip("/"))}
    for preset_id in preferred:
        preset = by_id.get(preset_id)
        if preset is None:
            continue
        model = str(getattr(preset, "model", "") or "")
        base_url = str(getattr(preset, "base_url", "") or "").rstrip("/")
        if not model or not base_url or (model, base_url) in seen:
            continue
        key = ozon.runtime_api_key(preset_id) or None
        if not key:
            continue
        fallback_configs.append(
            LLMConfig(
                model=model,
                base_url=base_url,
                api_key=key,
                timeout_seconds=primary.timeout_seconds,
            )
        )
        seen.add((model, base_url))
    return fallback_configs


def _complete_once(config: LLMConfig, prompt: str) -> str:
    if not config.api_key:
        raise RuntimeError("OPENAI_API_KEY is required for LLMClient")
    base_url = (config.base_url or "https://api.openai.com/v1").rstrip("/")
    payload = json.dumps(
        {
            "model": config.model,
            "messages": [{"role": "user", "content": prompt}],
        },
        ensure_ascii=False,
    ).encode("utf-8")
    req = request.Request(
        f"{base_url}/chat/completions",
        data=payload,
        method="POST",
        headers={
            "Authorization": f"Bearer {config.api_key}",
            "Content-Type": "application/json; charset=utf-8",
        },
    )
    try:
        with request.urlopen(req, timeout=config.timeout_seconds) as response:
            raw = response.read().decode("utf-8")
    except Exception as exc:
        raise RuntimeError(str(exc)) from exc
    data = json.loads(raw)
    return _extract_text(data)


def _extract_text(data: dict[str, Any]) -> str:
    choices = data.get("choices")
    if isinstance(choices, list) and choices:
        first = choices[0]
        if isinstance(first, dict):
            message = first.get("message")
            if isinstance(message, dict):
                content = message.get("content")
                if isinstance(content, str):
                    return content
                if isinstance(content, list):
                    parts = [
                        str(item.get("text") or "")
                        for item in content
                        if isinstance(item, dict) and item.get("type") in {None, "text", "output_text"}
                    ]
                    return "\n".join(part for part in parts if part)
            text = first.get("text")
            if isinstance(text, str):
                return text
    output_text = data.get("output_text")
    if isinstance(output_text, str):
        return output_text
    return ""

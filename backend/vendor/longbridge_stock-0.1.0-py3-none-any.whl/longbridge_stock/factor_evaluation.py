from __future__ import annotations

import json
from collections.abc import Iterable, Mapping, Sequence
from typing import Any

import numpy as np
import pandas as pd


IDENTITY_COLUMNS = {
    "source",
    "market",
    "symbol",
    "name",
    "signal_time",
    "signal_date",
    "trade_date",
    "score",
    "entry_price",
    "future_price",
    "future_return",
    "max_favorable_return",
    "max_drawdown",
    "hit_2pct",
    "horizon_days",
    "observed_until",
    "features",
}


def build_candidate_snapshot_rows(
    rows: Iterable[Mapping[str, Any] | Any],
    *,
    source: str,
    feature_columns: Sequence[str],
) -> list[dict[str, Any]]:
    snapshots: list[dict[str, Any]] = []
    for raw in rows:
        row = _mapping(raw)
        symbol = str(row.get("symbol") or "").strip().upper()
        market = str(row.get("market") or "").strip().lower()
        signal_time = _datetime_text(row.get("signal_time") or row.get("quote_minute"))
        if not symbol or not market or not signal_time:
            continue
        features = {
            column: float(row[column])
            for column in feature_columns
            if column in row and _is_number(row[column])
        }
        snapshots.append(
            {
                "source": source,
                "market": market,
                "trade_date": pd.Timestamp(signal_time).date().isoformat(),
                "signal_time": signal_time,
                "symbol": symbol,
                "name": str(row.get("name") or symbol),
                "score": _num_or_none(row.get("score")),
                "entry_price": _num_or_none(row.get("entry_price") or row.get("last")),
                "features": json.dumps(features, ensure_ascii=False, sort_keys=True),
            }
        )
    return snapshots


def build_forward_outcomes(
    signals: pd.DataFrame,
    price_bars: pd.DataFrame,
    *,
    horizon_days: int,
    target_return: float = 0.02,
) -> pd.DataFrame:
    if horizon_days <= 0:
        raise ValueError("horizon_days must be positive")
    if signals.empty or price_bars.empty:
        return _empty_outcomes()

    signal_frame = signals.copy()
    bar_frame = price_bars.copy()
    signal_frame["signal_time"] = pd.to_datetime(signal_frame["signal_time"], utc=True).dt.tz_convert(None)
    bar_frame["price_time"] = pd.to_datetime(bar_frame["price_time"], utc=True).dt.tz_convert(None)
    for column in ["entry_price"]:
        signal_frame[column] = pd.to_numeric(signal_frame[column], errors="coerce")
    for column in ["high", "low", "close"]:
        bar_frame[column] = pd.to_numeric(bar_frame[column], errors="coerce")
    bar_frame = bar_frame.sort_values(["symbol", "price_time"])

    outcomes: list[dict[str, Any]] = []
    for signal in signal_frame.to_dict("records"):
        entry_price = _num_or_none(signal.get("entry_price"))
        symbol = str(signal.get("symbol") or "").strip().upper()
        signal_time = pd.Timestamp(signal.get("signal_time"))
        if not symbol or entry_price in (None, 0):
            continue
        future = bar_frame[(bar_frame["symbol"].str.upper() == symbol) & (bar_frame["price_time"] > signal_time)].head(horizon_days)
        if future.empty:
            continue
        future_price = float(future.iloc[-1]["close"])
        max_high = float(future["high"].max())
        min_low = float(future["low"].min())
        outcomes.append(
            {
                "source": str(signal.get("source") or ""),
                "market": str(signal.get("market") or "").lower(),
                "symbol": symbol,
                "signal_time": signal_time.isoformat(),
                "horizon_days": int(horizon_days),
                "entry_price": float(entry_price),
                "future_price": future_price,
                "future_return": future_price / float(entry_price) - 1.0,
                "max_favorable_return": max_high / float(entry_price) - 1.0,
                "max_drawdown": min_low / float(entry_price) - 1.0,
                "hit_2pct": int(max_high / float(entry_price) - 1.0 >= target_return),
                "observed_until": pd.Timestamp(future.iloc[-1]["price_time"]).isoformat(),
            }
        )
    return pd.DataFrame(outcomes)


def evaluate_factor_frame(
    frame: pd.DataFrame,
    *,
    factor_columns: Sequence[str] | None = None,
    horizon_days: int,
    top_k: int = 10,
    target_return: float = 0.02,
    return_column: str = "future_return",
) -> dict[str, Any]:
    if top_k <= 0:
        raise ValueError("top_k must be positive")
    if frame.empty:
        return {"summary": {"rows": 0, "horizon_days": horizon_days, "top_k": top_k}, "factor_metrics": []}
    data = expand_feature_json(frame)
    if "signal_date" not in data.columns:
        if "trade_date" in data.columns:
            data["signal_date"] = data["trade_date"].astype(str)
        elif "signal_time" in data.columns:
            data["signal_date"] = pd.to_datetime(data["signal_time"]).dt.date.astype(str)
        else:
            raise ValueError("frame must include signal_date, trade_date, or signal_time")
    if "market" not in data.columns:
        data["market"] = "all"
    factor_list = list(factor_columns or infer_factor_columns(data))
    metrics = [
        row
        for factor in factor_list
        if (row := _evaluate_one_factor(data, factor, return_column=return_column, top_k=top_k, target_return=target_return)) is not None
    ]
    metrics.sort(
        key=lambda row: (
            _sort_num(row.get("rank_ic_mean")),
            _sort_num(row.get("topk_avg_return")),
            _sort_num(row.get("topk_hit_rate")),
        ),
        reverse=True,
    )
    return {
        "summary": {
            "rows": int(len(data)),
            "horizon_days": int(horizon_days),
            "top_k": int(top_k),
            "target_return": float(target_return),
            "factors": len(metrics),
            "markets": sorted(str(item) for item in data["market"].dropna().unique()),
            "start_date": str(data["signal_date"].min()),
            "end_date": str(data["signal_date"].max()),
        },
        "factor_metrics": metrics,
    }


def expand_feature_json(frame: pd.DataFrame, *, features_column: str = "features") -> pd.DataFrame:
    if features_column not in frame.columns:
        return frame.copy()
    output = frame.copy()
    feature_rows: list[dict[str, Any]] = []
    for value in output[features_column]:
        if isinstance(value, Mapping):
            loaded = dict(value)
        elif value:
            try:
                parsed = json.loads(str(value))
            except json.JSONDecodeError:
                parsed = {}
            loaded = parsed if isinstance(parsed, dict) else {}
        else:
            loaded = {}
        feature_rows.append({key: _num_or_none(item) for key, item in loaded.items()})
    features = pd.DataFrame(feature_rows, index=output.index)
    for column in features.columns:
        if column not in output.columns:
            output[column] = features[column]
    return output


def infer_factor_columns(frame: pd.DataFrame) -> list[str]:
    columns: list[str] = []
    for column in frame.columns:
        if column in IDENTITY_COLUMNS:
            continue
        values = pd.to_numeric(frame[column], errors="coerce")
        if values.notna().any():
            columns.append(column)
    return columns


def _evaluate_one_factor(
    frame: pd.DataFrame,
    factor: str,
    *,
    return_column: str,
    top_k: int,
    target_return: float,
) -> dict[str, Any] | None:
    if factor not in frame.columns or return_column not in frame.columns:
        return None
    data = frame[["market", "signal_date", "symbol", factor, return_column, "max_drawdown"]].copy()
    data[factor] = pd.to_numeric(data[factor], errors="coerce")
    data[return_column] = pd.to_numeric(data[return_column], errors="coerce")
    data["max_drawdown"] = pd.to_numeric(data["max_drawdown"], errors="coerce")
    data = data.dropna(subset=[factor, return_column])
    if data.empty:
        return None

    daily_ics: list[float] = []
    top_frames: list[pd.DataFrame] = []
    for _, group in data.groupby(["market", "signal_date"], sort=True):
        if len(group) >= 3 and group[factor].nunique() >= 2 and group[return_column].nunique() >= 2:
            rank_ic = group[factor].rank(method="average").corr(group[return_column].rank(method="average"))
            if pd.notna(rank_ic):
                daily_ics.append(float(rank_ic))
        top_frames.append(group.sort_values(factor, ascending=False).head(top_k))

    selected = pd.concat(top_frames) if top_frames else pd.DataFrame()
    ic_mean = float(np.mean(daily_ics)) if daily_ics else None
    ic_std = float(np.std(daily_ics, ddof=0)) if len(daily_ics) > 1 else None
    icir = ic_mean / ic_std if ic_mean is not None and ic_std not in (None, 0.0) else None
    return {
        "factor": factor,
        "observations": int(len(data)),
        "date_count": int(data.groupby(["market", "signal_date"]).ngroups),
        "rank_ic_mean": _round_or_none(ic_mean),
        "rank_ic_std": _round_or_none(ic_std),
        "icir": _round_or_none(icir),
        "topk_avg_return": _round_or_none(float(selected[return_column].mean())) if not selected.empty else None,
        "topk_hit_rate": _round_or_none(float((selected[return_column] >= target_return).mean())) if not selected.empty else None,
        "topk_avg_drawdown": _round_or_none(float(selected["max_drawdown"].mean())) if not selected.empty and selected["max_drawdown"].notna().any() else None,
    }


def _mapping(value: Mapping[str, Any] | Any) -> Mapping[str, Any]:
    if isinstance(value, Mapping):
        return value
    return {name: getattr(value, name) for name in dir(value) if not name.startswith("_") and not callable(getattr(value, name))}


def _datetime_text(value: Any) -> str:
    if value is None or value == "":
        return ""
    return pd.Timestamp(value).isoformat()


def _empty_outcomes() -> pd.DataFrame:
    return pd.DataFrame(
        columns=[
            "source",
            "market",
            "symbol",
            "signal_time",
            "horizon_days",
            "entry_price",
            "future_price",
            "future_return",
            "max_favorable_return",
            "max_drawdown",
            "hit_2pct",
            "observed_until",
        ]
    )


def _is_number(value: Any) -> bool:
    return _num_or_none(value) is not None


def _num_or_none(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if np.isfinite(number) else None


def _round_or_none(value: float | None) -> float | None:
    if value is None or not np.isfinite(value):
        return None
    return round(float(value), 6)


def _sort_num(value: Any) -> float:
    number = _num_or_none(value)
    return float("-inf") if number is None else number

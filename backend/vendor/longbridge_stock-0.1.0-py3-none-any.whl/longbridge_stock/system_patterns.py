from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from types import MappingProxyType
from typing import Literal

from longbridge_stock.dow_trend_replay import Bar
from longbridge_stock.market_detectors.candlestick import (
    detect_evening_star,
    detect_morning_star,
    detect_old_note_pregnancy,
    detect_three_soldiers,
)
from longbridge_stock.market_detectors.buy_points import (
    BuyPointDetection,
    detect_2b_reversal,
    detect_second_test,
    detect_strong_emergence,
)
from longbridge_stock.market_detectors.factory import build_default_market_detector
from longbridge_stock.market_detectors.models import DetectedStructure, Evidence


PatternRole = Literal["buy", "early_buy", "risk"]


@dataclass(frozen=True)
class PatternMatch:
    pattern_id: str
    role: PatternRole
    known_at_index: int
    score: float
    evidence: tuple[Evidence, ...] = ()


@dataclass(frozen=True)
class PatternDefinition:
    role: PatternRole
    warmup_bars: int
    required_fields: tuple[str, ...] = ("open", "high", "low", "close", "volume")


_SYSTEM_PATTERN_MANIFEST = MappingProxyType(
    {
        "head_shoulders_bottom": PatternDefinition("buy", 20),
        "head_shoulders_top": PatternDefinition("risk", 20),
        "morning_star": PatternDefinition("buy", 3),
        "evening_star": PatternDefinition("risk", 3),
        "three_red_soldiers": PatternDefinition("buy", 3),
        "bottom_pregnancy": PatternDefinition("buy", 2),
        "top_pregnancy": PatternDefinition("risk", 2),
        "two_b_reversal": PatternDefinition("buy", 7),
        "head_shoulders_right_shoulder": PatternDefinition("early_buy", 20),
        "second_test": PatternDefinition("buy", 5),
        "strong_emergence": PatternDefinition("buy", 6),
    }
)


def system_pattern_manifest() -> Mapping[str, PatternDefinition]:
    return _SYSTEM_PATTERN_MANIFEST


PatternScanner = Callable[
    [Sequence[Bar], str, str, Mapping[str, object]],
    DetectedStructure | None,
]


def _number(params: Mapping[str, object], key: str, default: float) -> float:
    value = params.get(key, default)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{key} must be numeric")
    return float(value)


def _morning(
    bars: Sequence[Bar], symbol: str, timeframe: str, params: Mapping[str, object]
) -> DetectedStructure | None:
    return detect_morning_star(
        bars,
        symbol,
        timeframe,
        body_ratio_min=_number(params, "body_ratio_min", 0.55),
    )


def _evening(
    bars: Sequence[Bar], symbol: str, timeframe: str, params: Mapping[str, object]
) -> DetectedStructure | None:
    return detect_evening_star(
        bars,
        symbol,
        timeframe,
        body_ratio_min=_number(params, "body_ratio_min", 0.55),
    )


def _soldiers(
    bars: Sequence[Bar], symbol: str, timeframe: str, params: Mapping[str, object]
) -> DetectedStructure | None:
    return detect_three_soldiers(
        bars,
        symbol,
        timeframe,
        body_ratio_min=_number(params, "body_ratio_min", 0.5),
    )


def _pregnancy(
    bars: Sequence[Bar],
    symbol: str,
    timeframe: str,
    params: Mapping[str, object],
    *,
    bullish: bool,
) -> DetectedStructure | None:
    return detect_old_note_pregnancy(
        bars,
        symbol,
        timeframe,
        bullish=bullish,
        small_body_max=_number(params, "small_body_max", 0.25),
        large_body_min=_number(params, "large_body_min", 0.55),
        volume_ratio_min=_number(params, "volume_ratio_min", 1.5),
    )


_CANDLE_PATTERNS: dict[str, tuple[PatternRole, PatternScanner]] = {
    "morning_star": ("buy", _morning),
    "evening_star": ("risk", _evening),
    "three_red_soldiers": ("buy", _soldiers),
    "bottom_pregnancy": (
        "buy",
        lambda bars, symbol, timeframe, params: _pregnancy(
            bars, symbol, timeframe, params, bullish=True
        ),
    ),
    "top_pregnancy": (
        "risk",
        lambda bars, symbol, timeframe, params: _pregnancy(
            bars, symbol, timeframe, params, bullish=False
        ),
    ),
}

_HEAD_SHOULDERS_EVENTS: dict[
    str, tuple[str, frozenset[str], PatternRole]
] = {
    "head_shoulders_bottom": (
        "structure.head_shoulders_bottom",
        frozenset({"NECKLINE_BREAK_CONFIRMED", "NECKLINE_RETEST_COMPLETED"}),
        "buy",
    ),
    "head_shoulders_top": (
        "structure.head_shoulders_top",
        frozenset({"NECKLINE_BREAKDOWN_CONFIRMED", "NECKLINE_RETEST_REJECTED"}),
        "risk",
    ),
}


def _evidence_values(evidence: Sequence[Evidence]) -> dict[str, object]:
    return {item.name: item.actual for item in evidence}


def _scan_head_shoulders_events(
    pattern_id: str,
    bars: Sequence[Bar],
    params: Mapping[str, object],
) -> tuple[PatternMatch, ...]:
    detector_id, event_types, role = _HEAD_SHOULDERS_EVENTS[pattern_id]
    detector = build_default_market_detector(
        "SYSTEM",
        "1d",
        head_shoulders_neckline_tolerance_ratio=_number(
            params, "neckline_tolerance_ratio", 0.03
        ),
    )
    matches: list[PatternMatch] = []
    for unified in detector.replay(bars):
        snapshot = unified.snapshots.get(detector_id)
        if snapshot is None:
            continue
        for event in snapshot.events:
            if event.event_type not in event_types:
                continue
            matches.append(
                PatternMatch(
                    pattern_id,
                    role,
                    event.known_at_index,
                    90.0 if event.confirmed else 75.0,
                    event.evidence,
                )
            )
    return tuple(matches)


def _scan_right_shoulder(
    bars: Sequence[Bar], params: Mapping[str, object]
) -> tuple[PatternMatch, ...]:
    retrace_min = _number(params, "retrace_min", 0.45)
    retrace_max = _number(params, "retrace_max", 0.55)
    volume_min = _number(params, "volume_ratio_min", 1.0)
    detector = build_default_market_detector(
        "SYSTEM",
        "1d",
        head_shoulders_neckline_tolerance_ratio=_number(
            params, "neckline_tolerance_ratio", 0.03
        ),
    )
    matches: list[PatternMatch] = []
    seen: set[str] = set()
    for unified in detector.replay(bars):
        snapshot = unified.snapshots.get("structure.head_shoulders_bottom")
        if snapshot is None:
            continue
        volume_snapshot = unified.snapshots.get("primitive.volume")
        volume_values = (
            _evidence_values(volume_snapshot.evidence)
            if volume_snapshot is not None
            else {}
        )
        volume_ratio = float(volume_values.get("volume_ratio", 1.0) or 0.0)
        for structure in snapshot.structures:
            if (
                structure.structure_id in seen
                or structure.local_state != "WAIT_NECKLINE_BREAK"
            ):
                continue
            values = _evidence_values(structure.evidence)
            try:
                head = float(values["head"])
                neck = float(values["second_neck"])
                shoulder = float(values["right_shoulder"])
            except (KeyError, TypeError, ValueError):
                continue
            distance = neck - head
            if distance <= 0:
                continue
            retrace = (shoulder - head) / distance
            if not retrace_min <= retrace <= retrace_max or volume_ratio < volume_min:
                continue
            seen.add(structure.structure_id)
            matches.append(
                PatternMatch(
                    "head_shoulders_right_shoulder",
                    "early_buy",
                    structure.known_at_index,
                    90.0 if structure.quality == "STRONG" else 80.0,
                    structure.evidence
                    + (
                        Evidence("right_shoulder_retrace", retrace),
                        Evidence("volume_ratio", volume_ratio, volume_min, True),
                    ),
                )
            )
    return tuple(matches)


def _scan_buy_point(
    pattern_id: str,
    bars: Sequence[Bar],
    params: Mapping[str, object],
) -> tuple[PatternMatch, ...]:
    matches: list[PatternMatch] = []
    for stop in range(1, len(bars) + 1):
        prefix = tuple(bars[:stop])
        detection: BuyPointDetection | None
        if pattern_id == "two_b_reversal":
            detection = detect_2b_reversal(
                prefix,
                body_ratio_min=_number(params, "body_ratio_min", 0.55),
                max_wave_span=int(_number(params, "max_wave_span", 120)),
            )
        elif pattern_id == "second_test":
            detection = detect_second_test(
                prefix,
                tolerance_ratio=_number(params, "tolerance_ratio", 0.03),
                min_gap=int(_number(params, "min_gap", 3)),
                max_gap=int(_number(params, "max_gap", 40)),
            )
        elif pattern_id == "strong_emergence":
            detection = detect_strong_emergence(
                prefix,
                bottom_window=int(_number(params, "bottom_window", 60)),
                bottom_fraction=_number(params, "bottom_fraction", 0.35),
                pressure_window=int(_number(params, "pressure_window", 5)),
                body_ratio_min=_number(params, "body_ratio_min", 0.55),
                volume_ratio_min=_number(params, "volume_ratio_min", 1.5),
            )
        else:
            raise ValueError(f"unsupported system pattern: {pattern_id}")
        if detection is not None:
            matches.append(
                PatternMatch(
                    pattern_id,
                    "buy",
                    detection.known_at_index,
                    detection.score,
                    detection.evidence,
                )
            )
    return tuple(matches)


def scan_system_pattern(
    pattern_id: str,
    bars: Sequence[Bar],
    params: Mapping[str, object] | None = None,
) -> tuple[PatternMatch, ...]:
    normalized = dict(params or {})
    if pattern_id in _HEAD_SHOULDERS_EVENTS:
        return _scan_head_shoulders_events(pattern_id, bars, normalized)
    if pattern_id == "head_shoulders_right_shoulder":
        return _scan_right_shoulder(bars, normalized)
    if pattern_id in {"two_b_reversal", "second_test", "strong_emergence"}:
        return _scan_buy_point(pattern_id, bars, normalized)
    try:
        role, scanner = _CANDLE_PATTERNS[pattern_id]
    except KeyError as exc:
        raise ValueError(f"unsupported system pattern: {pattern_id}") from exc

    matches: list[PatternMatch] = []
    for stop in range(1, len(bars) + 1):
        prefix = tuple(bars[:stop])
        structure = scanner(prefix, "SYSTEM", "1d", normalized)
        if structure is None:
            continue
        matches.append(
            PatternMatch(
                pattern_id=pattern_id,
                role=role,
                known_at_index=structure.known_at_index,
                score=90.0 if structure.quality == "STRONG" else 80.0,
                evidence=structure.evidence,
            )
        )
    return tuple(matches)

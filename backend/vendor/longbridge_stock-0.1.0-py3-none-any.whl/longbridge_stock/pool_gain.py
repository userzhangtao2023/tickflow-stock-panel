from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timezone
from decimal import Decimal
from pathlib import Path
from typing import Any

import json
import os
import pickle

import numpy as np
import pandas as pd


DEFAULT_DSN = "dbname=longbridge_stock user=alwin host=/var/run/postgresql"
DEFAULT_MODEL_ROOT = Path("/home/alwin/data/longbridge/pool_gain_models")
TARGET_RETURN = 0.05
HORIZON_DAYS = 5
FEATURE_NAMES = [
    "pct_change",
    "amplitude",
    "intraday_return",
    "close_position",
    "body_pct",
    "upper_shadow_pct",
    "lower_shadow_pct",
    "return_3d",
    "return_5d",
    "return_10d",
    "return_20d",
    "volatility_5d",
    "volatility_20d",
    "volume_ratio_5d",
    "volume_ratio_10d",
    "volume_ratio_20d",
    "turnover_ratio_5d",
    "turnover_ratio_20d",
    "market_advancing_ratio",
    "market_avg_return",
    "market_median_return",
    "market_up_volume_ratio",
    "market_above_ma20_ratio",
    "market_fresh_high_20_ratio",
    "market_volume_expansion_ratio",
    "market_strong_breadth",
    "market_weak_breadth",
    "market_breadth_change_3d",
    "supertrend_10_3",
    "supertrend_direction_10_3",
    "supertrend_flip_bullish",
    "supertrend_flip_bearish",
    "close_to_supertrend_10_3",
    "ichimoku_tenkan_9",
    "ichimoku_kijun_26",
    "ichimoku_span_a",
    "ichimoku_span_b",
    "ichimoku_cloud_top",
    "ichimoku_cloud_bottom",
    "ichimoku_above_cloud",
    "ichimoku_in_cloud",
    "ichimoku_tk_golden_cross",
    "ichimoku_cloud_bullish",
    "cci_20",
    "cci_cross_above_minus100",
    "cci_cross_above_0",
    "cci_cross_above_100",
    "cci_extreme_high",
    "cci_extreme_low",
    "roc_5",
    "roc_10",
    "roc_20",
    "roc_10_acceleration",
    "roc_10_cross_above_0",
    "williams_r_14",
    "williams_r_rebound_oversold",
    "williams_r_fall_overbought",
    "donchian_high_20",
    "donchian_low_20",
    "donchian_position_20",
    "donchian_width_20",
    "donchian_breakout_20",
    "donchian_breakdown_20",
    "keltner_mid_20",
    "keltner_upper_20",
    "keltner_lower_20",
    "keltner_position_20",
    "keltner_width_20",
    "keltner_break_upper_20",
    "keltner_reclaim_mid_20",
    "aroon_up_25",
    "aroon_down_25",
    "aroon_osc_25",
    "aroon_bullish_cross",
    "aroon_strong_up",
    "trix_15",
    "trix_signal_9",
    "trix_golden_cross",
    "trix_above_zero",
    "tsi_25_13",
    "tsi_signal_7",
    "tsi_golden_cross",
    "tsi_above_zero",
    "elder_bull_power_13",
    "elder_bear_power_13",
    "elder_bull_power_rising_3d",
    "elder_bear_power_recovering_3d",
    "rsi_6",
    "rsi_14",
    "rsi_24",
    "rsi_14_oversold",
    "rsi_14_overbought",
    "rsi_14_above_50",
    "rsi_14_cross_above_50",
    "rsi_14_cross_below_50",
    "rsi_14_slope_3d",
    "rsi_14_slope_5d",
    "rsi_bullish_divergence_20d",
    "rsi_bearish_divergence_20d",
    "boll_mid_20",
    "boll_upper_20",
    "boll_lower_20",
    "close_to_boll_mid_20",
    "boll_position_20",
    "boll_width_20",
    "boll_width_change_5d",
    "boll_squeeze_60d",
    "boll_break_upper_20",
    "boll_break_lower_20",
    "boll_reclaim_lower_20",
    "boll_pullback_mid_20",
    "boll_upper_break_with_volume",
    "kdj_k",
    "kdj_d",
    "kdj_j",
    "kdj_golden_cross",
    "kdj_dead_cross",
    "kdj_low_golden_cross",
    "kdj_high_dead_cross",
    "kdj_j_extreme_low",
    "kdj_j_extreme_high",
    "kdj_k_slope_3d",
    "kdj_j_slope_3d",
    "kdj_bullish_divergence_20d",
    "kdj_bearish_divergence_20d",
    "plus_di_14",
    "minus_di_14",
    "adx_14",
    "adx_rising_3d",
    "adx_strong_25",
    "dmi_bullish",
    "dmi_golden_cross",
    "dmi_dead_cross",
    "atr_14_pct",
    "atr_expansion_5d",
    "amplitude_ratio_5_20",
    "obv",
    "obv_slope_5d",
    "obv_slope_10d",
    "obv_new_high_20",
    "obv_bullish_divergence_20d",
    "obv_bearish_divergence_20d",
    "mfi_14",
    "mfi_14_strong",
    "mfi_14_oversold",
    "mfi_14_slope_3d",
    "cmf_20",
    "cmf_20_positive",
    "cmf_20_rising_5d",
    "vwap_20",
    "close_to_vwap_20",
    "vwap_reclaim_20",
    "technical_bullish_confluence",
    "technical_reversal_confluence",
    "macd_dif",
    "macd_dea",
    "macd_hist",
    "macd_dif_above_zero",
    "macd_dea_above_zero",
    "macd_hist_above_zero",
    "macd_above_zero_state",
    "macd_below_zero_state",
    "macd_golden_cross",
    "macd_dead_cross",
    "macd_golden_cross_above_zero",
    "macd_golden_cross_below_zero",
    "macd_dead_cross_above_zero",
    "macd_dead_cross_below_zero",
    "macd_hist_red_expanding",
    "macd_hist_red_shrinking",
    "macd_hist_green_expanding",
    "macd_hist_green_shrinking",
    "macd_hist_turn_red",
    "macd_hist_turn_green",
    "macd_dif_slope_3d",
    "macd_dif_slope_5d",
    "macd_hist_slope_3d",
    "macd_hist_acceleration",
    "macd_above_zero_days",
    "macd_red_days",
    "macd_green_days",
    "macd_bullish_divergence_20d",
    "macd_bearish_divergence_20d",
    "macd_hist_bullish_divergence_20d",
    "macd_hist_bearish_divergence_20d",
    "macd_below_zero_golden_cross_with_volume",
    "macd_above_zero_golden_cross_with_breakout",
    "macd_green_shrinking_near_ma20",
    "macd_red_expanding_above_ma5",
    "macd_bullish_divergence_reversal",
    "macd_bearish_divergence_risk",
    "close_to_ma5",
    "close_to_ma10",
    "close_to_ma20",
    "close_to_ma60",
    "above_ma5",
    "above_ma10",
    "above_ma20",
    "above_ma60",
    "ma_alignment_count",
    "ma5_slope_5d",
    "distance_to_20d_high",
    "distance_to_60d_high",
    "distance_to_120d_high",
    "breakout_20d",
    "breakout_60d",
    "breakout_120d",
    "fresh_breakout_20d",
    "fresh_breakout_60d",
    "fresh_breakout_120d",
    "drawdown_from_20d_low",
    "turnover_log",
    "volume_log",
    "trend_score",
    "momentum_score",
    "volume_score",
    "risk_score",
    "valuation_score",
    "quality_score",
    "model_score",
    "total_score",
    "rank_pct_in_market",
    "score_pool_tag",
    "observation_pool_tag",
    "limit_up_pool_tag",
    "volume_breakout_pool_tag",
]


@dataclass(frozen=True)
class PoolGainTrainSummary:
    model_run_id: str
    model_type: str
    train_count: int
    validation_count: int
    metrics: dict[str, Any]
    model_path: str


@dataclass(frozen=True)
class PoolGainPredictSummary:
    model_run_id: str
    as_of_date: str
    total: int
    top: list[dict[str, Any]]


def ensure_pool_gain_tables(conn: Any) -> None:
    conn.execute(
        """
        create table if not exists lb_pool_gain_model_runs (
            model_run_id text primary key,
            model_type text not null,
            target text not null,
            model_path text not null,
            train_count integer not null,
            validation_count integer not null,
            metrics jsonb not null,
            feature_names text[] not null,
            trained_at timestamptz not null default now()
        )
        """
    )
    conn.execute(
        """
        create table if not exists lb_pool_gain_predictions (
            model_run_id text not null references lb_pool_gain_model_runs(model_run_id),
            symbol text not null,
            market text not null,
            as_of_date date not null,
            name text,
            pool_tags text[] not null default '{}',
            probability numeric,
            score numeric,
            expected_max_return_5d numeric,
            risk_score numeric,
            suggested_entry text,
            reason text,
            payload jsonb not null default '{}'::jsonb,
            created_at timestamptz not null default now(),
            primary key (model_run_id, symbol, as_of_date)
        )
        """
    )
    conn.execute(
        "create index if not exists idx_lb_pool_gain_predictions_date_score on lb_pool_gain_predictions (as_of_date desc, score desc)"
    )


def train_pool_gain_model_from_db(
    dsn: str = DEFAULT_DSN,
    model_root: str | Path = DEFAULT_MODEL_ROOT,
    start_date: str | None = "2024-01-01",
    validation_ratio: float = 0.2,
    max_rows: int | None = None,
) -> PoolGainTrainSummary:
    psycopg, Jsonb = _load_psycopg()
    with psycopg.connect(dsn) as conn:
        ensure_pool_gain_tables(conn)
        bars = _load_daily_bars(conn, start_date=start_date, max_rows=max_rows)
        scores = _load_score_features(conn)

    samples = build_labeled_samples(bars, scores)
    samples = samples[samples["target_high_5d"].notna()].copy()
    if len(samples) < 500:
        raise RuntimeError(f"not enough labeled samples: {len(samples)}")

    train, validation = temporal_train_validation_split(samples, validation_ratio=validation_ratio)
    model, metrics = train_best_classifier(train, validation)
    model_run_id = f"pool_gain_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"
    model_root = Path(model_root)
    model_root.mkdir(parents=True, exist_ok=True)
    model_path = model_root / f"{model_run_id}.pkl"
    with model_path.open("wb") as fh:
        pickle.dump(model, fh)

    with psycopg.connect(dsn) as conn:
        ensure_pool_gain_tables(conn)
        conn.execute(
            """
            insert into lb_pool_gain_model_runs
              (model_run_id, model_type, target, model_path, train_count, validation_count, metrics, feature_names)
            values (%s, %s, %s, %s, %s, %s, %s, %s)
            on conflict (model_run_id) do update set
              model_type = excluded.model_type,
              target = excluded.target,
              model_path = excluded.model_path,
              train_count = excluded.train_count,
              validation_count = excluded.validation_count,
              metrics = excluded.metrics,
              feature_names = excluded.feature_names
            """,
            (
                model_run_id,
                model.model_type,
                f"next_{HORIZON_DAYS}d_high_return_ge_{TARGET_RETURN:.2f}",
                str(model_path),
                int(len(train)),
                int(len(validation)),
                Jsonb(metrics),
                model.feature_names,
            ),
        )

    return PoolGainTrainSummary(
        model_run_id=model_run_id,
        model_type=model.model_type,
        train_count=int(len(train)),
        validation_count=int(len(validation)),
        metrics=metrics,
        model_path=str(model_path),
    )


def predict_pool_gain_candidates(
    dsn: str = DEFAULT_DSN,
    model_root: str | Path = DEFAULT_MODEL_ROOT,
    limit: int = 50,
    as_of_date: str | None = None,
) -> PoolGainPredictSummary:
    psycopg, Jsonb = _load_psycopg()
    with psycopg.connect(dsn) as conn:
        ensure_pool_gain_tables(conn)
        run = _latest_model_run(conn, model_root)
        candidates = _load_current_pool_candidates(conn, as_of_date=as_of_date)

    if candidates.empty:
        return PoolGainPredictSummary(model_run_id=run["model_run_id"], as_of_date="", total=0, top=[])

    candidate_symbols = sorted({str(symbol) for symbol in candidates["symbol"].dropna().unique()})
    with psycopg.connect(dsn) as conn:
        bars = _load_daily_bars(conn, start_date="2025-01-01", symbols=candidate_symbols)
        scores = _load_score_features(conn)

    model = _load_model(Path(run["model_path"]))
    features = build_current_candidate_features(bars, scores, candidates)
    if features.empty:
        return PoolGainPredictSummary(model_run_id=run["model_run_id"], as_of_date="", total=0, top=[])

    probabilities = model.predict_proba(features)
    features["probability"] = probabilities
    features["score"] = (features["probability"] * 100).round(2)
    features["risk_score"] = _risk_score(features)
    features["expected_max_return_5d"] = (features["probability"] * TARGET_RETURN * 1.35).round(4)
    features["overheated_excluded"] = _overheated_mask(features).astype(float)
    features = features[features["overheated_excluded"] < 1].copy()
    if features.empty:
        return PoolGainPredictSummary(
            model_run_id=run["model_run_id"],
            as_of_date="",
            total=0,
            top=[],
        )
    features["suggested_entry"] = np.select(
        [
            features["fresh_breakout_60d"].fillna(0) >= 1,
            features["close_to_ma5"].between(-0.015, 0.025),
        ],
        ["T+1 open; breakout confirmation", "T+1/T+2 pullback near MA5"],
        default="watch for pullback",
    )
    features["reason"] = features.apply(_prediction_reason, axis=1)
    ranked = features.sort_values(["score", "risk_score", "total_score"], ascending=[False, False, False]).head(limit)

    with psycopg.connect(dsn) as conn:
        ensure_pool_gain_tables(conn)
        conn.execute(
            "delete from lb_pool_gain_predictions where model_run_id = %s and as_of_date = %s",
            (run["model_run_id"], ranked["trade_date"].max()),
        )
        for row in ranked.to_dict("records"):
            conn.execute(
                """
                insert into lb_pool_gain_predictions
                  (model_run_id, symbol, market, as_of_date, name, pool_tags, probability, score,
                   expected_max_return_5d, risk_score, suggested_entry, reason, payload)
                values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                on conflict (model_run_id, symbol, as_of_date) do update set
                  market = excluded.market,
                  name = excluded.name,
                  pool_tags = excluded.pool_tags,
                  probability = excluded.probability,
                  score = excluded.score,
                  expected_max_return_5d = excluded.expected_max_return_5d,
                  risk_score = excluded.risk_score,
                  suggested_entry = excluded.suggested_entry,
                  reason = excluded.reason,
                  payload = excluded.payload,
                  created_at = now()
                """,
                (
                    run["model_run_id"],
                    row["symbol"],
                    row["market"],
                    row["trade_date"],
                    row.get("name"),
                    row.get("pool_tags") or [],
                    _float_or_none(row.get("probability")),
                    _float_or_none(row.get("score")),
                    _float_or_none(row.get("expected_max_return_5d")),
                    _float_or_none(row.get("risk_score")),
                    row.get("suggested_entry"),
                    row.get("reason"),
                    Jsonb(_payload(row)),
                ),
            )

    top = ranked.head(min(limit, 20)).to_dict("records")
    return PoolGainPredictSummary(
        model_run_id=run["model_run_id"],
        as_of_date=str(ranked["trade_date"].max()),
        total=int(len(ranked)),
        top=[_public_prediction_row(row) for row in top],
    )


def fetch_pool_gain_predictions(
    dsn: str = DEFAULT_DSN,
    as_of_date: str | None = None,
    limit: int = 50,
) -> pd.DataFrame:
    psycopg, _ = _load_psycopg()
    date_filter = "and p.as_of_date = %s" if as_of_date else "and p.as_of_date = (select max(as_of_date) from lb_pool_gain_predictions)"
    params: list[Any] = [as_of_date] if as_of_date else []
    query = f"""
        select p.*, r.model_type, r.metrics
        from lb_pool_gain_predictions p
        join lb_pool_gain_model_runs r on r.model_run_id = p.model_run_id
        where p.model_run_id = (
          select model_run_id
          from lb_pool_gain_model_runs
          order by trained_at desc
          limit 1
        )
        {date_filter}
        order by p.score desc nulls last, p.risk_score desc nulls last, p.symbol
        limit %s
    """
    params.append(limit)
    with psycopg.connect(dsn) as conn:
        with conn.cursor() as cur:
            cur.execute(query, params)
            rows = cur.fetchall()
            columns = [desc.name for desc in cur.description]
    return pd.DataFrame(rows, columns=columns)


def build_labeled_samples(bars: pd.DataFrame, scores: pd.DataFrame | None = None) -> pd.DataFrame:
    frame = _add_price_features(bars)
    group = frame.groupby("symbol", group_keys=False)
    future_highs = [group["high"].shift(-step) for step in range(1, HORIZON_DAYS + 1)]
    future_closes = [group["close"].shift(-step) for step in range(1, HORIZON_DAYS + 1)]
    frame["next_open"] = group["open"].shift(-1)
    frame["future_high_5d"] = pd.concat(future_highs, axis=1).max(axis=1)
    frame["future_close_5d"] = future_closes[-1]
    frame["future_max_return_5d"] = frame["future_high_5d"] / frame["next_open"].replace(0, np.nan) - 1
    frame["future_close_return_5d"] = frame["future_close_5d"] / frame["next_open"].replace(0, np.nan) - 1
    frame["target_high_5d"] = (frame["future_max_return_5d"] >= TARGET_RETURN).astype(float)
    frame["target_close_5d"] = (frame["future_close_return_5d"] >= TARGET_RETURN).astype(float)
    frame = _merge_score_features(frame, scores)
    return frame


def build_current_candidate_features(
    bars: pd.DataFrame,
    scores: pd.DataFrame,
    candidates: pd.DataFrame,
) -> pd.DataFrame:
    frame = _add_price_features(bars)
    latest = frame.sort_values(["symbol", "trade_date"]).groupby("symbol", as_index=False).tail(1)
    if not latest.empty:
        latest_trade_date = latest["trade_date"].max()
        latest = latest[latest["trade_date"] == latest_trade_date].copy()
    latest = _merge_score_features(latest, scores)
    latest = latest.merge(candidates, on=["symbol", "market"], how="inner", suffixes=("", "_candidate"))
    if "name_candidate" in latest:
        latest["name"] = latest["name_candidate"].combine_first(latest.get("name"))
    elif "name" not in latest:
        latest["name"] = None
    for tag in ["score_pool_tag", "observation_pool_tag", "limit_up_pool_tag", "volume_breakout_pool_tag"]:
        if tag not in latest:
            latest[tag] = 0.0
    return _prepare_feature_frame(latest)


def temporal_train_validation_split(frame: pd.DataFrame, validation_ratio: float = 0.2) -> tuple[pd.DataFrame, pd.DataFrame]:
    dates = sorted(pd.to_datetime(frame["trade_date"]).dropna().unique())
    if len(dates) < 10:
        raise RuntimeError("not enough trading dates for temporal split")
    split_index = max(1, int(len(dates) * (1 - validation_ratio)))
    split_date = dates[min(split_index, len(dates) - 1)]
    train = frame[pd.to_datetime(frame["trade_date"]) < split_date].copy()
    validation = frame[pd.to_datetime(frame["trade_date"]) >= split_date].copy()
    return train, validation


def train_best_classifier(train: pd.DataFrame, validation: pd.DataFrame) -> tuple[Any, dict[str, Any]]:
    candidates = _candidate_classifiers()
    results: list[tuple[Any, dict[str, Any]]] = []
    for classifier in candidates:
        try:
            classifier.fit(train)
            probabilities = classifier.predict_proba(validation)
            metrics = evaluate_probabilities(validation["target_high_5d"], probabilities)
            metrics["model_type"] = classifier.model_type
            results.append((classifier, metrics))
        except Exception as exc:
            results.append((_FailedClassifier(str(exc)), {"model_type": getattr(classifier, "model_type", "unknown"), "error": str(exc)}))

    successful = [(model, metrics) for model, metrics in results if "error" not in metrics]
    if not successful:
        errors = [metrics for _, metrics in results]
        raise RuntimeError(f"all candidate models failed: {errors}")
    successful.sort(
        key=lambda item: (
            item[1].get("precision_at_50") or 0,
            item[1].get("precision_at_100") or 0,
            item[1].get("auc") or 0,
        ),
        reverse=True,
    )
    best, metrics = successful[0]
    metrics = dict(metrics)
    metrics["candidate_results"] = [dict(item[1]) for item in results]
    metrics["target_return"] = TARGET_RETURN
    metrics["horizon_days"] = HORIZON_DAYS
    metrics["baseline_hit_rate"] = float(pd.to_numeric(validation["target_high_5d"], errors="coerce").mean())
    return best, metrics


def evaluate_probabilities(target: pd.Series, probabilities: np.ndarray) -> dict[str, Any]:
    y = pd.to_numeric(target, errors="coerce").fillna(0).to_numpy(dtype="int64")
    p = np.asarray(probabilities, dtype="float64")
    metrics: dict[str, Any] = {
        "validation_count": int(len(y)),
        "hit_rate": float(y.mean()) if len(y) else None,
    }
    try:
        from sklearn.metrics import average_precision_score, roc_auc_score

        metrics["auc"] = float(roc_auc_score(y, p)) if len(np.unique(y)) > 1 else None
        metrics["average_precision"] = float(average_precision_score(y, p)) if len(np.unique(y)) > 1 else None
    except Exception:
        metrics["auc"] = None
        metrics["average_precision"] = None
    order = np.argsort(-p)
    for top_n in (20, 50, 100, 200):
        take = order[: min(top_n, len(order))]
        metrics[f"precision_at_{top_n}"] = float(y[take].mean()) if len(take) else None
    return metrics


class SklearnPoolGainModel:
    def __init__(self, model_type: str, estimator: Any, feature_names: list[str] | None = None) -> None:
        self.model_type = model_type
        self.estimator = estimator
        self.feature_names = feature_names or FEATURE_NAMES

    def fit(self, frame: pd.DataFrame) -> None:
        from sklearn.impute import SimpleImputer
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler

        x = _feature_matrix(frame, self.feature_names)
        y = pd.to_numeric(frame["target_high_5d"], errors="coerce").fillna(0).astype(int)
        if self.model_type == "logistic_regression":
            self.estimator = make_pipeline(SimpleImputer(strategy="median"), StandardScaler(), self.estimator)
        else:
            self.estimator = make_pipeline(SimpleImputer(strategy="median"), self.estimator)
        self.estimator.fit(x, y)

    def predict_proba(self, frame: pd.DataFrame) -> np.ndarray:
        x = _feature_matrix(frame, self.feature_names)
        if hasattr(self.estimator, "predict_proba"):
            return np.asarray(self.estimator.predict_proba(x))[:, 1]
        if hasattr(self.estimator, "decision_function"):
            raw = np.asarray(self.estimator.decision_function(x), dtype="float64")
            return 1 / (1 + np.exp(-raw))
        return np.asarray(self.estimator.predict(x), dtype="float64")


class _FailedClassifier:
    def __init__(self, error: str) -> None:
        self.error = error


def _candidate_classifiers() -> list[SklearnPoolGainModel]:
    from sklearn.ensemble import ExtraTreesClassifier, GradientBoostingClassifier, RandomForestClassifier
    from sklearn.linear_model import LogisticRegression

    requested = {
        item.strip()
        for item in os.getenv("POOL_GAIN_MODELS", "").split(",")
        if item.strip()
    }

    candidates = [
        SklearnPoolGainModel("logistic_regression", LogisticRegression(max_iter=1000, class_weight="balanced")),
        SklearnPoolGainModel(
            "random_forest",
            RandomForestClassifier(n_estimators=140, max_depth=9, min_samples_leaf=30, n_jobs=4, class_weight="balanced_subsample", random_state=42),
        ),
        SklearnPoolGainModel(
            "extra_trees",
            ExtraTreesClassifier(n_estimators=180, max_depth=10, min_samples_leaf=25, n_jobs=4, class_weight="balanced", random_state=42),
        ),
        SklearnPoolGainModel("gradient_boosting", GradientBoostingClassifier(random_state=42, max_depth=3, n_estimators=80)),
    ]
    if requested:
        candidates = [candidate for candidate in candidates if candidate.model_type in requested]

    try:
        from xgboost import XGBClassifier

        if not requested or "xgboost" in requested:
            candidates.append(
                SklearnPoolGainModel(
                    "xgboost",
                    XGBClassifier(
                        n_estimators=120,
                        max_depth=4,
                        learning_rate=0.055,
                        subsample=0.85,
                        colsample_bytree=0.85,
                        eval_metric="logloss",
                        tree_method="hist",
                        n_jobs=4,
                        random_state=42,
                    ),
                )
            )
    except Exception:
        pass
    try:
        from lightgbm import LGBMClassifier

        if not requested or "lightgbm" in requested:
            candidates.append(
                SklearnPoolGainModel(
                    "lightgbm",
                    LGBMClassifier(
                        n_estimators=150,
                        max_depth=5,
                        learning_rate=0.05,
                        subsample=0.85,
                        colsample_bytree=0.85,
                        class_weight="balanced",
                        n_jobs=4,
                        random_state=42,
                        verbose=-1,
                    ),
                )
            )
    except Exception:
        pass
    if requested:
        candidates = [candidate for candidate in candidates if candidate.model_type in requested]
    if not candidates:
        raise RuntimeError(f"no candidate classifiers selected from POOL_GAIN_MODELS={sorted(requested)}")
    return candidates


def _add_price_features(bars: pd.DataFrame) -> pd.DataFrame:
    frame = bars.copy()
    frame["trade_date"] = pd.to_datetime(frame["trade_date"])
    frame = frame.sort_values(["symbol", "trade_date"]).reset_index(drop=True)
    for column in ["open", "high", "low", "close", "volume", "turnover"]:
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
    group = frame.groupby("symbol", group_keys=False)
    frame["prev_close"] = group["close"].shift(1)
    frame["pct_change"] = frame["close"] / frame["prev_close"] - 1
    frame["amplitude"] = (frame["high"] - frame["low"]) / frame["prev_close"].replace(0, np.nan)
    frame["intraday_return"] = frame["close"] / frame["open"].replace(0, np.nan) - 1
    frame["close_position"] = (frame["close"] - frame["low"]) / (frame["high"] - frame["low"]).replace(0, np.nan)
    frame["body_pct"] = (frame["close"] - frame["open"]).abs() / frame["prev_close"].replace(0, np.nan)
    frame["upper_shadow_pct"] = (frame["high"] - frame[["open", "close"]].max(axis=1)) / frame["prev_close"].replace(0, np.nan)
    frame["lower_shadow_pct"] = (frame[["open", "close"]].min(axis=1) - frame["low"]) / frame["prev_close"].replace(0, np.nan)
    for window in (3, 5, 10, 20):
        frame[f"return_{window}d"] = frame["close"] / group["close"].shift(window) - 1
    for window in (5, 20):
        frame[f"volatility_{window}d"] = group["pct_change"].transform(lambda s, w=window: s.rolling(w, min_periods=2).std())
    for window in (5, 10, 20):
        volume_ma = group["volume"].transform(lambda s, w=window: s.shift(1).rolling(w, min_periods=2).mean())
        turnover_ma = group["turnover"].transform(lambda s, w=window: s.shift(1).rolling(w, min_periods=2).mean())
        frame[f"volume_ratio_{window}d"] = frame["volume"] / volume_ma.replace(0, np.nan)
        frame[f"turnover_ratio_{window}d"] = frame["turnover"] / turnover_ma.replace(0, np.nan)
    for window in (5, 10, 20, 60):
        ma = group["close"].transform(lambda s, w=window: s.rolling(w, min_periods=2).mean())
        frame[f"close_to_ma{window}"] = frame["close"] / ma.replace(0, np.nan) - 1
        frame[f"above_ma{window}"] = (frame["close"] >= ma).astype(float)
    frame["ma_alignment_count"] = frame[["above_ma5", "above_ma10", "above_ma20", "above_ma60"]].sum(axis=1)
    ma5 = group["close"].transform(lambda s: s.rolling(5, min_periods=2).mean())
    ma5_prev = group["close"].transform(lambda s: s.shift(5).rolling(5, min_periods=2).mean())
    frame["ma5_slope_5d"] = ma5 / ma5_prev.replace(0, np.nan) - 1
    prev_close = group["close"].shift(1)
    for window in (20, 60, 120):
        high = group["high"].transform(lambda s, w=window: s.shift(1).rolling(w, min_periods=5).max())
        low = group["low"].transform(lambda s, w=window: s.shift(1).rolling(w, min_periods=5).min())
        frame[f"distance_to_{window}d_high"] = frame["close"] / high.replace(0, np.nan) - 1
        frame[f"breakout_{window}d"] = (frame["close"] >= high).astype(float)
        frame[f"fresh_breakout_{window}d"] = ((frame["close"] >= high) & (prev_close < high)).astype(float)
        if window == 20:
            frame["drawdown_from_20d_low"] = frame["close"] / low.replace(0, np.nan) - 1
    frame["turnover_log"] = np.log1p(frame["turnover"].clip(lower=0))
    frame["volume_log"] = np.log1p(frame["volume"].clip(lower=0))
    frame = _add_secondary_technical_features(frame)
    frame = _add_macd_features(frame)
    frame = _add_market_breadth_features(frame)
    return frame


def _add_secondary_technical_features(frame: pd.DataFrame) -> pd.DataFrame:
    enriched = frame.copy()
    group = enriched.groupby("symbol", group_keys=False)
    prev_close = group["close"].shift(1)
    prev_high = group["high"].shift(1)
    prev_low = group["low"].shift(1)

    delta = group["close"].diff()
    gain = delta.clip(lower=0)
    loss = (-delta).clip(lower=0)
    for window in (6, 14, 24):
        avg_gain = gain.groupby(enriched["symbol"]).transform(lambda s, w=window: s.rolling(w, min_periods=max(3, w // 2)).mean())
        avg_loss = loss.groupby(enriched["symbol"]).transform(lambda s, w=window: s.rolling(w, min_periods=max(3, w // 2)).mean())
        rs = avg_gain / avg_loss.replace(0, np.nan)
        enriched[f"rsi_{window}"] = 100 - 100 / (1 + rs)
        enriched.loc[(avg_loss == 0) & (avg_gain > 0), f"rsi_{window}"] = 100
        enriched.loc[(avg_loss == 0) & (avg_gain == 0), f"rsi_{window}"] = 50
    prev_rsi14 = group["rsi_14"].shift(1)
    enriched["rsi_14_oversold"] = (enriched["rsi_14"] < 30).astype(float)
    enriched["rsi_14_overbought"] = (enriched["rsi_14"] > 70).astype(float)
    enriched["rsi_14_above_50"] = (enriched["rsi_14"] >= 50).astype(float)
    enriched["rsi_14_cross_above_50"] = ((prev_rsi14 < 50) & (enriched["rsi_14"] >= 50)).astype(float)
    enriched["rsi_14_cross_below_50"] = ((prev_rsi14 >= 50) & (enriched["rsi_14"] < 50)).astype(float)
    enriched["rsi_14_slope_3d"] = enriched["rsi_14"] - group["rsi_14"].shift(3)
    enriched["rsi_14_slope_5d"] = enriched["rsi_14"] - group["rsi_14"].shift(5)

    mid = group["close"].transform(lambda s: s.rolling(20, min_periods=10).mean())
    std = group["close"].transform(lambda s: s.rolling(20, min_periods=10).std())
    enriched["boll_mid_20"] = mid
    enriched["boll_upper_20"] = mid + 2 * std
    enriched["boll_lower_20"] = mid - 2 * std
    band_width = (enriched["boll_upper_20"] - enriched["boll_lower_20"]) / mid.replace(0, np.nan)
    enriched["close_to_boll_mid_20"] = enriched["close"] / mid.replace(0, np.nan) - 1
    enriched["boll_position_20"] = (enriched["close"] - enriched["boll_lower_20"]) / (
        enriched["boll_upper_20"] - enriched["boll_lower_20"]
    ).replace(0, np.nan)
    enriched["boll_width_20"] = band_width
    enriched["boll_width_change_5d"] = band_width / group["boll_width_20"].shift(5).replace(0, np.nan) - 1
    squeeze_threshold = group["boll_width_20"].transform(lambda s: s.shift(1).rolling(60, min_periods=20).quantile(0.25))
    enriched["boll_squeeze_60d"] = (enriched["boll_width_20"] <= squeeze_threshold).astype(float)
    enriched["boll_break_upper_20"] = (enriched["close"] > enriched["boll_upper_20"]).astype(float)
    enriched["boll_break_lower_20"] = (enriched["close"] < enriched["boll_lower_20"]).astype(float)
    prev_boll_lower = group["boll_lower_20"].shift(1)
    prev_boll_mid = group["boll_mid_20"].shift(1)
    enriched["boll_reclaim_lower_20"] = ((prev_close < prev_boll_lower) & (enriched["close"] >= enriched["boll_lower_20"])).astype(float)
    enriched["boll_pullback_mid_20"] = ((prev_close > prev_boll_mid) & enriched["close_to_boll_mid_20"].between(-0.015, 0.015)).astype(float)
    enriched["boll_upper_break_with_volume"] = (
        (enriched["boll_break_upper_20"] >= 1) & (enriched["volume_ratio_20d"] >= 1.2)
    ).astype(float)

    low_9 = group["low"].transform(lambda s: s.rolling(9, min_periods=5).min())
    high_9 = group["high"].transform(lambda s: s.rolling(9, min_periods=5).max())
    rsv = (enriched["close"] - low_9) / (high_9 - low_9).replace(0, np.nan) * 100
    enriched["kdj_k"] = rsv.groupby(enriched["symbol"]).transform(lambda s: s.ewm(alpha=1 / 3, adjust=False).mean())
    enriched["kdj_d"] = enriched.groupby("symbol", group_keys=False)["kdj_k"].transform(lambda s: s.ewm(alpha=1 / 3, adjust=False).mean())
    enriched["kdj_j"] = 3 * enriched["kdj_k"] - 2 * enriched["kdj_d"]
    prev_k = group["kdj_k"].shift(1)
    prev_d = group["kdj_d"].shift(1)
    kdj_golden = (prev_k <= prev_d) & (enriched["kdj_k"] > enriched["kdj_d"])
    kdj_dead = (prev_k >= prev_d) & (enriched["kdj_k"] < enriched["kdj_d"])
    enriched["kdj_golden_cross"] = kdj_golden.astype(float)
    enriched["kdj_dead_cross"] = kdj_dead.astype(float)
    enriched["kdj_low_golden_cross"] = (kdj_golden & (enriched["kdj_k"] < 30) & (enriched["kdj_d"] < 30)).astype(float)
    enriched["kdj_high_dead_cross"] = (kdj_dead & (enriched["kdj_k"] > 70) & (enriched["kdj_d"] > 70)).astype(float)
    enriched["kdj_j_extreme_low"] = (enriched["kdj_j"] < 0).astype(float)
    enriched["kdj_j_extreme_high"] = (enriched["kdj_j"] > 100).astype(float)
    enriched["kdj_k_slope_3d"] = enriched["kdj_k"] - group["kdj_k"].shift(3)
    enriched["kdj_j_slope_3d"] = enriched["kdj_j"] - group["kdj_j"].shift(3)

    tr_parts = pd.concat(
        [
            enriched["high"] - enriched["low"],
            (enriched["high"] - prev_close).abs(),
            (enriched["low"] - prev_close).abs(),
        ],
        axis=1,
    )
    true_range = tr_parts.max(axis=1)
    plus_dm = np.where((enriched["high"] - prev_high > prev_low - enriched["low"]) & (enriched["high"] - prev_high > 0), enriched["high"] - prev_high, 0.0)
    minus_dm = np.where((prev_low - enriched["low"] > enriched["high"] - prev_high) & (prev_low - enriched["low"] > 0), prev_low - enriched["low"], 0.0)
    tr_sum_14 = true_range.groupby(enriched["symbol"]).transform(lambda s: s.rolling(14, min_periods=7).sum())
    plus_sum_14 = pd.Series(plus_dm, index=enriched.index).groupby(enriched["symbol"]).transform(lambda s: s.rolling(14, min_periods=7).sum())
    minus_sum_14 = pd.Series(minus_dm, index=enriched.index).groupby(enriched["symbol"]).transform(lambda s: s.rolling(14, min_periods=7).sum())
    enriched["plus_di_14"] = 100 * plus_sum_14 / tr_sum_14.replace(0, np.nan)
    enriched["minus_di_14"] = 100 * minus_sum_14 / tr_sum_14.replace(0, np.nan)
    dx = (enriched["plus_di_14"] - enriched["minus_di_14"]).abs() / (enriched["plus_di_14"] + enriched["minus_di_14"]).replace(0, np.nan) * 100
    enriched["adx_14"] = dx.groupby(enriched["symbol"]).transform(lambda s: s.rolling(14, min_periods=7).mean())
    prev_plus_di = group["plus_di_14"].shift(1)
    prev_minus_di = group["minus_di_14"].shift(1)
    enriched["adx_rising_3d"] = (enriched["adx_14"] > group["adx_14"].shift(3)).astype(float)
    enriched["adx_strong_25"] = (enriched["adx_14"] >= 25).astype(float)
    enriched["dmi_bullish"] = (enriched["plus_di_14"] > enriched["minus_di_14"]).astype(float)
    enriched["dmi_golden_cross"] = ((prev_plus_di <= prev_minus_di) & (enriched["plus_di_14"] > enriched["minus_di_14"])).astype(float)
    enriched["dmi_dead_cross"] = ((prev_plus_di >= prev_minus_di) & (enriched["plus_di_14"] < enriched["minus_di_14"])).astype(float)

    atr_14 = true_range.groupby(enriched["symbol"]).transform(lambda s: s.rolling(14, min_periods=7).mean())
    enriched["atr_14_pct"] = atr_14 / enriched["close"].replace(0, np.nan)
    enriched["atr_expansion_5d"] = (enriched["atr_14_pct"] > group["atr_14_pct"].shift(5)).astype(float)
    amp_5 = group["amplitude"].transform(lambda s: s.rolling(5, min_periods=3).mean())
    amp_20 = group["amplitude"].transform(lambda s: s.rolling(20, min_periods=10).mean())
    enriched["amplitude_ratio_5_20"] = amp_5 / amp_20.replace(0, np.nan)

    direction = np.sign(enriched["close"] - prev_close).fillna(0)
    enriched["obv"] = (direction * enriched["volume"].fillna(0)).groupby(enriched["symbol"]).cumsum()
    enriched["obv_slope_5d"] = enriched["obv"] - group["obv"].shift(5)
    enriched["obv_slope_10d"] = enriched["obv"] - group["obv"].shift(10)
    prev_obv_high_20 = group["obv"].transform(lambda s: s.shift(1).rolling(20, min_periods=10).max())
    enriched["obv_new_high_20"] = (enriched["obv"] >= prev_obv_high_20).astype(float)

    typical_price = (enriched["high"] + enriched["low"] + enriched["close"]) / 3
    raw_money_flow = typical_price * enriched["volume"]
    tp_delta = typical_price.groupby(enriched["symbol"]).diff()
    positive_flow = raw_money_flow.where(tp_delta > 0, 0.0)
    negative_flow = raw_money_flow.where(tp_delta < 0, 0.0).abs()
    pos_flow_14 = positive_flow.groupby(enriched["symbol"]).transform(lambda s: s.rolling(14, min_periods=7).sum())
    neg_flow_14 = negative_flow.groupby(enriched["symbol"]).transform(lambda s: s.rolling(14, min_periods=7).sum())
    money_ratio = pos_flow_14 / neg_flow_14.replace(0, np.nan)
    enriched["mfi_14"] = 100 - 100 / (1 + money_ratio)
    enriched.loc[(neg_flow_14 == 0) & (pos_flow_14 > 0), "mfi_14"] = 100
    enriched["mfi_14_strong"] = (enriched["mfi_14"] >= 60).astype(float)
    enriched["mfi_14_oversold"] = (enriched["mfi_14"] <= 20).astype(float)
    enriched["mfi_14_slope_3d"] = enriched["mfi_14"] - group["mfi_14"].shift(3)

    money_flow_multiplier = ((enriched["close"] - enriched["low"]) - (enriched["high"] - enriched["close"])) / (
        enriched["high"] - enriched["low"]
    ).replace(0, np.nan)
    money_flow_volume = money_flow_multiplier * enriched["volume"]
    volume_sum_20 = group["volume"].transform(lambda s: s.rolling(20, min_periods=10).sum())
    enriched["cmf_20"] = money_flow_volume.groupby(enriched["symbol"]).transform(lambda s: s.rolling(20, min_periods=10).sum()) / volume_sum_20.replace(0, np.nan)
    enriched["cmf_20_positive"] = (enriched["cmf_20"] > 0).astype(float)
    enriched["cmf_20_rising_5d"] = (enriched["cmf_20"] > group["cmf_20"].shift(5)).astype(float)

    pv_sum_20 = (typical_price * enriched["volume"]).groupby(enriched["symbol"]).transform(lambda s: s.rolling(20, min_periods=10).sum())
    enriched["vwap_20"] = pv_sum_20 / volume_sum_20.replace(0, np.nan)
    enriched["close_to_vwap_20"] = enriched["close"] / enriched["vwap_20"].replace(0, np.nan) - 1
    enriched["vwap_reclaim_20"] = ((prev_close < group["vwap_20"].shift(1)) & (enriched["close"] >= enriched["vwap_20"])).astype(float)

    prev_price_high_20 = group["high"].transform(lambda s: s.shift(1).rolling(20, min_periods=10).max())
    prev_price_low_20 = group["low"].transform(lambda s: s.shift(1).rolling(20, min_periods=10).min())
    price_new_low = enriched["low"] <= prev_price_low_20
    price_new_high = enriched["high"] >= prev_price_high_20
    prev_rsi_low_20 = group["rsi_14"].transform(lambda s: s.shift(1).rolling(20, min_periods=10).min())
    prev_rsi_high_20 = group["rsi_14"].transform(lambda s: s.shift(1).rolling(20, min_periods=10).max())
    prev_kdj_low_20 = group["kdj_j"].transform(lambda s: s.shift(1).rolling(20, min_periods=10).min())
    prev_kdj_high_20 = group["kdj_j"].transform(lambda s: s.shift(1).rolling(20, min_periods=10).max())
    prev_obv_low_20 = group["obv"].transform(lambda s: s.shift(1).rolling(20, min_periods=10).min())
    enriched["rsi_bullish_divergence_20d"] = (price_new_low & (enriched["rsi_14"] > prev_rsi_low_20)).astype(float)
    enriched["rsi_bearish_divergence_20d"] = (price_new_high & (enriched["rsi_14"] < prev_rsi_high_20)).astype(float)
    enriched["kdj_bullish_divergence_20d"] = (price_new_low & (enriched["kdj_j"] > prev_kdj_low_20)).astype(float)
    enriched["kdj_bearish_divergence_20d"] = (price_new_high & (enriched["kdj_j"] < prev_kdj_high_20)).astype(float)
    enriched["obv_bullish_divergence_20d"] = (price_new_low & (enriched["obv"] > prev_obv_low_20)).astype(float)
    enriched["obv_bearish_divergence_20d"] = (price_new_high & (enriched["obv"] < prev_obv_high_20)).astype(float)

    enriched["technical_bullish_confluence"] = (
        (enriched["rsi_14_above_50"] >= 1).astype(int)
        + (enriched["boll_break_upper_20"] >= 1).astype(int)
        + (enriched["kdj_golden_cross"] >= 1).astype(int)
        + (enriched["dmi_bullish"] >= 1).astype(int)
        + (enriched["cmf_20_positive"] >= 1).astype(int)
    ).astype(float)
    enriched["technical_reversal_confluence"] = (
        (enriched["boll_reclaim_lower_20"] >= 1).astype(int)
        + (enriched["rsi_bullish_divergence_20d"] >= 1).astype(int)
        + (enriched["kdj_low_golden_cross"] >= 1).astype(int)
        + (enriched["mfi_14_oversold"] >= 1).astype(int)
    ).astype(float)

    hl2 = (enriched["high"] + enriched["low"]) / 2
    supertrend_upper = hl2 + 3 * atr_14
    supertrend_lower = hl2 - 3 * atr_14
    enriched["supertrend_10_3"] = _supertrend_by_symbol(enriched, supertrend_upper, supertrend_lower)
    enriched["supertrend_direction_10_3"] = (enriched["close"] >= enriched["supertrend_10_3"]).astype(float)
    prev_supertrend_direction = group["supertrend_direction_10_3"].shift(1)
    enriched["supertrend_flip_bullish"] = ((prev_supertrend_direction < 1) & (enriched["supertrend_direction_10_3"] >= 1)).astype(float)
    enriched["supertrend_flip_bearish"] = ((prev_supertrend_direction >= 1) & (enriched["supertrend_direction_10_3"] < 1)).astype(float)
    enriched["close_to_supertrend_10_3"] = enriched["close"] / enriched["supertrend_10_3"].replace(0, np.nan) - 1

    high_9_ichi = group["high"].transform(lambda s: s.rolling(9, min_periods=5).max())
    low_9_ichi = group["low"].transform(lambda s: s.rolling(9, min_periods=5).min())
    high_26_ichi = group["high"].transform(lambda s: s.rolling(26, min_periods=13).max())
    low_26_ichi = group["low"].transform(lambda s: s.rolling(26, min_periods=13).min())
    high_52_ichi = group["high"].transform(lambda s: s.rolling(52, min_periods=26).max())
    low_52_ichi = group["low"].transform(lambda s: s.rolling(52, min_periods=26).min())
    enriched["ichimoku_tenkan_9"] = (high_9_ichi + low_9_ichi) / 2
    enriched["ichimoku_kijun_26"] = (high_26_ichi + low_26_ichi) / 2
    enriched["ichimoku_span_a"] = (enriched["ichimoku_tenkan_9"] + enriched["ichimoku_kijun_26"]) / 2
    enriched["ichimoku_span_b"] = (high_52_ichi + low_52_ichi) / 2
    enriched["ichimoku_cloud_top"] = enriched[["ichimoku_span_a", "ichimoku_span_b"]].max(axis=1)
    enriched["ichimoku_cloud_bottom"] = enriched[["ichimoku_span_a", "ichimoku_span_b"]].min(axis=1)
    enriched["ichimoku_above_cloud"] = (enriched["close"] > enriched["ichimoku_cloud_top"]).astype(float)
    enriched["ichimoku_in_cloud"] = enriched["close"].between(enriched["ichimoku_cloud_bottom"], enriched["ichimoku_cloud_top"]).astype(float)
    prev_tenkan = group["ichimoku_tenkan_9"].shift(1)
    prev_kijun = group["ichimoku_kijun_26"].shift(1)
    enriched["ichimoku_tk_golden_cross"] = (
        (prev_tenkan <= prev_kijun) & (enriched["ichimoku_tenkan_9"] > enriched["ichimoku_kijun_26"])
    ).astype(float)
    enriched["ichimoku_cloud_bullish"] = (enriched["ichimoku_span_a"] > enriched["ichimoku_span_b"]).astype(float)

    typical_ma_20 = typical_price.groupby(enriched["symbol"]).transform(lambda s: s.rolling(20, min_periods=10).mean())
    mean_dev_20 = typical_price.groupby(enriched["symbol"]).transform(
        lambda s: s.rolling(20, min_periods=10).apply(lambda x: np.mean(np.abs(x - np.mean(x))), raw=True)
    )
    enriched["cci_20"] = (typical_price - typical_ma_20) / (0.015 * mean_dev_20.replace(0, np.nan))
    prev_cci = group["cci_20"].shift(1)
    enriched["cci_cross_above_minus100"] = ((prev_cci < -100) & (enriched["cci_20"] >= -100)).astype(float)
    enriched["cci_cross_above_0"] = ((prev_cci < 0) & (enriched["cci_20"] >= 0)).astype(float)
    enriched["cci_cross_above_100"] = ((prev_cci < 100) & (enriched["cci_20"] >= 100)).astype(float)
    enriched["cci_extreme_high"] = (enriched["cci_20"] >= 200).astype(float)
    enriched["cci_extreme_low"] = (enriched["cci_20"] <= -200).astype(float)

    for window in (5, 10, 20):
        enriched[f"roc_{window}"] = enriched["close"] / group["close"].shift(window).replace(0, np.nan) - 1
    enriched["roc_10_acceleration"] = enriched["roc_10"] - group["roc_10"].shift(5)
    enriched["roc_10_cross_above_0"] = ((group["roc_10"].shift(1) < 0) & (enriched["roc_10"] >= 0)).astype(float)

    high_14 = group["high"].transform(lambda s: s.rolling(14, min_periods=7).max())
    low_14 = group["low"].transform(lambda s: s.rolling(14, min_periods=7).min())
    enriched["williams_r_14"] = -100 * (high_14 - enriched["close"]) / (high_14 - low_14).replace(0, np.nan)
    prev_wr = group["williams_r_14"].shift(1)
    enriched["williams_r_rebound_oversold"] = ((prev_wr < -80) & (enriched["williams_r_14"] >= -80)).astype(float)
    enriched["williams_r_fall_overbought"] = ((prev_wr > -20) & (enriched["williams_r_14"] <= -20)).astype(float)

    enriched["donchian_high_20"] = prev_price_high_20
    enriched["donchian_low_20"] = prev_price_low_20
    enriched["donchian_position_20"] = (enriched["close"] - enriched["donchian_low_20"]) / (
        enriched["donchian_high_20"] - enriched["donchian_low_20"]
    ).replace(0, np.nan)
    enriched["donchian_width_20"] = (enriched["donchian_high_20"] - enriched["donchian_low_20"]) / enriched["close"].replace(0, np.nan)
    enriched["donchian_breakout_20"] = (enriched["close"] >= enriched["donchian_high_20"]).astype(float)
    enriched["donchian_breakdown_20"] = (enriched["close"] <= enriched["donchian_low_20"]).astype(float)

    enriched["keltner_mid_20"] = enriched["vwap_20"].combine_first(mid)
    enriched["keltner_upper_20"] = enriched["keltner_mid_20"] + 2 * atr_14
    enriched["keltner_lower_20"] = enriched["keltner_mid_20"] - 2 * atr_14
    enriched["keltner_position_20"] = (enriched["close"] - enriched["keltner_lower_20"]) / (
        enriched["keltner_upper_20"] - enriched["keltner_lower_20"]
    ).replace(0, np.nan)
    enriched["keltner_width_20"] = (enriched["keltner_upper_20"] - enriched["keltner_lower_20"]) / enriched["keltner_mid_20"].replace(0, np.nan)
    enriched["keltner_break_upper_20"] = (enriched["close"] > enriched["keltner_upper_20"]).astype(float)
    enriched["keltner_reclaim_mid_20"] = ((prev_close < group["keltner_mid_20"].shift(1)) & (enriched["close"] >= enriched["keltner_mid_20"])).astype(float)

    enriched["aroon_up_25"] = group["high"].transform(lambda s: s.rolling(25, min_periods=12).apply(_aroon_up, raw=True))
    enriched["aroon_down_25"] = group["low"].transform(lambda s: s.rolling(25, min_periods=12).apply(_aroon_down, raw=True))
    enriched["aroon_osc_25"] = enriched["aroon_up_25"] - enriched["aroon_down_25"]
    enriched["aroon_bullish_cross"] = (
        (group["aroon_up_25"].shift(1) <= group["aroon_down_25"].shift(1)) & (enriched["aroon_up_25"] > enriched["aroon_down_25"])
    ).astype(float)
    enriched["aroon_strong_up"] = ((enriched["aroon_up_25"] >= 70) & (enriched["aroon_down_25"] <= 30)).astype(float)

    ema15_1 = group["close"].transform(lambda s: s.ewm(span=15, adjust=False, min_periods=15).mean())
    ema15_2 = ema15_1.groupby(enriched["symbol"]).transform(lambda s: s.ewm(span=15, adjust=False, min_periods=15).mean())
    ema15_3 = ema15_2.groupby(enriched["symbol"]).transform(lambda s: s.ewm(span=15, adjust=False, min_periods=15).mean())
    enriched["trix_15"] = ema15_3 / ema15_3.groupby(enriched["symbol"]).shift(1).replace(0, np.nan) - 1
    enriched["trix_signal_9"] = group["trix_15"].transform(lambda s: s.rolling(9, min_periods=4).mean())
    enriched["trix_golden_cross"] = (
        (group["trix_15"].shift(1) <= group["trix_signal_9"].shift(1)) & (enriched["trix_15"] > enriched["trix_signal_9"])
    ).astype(float)
    enriched["trix_above_zero"] = (enriched["trix_15"] > 0).astype(float)

    price_change = group["close"].diff()
    abs_price_change = price_change.abs()
    ema_pc_25 = price_change.groupby(enriched["symbol"]).transform(lambda s: s.ewm(span=25, adjust=False, min_periods=13).mean())
    ema_abs_pc_25 = abs_price_change.groupby(enriched["symbol"]).transform(lambda s: s.ewm(span=25, adjust=False, min_periods=13).mean())
    double_pc = ema_pc_25.groupby(enriched["symbol"]).transform(lambda s: s.ewm(span=13, adjust=False, min_periods=7).mean())
    double_abs_pc = ema_abs_pc_25.groupby(enriched["symbol"]).transform(lambda s: s.ewm(span=13, adjust=False, min_periods=7).mean())
    enriched["tsi_25_13"] = 100 * double_pc / double_abs_pc.replace(0, np.nan)
    enriched["tsi_signal_7"] = group["tsi_25_13"].transform(lambda s: s.rolling(7, min_periods=3).mean())
    enriched["tsi_golden_cross"] = (
        (group["tsi_25_13"].shift(1) <= group["tsi_signal_7"].shift(1)) & (enriched["tsi_25_13"] > enriched["tsi_signal_7"])
    ).astype(float)
    enriched["tsi_above_zero"] = (enriched["tsi_25_13"] > 0).astype(float)

    ema13 = group["close"].transform(lambda s: s.ewm(span=13, adjust=False, min_periods=7).mean())
    enriched["elder_bull_power_13"] = enriched["high"] - ema13
    enriched["elder_bear_power_13"] = enriched["low"] - ema13
    enriched["elder_bull_power_rising_3d"] = (enriched["elder_bull_power_13"] > group["elder_bull_power_13"].shift(3)).astype(float)
    enriched["elder_bear_power_recovering_3d"] = (enriched["elder_bear_power_13"] > group["elder_bear_power_13"].shift(3)).astype(float)
    return enriched


def _supertrend_by_symbol(frame: pd.DataFrame, upper: pd.Series, lower: pd.Series) -> pd.Series:
    result = pd.Series(np.nan, index=frame.index)
    for _, idx in frame.groupby("symbol").groups.items():
        idx_list = list(idx)
        closes = frame.loc[idx_list, "close"].to_numpy(dtype="float64")
        upper_values = upper.loc[idx_list].to_numpy(dtype="float64")
        lower_values = lower.loc[idx_list].to_numpy(dtype="float64")
        trend = np.full(len(idx_list), np.nan)
        bullish = True
        for pos in range(len(idx_list)):
            if np.isnan(upper_values[pos]) or np.isnan(lower_values[pos]):
                continue
            if pos > 0 and not np.isnan(trend[pos - 1]):
                if closes[pos] > trend[pos - 1]:
                    bullish = True
                elif closes[pos] < trend[pos - 1]:
                    bullish = False
            trend[pos] = lower_values[pos] if bullish else upper_values[pos]
        result.loc[idx_list] = trend
    return result


def _aroon_up(values: np.ndarray) -> float:
    if len(values) == 0 or np.all(np.isnan(values)):
        return np.nan
    return 100.0 * (int(np.nanargmax(values)) + 1) / len(values)


def _aroon_down(values: np.ndarray) -> float:
    if len(values) == 0 or np.all(np.isnan(values)):
        return np.nan
    return 100.0 * (int(np.nanargmin(values)) + 1) / len(values)


def _add_market_breadth_features(frame: pd.DataFrame) -> pd.DataFrame:
    enriched = frame.copy()
    keys = ["market", "trade_date"]
    breadth = enriched.groupby(keys).agg(
        market_advancing_ratio=("pct_change", lambda s: float((pd.to_numeric(s, errors="coerce") > 0).mean())),
        market_avg_return=("pct_change", "mean"),
        market_median_return=("pct_change", "median"),
        market_up_volume_ratio=("volume", lambda s: np.nan),
        market_above_ma20_ratio=("above_ma20", "mean"),
        market_fresh_high_20_ratio=("fresh_breakout_20d", "mean"),
        market_volume_expansion_ratio=("volume_ratio_20d", lambda s: float((pd.to_numeric(s, errors="coerce") >= 1.5).mean())),
    ).reset_index()
    up_volume = (
        enriched.assign(_up_volume=np.where(enriched["pct_change"] > 0, enriched["volume"], 0.0))
        .groupby(keys)
        .agg(_up_volume=("_up_volume", "sum"), _total_volume=("volume", "sum"))
        .reset_index()
    )
    up_volume["market_up_volume_ratio"] = up_volume["_up_volume"] / up_volume["_total_volume"].replace(0, np.nan)
    breadth = breadth.drop(columns=["market_up_volume_ratio"]).merge(up_volume[keys + ["market_up_volume_ratio"]], on=keys, how="left")
    breadth = breadth.sort_values(keys)
    breadth["market_strong_breadth"] = (
        (breadth["market_advancing_ratio"] >= 0.6)
        & (breadth["market_above_ma20_ratio"] >= 0.55)
        & (breadth["market_up_volume_ratio"] >= 0.55)
    ).astype(float)
    breadth["market_weak_breadth"] = (
        (breadth["market_advancing_ratio"] <= 0.4)
        & (breadth["market_above_ma20_ratio"] <= 0.45)
    ).astype(float)
    breadth["market_breadth_change_3d"] = breadth["market_advancing_ratio"] - breadth.groupby("market")["market_advancing_ratio"].shift(3)
    return enriched.merge(breadth, on=keys, how="left")


def _add_macd_features(frame: pd.DataFrame) -> pd.DataFrame:
    enriched = frame.copy()
    group = enriched.groupby("symbol", group_keys=False)
    ema12 = group["close"].transform(lambda s: s.ewm(span=12, adjust=False, min_periods=12).mean())
    ema26 = group["close"].transform(lambda s: s.ewm(span=26, adjust=False, min_periods=26).mean())
    enriched["macd_dif"] = ema12 - ema26
    macd_group = enriched.groupby("symbol", group_keys=False)
    enriched["macd_dea"] = macd_group["macd_dif"].transform(lambda s: s.ewm(span=9, adjust=False, min_periods=9).mean())
    enriched["macd_hist"] = enriched["macd_dif"] - enriched["macd_dea"]

    macd_group = enriched.groupby("symbol", group_keys=False)
    prev_dif = macd_group["macd_dif"].shift(1)
    prev_dea = macd_group["macd_dea"].shift(1)
    prev_hist = macd_group["macd_hist"].shift(1)
    prev_prev_hist = macd_group["macd_hist"].shift(2)

    enriched["macd_dif_above_zero"] = (enriched["macd_dif"] > 0).astype(float)
    enriched["macd_dea_above_zero"] = (enriched["macd_dea"] > 0).astype(float)
    enriched["macd_hist_above_zero"] = (enriched["macd_hist"] > 0).astype(float)
    enriched["macd_above_zero_state"] = ((enriched["macd_dif"] > 0) & (enriched["macd_dea"] > 0)).astype(float)
    enriched["macd_below_zero_state"] = ((enriched["macd_dif"] < 0) & (enriched["macd_dea"] < 0)).astype(float)

    golden_cross = (prev_dif <= prev_dea) & (enriched["macd_dif"] > enriched["macd_dea"])
    dead_cross = (prev_dif >= prev_dea) & (enriched["macd_dif"] < enriched["macd_dea"])
    enriched["macd_golden_cross"] = golden_cross.astype(float)
    enriched["macd_dead_cross"] = dead_cross.astype(float)
    enriched["macd_golden_cross_above_zero"] = (golden_cross & (enriched["macd_dif"] > 0) & (enriched["macd_dea"] > 0)).astype(float)
    enriched["macd_golden_cross_below_zero"] = (golden_cross & (enriched["macd_dif"] < 0) & (enriched["macd_dea"] < 0)).astype(float)
    enriched["macd_dead_cross_above_zero"] = (dead_cross & (enriched["macd_dif"] > 0) & (enriched["macd_dea"] > 0)).astype(float)
    enriched["macd_dead_cross_below_zero"] = (dead_cross & (enriched["macd_dif"] < 0) & (enriched["macd_dea"] < 0)).astype(float)

    enriched["macd_hist_red_expanding"] = ((enriched["macd_hist"] > 0) & (enriched["macd_hist"] > prev_hist)).astype(float)
    enriched["macd_hist_red_shrinking"] = ((enriched["macd_hist"] > 0) & (enriched["macd_hist"] < prev_hist)).astype(float)
    enriched["macd_hist_green_expanding"] = ((enriched["macd_hist"] < 0) & (enriched["macd_hist"] < prev_hist)).astype(float)
    enriched["macd_hist_green_shrinking"] = ((enriched["macd_hist"] < 0) & (enriched["macd_hist"] > prev_hist)).astype(float)
    enriched["macd_hist_turn_red"] = ((prev_hist <= 0) & (enriched["macd_hist"] > 0)).astype(float)
    enriched["macd_hist_turn_green"] = ((prev_hist >= 0) & (enriched["macd_hist"] < 0)).astype(float)

    enriched["macd_dif_slope_3d"] = enriched["macd_dif"] - macd_group["macd_dif"].shift(3)
    enriched["macd_dif_slope_5d"] = enriched["macd_dif"] - macd_group["macd_dif"].shift(5)
    enriched["macd_hist_slope_3d"] = enriched["macd_hist"] - macd_group["macd_hist"].shift(3)
    enriched["macd_hist_acceleration"] = (enriched["macd_hist"] - prev_hist) - (prev_hist - prev_prev_hist)

    enriched["macd_above_zero_days"] = _consecutive_true_by_symbol(enriched["symbol"], enriched["macd_above_zero_state"] >= 1)
    enriched["macd_red_days"] = _consecutive_true_by_symbol(enriched["symbol"], enriched["macd_hist"] > 0)
    enriched["macd_green_days"] = _consecutive_true_by_symbol(enriched["symbol"], enriched["macd_hist"] < 0)

    prev_price_high_20 = group["high"].transform(lambda s: s.shift(1).rolling(20, min_periods=10).max())
    prev_price_low_20 = group["low"].transform(lambda s: s.shift(1).rolling(20, min_periods=10).min())
    prev_dif_high_20 = macd_group["macd_dif"].transform(lambda s: s.shift(1).rolling(20, min_periods=10).max())
    prev_dif_low_20 = macd_group["macd_dif"].transform(lambda s: s.shift(1).rolling(20, min_periods=10).min())
    prev_hist_high_20 = macd_group["macd_hist"].transform(lambda s: s.shift(1).rolling(20, min_periods=10).max())
    prev_hist_low_20 = macd_group["macd_hist"].transform(lambda s: s.shift(1).rolling(20, min_periods=10).min())

    price_new_low = enriched["low"] <= prev_price_low_20
    price_new_high = enriched["high"] >= prev_price_high_20
    enriched["macd_bullish_divergence_20d"] = (price_new_low & (enriched["macd_dif"] > prev_dif_low_20)).astype(float)
    enriched["macd_bearish_divergence_20d"] = (price_new_high & (enriched["macd_dif"] < prev_dif_high_20)).astype(float)
    enriched["macd_hist_bullish_divergence_20d"] = (price_new_low & (enriched["macd_hist"] > prev_hist_low_20)).astype(float)
    enriched["macd_hist_bearish_divergence_20d"] = (price_new_high & (enriched["macd_hist"] < prev_hist_high_20)).astype(float)

    enriched["macd_below_zero_golden_cross_with_volume"] = (
        (enriched["macd_golden_cross_below_zero"] >= 1) & (enriched["volume_ratio_20d"] >= 1.2)
    ).astype(float)
    enriched["macd_above_zero_golden_cross_with_breakout"] = (
        (enriched["macd_golden_cross_above_zero"] >= 1) & (enriched["fresh_breakout_60d"] >= 1)
    ).astype(float)
    enriched["macd_green_shrinking_near_ma20"] = (
        (enriched["macd_hist_green_shrinking"] >= 1) & enriched["close_to_ma20"].between(-0.03, 0.03)
    ).astype(float)
    enriched["macd_red_expanding_above_ma5"] = (
        (enriched["macd_hist_red_expanding"] >= 1) & (enriched["above_ma5"] >= 1)
    ).astype(float)
    enriched["macd_bullish_divergence_reversal"] = (
        ((enriched["macd_bullish_divergence_20d"] >= 1) | (enriched["macd_hist_bullish_divergence_20d"] >= 1))
        & (enriched["macd_hist_slope_3d"] > 0)
    ).astype(float)
    enriched["macd_bearish_divergence_risk"] = (
        ((enriched["macd_bearish_divergence_20d"] >= 1) | (enriched["macd_hist_bearish_divergence_20d"] >= 1))
        & (enriched["macd_hist_slope_3d"] < 0)
    ).astype(float)
    return enriched


def _consecutive_true_by_symbol(symbols: pd.Series, flag: pd.Series) -> pd.Series:
    result = pd.Series(0.0, index=flag.index)
    for _, idx in flag.groupby(symbols).groups.items():
        current = 0
        values = flag.loc[idx].fillna(False).astype(bool)
        counts: list[float] = []
        for value in values:
            current = current + 1 if bool(value) else 0
            counts.append(float(current))
        result.loc[idx] = counts
    return result


def _merge_score_features(frame: pd.DataFrame, scores: pd.DataFrame | None) -> pd.DataFrame:
    merged = frame.copy()
    if scores is None or scores.empty:
        for column in _score_columns():
            merged[column] = np.nan
        return _prepare_feature_frame(merged)
    score_frame = scores.copy()
    score_frame["trade_date"] = pd.to_datetime(score_frame["score_date"])
    merged = merged.merge(score_frame.drop(columns=["score_date"]), on=["symbol", "market", "trade_date"], how="left")
    return _prepare_feature_frame(merged)


def _prepare_feature_frame(frame: pd.DataFrame) -> pd.DataFrame:
    prepared = frame.copy()
    for column in _score_columns():
        if column not in prepared:
            prepared[column] = np.nan
    for tag in ["score_pool_tag", "observation_pool_tag", "limit_up_pool_tag", "volume_breakout_pool_tag"]:
        if tag not in prepared:
            prepared[tag] = 0.0
    if "rank_in_market" in prepared:
        rank = pd.to_numeric(prepared["rank_in_market"], errors="coerce")
        prepared["rank_pct_in_market"] = 1 - rank / rank.groupby(prepared["market"]).transform("max").replace(0, np.nan)
    else:
        prepared["rank_pct_in_market"] = np.nan
    return prepared


def _score_columns() -> list[str]:
    return [
        "trend_score",
        "momentum_score",
        "volume_score",
        "risk_score",
        "valuation_score",
        "quality_score",
        "model_score",
        "total_score",
        "rank_in_market",
    ]


def _feature_matrix(frame: pd.DataFrame, feature_names: list[str]) -> pd.DataFrame:
    columns: dict[str, pd.Series] = {}
    for name in feature_names:
        if name in frame:
            columns[name] = pd.to_numeric(frame[name], errors="coerce").replace([np.inf, -np.inf], np.nan)
        else:
            columns[name] = pd.Series(np.nan, index=frame.index)
    return pd.DataFrame(columns, index=frame.index)


def _load_daily_bars(
    conn: Any,
    start_date: str | None,
    max_rows: int | None = None,
    symbols: list[str] | None = None,
) -> pd.DataFrame:
    params: list[Any] = []
    where_parts: list[str] = []
    if start_date:
        where_parts.append("trade_date >= %s")
        params.append(start_date)
    if symbols:
        where_parts.append("symbol = any(%s)")
        params.append(symbols)
    where = f"where {' and '.join(where_parts)}" if where_parts else ""
    if max_rows:
        params.append(max_rows)
        query = f"""
            with recent as (
              select symbol, lower(market) as market, trade_date, open, high, low, close, volume, turnover
              from lb_daily_bars
              {where}
              order by trade_date desc, symbol
              limit %s
            )
            select *
            from recent
            order by symbol, trade_date
        """
    else:
        query = f"""
            select symbol, lower(market) as market, trade_date, open, high, low, close, volume, turnover
            from lb_daily_bars
            {where}
            order by symbol, trade_date
        """
    return _query_frame(conn, query, params)


def _load_score_features(conn: Any) -> pd.DataFrame:
    query = """
        select symbol, lower(market) as market, score_date, total_score, trend_score, momentum_score,
               volume_score, risk_score, valuation_score, quality_score, model_score, rank_in_market,
               case when coalesce(total_score, 0) >= 65 then 1.0 else 0.0 end as score_pool_tag,
               case when coalesce((payload->>'fresh_breakout_over_60')::boolean, false)
                     and (
                       coalesce((payload->>'breakout_volume_ratio_20')::numeric, 0) >= 1.5
                       or coalesce((payload->>'breakout_turnover_ratio_20')::numeric, 0) >= 1.5
                     )
                    then 1.0 else 0.0 end as volume_breakout_pool_tag
        from lb_stock_scores
    """
    return _query_frame(conn, query)


def _load_current_pool_candidates(conn: Any, as_of_date: str | None = None) -> pd.DataFrame:
    params: list[Any] = []
    score_date_clause = "select max(score_date) from lb_stock_scores" if not as_of_date else "%s::date"
    if as_of_date:
        params.append(as_of_date)
    query = f"""
        with latest_score as (
          select s.symbol, lower(s.market) as market, sym.name,
                 array_remove(array[
                   case when coalesce(s.total_score, 0) >= 65 then 'score_pool' end,
                   case when coalesce((s.payload->>'fresh_breakout_over_60')::boolean, false)
                         and (
                           coalesce((s.payload->>'breakout_volume_ratio_20')::numeric, 0) >= 1.5
                           or coalesce((s.payload->>'breakout_turnover_ratio_20')::numeric, 0) >= 1.5
                         ) then 'volume_breakout' end
                 ], null) as score_tags
          from lb_stock_scores s
          left join lb_symbols sym on sym.symbol = s.symbol
          where s.score_date = ({score_date_clause})
            and (
              coalesce(s.total_score, 0) >= 65
              or coalesce((s.payload->>'fresh_breakout_over_60')::boolean, false)
            )
        ),
        obs as (
          select symbol, lower(market) as market, max(name) as name,
                 array_agg(distinct strategy) filter (where strategy is not null) as obs_tags
          from lb_observation_pool
          where status in ('watch','active','candidate','观察','候选','入池')
          group by symbol, lower(market)
        ),
        latest_limit_up_model as (
          select model_run_id from lb_limit_up_model_runs order by trained_at desc limit 1
        ),
        limit_up as (
          select p.symbol, 'cn'::text as market, array['limit_up']::text[] as limit_tags
          from lb_limit_up_predictions p
          join latest_limit_up_model m on m.model_run_id = p.model_run_id
          where p.event_date = ((now() at time zone 'Asia/Shanghai')::date - 1)
            and coalesce(p.open_buy_score, 0) >= 50
        ),
        combined as (
          select symbol, market, name, score_tags as tags from latest_score
          union all
          select symbol, market, name, obs_tags as tags from obs
          union all
          select symbol, market, null::text as name, limit_tags as tags from limit_up
        )
        select c.symbol, c.market, coalesce(max(c.name), max(sym.name)) as name,
               array_agg(distinct tag) filter (where tag is not null) as pool_tags,
               max(case when tag='score_pool' then 1.0 else 0.0 end) as score_pool_tag,
               max(case when tag not in ('score_pool','volume_breakout','limit_up') then 1.0 else 0.0 end) as observation_pool_tag,
               max(case when tag='limit_up' then 1.0 else 0.0 end) as limit_up_pool_tag,
               max(case when tag='volume_breakout' then 1.0 else 0.0 end) as volume_breakout_pool_tag
        from combined c
        left join lb_symbols sym on sym.symbol = c.symbol
        left join lateral unnest(c.tags) tag on true
        group by c.symbol, c.market
    """
    frame = _query_frame(conn, query, params)
    if frame.empty:
        return frame
    frame["pool_tags"] = frame["pool_tags"].apply(lambda value: list(value or []))
    return frame


def _latest_model_run(conn: Any, model_root: str | Path) -> dict[str, Any]:
    rows = _query_frame(
        conn,
        """
        select model_run_id, model_type, model_path, metrics
        from lb_pool_gain_model_runs
        order by trained_at desc
        limit 1
        """,
    )
    if rows.empty:
        raise RuntimeError("no pool gain model run found; train first")
    row = rows.iloc[0].to_dict()
    path = Path(str(row["model_path"]))
    if not path.exists():
        fallback = Path(model_root) / path.name
        if fallback.exists():
            row["model_path"] = str(fallback)
    return row


def _query_frame(conn: Any, query: str, params: list[Any] | None = None) -> pd.DataFrame:
    with conn.cursor() as cur:
        cur.execute(query, params or [])
        rows = cur.fetchall()
        columns = [desc.name for desc in cur.description]
    return pd.DataFrame(rows, columns=columns)


def _load_model(path: Path) -> Any:
    with path.open("rb") as fh:
        return pickle.load(fh)


def _risk_score(frame: pd.DataFrame) -> pd.Series:
    volatility = pd.to_numeric(frame.get("volatility_20d"), errors="coerce").fillna(0.03)
    upper_shadow = pd.to_numeric(frame.get("upper_shadow_pct"), errors="coerce").fillna(0)
    chase = pd.to_numeric(frame.get("return_5d"), errors="coerce").fillna(0).clip(lower=0)
    score = 100 - volatility * 700 - upper_shadow * 450 - chase * 120
    return score.clip(0, 100).round(2)


def _overheated_mask(frame: pd.DataFrame) -> pd.Series:
    return_5d = pd.to_numeric(frame.get("return_5d"), errors="coerce").fillna(0)
    return_10d = pd.to_numeric(frame.get("return_10d"), errors="coerce").fillna(0)
    return_20d = pd.to_numeric(frame.get("return_20d"), errors="coerce").fillna(0)
    close_to_ma5 = pd.to_numeric(frame.get("close_to_ma5"), errors="coerce").fillna(0)
    close_to_ma20 = pd.to_numeric(frame.get("close_to_ma20"), errors="coerce").fillna(0)
    rsi_14 = pd.to_numeric(frame.get("rsi_14"), errors="coerce").fillna(50)
    mfi_14 = pd.to_numeric(frame.get("mfi_14"), errors="coerce").fillna(50)
    kdj_k = pd.to_numeric(frame.get("kdj_k"), errors="coerce").fillna(50)
    kdj_d = pd.to_numeric(frame.get("kdj_d"), errors="coerce").fillna(50)
    volume_ratio_20d = pd.to_numeric(frame.get("volume_ratio_20d"), errors="coerce").fillna(1)
    boll_position_20 = pd.to_numeric(frame.get("boll_position_20"), errors="coerce").fillna(0.5)
    pct_change = pd.to_numeric(frame.get("pct_change"), errors="coerce").fillna(0)

    high_chase = (return_5d >= 0.30) | (return_10d >= 0.70) | (return_20d >= 1.0)
    far_from_value = (close_to_ma20 >= 0.45) | ((close_to_ma5 >= 0.10) & (close_to_ma20 >= 0.30))
    overbought = (rsi_14 >= 85) & (mfi_14 >= 80) & (kdj_k >= 85) & (kdj_d >= 80)
    blowoff = (volume_ratio_20d >= 2.0) & (pct_change >= 0.08) & (boll_position_20 >= 1.0)
    return high_chase | far_from_value | (overbought & (far_from_value | blowoff))


def _prediction_reason(row: pd.Series) -> str:
    reasons: list[str] = []
    if row.get("score_pool_tag", 0) >= 1:
        reasons.append("score pool")
    if row.get("volume_breakout_pool_tag", 0) >= 1:
        reasons.append("fresh breakout")
    if row.get("limit_up_pool_tag", 0) >= 1:
        reasons.append("limit-up model")
    if row.get("ma_alignment_count", 0) >= 3:
        reasons.append("MA alignment")
    if row.get("volume_ratio_20d", 0) >= 1.5:
        reasons.append("volume expansion")
    if row.get("market_strong_breadth", 0) >= 1:
        reasons.append("strong market breadth")
    elif row.get("market_breadth_change_3d", 0) >= 0.15:
        reasons.append("market breadth improving")
    if row.get("supertrend_flip_bullish", 0) >= 1:
        reasons.append("Supertrend turns bullish")
    elif row.get("supertrend_direction_10_3", 0) >= 1:
        reasons.append("above Supertrend")
    if row.get("ichimoku_above_cloud", 0) >= 1 and row.get("ichimoku_cloud_bullish", 0) >= 1:
        reasons.append("Ichimoku bullish")
    if row.get("donchian_breakout_20", 0) >= 1:
        reasons.append("Donchian breakout")
    elif row.get("keltner_break_upper_20", 0) >= 1:
        reasons.append("Keltner breakout")
    if row.get("aroon_strong_up", 0) >= 1:
        reasons.append("Aroon strong up")
    if row.get("trix_golden_cross", 0) >= 1 or row.get("tsi_golden_cross", 0) >= 1:
        reasons.append("smoothed momentum cross")
    if row.get("cci_cross_above_100", 0) >= 1 or row.get("roc_10_cross_above_0", 0) >= 1:
        reasons.append("momentum breakout")
    if row.get("rsi_14_cross_above_50", 0) >= 1:
        reasons.append("RSI crosses 50")
    elif row.get("rsi_bullish_divergence_20d", 0) >= 1:
        reasons.append("RSI bullish divergence")
    if row.get("boll_upper_break_with_volume", 0) >= 1:
        reasons.append("BOLL volume breakout")
    elif row.get("boll_reclaim_lower_20", 0) >= 1:
        reasons.append("BOLL lower reclaim")
    if row.get("kdj_low_golden_cross", 0) >= 1:
        reasons.append("KDJ low golden cross")
    elif row.get("kdj_golden_cross", 0) >= 1:
        reasons.append("KDJ golden cross")
    if row.get("adx_strong_25", 0) >= 1 and row.get("dmi_bullish", 0) >= 1:
        reasons.append("ADX trend strength")
    if row.get("cmf_20_positive", 0) >= 1 and row.get("mfi_14_strong", 0) >= 1:
        reasons.append("money flow confirmation")
    if row.get("macd_golden_cross_above_zero", 0) >= 1:
        reasons.append("MACD upper golden cross")
    elif row.get("macd_golden_cross_below_zero", 0) >= 1:
        reasons.append("MACD lower golden cross")
    if row.get("macd_red_expanding_above_ma5", 0) >= 1:
        reasons.append("MACD red expanding")
    if row.get("macd_bullish_divergence_reversal", 0) >= 1:
        reasons.append("MACD bullish divergence")
    if row.get("macd_bearish_divergence_risk", 0) >= 1:
        reasons.append("MACD divergence risk")
    if not reasons:
        reasons.append("model-ranked watch")
    return "; ".join(reasons[:4])


def _payload(row: dict[str, Any]) -> dict[str, Any]:
    payload = {name: _json_value(row.get(name)) for name in FEATURE_NAMES if name in row}
    payload["next_open_target"] = "future 5 trading day high return >= 5%"
    return payload


def _public_prediction_row(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "symbol": row.get("symbol"),
        "market": row.get("market"),
        "name": row.get("name"),
        "asOfDate": str(row.get("trade_date")),
        "poolTags": row.get("pool_tags") or [],
        "probability": _float_or_none(row.get("probability")),
        "score": _float_or_none(row.get("score")),
        "riskScore": _float_or_none(row.get("risk_score")),
        "expectedMaxReturn5d": _float_or_none(row.get("expected_max_return_5d")),
        "suggestedEntry": row.get("suggested_entry"),
        "reason": row.get("reason"),
    }


def _json_value(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, (datetime, date, pd.Timestamp)):
        return value.isoformat()
    try:
        if pd.isna(value):
            return None
    except Exception:
        pass
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Decimal):
        return float(value)
    return value


def _float_or_none(value: Any) -> float | None:
    try:
        if value is None or pd.isna(value):
            return None
        return float(value)
    except Exception:
        return None


def _load_psycopg():
    try:
        import psycopg
        from psycopg.types.json import Jsonb
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("psycopg is required for pool gain modeling") from exc
    return psycopg, Jsonb


def summary_to_dict(summary: PoolGainTrainSummary | PoolGainPredictSummary) -> dict[str, Any]:
    return json.loads(json.dumps(summary.__dict__, default=str, ensure_ascii=False))

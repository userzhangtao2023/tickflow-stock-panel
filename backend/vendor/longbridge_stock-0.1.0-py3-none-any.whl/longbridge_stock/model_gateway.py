from __future__ import annotations

import os
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse

from longbridge_stock.model_registry import ModelRegistryError, UnsupportedModelError, get_model, list_models, predict


REGISTRY_PATH = os.getenv("LONGBRIDGE_ALGORITHM_REGISTRY", "configs/algorithm_registry.yaml")
MLFLOW_TRACKING_URI = os.getenv("MLFLOW_TRACKING_URI") or os.getenv("LONGBRIDGE_MLFLOW_TRACKING_URI") or "http://127.0.0.1:5000"

app = FastAPI(title="Longbridge Model Gateway")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class UTF8JSONResponse(JSONResponse):
    media_type = "application/json; charset=utf-8"


@app.get("/", response_class=HTMLResponse)
@app.get("/models", response_class=HTMLResponse)
def model_ui() -> HTMLResponse:
    return HTMLResponse(_model_ui_html())


@app.get("/api/health", response_class=UTF8JSONResponse)
def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "registryPath": REGISTRY_PATH,
        "mlflowTrackingUri": MLFLOW_TRACKING_URI,
    }


@app.get("/api/models", response_class=UTF8JSONResponse)
def models(
    family: str | None = None,
    status: str | None = None,
    include_metadata: bool = Query(default=False, alias="includeMetadata"),
) -> dict[str, Any]:
    try:
        rows = list_models(registry_path=REGISTRY_PATH, max_artifacts_per_algorithm=1000)
    except ModelRegistryError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    if family:
        rows = [row for row in rows if row.get("family") == family]
    if status:
        rows = [row for row in rows if row.get("status") == status]
    if not include_metadata:
        rows = [{key: value for key, value in row.items() if key != "metadata"} for row in rows]
    return {"total": len(rows), "models": rows}


@app.post("/api/models/{model_id:path}/predict", response_class=UTF8JSONResponse)
def model_predict(model_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return predict(model_id, payload, registry_path=REGISTRY_PATH)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=f"Model not found: {model_id}") from exc
    except UnsupportedModelError as exc:
        raise HTTPException(status_code=501, detail=str(exc)) from exc
    except ModelRegistryError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


def _model_ui_html() -> str:
    return """<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Longbridge Model Gateway</title>
  <style>
    :root { color-scheme: light; --bg:#f7f8fa; --panel:#fff; --ink:#172033; --muted:#667085; --line:#d9dee7; --blue:#2358d4; --green:#147a3f; --amber:#936600; --red:#b42318; font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }
    * { box-sizing: border-box; }
    body { margin:0; background:var(--bg); color:var(--ink); font-size:14px; line-height:1.45; }
    header { padding:18px 24px 14px; border-bottom:1px solid var(--line); background:var(--panel); display:grid; gap:14px; }
    .title-row, .actions, .filters, .summary { display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
    .title-row { justify-content:space-between; gap:16px; }
    h1 { font-size:20px; line-height:28px; margin:0; font-weight:720; letter-spacing:0; }
    .summary { color:var(--muted); gap:12px; }
    .metric strong { color:var(--ink); font-size:18px; margin-right:4px; }
    button, a.button, select, input { height:36px; border:1px solid var(--line); background:#fff; color:var(--ink); border-radius:6px; padding:0 11px; font:inherit; }
    button, a.button { display:inline-flex; align-items:center; justify-content:center; text-decoration:none; cursor:pointer; font-weight:620; }
    button.primary { background:var(--blue); border-color:var(--blue); color:#fff; }
    input { min-width:min(360px, 100%); flex:1 1 240px; }
    main { display:grid; grid-template-columns:minmax(0, 1fr) 390px; gap:0; min-height:calc(100vh - 126px); }
    .table-wrap { overflow:auto; }
    table { width:100%; border-collapse:collapse; background:#fff; table-layout:fixed; }
    th, td { border-bottom:1px solid var(--line); padding:10px 12px; text-align:left; vertical-align:top; }
    th { position:sticky; top:0; background:#eef2f7; z-index:1; color:#344054; font-size:12px; text-transform:uppercase; letter-spacing:0; }
    tr { cursor:pointer; }
    tr:hover td { background:#f2f6ff; }
    .status { display:inline-flex; align-items:center; min-width:72px; height:24px; border-radius:999px; padding:0 9px; font-size:12px; font-weight:700; border:1px solid transparent; }
    .status.active { color:var(--green); background:#e8f6ee; border-color:#b7e2c6; }
    .status.testing, .status.experimental { color:var(--amber); background:#fff7df; border-color:#efd27a; }
    .status.deprecated { color:var(--red); background:#fff0ef; border-color:#f3b8b3; }
    .mono { font-family:Consolas, "SFMono-Regular", Menlo, monospace; font-size:12px; overflow-wrap:anywhere; }
    .muted { color:var(--muted); }
    .name-cell strong { display:block; margin-bottom:3px; }
    .version-pill { display:inline-flex; align-items:center; height:22px; padding:0 8px; border:1px solid var(--line); border-radius:999px; background:#f8fafc; color:#475467; font-size:12px; font-weight:650; }
    aside { border-left:1px solid var(--line); background:var(--panel); padding:18px; overflow:auto; }
    aside h2 { margin:0 0 8px; font-size:17px; line-height:24px; letter-spacing:0; }
    .detail-grid { display:grid; gap:12px; margin-top:16px; }
    .detail-item span { display:block; color:var(--muted); font-size:12px; margin-bottom:3px; }
    pre { white-space:pre-wrap; word-break:break-word; background:#0f172a; color:#dbeafe; border-radius:6px; padding:12px; max-height:240px; overflow:auto; font-size:12px; }
    .version-list { display:grid; gap:8px; margin-top:8px; }
    .version-row { border:1px solid var(--line); border-radius:6px; padding:8px; background:#fbfcfe; }
    .empty, .error { padding:28px; color:var(--muted); }
    .error { color:var(--red); }
    @media (max-width:980px) { main { grid-template-columns:1fr; } aside { border-left:0; border-top:1px solid var(--line); } th:nth-child(4), td:nth-child(4), th:nth-child(6), td:nth-child(6) { display:none; } }
  </style>
</head>
<body>
  <header>
    <div class="title-row">
      <h1>Longbridge Model Gateway</h1>
      <div class="actions">
        <button class="primary" id="refreshBtn" type="button">&#21047;&#26032;</button>
        <a class="button" id="mlflowLink" href="http://192.168.10.28:5000" target="_blank" rel="noreferrer">MLflow</a>
        <a class="button" href="/api/models" target="_blank" rel="noreferrer">API JSON</a>
      </div>
    </div>
    <div class="summary">
      <div class="metric"><strong id="algorithmCount">--</strong>&#31639;&#27861;</div>
      <div class="metric"><strong id="totalCount">--</strong>&#29256;&#26412;</div>
      <div class="metric"><strong id="activeCount">--</strong>Active</div>
      <div class="metric"><strong id="artifactCount">--</strong>Artifact</div>
      <div class="metric muted" id="updatedAt">&#31561;&#24453;&#21152;&#36733;</div>
    </div>
    <div class="filters">
      <input id="searchInput" placeholder="&#25628;&#32034;&#31639;&#27861;&#12289;&#29992;&#36884;&#12289;run id&#12289;artifact &#36335;&#24452;" />
      <select id="viewMode" aria-label="&#35270;&#22270;&#27169;&#24335;">
        <option value="grouped">&#25353;&#31639;&#27861;&#27719;&#24635;</option>
        <option value="versions">&#20840;&#37096;&#29256;&#26412;</option>
      </select>
      <select id="statusFilter" aria-label="&#29366;&#24577;&#31579;&#36873;"><option value="">&#20840;&#37096;&#29366;&#24577;</option></select>
      <select id="familyFilter" aria-label="&#23478;&#26063;&#31579;&#36873;"><option value="">&#20840;&#37096;&#23478;&#26063;</option></select>
    </div>
  </header>
  <main>
    <section class="table-wrap">
      <table>
        <thead>
          <tr>
            <th style="width:96px">&#29366;&#24577;</th>
            <th style="width:250px">&#27169;&#22411;</th>
            <th style="width:140px">&#23478;&#26063;</th>
            <th>&#29992;&#36884;</th>
            <th style="width:190px">Run</th>
            <th style="width:150px">&#26381;&#21153;</th>
            <th style="width:90px">Artifact</th>
          </tr>
        </thead>
        <tbody id="modelRows"></tbody>
      </table>
      <div class="empty" id="emptyState" hidden>&#27809;&#26377;&#21305;&#37197;&#30340;&#27169;&#22411;&#12290;</div>
      <div class="error" id="errorState" hidden></div>
    </section>
    <aside>
      <h2 id="detailTitle">&#36873;&#25321;&#19968;&#20010;&#27169;&#22411;</h2>
      <div class="muted" id="detailPurpose">&#28857;&#20987;&#24038;&#20391;&#34920;&#26684;&#26597;&#30475;&#35814;&#24773;&#12290;</div>
      <div class="detail-grid" id="detailGrid"></div>
    </aside>
  </main>
  <script>
    let models = [];
    let groups = [];
    let selected = null;

    const els = {
      rows: document.getElementById("modelRows"), empty: document.getElementById("emptyState"), error: document.getElementById("errorState"),
      search: document.getElementById("searchInput"), viewMode: document.getElementById("viewMode"), status: document.getElementById("statusFilter"), family: document.getElementById("familyFilter"),
      algorithmCount: document.getElementById("algorithmCount"), total: document.getElementById("totalCount"), active: document.getElementById("activeCount"), artifacts: document.getElementById("artifactCount"), updated: document.getElementById("updatedAt"),
      detailTitle: document.getElementById("detailTitle"), detailPurpose: document.getElementById("detailPurpose"), detailGrid: document.getElementById("detailGrid"), refresh: document.getElementById("refreshBtn"), mlflow: document.getElementById("mlflowLink"),
    };

    function text(value) { return value === null || value === undefined || value === "" ? "--" : String(value); }
    function escapeHtml(value) { return text(value).replace(/[&<>"']/g, (ch) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch])); }
    function sameHostLinks() { const host = window.location.hostname || "192.168.10.28"; els.mlflow.href = `${window.location.protocol}//${host}:5000`; }

    async function loadModels() {
      els.error.hidden = true; els.refresh.disabled = true;
      try {
        const response = await fetch("/api/models?includeMetadata=true", { cache: "no-store" });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const payload = await response.json();
        models = payload.models || [];
        groups = buildGroups(models);
        selected = selected || groups[0] || models[0] || null;
        updateFilters(); render();
      } catch (error) {
        els.error.textContent = `\u52a0\u8f7d\u5931\u8d25\uff1a${error.message || error}`; els.error.hidden = false;
      } finally { els.refresh.disabled = false; }
    }

    function buildGroups(items) {
      const map = new Map();
      for (const model of items) {
        const key = model.algorithmId || model.name || model.modelId;
        if (!map.has(key)) map.set(key, { kind:"group", algorithmId:key, name:model.name, family:model.family, status:model.status, framework:model.framework, servingBackend:model.servingBackend, purpose:model.purpose, versions:[], latest:null });
        const group = map.get(key);
        group.versions.push(model);
        if (model.status === "active") group.status = "active";
        if (!group.latest || model.latest || String(model.createdAt || "") > String(group.latest.createdAt || "")) group.latest = model;
      }
      return [...map.values()].map((group) => ({ ...group, versionCount: group.versions.length, artifactExists: group.versions.some((m) => m.artifactExists), modelId: group.algorithmId, runId: group.latest?.runId || "--", artifactPath: group.latest?.artifactPath || "" }));
    }

    function updateFilters() {
      const currentStatus = els.status.value, currentFamily = els.family.value;
      const statuses = [...new Set(models.map((m) => m.status).filter(Boolean))].sort();
      const families = [...new Set(models.map((m) => m.family).filter(Boolean))].sort();
      els.status.innerHTML = '<option value="">&#20840;&#37096;&#29366;&#24577;</option>' + statuses.map((value) => `<option value="${escapeHtml(value)}">${escapeHtml(value)}</option>`).join("");
      els.family.innerHTML = '<option value="">&#20840;&#37096;&#23478;&#26063;</option>' + families.map((value) => `<option value="${escapeHtml(value)}">${escapeHtml(value)}</option>`).join("");
      els.status.value = statuses.includes(currentStatus) ? currentStatus : "";
      els.family.value = families.includes(currentFamily) ? currentFamily : "";
    }

    function currentRows() { return els.viewMode.value === "grouped" ? groups : models; }
    function filteredRows() {
      const query = els.search.value.trim().toLowerCase();
      return currentRows().filter((row) => {
        const versions = row.versions || [row];
        if (els.status.value && !versions.some((m) => m.status === els.status.value)) return false;
        if (els.family.value && row.family !== els.family.value) return false;
        if (!query) return true;
        return [row.modelId, row.name, row.family, row.purpose, row.runId, row.artifactPath, row.servingBackend, ...(versions.map((m) => `${m.modelId} ${m.runId} ${m.artifactPath}`))]
          .map((value) => text(value).toLowerCase()).some((value) => value.includes(query));
      });
    }

    function render() {
      const rows = filteredRows();
      els.algorithmCount.textContent = groups.length;
      els.total.textContent = models.length;
      els.active.textContent = models.filter((m) => m.status === "active").length;
      els.artifacts.textContent = models.filter((m) => m.artifactExists).length;
      els.updated.textContent = `\u66f4\u65b0\uff1a${new Date().toLocaleString()}`;
      els.empty.hidden = rows.length > 0;
      els.rows.innerHTML = rows.map((row) => row.kind === "group" ? groupRow(row) : versionRow(row)).join("");
      els.rows.querySelectorAll("tr").forEach((tr) => tr.addEventListener("click", () => { selected = currentRows().find((row) => row.modelId === tr.dataset.id) || null; renderDetail(); }));
      if (selected && !currentRows().find((row) => row.modelId === selected.modelId)) selected = rows[0] || currentRows()[0] || null;
      renderDetail();
    }

    function groupRow(group) {
      return `<tr data-id="${escapeHtml(group.modelId)}"><td><span class="status ${escapeHtml(group.status)}">${escapeHtml(group.status)}</span></td><td class="name-cell"><strong>${escapeHtml(group.name)}</strong><div class="mono muted">${escapeHtml(group.algorithmId)}</div><span class="version-pill">${group.versionCount} &#20010;&#29256;&#26412;</span></td><td>${escapeHtml(group.family)}</td><td>${escapeHtml(group.purpose)}</td><td class="mono">${escapeHtml(group.runId)}</td><td>${escapeHtml(group.servingBackend)}</td><td>${group.artifactExists ? "Yes" : "No"}</td></tr>`;
    }
    function versionRow(model) {
      return `<tr data-id="${escapeHtml(model.modelId)}"><td><span class="status ${escapeHtml(model.status)}">${escapeHtml(model.status)}</span></td><td class="name-cell"><strong>${escapeHtml(model.name)}</strong><div class="mono muted">${escapeHtml(model.modelId)}</div></td><td>${escapeHtml(model.family)}</td><td>${escapeHtml(model.purpose)}</td><td class="mono">${escapeHtml(model.runId)}</td><td>${escapeHtml(model.servingBackend)}</td><td>${model.artifactExists ? "Yes" : "No"}</td></tr>`;
    }

    function renderDetail() {
      if (!selected) { els.detailTitle.textContent = "\u9009\u62e9\u4e00\u4e2a\u6a21\u578b"; els.detailPurpose.textContent = "\u70b9\u51fb\u5de6\u4fa7\u8868\u683c\u67e5\u770b\u8be6\u60c5\u3002"; els.detailGrid.innerHTML = ""; return; }
      if (selected.kind === "group") return renderGroupDetail(selected);
      renderVersionDetail(selected);
    }
    function renderGroupDetail(group) {
      els.detailTitle.textContent = group.name || group.algorithmId;
      els.detailPurpose.textContent = group.purpose || "";
      const latest = group.latest || {};
      els.detailGrid.innerHTML = `${detailItem("\u7b97\u6cd5 ID", group.algorithmId, true)}${detailItem("\u7248\u672c\u6570", group.versionCount)}${detailItem("\u6700\u65b0 Run", latest.runId || "--", true)}${detailItem("\u670d\u52a1\u65b9\u5f0f", group.servingBackend)}${detailItem("\u6700\u65b0 Artifact", latest.artifactPath || "--", true)}<div class="detail-item"><span>&#29256;&#26412;&#21015;&#34920;</span><div class="version-list">${group.versions.map((m) => `<div class="version-row"><div class="mono">${escapeHtml(m.runId)}</div><div class="muted">${escapeHtml(m.createdAt || "")}</div></div>`).join("")}</div></div>`;
    }
    function renderVersionDetail(model) {
      els.detailTitle.textContent = model.name || model.modelId; els.detailPurpose.textContent = model.purpose || "";
      const metrics = model.metrics && Object.keys(model.metrics).length ? JSON.stringify(model.metrics, null, 2) : "--";
      els.detailGrid.innerHTML = `${detailItem("Model ID", model.modelId, true)}${detailItem("\u72b6\u6001", model.status)}${detailItem("\u6846\u67b6", model.framework)}${detailItem("\u670d\u52a1\u65b9\u5f0f", model.servingBackend)}${detailItem("\u521b\u5efa\u65f6\u95f4", model.createdAt)}${detailItem("Artifact", model.artifactPath || "--", true)}${detailItem("\u8f93\u5165", JSON.stringify(model.inputs || {}, null, 2), true)}${detailItem("\u8f93\u51fa", (model.outputs || []).join(", ") || "--")}<div class="detail-item"><span>&#25351;&#26631;</span><pre>${escapeHtml(metrics)}</pre></div>`;
    }
    function detailItem(label, value, mono = false) { return `<div class="detail-item"><span>${escapeHtml(label)}</span><div class="${mono ? "mono" : ""}">${escapeHtml(value)}</div></div>`; }

    [els.search, els.status, els.family, els.viewMode].forEach((el) => el.addEventListener("input", () => { selected = null; render(); }));
    els.refresh.addEventListener("click", loadModels); sameHostLinks(); loadModels();
  </script>
</body>
</html>"""


@app.get("/api/models/{model_id:path}", response_class=UTF8JSONResponse)
def model_detail(model_id: str) -> dict[str, Any]:
    try:
        return get_model(model_id, registry_path=REGISTRY_PATH)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=f"Model not found: {model_id}") from exc

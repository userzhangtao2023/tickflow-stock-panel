from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd
import psycopg
from psycopg.types.json import Jsonb


LIMIT_UP_EVENT_THRESHOLD = 0.098
LIMIT_UP_20_THRESHOLD = 0.195
TARGET_MAX_RETURN_THRESHOLD = 0.05
TARGET_MAX_DRAWDOWN_THRESHOLD = -0.06
MODEL_ROOT = Path("/home/alwin/data/longbridge/limit_up_models")

FUNDAMENTAL_RAW_FEATURE_NAMES = [
    "pe",
    "pb",
    "ps",
    "roe",
    "roa",
    "net_margin",
    "gross_margin",
    "revenue_yoy",
    "net_profit_yoy",
    "liabilities_assets",
    "leverage",
    "market_value",
]

FUNDAMENTAL_SCORE_FEATURE_NAMES = [
    "valuation_score",
    "quality_score",
    "fundamental_risk_score",
    "fundamental_score",
    "market_value_log",
    "market_value_rank_pct",
]

EASTMONEY_LIMIT_POOL_FEATURE_NAMES = [
    "eastmoney_limit_up_pool",
    "eastmoney_previous_limit_up_pool",
    "eastmoney_strong_pool",
    "eastmoney_open_board_pool",
    "eastmoney_limit_down_pool",
    "eastmoney_pool_count",
    "eastmoney_consecutive_boards",
    "eastmoney_break_count",
    "eastmoney_seal_amount",
    "eastmoney_seal_amount_log",
    "eastmoney_seal_amount_rank_pct",
    "eastmoney_turnover_rate",
    "eastmoney_float_market_cap_log",
    "eastmoney_total_market_cap_log",
    "eastmoney_first_seal_minutes",
    "eastmoney_last_seal_minutes",
    "eastmoney_first_seal_early_score",
]

EASTMONEY_FUND_FLOW_FEATURE_NAMES = [
    "eastmoney_main_net_flow",
    "eastmoney_main_net_flow_ratio",
    "eastmoney_super_large_net_flow",
    "eastmoney_large_net_flow",
    "eastmoney_medium_net_flow",
    "eastmoney_small_net_flow",
    "eastmoney_main_net_flow_log",
    "eastmoney_main_net_flow_rank_pct",
    "eastmoney_main_net_flow_to_turnover",
]

EASTMONEY_FEATURE_NAMES = [
    *EASTMONEY_LIMIT_POOL_FEATURE_NAMES,
    *EASTMONEY_FUND_FLOW_FEATURE_NAMES,
]

HMM_OBSERVATION_FEATURE_NAMES = [
    "pct_change",
    "amplitude",
    "intraday_return",
    "volume_ratio_5d",
    "turnover_ratio_5d",
    "return_5d",
    "return_20d",
    "volatility_10d",
    "rsi_14",
    "macd_hist",
    "bollinger_position_20",
    "atr_14",
]

HMM_STATE_FEATURE_NAMES = [
    "hmm_state",
    "hmm_state_prob",
    "hmm_state_momentum",
    "hmm_transition_risk",
]

FEATURE_NAMES = [
    "pct_change",
    "amplitude",
    "body_strength",
    "upper_shadow",
    "lower_shadow",
    "volume_ratio_5d",
    "volume_ratio_10d",
    "volume_ratio_20d",
    "turnover_ratio_5d",
    "turnover_ratio_10d",
    "turnover_ratio_20d",
    "return_3d",
    "return_5d",
    "return_10d",
    "return_20d",
    "volatility_5d",
    "volatility_10d",
    "volatility_20d",
    "limit_up_count_20d",
    "limit_streak",
    "distance_to_60d_high",
    "distance_to_60d_low",
    "market_return_mean",
    "market_return_median",
    "market_return_3d",
    "market_return_5d",
    "market_return_10d",
    "market_return_20d",
    "market_advancer_ratio",
    "market_limit_up_count",
    "market_limit_up_ratio",
    "market_limit_up_count_3d",
    "market_limit_up_count_5d",
    "market_limit_up_ratio_3d",
    "market_limit_up_ratio_5d",
    "market_turnover_change",
    "relative_return_3d",
    "relative_return_5d",
    "relative_return_10d",
    "relative_return_20d",
    "turnover_rank_pct",
    "volume_rank_pct",
    "pct_change_rank_pct",
    "amplitude_rank_pct",
    "close_to_ma5",
    "close_to_ma10",
    "close_to_ma20",
    "close_to_ma60",
    "above_ma5",
    "above_ma10",
    "above_ma20",
    "above_ma60",
    "ma_alignment_count",
    "ma5_slope_5d",
    "turnover_acceleration_5d",
    "volume_acceleration_5d",
    "drawdown_from_20d_high",
    "rebound_from_20d_low",
    "consecutive_up_days",
    "is_20pct_board",
    "limit_up_count_5d",
    "limit_up_count_10d",
    "days_since_last_limit_up",
    "large_gain_count_5d",
    "large_gain_count_20d",
    "near_limit_up_count_5d",
    "near_limit_up_count_20d",
    "open_return",
    "intraday_return",
    "close_position_in_range",
    "high_close_pullback",
    "low_close_recovery",
    "log_turnover",
    "log_volume",
    "price_level",
    "prev_day_return",
    "prev_day_amplitude",
    "prev_day_volume_ratio",
    "market_heat_score",
    "liquidity_pressure",
    "risk_adjusted_return_5d",
    "risk_adjusted_return_20d",
    "opening_strength_ratio",
    "shadow_pressure",
    "breakout_20d",
    "breakout_60d",
    "breakout_prev_high",
    "up_volume_rank_60d",
    "up_turnover_rank_60d",
    "up_volume_ratio_20d",
    "up_turnover_ratio_20d",
    "volume_zscore_20",
    "turnover_zscore_20",
    "return_acceleration_5d",
    "overheat_score",
    "rsi_6",
    "rsi_14",
    "macd_dif",
    "macd_dea",
    "macd_hist",
    "kdj_k",
    "kdj_d",
    "kdj_j",
    "bollinger_position_20",
    "bollinger_width_20",
    "atr_14",
    "cci_20",
    "williams_r_14",
    "obv_trend_10",
    *HMM_STATE_FEATURE_NAMES,
    *FUNDAMENTAL_RAW_FEATURE_NAMES,
    *FUNDAMENTAL_SCORE_FEATURE_NAMES,
    *EASTMONEY_FEATURE_NAMES,
]

TACTICAL_FEATURE_NAMES = [
    "intraday_return",
    "high_close_pullback",
    "low_close_recovery",
    "market_limit_up_count_3d",
    "market_limit_up_count_5d",
    "market_limit_up_ratio_3d",
    "market_limit_up_ratio_5d",
    "pct_change_rank_pct",
    "amplitude_rank_pct",
    "large_gain_count_5d",
    "large_gain_count_20d",
    "near_limit_up_count_5d",
    "near_limit_up_count_20d",
    "volume_zscore_20",
    "turnover_zscore_20",
    "return_acceleration_5d",
]

CORE_FEATURE_NAMES = [name for name in FEATURE_NAMES if name not in set(TACTICAL_FEATURE_NAMES)]


@dataclass(frozen=True)
class LimitUpBuildSummary:
    events: int
    labeled: int
    start_date: str | None
    end_date: str | None


@dataclass(frozen=True)
class LimitUpTrainSummary:
    model_run_id: str
    model_path: str
    train_count: int
    validation_count: int
    metrics: dict[str, float | int | None]


@dataclass(frozen=True)
class LimitUpPredictSummary:
    prediction_date: str | None
    total: int
    candidates: list[dict[str, Any]]


class LimitUpStatisticalModel:
    model_type = "limit_up_statistical_baseline"

    def __init__(
        self,
        *,
        feature_names: list[str],
        feature_stats: dict[str, dict[str, float]],
        base_rate: float,
        created_at: str | None = None,
    ) -> None:
        self.feature_names = feature_names
        self.feature_stats = feature_stats
        self.base_rate = float(min(max(base_rate, 0.001), 0.999))
        self.created_at = created_at or datetime.now(timezone.utc).isoformat(timespec="seconds")

    @classmethod
    def fit(cls, frame: pd.DataFrame, feature_names: Iterable[str] = FEATURE_NAMES) -> "LimitUpStatisticalModel":
        features = [name for name in feature_names if name in frame.columns]
        if not features:
            raise ValueError("No usable feature columns were found for limit-up model training.")
        target = frame["target_open_buy"].astype(bool)
        base_rate = float(target.mean()) if len(target) else 0.5
        stats: dict[str, dict[str, float]] = {}
        strengths: dict[str, float] = {}
        for name in features:
            values = pd.to_numeric(frame[name], errors="coerce").replace([np.inf, -np.inf], np.nan)
            median = float(values.median()) if values.notna().any() else 0.0
            filled = values.fillna(median)
            pos = filled[target]
            neg = filled[~target]
            pos_mean = float(pos.mean()) if len(pos) else median
            neg_mean = float(neg.mean()) if len(neg) else median
            std = float(filled.std(ddof=0))
            if not math.isfinite(std) or std <= 1e-9:
                std = 1.0
            direction = 1.0 if pos_mean >= neg_mean else -1.0
            strength = abs(pos_mean - neg_mean) / std
            strengths[name] = strength
            stats[name] = {
                "median": median,
                "mean": float(filled.mean()),
                "std": std,
                "direction": direction,
                "raw_strength": float(strength),
                "weight": 0.0,
            }
        total_strength = sum(strengths.values())
        if total_strength <= 1e-9:
            equal_weight = 1.0 / len(features)
            for name in features:
                stats[name]["weight"] = equal_weight
        else:
            for name in features:
                stats[name]["weight"] = float(strengths[name] / total_strength)
        return cls(feature_names=features, feature_stats=stats, base_rate=base_rate)

    def predict_proba(self, frame: pd.DataFrame) -> pd.Series:
        if frame.empty:
            return pd.Series([], dtype="float64")
        raw = np.zeros(len(frame), dtype="float64")
        for name in self.feature_names:
            if name not in frame.columns:
                continue
            stat = self.feature_stats[name]
            values = pd.to_numeric(frame[name], errors="coerce").replace([np.inf, -np.inf], np.nan).fillna(stat["median"])
            z = ((values.to_numpy(dtype="float64") - stat["mean"]) / stat["std"]).clip(-4, 4)
            raw += stat["direction"] * stat["weight"] * z
        base_logit = math.log(self.base_rate / (1 - self.base_rate))
        probability = 1 / (1 + np.exp(-(base_logit + raw * 2.0)))
        return pd.Series(probability, index=frame.index, dtype="float64")

    def to_dict(self) -> dict[str, Any]:
        return {
            "model_type": "limit_up_statistical_baseline",
            "feature_names": self.feature_names,
            "feature_stats": self.feature_stats,
            "base_rate": self.base_rate,
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "LimitUpStatisticalModel":
        return cls(
            feature_names=list(payload["feature_names"]),
            feature_stats=dict(payload["feature_stats"]),
            base_rate=float(payload["base_rate"]),
            created_at=payload.get("created_at"),
        )

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> "LimitUpStatisticalModel":
        return cls.from_dict(json.loads(path.read_text(encoding="utf-8")))


class LimitUpSklearnModel:
    model_type = "limit_up_sklearn_hist_gradient_boosting"

    def __init__(self, *, feature_names: list[str], estimator: Any, created_at: str | None = None) -> None:
        self.feature_names = feature_names
        self.estimator = estimator
        self.created_at = created_at or datetime.now(timezone.utc).isoformat(timespec="seconds")

    @classmethod
    def fit(cls, frame: pd.DataFrame, feature_names: Iterable[str] = FEATURE_NAMES) -> "LimitUpSklearnModel":
        from sklearn.ensemble import HistGradientBoostingClassifier

        features = [name for name in feature_names if name in frame.columns]
        if not features:
            raise ValueError("No usable feature columns were found for limit-up model training.")
        x = _model_matrix(frame, features)
        y = frame["target_open_buy"].astype(bool).astype(int)
        estimator = HistGradientBoostingClassifier(
            max_iter=260,
            learning_rate=0.035,
            max_leaf_nodes=15,
            min_samples_leaf=25,
            l2_regularization=0.15,
            random_state=42,
        )
        estimator.fit(x, y)
        return cls(feature_names=features, estimator=estimator)

    def predict_proba(self, frame: pd.DataFrame) -> pd.Series:
        if frame.empty:
            return pd.Series([], dtype="float64")
        x = _model_matrix(frame, self.feature_names)
        probability = self.estimator.predict_proba(x)[:, 1]
        return pd.Series(probability, index=frame.index, dtype="float64")

    def save(self, path: Path) -> None:
        import joblib

        path.mkdir(parents=True, exist_ok=True)
        joblib.dump(self.estimator, path / "model.joblib")
        metadata = {
            "model_type": self.model_type,
            "feature_names": self.feature_names,
            "created_at": self.created_at,
        }
        (path / "metadata.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> "LimitUpSklearnModel":
        import joblib

        metadata = json.loads((path / "metadata.json").read_text(encoding="utf-8"))
        estimator = joblib.load(path / "model.joblib")
        return cls(
            feature_names=list(metadata["feature_names"]),
            estimator=estimator,
            created_at=metadata.get("created_at"),
        )


class LimitUpLightGbmModel(LimitUpSklearnModel):
    model_type = "limit_up_lightgbm"

    @classmethod
    def fit(cls, frame: pd.DataFrame, feature_names: Iterable[str] = FEATURE_NAMES) -> "LimitUpLightGbmModel":
        from lightgbm import LGBMClassifier

        features = [name for name in feature_names if name in frame.columns]
        if not features:
            raise ValueError("No usable feature columns were found for limit-up model training.")
        x = _model_matrix(frame, features)
        y = frame["target_open_buy"].astype(bool).astype(int)
        estimator = LGBMClassifier(
            n_estimators=450,
            learning_rate=0.025,
            num_leaves=15,
            min_child_samples=35,
            subsample=0.82,
            colsample_bytree=0.82,
            reg_lambda=2.0,
            random_state=42,
            class_weight="balanced",
            verbosity=-1,
        )
        estimator.fit(x, y)
        return cls(feature_names=features, estimator=estimator)


class LimitUpXGBoostModel(LimitUpSklearnModel):
    model_type = "limit_up_xgboost"

    @classmethod
    def fit(cls, frame: pd.DataFrame, feature_names: Iterable[str] = FEATURE_NAMES) -> "LimitUpXGBoostModel":
        from xgboost import XGBClassifier

        features = [name for name in feature_names if name in frame.columns]
        if not features:
            raise ValueError("No usable feature columns were found for limit-up model training.")
        x = _model_matrix(frame, features)
        y = frame["target_open_buy"].astype(bool).astype(int)
        positives = int(y.sum())
        negatives = int(len(y) - positives)
        scale_pos_weight = negatives / positives if positives else 1.0
        estimator = XGBClassifier(
            n_estimators=420,
            max_depth=3,
            learning_rate=0.025,
            subsample=0.82,
            colsample_bytree=0.82,
            min_child_weight=8,
            reg_lambda=2.5,
            objective="binary:logistic",
            eval_metric="logloss",
            tree_method="hist",
            random_state=42,
            scale_pos_weight=scale_pos_weight,
            n_jobs=2,
        )
        estimator.fit(x, y)
        return cls(feature_names=features, estimator=estimator)


class LimitUpRandomForestModel(LimitUpSklearnModel):
    model_type = "limit_up_sklearn_random_forest"

    @classmethod
    def fit(cls, frame: pd.DataFrame, feature_names: Iterable[str] = FEATURE_NAMES) -> "LimitUpRandomForestModel":
        from sklearn.ensemble import RandomForestClassifier

        features = [name for name in feature_names if name in frame.columns]
        if not features:
            raise ValueError("No usable feature columns were found for limit-up model training.")
        x = _model_matrix(frame, features).fillna(0)
        y = frame["target_open_buy"].astype(bool).astype(int)
        estimator = RandomForestClassifier(
            n_estimators=360,
            max_depth=7,
            min_samples_leaf=18,
            max_features="sqrt",
            class_weight="balanced_subsample",
            random_state=42,
            n_jobs=2,
        )
        estimator.fit(x, y)
        return cls(feature_names=features, estimator=estimator)


class LimitUpExtraTreesModel(LimitUpSklearnModel):
    model_type = "limit_up_sklearn_extra_trees"

    @classmethod
    def fit(cls, frame: pd.DataFrame, feature_names: Iterable[str] = FEATURE_NAMES) -> "LimitUpExtraTreesModel":
        from sklearn.ensemble import ExtraTreesClassifier

        features = [name for name in feature_names if name in frame.columns]
        if not features:
            raise ValueError("No usable feature columns were found for limit-up model training.")
        x = _model_matrix(frame, features).fillna(0)
        y = frame["target_open_buy"].astype(bool).astype(int)
        estimator = ExtraTreesClassifier(
            n_estimators=420,
            max_depth=8,
            min_samples_leaf=16,
            max_features="sqrt",
            class_weight="balanced",
            random_state=42,
            n_jobs=2,
        )
        estimator.fit(x, y)
        return cls(feature_names=features, estimator=estimator)


class LimitUpLogisticRegressionModel(LimitUpSklearnModel):
    model_type = "limit_up_sklearn_logistic_regression"

    @classmethod
    def fit(
        cls, frame: pd.DataFrame, feature_names: Iterable[str] = FEATURE_NAMES
    ) -> "LimitUpLogisticRegressionModel":
        from sklearn.impute import SimpleImputer
        from sklearn.linear_model import LogisticRegression
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler

        features = [name for name in feature_names if name in frame.columns]
        if not features:
            raise ValueError("No usable feature columns were found for limit-up model training.")
        x = _model_matrix(frame, features)
        y = frame["target_open_buy"].astype(bool).astype(int)
        estimator = make_pipeline(
            SimpleImputer(strategy="median"),
            StandardScaler(),
            LogisticRegression(C=0.35, max_iter=1200, class_weight="balanced", random_state=42),
        )
        estimator.fit(x, y)
        return cls(feature_names=features, estimator=estimator)


def load_limit_up_model(path: Path) -> LimitUpStatisticalModel | LimitUpSklearnModel:
    if path.is_dir() and (path / "model.joblib").exists():
        return LimitUpSklearnModel.load(path)
    return LimitUpStatisticalModel.load(path)


def identify_limit_up_events(bars: pd.DataFrame) -> pd.DataFrame:
    frame = _prepare_bars(bars)
    frame["prev_close"] = frame.groupby("symbol")["close"].shift(1)
    frame["pct_change"] = frame["close"] / frame["prev_close"] - 1
    mask = frame["symbol"].map(_is_a_share_symbol) & (frame["pct_change"] >= LIMIT_UP_EVENT_THRESHOLD)
    events = frame.loc[mask].copy()
    events["event_date"] = events["trade_date"]
    events["is_limit_up_10"] = events["pct_change"] >= LIMIT_UP_EVENT_THRESHOLD
    events["is_limit_up_20"] = events["pct_change"] >= LIMIT_UP_20_THRESHOLD
    return events.reset_index(drop=True)


def build_labeled_limit_up_events(bars: pd.DataFrame) -> pd.DataFrame:
    frame = _prepare_bars(bars)
    frame = _add_features(frame)
    events = frame.loc[frame["symbol"].map(_is_a_share_symbol) & (frame["pct_change"] >= LIMIT_UP_EVENT_THRESHOLD)].copy()
    rows: list[dict[str, Any]] = []
    for _, row in events.iterrows():
        symbol_rows = frame[frame["symbol"] == row["symbol"]].reset_index(drop=True)
        event_positions = symbol_rows.index[symbol_rows["trade_date"] == row["trade_date"]].tolist()
        if not event_positions:
            continue
        pos = event_positions[0]
        future = symbol_rows.iloc[pos + 1 : pos + 6]
        next_open = _safe_float(future.iloc[0]["open"]) if not future.empty else None
        has_entry = next_open is not None and next_open > 0
        max_return = float(future["high"].max() / next_open - 1) if has_entry else None
        max_drawdown = float(future["low"].min() / next_open - 1) if has_entry else None
        payload = row.to_dict()
        payload["event_date"] = row["trade_date"]
        payload["next_open"] = next_open
        payload["max_return_5d"] = max_return
        payload["max_drawdown_5d"] = max_drawdown
        payload["close_return_1d"] = _future_close_return(future, next_open, 1) if has_entry else None
        payload["close_return_3d"] = _future_close_return(future, next_open, 3) if has_entry else None
        payload["close_return_5d"] = _future_close_return(future, next_open, 5) if has_entry else None
        payload["target_open_buy"] = (
            bool(max_return >= TARGET_MAX_RETURN_THRESHOLD and max_drawdown >= TARGET_MAX_DRAWDOWN_THRESHOLD)
            if has_entry
            else None
        )
        payload["is_limit_up_10"] = bool(row["pct_change"] >= LIMIT_UP_EVENT_THRESHOLD)
        payload["is_limit_up_20"] = bool(row["pct_change"] >= LIMIT_UP_20_THRESHOLD)
        rows.append(payload)
    if not rows:
        return pd.DataFrame(columns=["symbol", "event_date", "target_open_buy", *FEATURE_NAMES])
    result = pd.DataFrame(rows)
    result["target_open_buy"] = result["target_open_buy"].astype(object)
    result["is_limit_up_10"] = result["is_limit_up_10"].astype(object)
    result["is_limit_up_20"] = result["is_limit_up_20"].astype(object)
    return result.sort_values(["event_date", "symbol"]).reset_index(drop=True)


def temporal_train_validation_split(events: pd.DataFrame, validation_ratio: float = 0.2) -> tuple[pd.DataFrame, pd.DataFrame]:
    if events.empty:
        return events.copy(), events.copy()
    ratio = min(max(validation_ratio, 0.05), 0.5)
    sort_columns = ["event_date"] + (["symbol"] if "symbol" in events.columns else [])
    ordered = events.sort_values(sort_columns).reset_index(drop=True)
    validation_count = max(1, int(math.ceil(len(ordered) * ratio)))
    split_at = max(1, len(ordered) - validation_count)
    return ordered.iloc[:split_at].copy(), ordered.iloc[split_at:].copy()


def score_limit_up_candidates(model: LimitUpStatisticalModel | LimitUpSklearnModel, candidates: pd.DataFrame) -> pd.DataFrame:
    frame = candidates.copy()
    if frame.empty:
        return frame.assign(open_buy_probability=[], open_buy_score=[], decision=[], reason=[])
    probability = model.predict_proba(frame).clip(0, 1)
    frame["open_buy_probability"] = _calibrate_eastmoney_limit_pool_probability(frame, probability).clip(0, 1)
    frame["open_buy_score"] = (frame["open_buy_probability"] * 100).round(2)
    frame["decision"] = frame["open_buy_score"].map(_decision)
    frame["reason"] = frame.apply(_reason, axis=1)
    return frame.sort_values(["open_buy_probability", "symbol"], ascending=[False, True]).reset_index(drop=True)


def evaluate_limit_up_predictions(predictions: pd.DataFrame, top_ns: Iterable[int] = (10, 20, 50)) -> dict[str, float | int | None]:
    if predictions.empty or "target_open_buy" not in predictions:
        return {"sample_count": 0, "positive_count": 0, "base_rate": None, "auc": None}
    frame = predictions.sort_values("open_buy_probability", ascending=False).reset_index(drop=True)
    target = frame["target_open_buy"].astype(bool)
    metrics: dict[str, float | int | None] = {
        "sample_count": int(len(frame)),
        "positive_count": int(target.sum()),
        "base_rate": float(target.mean()) if len(frame) else None,
        "auc": _auc(frame["open_buy_probability"], target),
        "avg_max_return_top_20": _mean_top(frame, "max_return_5d", 20),
        "avg_max_drawdown_top_20": _mean_top(frame, "max_drawdown_5d", 20),
    }
    for top_n in top_ns:
        if len(frame) >= top_n:
            metrics[f"precision_at_{top_n}"] = float(target.head(top_n).mean())
        elif len(frame):
            metrics[f"precision_at_{top_n}"] = float(target.mean())
        else:
            metrics[f"precision_at_{top_n}"] = None
    for threshold in (0.6, 0.7, 0.8, 0.9):
        selected = frame[frame["open_buy_probability"] >= threshold]
        key = int(threshold * 100)
        metrics[f"precision_prob_ge_{key}"] = float(selected["target_open_buy"].astype(bool).mean()) if len(selected) else None
        metrics[f"count_prob_ge_{key}"] = int(len(selected))
    return metrics


def ensure_limit_up_tables(conn: psycopg.Connection[Any]) -> None:
    with conn.cursor() as cur:
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS lb_limit_up_events (
                symbol TEXT NOT NULL,
                event_date DATE NOT NULL,
                prev_close NUMERIC,
                open_price NUMERIC,
                high_price NUMERIC,
                low_price NUMERIC,
                close_price NUMERIC,
                volume NUMERIC,
                turnover NUMERIC,
                pct_change NUMERIC,
                is_limit_up_10 BOOLEAN,
                is_limit_up_20 BOOLEAN,
                next_open NUMERIC,
                max_return_5d NUMERIC,
                max_drawdown_5d NUMERIC,
                close_return_1d NUMERIC,
                close_return_3d NUMERIC,
                close_return_5d NUMERIC,
                target_open_buy BOOLEAN,
                features JSONB NOT NULL DEFAULT '{}'::jsonb,
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                PRIMARY KEY (symbol, event_date)
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS lb_limit_up_model_runs (
                model_run_id TEXT PRIMARY KEY,
                model_type TEXT NOT NULL,
                trained_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                model_path TEXT NOT NULL,
                train_count INTEGER NOT NULL,
                validation_count INTEGER NOT NULL,
                metrics JSONB NOT NULL DEFAULT '{}'::jsonb,
                feature_names JSONB NOT NULL DEFAULT '[]'::jsonb
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS lb_limit_up_predictions (
                model_run_id TEXT NOT NULL,
                symbol TEXT NOT NULL,
                event_date DATE NOT NULL,
                open_buy_probability NUMERIC,
                open_buy_score NUMERIC,
                decision TEXT,
                reason TEXT,
                features JSONB NOT NULL DEFAULT '{}'::jsonb,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                PRIMARY KEY (model_run_id, symbol, event_date)
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS lb_external_limit_pools (
                source TEXT NOT NULL,
                pool TEXT NOT NULL,
                trade_date DATE NOT NULL,
                symbol TEXT NOT NULL,
                name TEXT,
                pct_change NUMERIC,
                last_price NUMERIC,
                turnover NUMERIC,
                float_market_cap NUMERIC,
                total_market_cap NUMERIC,
                turnover_rate NUMERIC,
                seal_amount NUMERIC,
                first_seal_time TEXT,
                last_seal_time TEXT,
                break_count INTEGER,
                limit_up_stat TEXT,
                consecutive_boards INTEGER,
                industry TEXT,
                payload JSONB,
                fetched_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                PRIMARY KEY (source, pool, trade_date, symbol)
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS lb_external_fund_flow_rank (
                source TEXT NOT NULL,
                trade_date DATE NOT NULL,
                period TEXT NOT NULL,
                symbol TEXT NOT NULL,
                name TEXT,
                latest_price NUMERIC,
                pct_change NUMERIC,
                main_net_flow NUMERIC,
                main_net_flow_ratio NUMERIC,
                super_large_net_flow NUMERIC,
                large_net_flow NUMERIC,
                medium_net_flow NUMERIC,
                small_net_flow NUMERIC,
                payload JSONB,
                fetched_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                PRIMARY KEY (source, trade_date, period, symbol)
            )
            """
        )


def refresh_limit_up_events(
    *,
    dsn: str,
    start_date: str | date | None = None,
    end_date: str | date | None = None,
) -> LimitUpBuildSummary:
    with psycopg.connect(dsn) as conn:
        ensure_limit_up_tables(conn)
        bars = _load_cn_daily_bars(conn, start_date=start_date, end_date=end_date)
        events = build_labeled_limit_up_events(bars)
        external_events = _load_external_limit_pool_events(conn, start_date=start_date, end_date=end_date)
        events = _merge_external_limit_pool_events(events, external_events)
        _upsert_limit_up_events(conn, events)
        conn.commit()
    labeled = int(events["target_open_buy"].notna().sum()) if "target_open_buy" in events else 0
    start = _date_string(events["event_date"].min()) if not events.empty else None
    end = _date_string(events["event_date"].max()) if not events.empty else None
    return LimitUpBuildSummary(events=int(len(events)), labeled=labeled, start_date=start, end_date=end)


def train_limit_up_model_from_db(
    *,
    dsn: str,
    model_root: str | Path = MODEL_ROOT,
    validation_ratio: float = 0.2,
    min_events: int = 20,
) -> LimitUpTrainSummary:
    with psycopg.connect(dsn) as conn:
        ensure_limit_up_tables(conn)
        events = _load_limit_up_events(conn, labeled_only=True)
        if len(events) < min_events:
            raise ValueError(f"Need at least {min_events} labeled events, found {len(events)}.")
        train, validation = temporal_train_validation_split(events, validation_ratio=validation_ratio)
        model, metrics = _fit_best_available_model(train, validation)
        model_run_id = f"limit_up_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"
        model_path = Path(model_root) / model_run_id
        model.save(model_path)
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO lb_limit_up_model_runs (
                    model_run_id, model_type, model_path, train_count, validation_count, metrics, feature_names
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (model_run_id) DO UPDATE SET
                    model_path = EXCLUDED.model_path,
                    train_count = EXCLUDED.train_count,
                    validation_count = EXCLUDED.validation_count,
                    metrics = EXCLUDED.metrics,
                    feature_names = EXCLUDED.feature_names
                """,
                (
                    model_run_id,
                    _model_type(model),
                    str(model_path),
                    len(train),
                    len(validation),
                    Jsonb(_json_ready(metrics)),
                    Jsonb(model.feature_names),
                ),
            )
        conn.commit()
    return LimitUpTrainSummary(
        model_run_id=model_run_id,
        model_path=str(model_path),
        train_count=int(len(train)),
        validation_count=int(len(validation)),
        metrics=metrics,
    )


def predict_limit_up_candidates(
    *,
    dsn: str,
    event_date: str | date | None = None,
    model_root: str | Path = MODEL_ROOT,
    limit: int = 50,
) -> LimitUpPredictSummary:
    with psycopg.connect(dsn) as conn:
        ensure_limit_up_tables(conn)
        model_run_id, model_path = _latest_model_run(conn)
        model = load_limit_up_model(Path(model_path))
        target_date = _resolve_prediction_date(conn, event_date)
        if target_date is None:
            return LimitUpPredictSummary(prediction_date=None, total=0, candidates=[])
        candidates = _load_limit_up_events(conn, event_date=target_date)
        scored = score_limit_up_candidates(model, candidates)
        _upsert_limit_up_predictions(conn, model_run_id, scored)
        conn.commit()
    top = scored.head(limit)
    return LimitUpPredictSummary(
        prediction_date=_date_string(target_date),
        total=int(len(scored)),
        candidates=_records(top),
    )


def fetch_limit_up_candidates(
    *,
    dsn: str,
    event_date: str | date | None = None,
    limit: int = 50,
) -> pd.DataFrame:
    with psycopg.connect(dsn) as conn:
        ensure_limit_up_tables(conn)
        target_date = _resolve_prediction_date(conn, event_date, predictions=True)
        if target_date is None:
            return pd.DataFrame()
        query = """
            WITH latest_limit_up_model AS (
                SELECT model_run_id
                FROM lb_limit_up_model_runs
                ORDER BY trained_at DESC
                LIMIT 1
            )
            SELECT
                p.model_run_id,
                p.symbol,
                p.event_date,
                p.open_buy_probability,
                p.open_buy_score,
                p.decision,
                p.reason,
                e.close_price,
                e.pct_change,
                e.next_open,
                e.max_return_5d,
                e.max_drawdown_5d,
                e.target_open_buy
            FROM lb_limit_up_predictions p
            JOIN latest_limit_up_model m ON m.model_run_id = p.model_run_id
            JOIN lb_limit_up_events e
              ON e.symbol = p.symbol AND e.event_date = p.event_date
            WHERE p.event_date = %s
            ORDER BY p.open_buy_probability DESC, p.symbol ASC
            LIMIT %s
        """
        return pd.read_sql_query(query, conn, params=(target_date, limit))


def _prepare_bars(bars: pd.DataFrame) -> pd.DataFrame:
    frame = bars.copy()
    frame["trade_date"] = pd.to_datetime(frame["trade_date"]).dt.date
    for column in ["open", "high", "low", "close", "volume", "turnover"]:
        if column in frame:
            frame[column] = pd.to_numeric(frame[column], errors="coerce")
    return frame.sort_values(["symbol", "trade_date"]).reset_index(drop=True)


def _fit_best_available_model(
    train: pd.DataFrame,
    validation: pd.DataFrame,
) -> tuple[LimitUpSklearnModel | LimitUpStatisticalModel, dict[str, float | int | None]]:
    candidates: list[LimitUpSklearnModel | LimitUpStatisticalModel] = []
    candidate_feature_sets: dict[int, str] = {}
    for feature_set_name, feature_names in _candidate_feature_sets():
        for model_cls in _candidate_model_classes():
            try:
                model = model_cls.fit(train, feature_names)
                candidates.append(model)
                candidate_feature_sets[id(model)] = feature_set_name
            except Exception:
                continue
    if not candidates:
        raise ValueError("No limit-up model candidate could be trained.")
    evaluated: list[tuple[tuple[float, float, float], LimitUpSklearnModel | LimitUpStatisticalModel, dict[str, float | int | None]]] = []
    candidate_results: list[dict[str, Any]] = []
    for model in candidates:
        scored = score_limit_up_candidates(model, validation)
        metrics = evaluate_limit_up_predictions(scored)
        candidate_results.append(
            {
                "model_type": _model_type(model),
                "feature_set": candidate_feature_sets.get(id(model), "unknown"),
                "feature_count": len(model.feature_names),
                "auc": metrics.get("auc"),
                "precision_at_10": metrics.get("precision_at_10"),
                "precision_at_20": metrics.get("precision_at_20"),
                "precision_at_50": metrics.get("precision_at_50"),
                "precision_prob_ge_70": metrics.get("precision_prob_ge_70"),
                "count_prob_ge_70": metrics.get("count_prob_ge_70"),
            }
        )
        rank_key = (
            float(metrics.get("precision_at_50") or 0),
            float(metrics.get("precision_at_20") or 0),
            float(metrics.get("auc") or 0),
        )
        evaluated.append((rank_key, model, metrics))
    evaluated.sort(key=lambda item: item[0], reverse=True)
    _, best_model, best_metrics = evaluated[0]
    best_metrics = dict(best_metrics)
    best_metrics["selected_model_type"] = _model_type(best_model)
    best_metrics["selected_feature_set"] = candidate_feature_sets.get(id(best_model), "unknown")
    best_metrics["selected_feature_count"] = len(best_model.feature_names)
    best_metrics["candidate_results"] = sorted(
        candidate_results,
        key=lambda item: (
            float(item.get("precision_at_50") or 0),
            float(item.get("precision_at_20") or 0),
            float(item.get("auc") or 0),
        ),
        reverse=True,
    )
    return best_model, best_metrics


def _candidate_feature_sets() -> list[tuple[str, list[str]]]:
    return [
        ("core", CORE_FEATURE_NAMES),
        ("enhanced", FEATURE_NAMES),
    ]


def _candidate_model_classes() -> list[type[LimitUpSklearnModel] | type[LimitUpStatisticalModel]]:
    return [
        LimitUpLightGbmModel,
        LimitUpXGBoostModel,
        LimitUpSklearnModel,
        LimitUpRandomForestModel,
        LimitUpExtraTreesModel,
        LimitUpLogisticRegressionModel,
        LimitUpStatisticalModel,
    ]


def _model_type(model: LimitUpSklearnModel | LimitUpStatisticalModel) -> str:
    if isinstance(model, LimitUpSklearnModel):
        return model.model_type
    return "limit_up_statistical_baseline"


def _model_matrix(frame: pd.DataFrame, feature_names: list[str]) -> pd.DataFrame:
    matrix = pd.DataFrame(index=frame.index)
    for name in feature_names:
        if name in frame.columns:
            matrix[name] = pd.to_numeric(frame[name], errors="coerce").replace([np.inf, -np.inf], np.nan)
        else:
            matrix[name] = np.nan
    return matrix


def _add_features(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()
    group = frame.groupby("symbol", group_keys=False)
    frame["prev_close"] = group["close"].shift(1)
    frame["pct_change"] = frame["close"] / frame["prev_close"] - 1
    frame["amplitude"] = (frame["high"] - frame["low"]) / frame["prev_close"]
    frame["body_strength"] = (frame["close"] - frame["open"]) / frame["prev_close"]
    frame["upper_shadow"] = (frame["high"] - frame[["open", "close"]].max(axis=1)) / frame["prev_close"]
    frame["lower_shadow"] = (frame[["open", "close"]].min(axis=1) - frame["low"]) / frame["prev_close"]
    frame["open_return"] = frame["open"] / frame["prev_close"] - 1
    frame["intraday_return"] = frame["close"] / frame["open"].replace(0, np.nan) - 1
    frame["close_position_in_range"] = (frame["close"] - frame["low"]) / (frame["high"] - frame["low"]).replace(0, np.nan)
    frame["high_close_pullback"] = (frame["high"] - frame["close"]) / frame["prev_close"]
    frame["low_close_recovery"] = (frame["close"] - frame["low"]) / frame["prev_close"]
    frame["log_turnover"] = np.log1p(frame["turnover"].clip(lower=0))
    frame["log_volume"] = np.log1p(frame["volume"].clip(lower=0))
    frame["price_level"] = frame["close"]
    frame = _add_common_technical_indicators(frame)
    for window in (5, 10, 20):
        avg_volume = group["volume"].transform(lambda s, w=window: s.shift(1).rolling(w, min_periods=1).mean())
        avg_turnover = group["turnover"].transform(lambda s, w=window: s.shift(1).rolling(w, min_periods=1).mean())
        frame[f"volume_ratio_{window}d"] = frame["volume"] / avg_volume.replace(0, np.nan)
        frame[f"turnover_ratio_{window}d"] = frame["turnover"] / avg_turnover.replace(0, np.nan)
        frame[f"volatility_{window}d"] = group["pct_change"].transform(
            lambda s, w=window: s.shift(1).rolling(w, min_periods=2).std()
        )
    volume_mean_20 = group["volume"].transform(lambda s: s.shift(1).rolling(20, min_periods=2).mean())
    volume_std_20 = group["volume"].transform(lambda s: s.shift(1).rolling(20, min_periods=2).std())
    turnover_mean_20 = group["turnover"].transform(lambda s: s.shift(1).rolling(20, min_periods=2).mean())
    turnover_std_20 = group["turnover"].transform(lambda s: s.shift(1).rolling(20, min_periods=2).std())
    frame["volume_zscore_20"] = (frame["volume"] - volume_mean_20) / volume_std_20.replace(0, np.nan)
    frame["turnover_zscore_20"] = (frame["turnover"] - turnover_mean_20) / turnover_std_20.replace(0, np.nan)
    for window in (3, 5, 10, 20):
        frame[f"return_{window}d"] = frame["close"] / group["close"].shift(window) - 1
    frame["return_acceleration_5d"] = frame["return_5d"] - frame["return_10d"]
    moving_averages: dict[int, pd.Series] = {}
    for window in (5, 10, 20, 60):
        ma = group["close"].transform(lambda s, w=window: s.shift(1).rolling(w, min_periods=1).mean())
        moving_averages[window] = ma
        frame[f"close_to_ma{window}"] = frame["close"] / ma - 1
        frame[f"above_ma{window}"] = (frame["close"] >= ma).astype(float)
    frame["ma_alignment_count"] = frame[["above_ma5", "above_ma10", "above_ma20", "above_ma60"]].sum(axis=1)
    ma5 = group["close"].transform(lambda s: s.shift(1).rolling(5, min_periods=1).mean())
    ma5_prev = group["close"].transform(lambda s: s.shift(6).rolling(5, min_periods=1).mean())
    frame["ma5_slope_5d"] = ma5 / ma5_prev - 1
    limit_flag = frame["pct_change"] >= LIMIT_UP_EVENT_THRESHOLD
    for window in (5, 10):
        frame[f"limit_up_count_{window}d"] = limit_flag.groupby(frame["symbol"]).transform(
            lambda s, w=window: s.shift(1).rolling(w, min_periods=1).sum()
        )
    frame["limit_up_count_20d"] = limit_flag.groupby(frame["symbol"]).transform(
        lambda s: s.shift(1).rolling(20, min_periods=1).sum()
    )
    large_gain_flag = frame["pct_change"] >= 0.07
    near_limit_up_flag = frame["pct_change"] >= 0.085
    for window in (5, 20):
        frame[f"large_gain_count_{window}d"] = large_gain_flag.groupby(frame["symbol"]).transform(
            lambda s, w=window: s.shift(1).rolling(w, min_periods=1).sum()
        )
        frame[f"near_limit_up_count_{window}d"] = near_limit_up_flag.groupby(frame["symbol"]).transform(
            lambda s, w=window: s.shift(1).rolling(w, min_periods=1).sum()
        )
    frame["days_since_last_limit_up"] = _days_since_last_true(frame["symbol"], limit_flag)
    frame["limit_streak"] = _limit_streak(frame["symbol"], limit_flag)
    frame["consecutive_up_days"] = _limit_streak(frame["symbol"], frame["pct_change"] > 0)
    current_group = frame.groupby("symbol", group_keys=False)
    frame["prev_day_return"] = current_group["pct_change"].shift(1)
    frame["prev_day_amplitude"] = current_group["amplitude"].shift(1)
    frame["prev_day_volume_ratio"] = current_group["volume_ratio_5d"].shift(1)
    high_60 = group["high"].transform(lambda s: s.shift(1).rolling(60, min_periods=1).max())
    low_60 = group["low"].transform(lambda s: s.shift(1).rolling(60, min_periods=1).min())
    frame["distance_to_60d_high"] = frame["close"] / high_60 - 1
    frame["distance_to_60d_low"] = frame["close"] / low_60 - 1
    high_20 = group["high"].transform(lambda s: s.shift(1).rolling(20, min_periods=1).max())
    low_20 = group["low"].transform(lambda s: s.shift(1).rolling(20, min_periods=1).min())
    frame["drawdown_from_20d_high"] = frame["close"] / high_20 - 1
    frame["rebound_from_20d_low"] = frame["close"] / low_20 - 1
    frame["breakout_prev_high"] = (frame["close"] >= group["high"].shift(1)).astype(float)
    frame["breakout_60d"] = (frame["close"] >= high_60).astype(float)
    frame["turnover_acceleration_5d"] = frame["turnover_ratio_5d"] / frame["turnover_ratio_20d"].replace(0, np.nan)
    frame["volume_acceleration_5d"] = frame["volume_ratio_5d"] / frame["volume_ratio_20d"].replace(0, np.nan)
    frame["up_volume_rank_60d"] = group["volume"].transform(lambda s: s.rolling(60, min_periods=1).rank(pct=True))
    frame["up_turnover_rank_60d"] = group["turnover"].transform(lambda s: s.rolling(60, min_periods=1).rank(pct=True))
    positive_volume_avg = group["volume"].transform(lambda s: s.where(frame.loc[s.index, "pct_change"] > 0).shift(1).rolling(20, min_periods=1).mean())
    positive_turnover_avg = group["turnover"].transform(lambda s: s.where(frame.loc[s.index, "pct_change"] > 0).shift(1).rolling(20, min_periods=1).mean())
    frame["up_volume_ratio_20d"] = frame["volume"] / positive_volume_avg.replace(0, np.nan)
    frame["up_turnover_ratio_20d"] = frame["turnover"] / positive_turnover_avg.replace(0, np.nan)
    frame["is_20pct_board"] = frame["symbol"].map(_is_20pct_board).astype(float)
    frame = _add_market_context_features(frame, limit_flag)
    frame["market_heat_score"] = frame["market_limit_up_ratio"] * frame["market_advancer_ratio"]
    frame["liquidity_pressure"] = frame["turnover_rank_pct"] * frame["turnover_ratio_5d"]
    frame["risk_adjusted_return_5d"] = frame["return_5d"] / frame["volatility_5d"].replace(0, np.nan)
    frame["risk_adjusted_return_20d"] = frame["return_20d"] / frame["volatility_20d"].replace(0, np.nan)
    frame["opening_strength_ratio"] = frame["open_return"] / frame["pct_change"].replace(0, np.nan)
    frame["shadow_pressure"] = frame["lower_shadow"] - frame["upper_shadow"]
    frame["breakout_20d"] = (frame["drawdown_from_20d_high"] >= 0).astype(float)
    frame["overheat_score"] = (
        frame["return_20d"].fillna(0)
        + frame["rebound_from_20d_low"].fillna(0) * 0.25
        + frame["limit_up_count_20d"].fillna(0) * 0.05
    )
    frame = _add_hmm_state_features(frame)
    frame = _add_fundamental_features(frame)
    frame = _add_eastmoney_external_features(frame)
    return frame


def _add_hmm_state_features(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()
    for column in HMM_STATE_FEATURE_NAMES:
        frame[column] = np.nan

    observation_columns = [name for name in HMM_OBSERVATION_FEATURE_NAMES if name in frame.columns]
    if len(frame) < 30 or len(observation_columns) < 4:
        return _add_hmm_proxy_features(frame)

    observations = _model_matrix(frame, observation_columns)
    valid_mask = observations.notna().sum(axis=1) >= max(4, int(len(observation_columns) * 0.6))
    if int(valid_mask.sum()) < 30:
        return _add_hmm_proxy_features(frame)

    try:
        from hmmlearn.hmm import GaussianHMM
        from sklearn.impute import SimpleImputer
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler
    except Exception:
        return _add_hmm_proxy_features(frame)

    try:
        valid_observations = observations.loc[valid_mask]
        sample = valid_observations
        if len(valid_observations) > 60_000:
            sample = valid_observations.sample(60_000, random_state=42).sort_index()
        transformer = make_pipeline(SimpleImputer(strategy="median"), StandardScaler())
        sample_matrix = transformer.fit_transform(sample)
        model = GaussianHMM(
            n_components=4,
            covariance_type="diag",
            n_iter=120,
            tol=0.01,
            random_state=42,
            min_covar=1e-3,
        )
        model.fit(sample_matrix)
        valid_matrix = transformer.transform(valid_observations)
        probabilities = model.predict_proba(valid_matrix)
        states = probabilities.argmax(axis=1)
        state_probability = probabilities.max(axis=1)
        state_momentum = _hmm_state_momentum(frame.loc[valid_mask, "pct_change"], states, probabilities)
        transition_risk = _hmm_transition_risk(model, state_momentum, states)

        frame.loc[valid_mask, "hmm_state"] = states.astype(float)
        frame.loc[valid_mask, "hmm_state_prob"] = state_probability
        frame.loc[valid_mask, "hmm_state_momentum"] = state_momentum
        frame.loc[valid_mask, "hmm_transition_risk"] = transition_risk
    except Exception:
        return _add_hmm_proxy_features(frame)

    return _fill_hmm_feature_gaps(frame)


def _hmm_state_momentum(pct_change: pd.Series, states: np.ndarray, probabilities: np.ndarray) -> np.ndarray:
    returns = pd.to_numeric(pct_change, errors="coerce").fillna(0).to_numpy(dtype="float64")
    state_count = probabilities.shape[1]
    means = np.zeros(state_count, dtype="float64")
    for state in range(state_count):
        mask = states == state
        means[state] = float(returns[mask].mean()) if mask.any() else 0.0
    return probabilities @ means


def _hmm_transition_risk(model: Any, state_momentum: np.ndarray, states: np.ndarray) -> np.ndarray:
    transition = getattr(model, "transmat_", None)
    if transition is None or transition.shape[0] == 0:
        return np.where(state_momentum < 0, 0.7, 0.3)
    state_means = np.array([state_momentum[states == state].mean() if np.any(states == state) else 0.0 for state in range(transition.shape[0])])
    weak_states = state_means <= np.nanmedian(state_means)
    return np.array([float(transition[int(state), weak_states].sum()) for state in states], dtype="float64")


def _add_hmm_proxy_features(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()
    trend = (
        pd.to_numeric(frame.get("return_5d"), errors="coerce").fillna(0) * 0.45
        + pd.to_numeric(frame.get("return_20d"), errors="coerce").fillna(0) * 0.25
        + pd.to_numeric(frame.get("pct_change"), errors="coerce").fillna(0) * 0.30
    )
    volume = pd.to_numeric(frame.get("volume_ratio_5d"), errors="coerce").fillna(1.0)
    risk = pd.to_numeric(frame.get("high_close_pullback"), errors="coerce").fillna(0)
    state = np.select(
        [
            (trend >= 0.08) & (volume >= 1.8),
            trend >= 0.03,
            trend <= -0.02,
        ],
        [3.0, 2.0, 0.0],
        default=1.0,
    )
    confidence = (0.55 + trend.abs().clip(upper=0.25) * 1.4 + (volume - 1).clip(lower=0, upper=3) * 0.05).clip(0.55, 0.92)
    frame["hmm_state"] = state
    frame["hmm_state_prob"] = confidence
    frame["hmm_state_momentum"] = trend
    frame["hmm_transition_risk"] = (0.55 - trend.clip(-0.2, 0.2) + risk.clip(0, 0.2)).clip(0.05, 0.95)
    return _fill_hmm_feature_gaps(frame)


def _fill_hmm_feature_gaps(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()
    frame["hmm_state"] = pd.to_numeric(frame["hmm_state"], errors="coerce").fillna(1.0)
    frame["hmm_state_prob"] = pd.to_numeric(frame["hmm_state_prob"], errors="coerce").fillna(0.5).clip(0, 1)
    frame["hmm_state_momentum"] = pd.to_numeric(frame["hmm_state_momentum"], errors="coerce").fillna(0.0)
    frame["hmm_transition_risk"] = pd.to_numeric(frame["hmm_transition_risk"], errors="coerce").fillna(0.5).clip(0, 1)
    return frame


def _add_fundamental_features(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()
    for column in FUNDAMENTAL_RAW_FEATURE_NAMES:
        if column not in frame:
            frame[column] = np.nan
        frame[column] = pd.to_numeric(frame[column], errors="coerce").replace([np.inf, -np.inf], np.nan)

    grouped = frame.groupby("trade_date", group_keys=False)
    frame["valuation_score"] = _average_score_columns(
        grouped["pe"].transform(lambda s: _rank_score(_positive_only(s), higher_is_better=False)),
        grouped["pb"].transform(lambda s: _rank_score(_positive_only(s), higher_is_better=False)),
        grouped["ps"].transform(lambda s: _rank_score(_positive_only(s), higher_is_better=False)),
    )
    frame["quality_score"] = _average_score_columns(
        grouped["roe"].transform(lambda s: _rank_score(s, higher_is_better=True)),
        grouped["roa"].transform(lambda s: _rank_score(s, higher_is_better=True)),
        grouped["net_margin"].transform(lambda s: _rank_score(s, higher_is_better=True)),
        grouped["gross_margin"].transform(lambda s: _rank_score(s, higher_is_better=True)),
        grouped["revenue_yoy"].transform(lambda s: _rank_score(s, higher_is_better=True)),
        grouped["net_profit_yoy"].transform(lambda s: _rank_score(s, higher_is_better=True)),
    )
    frame["fundamental_risk_score"] = _average_score_columns(
        grouped["liabilities_assets"].transform(lambda s: _rank_score(s, higher_is_better=False)),
        grouped["leverage"].transform(lambda s: _rank_score(s, higher_is_better=False)),
    )
    frame["fundamental_score"] = _average_score_columns(
        frame["valuation_score"],
        frame["quality_score"],
        frame["fundamental_risk_score"],
    )
    frame["market_value_log"] = np.log1p(frame["market_value"].clip(lower=0))
    frame["market_value_rank_pct"] = grouped["market_value"].transform(lambda s: s.rank(pct=True))
    return frame


def _add_eastmoney_external_features(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()
    pool_flag_columns = [
        "eastmoney_limit_up_pool",
        "eastmoney_previous_limit_up_pool",
        "eastmoney_strong_pool",
        "eastmoney_open_board_pool",
        "eastmoney_limit_down_pool",
    ]
    for column in pool_flag_columns:
        if column not in frame:
            frame[column] = 0.0
        frame[column] = pd.to_numeric(frame[column], errors="coerce").fillna(0.0).clip(0, 1)

    if "eastmoney_pool_count" not in frame:
        frame["eastmoney_pool_count"] = frame[pool_flag_columns].sum(axis=1)
    frame["eastmoney_pool_count"] = pd.to_numeric(frame["eastmoney_pool_count"], errors="coerce").fillna(0.0)

    for column in [
        "eastmoney_consecutive_boards",
        "eastmoney_break_count",
        "eastmoney_seal_amount",
        "eastmoney_turnover_rate",
        "eastmoney_float_market_cap",
        "eastmoney_total_market_cap",
        "eastmoney_main_net_flow",
        "eastmoney_main_net_flow_ratio",
        "eastmoney_super_large_net_flow",
        "eastmoney_large_net_flow",
        "eastmoney_medium_net_flow",
        "eastmoney_small_net_flow",
    ]:
        if column not in frame:
            frame[column] = np.nan
        frame[column] = pd.to_numeric(frame[column], errors="coerce").replace([np.inf, -np.inf], np.nan)

    fallback_streak = frame["limit_streak"] if "limit_streak" in frame else 0.0
    frame["eastmoney_consecutive_boards"] = frame["eastmoney_consecutive_boards"].fillna(fallback_streak)
    frame["eastmoney_break_count"] = frame["eastmoney_break_count"].fillna(0.0)
    frame["eastmoney_seal_amount_log"] = np.sign(frame["eastmoney_seal_amount"].fillna(0)) * np.log1p(
        frame["eastmoney_seal_amount"].abs().fillna(0)
    )
    frame["eastmoney_float_market_cap_log"] = np.log1p(frame["eastmoney_float_market_cap"].clip(lower=0))
    frame["eastmoney_total_market_cap_log"] = np.log1p(frame["eastmoney_total_market_cap"].clip(lower=0))
    frame["eastmoney_main_net_flow_log"] = np.sign(frame["eastmoney_main_net_flow"].fillna(0)) * np.log1p(
        frame["eastmoney_main_net_flow"].abs().fillna(0)
    )
    frame["eastmoney_main_net_flow_to_turnover"] = frame["eastmoney_main_net_flow"] / frame["turnover"].replace(0, np.nan)

    grouped = frame.groupby("trade_date", group_keys=False)
    frame["eastmoney_seal_amount_rank_pct"] = grouped["eastmoney_seal_amount"].transform(lambda s: s.rank(pct=True))
    frame["eastmoney_main_net_flow_rank_pct"] = grouped["eastmoney_main_net_flow"].transform(lambda s: s.rank(pct=True))

    for raw_column, feature_column in [
        ("eastmoney_first_seal_time", "eastmoney_first_seal_minutes"),
        ("eastmoney_last_seal_time", "eastmoney_last_seal_minutes"),
    ]:
        if raw_column not in frame:
            frame[feature_column] = np.nan
        else:
            frame[feature_column] = frame[raw_column].map(_seal_time_minutes)
    minutes_from_open = frame["eastmoney_first_seal_minutes"] - (9 * 60 + 30)
    frame["eastmoney_first_seal_early_score"] = (1 - minutes_from_open / 240).clip(0, 1)

    for column in EASTMONEY_FEATURE_NAMES:
        if column not in frame:
            frame[column] = np.nan
        frame[column] = pd.to_numeric(frame[column], errors="coerce").replace([np.inf, -np.inf], np.nan)
    return frame


def _seal_time_minutes(value: Any) -> float | None:
    if value is None or pd.isna(value):
        return None
    text = str(value).strip().replace(":", "")
    if not text or not text.isdigit():
        return None
    if len(text) <= 4:
        text = text.zfill(4)
    hour = int(text[:2])
    minute = int(text[2:4])
    if hour < 0 or hour > 23 or minute < 0 or minute > 59:
        return None
    return float(hour * 60 + minute)


def _rank_score(series: pd.Series, *, higher_is_better: bool) -> pd.Series:
    numeric = pd.to_numeric(series, errors="coerce")
    valid = numeric.dropna()
    if valid.empty:
        return pd.Series(50.0, index=series.index, dtype="float64")
    ranks = valid.rank(pct=True, ascending=higher_is_better) * 100.0
    scored = pd.Series(50.0, index=series.index, dtype="float64")
    scored.loc[valid.index] = ranks.round(2)
    return scored


def _average_score_columns(*scores: pd.Series) -> pd.Series:
    return pd.concat(scores, axis=1).mean(axis=1).fillna(50.0).round(2)


def _positive_only(series: pd.Series) -> pd.Series:
    numeric = pd.to_numeric(series, errors="coerce")
    return numeric.where(numeric > 0)


def _add_common_technical_indicators(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()
    group = frame.groupby("symbol", group_keys=False)
    frame["rsi_6"] = group["close"].transform(lambda s: _rsi(s, 6))
    frame["rsi_14"] = group["close"].transform(lambda s: _rsi(s, 14))

    ema12 = group["close"].transform(lambda s: s.ewm(span=12, adjust=False).mean())
    ema26 = group["close"].transform(lambda s: s.ewm(span=26, adjust=False).mean())
    frame["macd_dif"] = ema12 - ema26
    frame["macd_dea"] = frame.groupby("symbol")["macd_dif"].transform(lambda s: s.ewm(span=9, adjust=False).mean())
    frame["macd_hist"] = frame["macd_dif"] - frame["macd_dea"]

    low9 = group["low"].transform(lambda s: s.rolling(9, min_periods=1).min())
    high9 = group["high"].transform(lambda s: s.rolling(9, min_periods=1).max())
    rsv = ((frame["close"] - low9) / (high9 - low9).replace(0, np.nan) * 100).fillna(50)
    frame["kdj_k"] = rsv.groupby(frame["symbol"]).transform(lambda s: s.ewm(alpha=1 / 3, adjust=False).mean())
    frame["kdj_d"] = frame.groupby("symbol")["kdj_k"].transform(lambda s: s.ewm(alpha=1 / 3, adjust=False).mean())
    frame["kdj_j"] = 3 * frame["kdj_k"] - 2 * frame["kdj_d"]

    ma20 = group["close"].transform(lambda s: s.rolling(20, min_periods=2).mean())
    std20 = group["close"].transform(lambda s: s.rolling(20, min_periods=2).std())
    upper = ma20 + 2 * std20
    lower = ma20 - 2 * std20
    frame["bollinger_position_20"] = (frame["close"] - lower) / (upper - lower).replace(0, np.nan)
    frame["bollinger_width_20"] = (upper - lower) / ma20.replace(0, np.nan)

    true_range = pd.concat(
        [
            frame["high"] - frame["low"],
            (frame["high"] - frame["prev_close"]).abs(),
            (frame["low"] - frame["prev_close"]).abs(),
        ],
        axis=1,
    ).max(axis=1)
    frame["atr_14"] = true_range.groupby(frame["symbol"]).transform(lambda s: s.rolling(14, min_periods=1).mean())

    typical_price = (frame["high"] + frame["low"] + frame["close"]) / 3
    tp_ma20 = typical_price.groupby(frame["symbol"]).transform(lambda s: s.rolling(20, min_periods=2).mean())
    tp_md20 = typical_price.groupby(frame["symbol"]).transform(
        lambda s: s.rolling(20, min_periods=2).apply(lambda values: float(np.mean(np.abs(values - np.mean(values)))), raw=True)
    )
    frame["cci_20"] = (typical_price - tp_ma20) / (0.015 * tp_md20.replace(0, np.nan))

    high14 = group["high"].transform(lambda s: s.rolling(14, min_periods=1).max())
    low14 = group["low"].transform(lambda s: s.rolling(14, min_periods=1).min())
    frame["williams_r_14"] = -100 * (high14 - frame["close"]) / (high14 - low14).replace(0, np.nan)

    obv_flow = np.sign(frame["pct_change"].fillna(0)) * frame["volume"].fillna(0)
    obv = obv_flow.groupby(frame["symbol"]).cumsum()
    avg_volume_10 = group["volume"].transform(lambda s: s.rolling(10, min_periods=1).mean())
    frame["obv_trend_10"] = (obv - obv.groupby(frame["symbol"]).shift(10)) / avg_volume_10.replace(0, np.nan)
    return frame


def _rsi(close: pd.Series, window: int) -> pd.Series:
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1 / window, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1 / window, adjust=False).mean()
    rs = gain / loss.replace(0, np.nan)
    rsi = 100 - 100 / (1 + rs)
    rsi = rsi.mask((loss == 0) & (gain > 0), 100)
    return rsi.fillna(50)


def _add_market_context_features(frame: pd.DataFrame, limit_flag: pd.Series) -> pd.DataFrame:
    a_share = frame["symbol"].map(_is_a_share_symbol)
    scoped = frame.loc[a_share].copy()
    scoped["_limit_flag"] = limit_flag.loc[scoped.index].astype(float)
    grouped = scoped.groupby("trade_date")
    context = grouped.agg(
        market_return_mean=("pct_change", "mean"),
        market_return_median=("pct_change", "median"),
        market_return_3d=("return_3d", "mean"),
        market_return_5d=("return_5d", "mean"),
        market_return_10d=("return_10d", "mean"),
        market_return_20d=("return_20d", "mean"),
        market_advancer_ratio=("pct_change", lambda s: float((s > 0).mean())),
        market_limit_up_count=("_limit_flag", "sum"),
        market_symbol_count=("symbol", "count"),
        market_turnover=("turnover", "sum"),
    )
    context["market_limit_up_ratio"] = context["market_limit_up_count"] / context["market_symbol_count"].replace(0, np.nan)
    context["market_limit_up_count_3d"] = context["market_limit_up_count"].rolling(3, min_periods=1).sum()
    context["market_limit_up_count_5d"] = context["market_limit_up_count"].rolling(5, min_periods=1).sum()
    context["market_limit_up_ratio_3d"] = context["market_limit_up_ratio"].rolling(3, min_periods=1).mean()
    context["market_limit_up_ratio_5d"] = context["market_limit_up_ratio"].rolling(5, min_periods=1).mean()
    context["market_turnover_change"] = context["market_turnover"] / context["market_turnover"].shift(1) - 1
    frame = frame.merge(
        context[
            [
                "market_return_mean",
                "market_return_median",
                "market_return_3d",
                "market_return_5d",
                "market_return_10d",
                "market_return_20d",
                "market_advancer_ratio",
                "market_limit_up_count",
                "market_limit_up_ratio",
                "market_limit_up_count_3d",
                "market_limit_up_count_5d",
                "market_limit_up_ratio_3d",
                "market_limit_up_ratio_5d",
                "market_turnover_change",
            ]
        ],
        left_on="trade_date",
        right_index=True,
        how="left",
    )
    for window in (3, 5, 10, 20):
        frame[f"relative_return_{window}d"] = frame[f"return_{window}d"] - frame[f"market_return_{window}d"]
    frame["turnover_rank_pct"] = frame.groupby("trade_date")["turnover"].rank(pct=True)
    frame["volume_rank_pct"] = frame.groupby("trade_date")["volume"].rank(pct=True)
    frame["pct_change_rank_pct"] = frame.groupby("trade_date")["pct_change"].rank(pct=True)
    frame["amplitude_rank_pct"] = frame.groupby("trade_date")["amplitude"].rank(pct=True)
    return frame


def _limit_streak(symbols: pd.Series, limit_flag: pd.Series) -> pd.Series:
    values: list[int] = []
    previous_symbol = None
    streak = 0
    for symbol, flag in zip(symbols, limit_flag):
        if symbol != previous_symbol:
            streak = 0
            previous_symbol = symbol
        streak = streak + 1 if bool(flag) else 0
        values.append(streak)
    return pd.Series(values, index=limit_flag.index)


def _days_since_last_true(symbols: pd.Series, flag: pd.Series) -> pd.Series:
    values: list[float | None] = []
    previous_symbol = None
    last_true_position: int | None = None
    symbol_position = 0
    for symbol, is_true in zip(symbols, flag):
        if symbol != previous_symbol:
            previous_symbol = symbol
            last_true_position = None
            symbol_position = 0
        values.append(None if last_true_position is None else symbol_position - last_true_position)
        if bool(is_true):
            last_true_position = symbol_position
        symbol_position += 1
    return pd.Series(values, index=flag.index, dtype="float64")


def _future_close_return(future: pd.DataFrame, next_open: float, day: int) -> float | None:
    if len(future) < day:
        return None
    return float(future.iloc[day - 1]["close"] / next_open - 1)


def _decision(score: float) -> str:
    if score >= 75:
        return "strong_candidate"
    if score >= 60:
        return "candidate"
    if score >= 45:
        return "watch"
    return "avoid"


def _calibrate_eastmoney_limit_pool_probability(frame: pd.DataFrame, probability: pd.Series) -> pd.Series:
    if "eastmoney_limit_up_pool" not in frame:
        return probability
    mask = pd.to_numeric(frame["eastmoney_limit_up_pool"], errors="coerce").fillna(0) > 0
    if not bool(mask.any()):
        return probability
    seal_rank = _numeric_feature(frame, "eastmoney_seal_amount_rank_pct", 0.5).clip(0, 1)
    early_score = _numeric_feature(frame, "eastmoney_first_seal_early_score", 0.5).clip(0, 1)
    consecutive = (_numeric_feature(frame, "eastmoney_consecutive_boards", 1.0) / 4.0).clip(0, 1)
    break_control = (1.0 - _numeric_feature(frame, "eastmoney_break_count", 0.0) / 4.0).clip(0, 1)
    turnover = (_numeric_feature(frame, "eastmoney_turnover_rate", 5.0) / 20.0).clip(0, 1)
    fund_rank = _numeric_feature(frame, "eastmoney_main_net_flow_rank_pct", 0.5).clip(0, 1)
    tactical_score = (
        seal_rank * 0.30
        + early_score * 0.25
        + consecutive * 0.15
        + break_control * 0.15
        + turnover * 0.10
        + fund_rank * 0.05
    )
    adjusted = probability.copy()
    adjusted.loc[mask] = (probability.loc[mask] + (tactical_score.loc[mask] - 0.5) * 0.28).clip(0.02, 0.98)
    return adjusted


def _numeric_feature(frame: pd.DataFrame, column: str, default: float) -> pd.Series:
    if column not in frame:
        return pd.Series(default, index=frame.index, dtype="float64")
    return pd.to_numeric(frame[column], errors="coerce").replace([np.inf, -np.inf], np.nan).fillna(default)


def _reason(row: pd.Series) -> str:
    volume = _safe_float(row.get("volume_ratio_5d"))
    momentum = _safe_float(row.get("return_5d"))
    seal_rank = _safe_float(row.get("eastmoney_seal_amount_rank_pct"))
    first_seal_score = _safe_float(row.get("eastmoney_first_seal_early_score"))
    break_count = _safe_float(row.get("eastmoney_break_count"))
    consecutive = _safe_float(row.get("eastmoney_consecutive_boards"))
    parts = []
    if volume is not None and volume >= 2:
        parts.append("volume_expansion")
    if momentum is not None and momentum > 0:
        parts.append("positive_short_momentum")
    if seal_rank is not None and seal_rank >= 0.75:
        parts.append("strong_seal_fund")
    if first_seal_score is not None and first_seal_score >= 0.8:
        parts.append("early_first_seal")
    if consecutive is not None and consecutive >= 2:
        parts.append("multi_board")
    if break_count is not None and break_count > 0:
        parts.append("has_open_board_risk")
    if not parts:
        parts.append("baseline_score")
    return ",".join(parts)


def _auc(scores: pd.Series, target: pd.Series) -> float | None:
    positives = int(target.sum())
    negatives = int((~target).sum())
    if positives == 0 or negatives == 0:
        return None
    ranks = scores.rank(method="average")
    pos_rank_sum = float(ranks[target].sum())
    return float((pos_rank_sum - positives * (positives + 1) / 2) / (positives * negatives))


def _mean_top(frame: pd.DataFrame, column: str, top_n: int) -> float | None:
    if column not in frame or frame.empty:
        return None
    return _safe_float(pd.to_numeric(frame.head(top_n)[column], errors="coerce").mean())


def _is_a_share_symbol(symbol: str) -> bool:
    return str(symbol).endswith((".SH", ".SZ"))


def _is_20pct_board(symbol: str) -> bool:
    text = str(symbol)
    return text.startswith(("300", "301", "688"))


def _load_cn_daily_bars(
    conn: psycopg.Connection[Any],
    *,
    start_date: str | date | None,
    end_date: str | date | None,
) -> pd.DataFrame:
    where = ["right(b.symbol, 3) IN (%s, %s)"]
    params: list[Any] = [".SH", ".SZ"]
    if start_date:
        where.append("b.trade_date >= %s")
        params.append(start_date)
    if end_date:
        where.append("b.trade_date <= %s")
        params.append(end_date)
    query = f"""
        SELECT
            b.symbol, b.trade_date, b.open, b.high, b.low, b.close, b.volume, b.turnover,
            COALESCE(calc.pe, val.pe) AS pe,
            COALESCE(calc.pb, val.pb) AS pb,
            val.ps, val.roe, val.roa, val.net_margin, val.liabilities_assets,
            val.leverage,
            COALESCE(calc.mktcap, val.market_value) AS market_value,
            fin.gross_margin, fin.revenue_yoy, fin.net_profit_yoy,
            east_pool.eastmoney_limit_up_pool,
            east_pool.eastmoney_previous_limit_up_pool,
            east_pool.eastmoney_strong_pool,
            east_pool.eastmoney_open_board_pool,
            east_pool.eastmoney_limit_down_pool,
            east_pool.eastmoney_pool_count,
            east_pool.eastmoney_consecutive_boards,
            east_pool.eastmoney_break_count,
            east_pool.eastmoney_seal_amount,
            east_pool.eastmoney_turnover_rate,
            east_pool.eastmoney_float_market_cap,
            east_pool.eastmoney_total_market_cap,
            east_pool.eastmoney_first_seal_time,
            east_pool.eastmoney_last_seal_time,
            east_flow.eastmoney_main_net_flow,
            east_flow.eastmoney_main_net_flow_ratio,
            east_flow.eastmoney_super_large_net_flow,
            east_flow.eastmoney_large_net_flow,
            east_flow.eastmoney_medium_net_flow,
            east_flow.eastmoney_small_net_flow
        FROM lb_daily_bars b
        LEFT JOIN LATERAL (
            SELECT pe, pb, mktcap
            FROM lb_calc_index
            WHERE symbol = b.symbol AND trade_date <= b.trade_date
            ORDER BY trade_date DESC
            LIMIT 1
        ) calc ON TRUE
        LEFT JOIN LATERAL (
            SELECT pe, pb, ps, roe, roa, net_margin, liabilities_assets, leverage, market_value
            FROM lb_valuation
            WHERE symbol = b.symbol AND trade_date <= b.trade_date
            ORDER BY trade_date DESC
            LIMIT 1
        ) val ON TRUE
        LEFT JOIN LATERAL (
            SELECT
                MAX(value) FILTER (WHERE field = 'GrossMgn') AS gross_margin,
                MAX(yoy::numeric) FILTER (WHERE field = 'OperatingRevenue' AND yoy ~ '^-?[0-9]+(\\.[0-9]+)?$') AS revenue_yoy,
                MAX(yoy::numeric) FILTER (WHERE field = 'NetProfit' AND yoy ~ '^-?[0-9]+(\\.[0-9]+)?$') AS net_profit_yoy
            FROM (
                SELECT DISTINCT ON (field) field, value, yoy
                FROM lb_financial_report
                WHERE symbol = b.symbol
                  AND fp_end <= b.trade_date
                  AND field IN ('GrossMgn', 'OperatingRevenue', 'NetProfit')
                ORDER BY field, fp_end DESC
            ) latest_report
        ) fin ON TRUE
        LEFT JOIN LATERAL (
            SELECT
                MAX(CASE WHEN pool = 'limit_up' THEN 1 ELSE 0 END)::numeric AS eastmoney_limit_up_pool,
                MAX(CASE WHEN pool = 'previous_limit_up' THEN 1 ELSE 0 END)::numeric AS eastmoney_previous_limit_up_pool,
                MAX(CASE WHEN pool = 'strong' THEN 1 ELSE 0 END)::numeric AS eastmoney_strong_pool,
                MAX(CASE WHEN pool = 'open_board' THEN 1 ELSE 0 END)::numeric AS eastmoney_open_board_pool,
                MAX(CASE WHEN pool = 'limit_down' THEN 1 ELSE 0 END)::numeric AS eastmoney_limit_down_pool,
                COUNT(*)::numeric AS eastmoney_pool_count,
                MAX(consecutive_boards) AS eastmoney_consecutive_boards,
                MAX(break_count) AS eastmoney_break_count,
                MAX(seal_amount) AS eastmoney_seal_amount,
                MAX(turnover_rate) AS eastmoney_turnover_rate,
                MAX(float_market_cap) AS eastmoney_float_market_cap,
                MAX(total_market_cap) AS eastmoney_total_market_cap,
                MIN(first_seal_time) AS eastmoney_first_seal_time,
                MAX(last_seal_time) AS eastmoney_last_seal_time
            FROM lb_external_limit_pools
            WHERE source = 'eastmoney'
              AND symbol = b.symbol
              AND trade_date = b.trade_date
        ) east_pool ON TRUE
        LEFT JOIN LATERAL (
            SELECT
                main_net_flow AS eastmoney_main_net_flow,
                main_net_flow_ratio AS eastmoney_main_net_flow_ratio,
                super_large_net_flow AS eastmoney_super_large_net_flow,
                large_net_flow AS eastmoney_large_net_flow,
                medium_net_flow AS eastmoney_medium_net_flow,
                small_net_flow AS eastmoney_small_net_flow
            FROM lb_external_fund_flow_rank
            WHERE source = 'eastmoney'
              AND symbol = b.symbol
              AND trade_date = b.trade_date
            ORDER BY CASE period WHEN '今日' THEN 0 ELSE 1 END
            LIMIT 1
        ) east_flow ON TRUE
        WHERE {' AND '.join(f'({item})' for item in where)}
        ORDER BY b.symbol, b.trade_date
    """
    return pd.read_sql_query(query, conn, params=params)


def _upsert_limit_up_events(conn: psycopg.Connection[Any], events: pd.DataFrame) -> None:
    if events.empty:
        return
    with conn.cursor() as cur:
        for row in events.to_dict("records"):
            features = {name: _safe_float(row.get(name)) for name in FEATURE_NAMES if name in row}
            cur.execute(
                """
                INSERT INTO lb_limit_up_events (
                    symbol, event_date, prev_close, open_price, high_price, low_price, close_price,
                    volume, turnover, pct_change, is_limit_up_10, is_limit_up_20, next_open,
                    max_return_5d, max_drawdown_5d, close_return_1d, close_return_3d, close_return_5d,
                    target_open_buy, features, updated_at
                )
                VALUES (
                    %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW()
                )
                ON CONFLICT (symbol, event_date) DO UPDATE SET
                    prev_close = EXCLUDED.prev_close,
                    open_price = EXCLUDED.open_price,
                    high_price = EXCLUDED.high_price,
                    low_price = EXCLUDED.low_price,
                    close_price = EXCLUDED.close_price,
                    volume = EXCLUDED.volume,
                    turnover = EXCLUDED.turnover,
                    pct_change = EXCLUDED.pct_change,
                    is_limit_up_10 = EXCLUDED.is_limit_up_10,
                    is_limit_up_20 = EXCLUDED.is_limit_up_20,
                    next_open = EXCLUDED.next_open,
                    max_return_5d = EXCLUDED.max_return_5d,
                    max_drawdown_5d = EXCLUDED.max_drawdown_5d,
                    close_return_1d = EXCLUDED.close_return_1d,
                    close_return_3d = EXCLUDED.close_return_3d,
                    close_return_5d = EXCLUDED.close_return_5d,
                    target_open_buy = EXCLUDED.target_open_buy,
                    features = EXCLUDED.features,
                    updated_at = NOW()
                """,
                (
                    row["symbol"],
                    row["event_date"],
                    _safe_float(row.get("prev_close")),
                    _safe_float(row.get("open")),
                    _safe_float(row.get("high")),
                    _safe_float(row.get("low")),
                    _safe_float(row.get("close")),
                    _safe_float(row.get("volume")),
                    _safe_float(row.get("turnover")),
                    _safe_float(row.get("pct_change")),
                    bool(row.get("is_limit_up_10")),
                    bool(row.get("is_limit_up_20")),
                    _safe_float(row.get("next_open")),
                    _safe_float(row.get("max_return_5d")),
                    _safe_float(row.get("max_drawdown_5d")),
                    _safe_float(row.get("close_return_1d")),
                    _safe_float(row.get("close_return_3d")),
                    _safe_float(row.get("close_return_5d")),
                    _safe_bool(row.get("target_open_buy")),
                    Jsonb(_json_ready(features)),
                ),
            )


def _load_limit_up_events(
    conn: psycopg.Connection[Any],
    *,
    event_date: str | date | None = None,
    labeled_only: bool = False,
) -> pd.DataFrame:
    where: list[str] = []
    params: list[Any] = []
    if event_date:
        where.append("event_date = %s")
        params.append(event_date)
    if labeled_only:
        where.append("target_open_buy IS NOT NULL")
    clause = f"WHERE {' AND '.join(where)}" if where else ""
    query = f"""
        SELECT
            symbol, event_date, pct_change, next_open, max_return_5d, max_drawdown_5d,
            close_return_1d, close_return_3d, close_return_5d, target_open_buy, features
        FROM lb_limit_up_events
        {clause}
        ORDER BY event_date, symbol
    """
    rows = pd.read_sql_query(query, conn, params=params)
    if rows.empty:
        return rows
    features = pd.json_normalize(rows["features"]).reindex(columns=FEATURE_NAMES)
    combined = pd.concat([rows.drop(columns=["features"]), features], axis=1)
    return combined.loc[:, ~combined.columns.duplicated()]


def _load_external_limit_pool_events(
    conn: psycopg.Connection[Any],
    *,
    start_date: str | date | None,
    end_date: str | date | None,
) -> pd.DataFrame:
    where = ["source = 'eastmoney'", "pool = 'limit_up'"]
    params: list[Any] = []
    if start_date:
        where.append("trade_date >= %s")
        params.append(start_date)
    if end_date:
        where.append("trade_date <= %s")
        params.append(end_date)
    query = f"""
        SELECT
            symbol,
            trade_date AS event_date,
            (last_price / NULLIF(1 + pct_change / 100.0, 0)) AS prev_close,
            last_price AS open,
            last_price AS high,
            last_price AS low,
            last_price AS close,
            NULL::numeric AS volume,
            turnover,
            pct_change / 100.0 AS pct_change,
            TRUE AS is_limit_up_10,
            (pct_change / 100.0) >= %s AS is_limit_up_20,
            NULL::numeric AS next_open,
            NULL::numeric AS max_return_5d,
            NULL::numeric AS max_drawdown_5d,
            NULL::numeric AS close_return_1d,
            NULL::numeric AS close_return_3d,
            NULL::numeric AS close_return_5d,
            NULL::boolean AS target_open_buy,
            1.0 AS eastmoney_limit_up_pool,
            0.0 AS eastmoney_previous_limit_up_pool,
            0.0 AS eastmoney_strong_pool,
            0.0 AS eastmoney_open_board_pool,
            0.0 AS eastmoney_limit_down_pool,
            1.0 AS eastmoney_pool_count,
            consecutive_boards AS eastmoney_consecutive_boards,
            break_count AS eastmoney_break_count,
            seal_amount AS eastmoney_seal_amount,
            turnover_rate AS eastmoney_turnover_rate,
            float_market_cap AS eastmoney_float_market_cap,
            total_market_cap AS eastmoney_total_market_cap,
            first_seal_time AS eastmoney_first_seal_time,
            last_seal_time AS eastmoney_last_seal_time
        FROM lb_external_limit_pools
        WHERE {' AND '.join(f'({item})' for item in where)}
        ORDER BY trade_date, symbol
    """
    rows = pd.read_sql_query(query, conn, params=[LIMIT_UP_20_THRESHOLD, *params])
    if rows.empty:
        return rows
    rows["trade_date"] = pd.to_datetime(rows["event_date"]).dt.date
    rows = _add_eastmoney_external_features(rows)
    rows["event_date"] = pd.to_datetime(rows["event_date"]).dt.date
    for column in FEATURE_NAMES:
        if column not in rows:
            rows[column] = np.nan
    return rows


def _merge_external_limit_pool_events(events: pd.DataFrame, external_events: pd.DataFrame) -> pd.DataFrame:
    if external_events.empty:
        return events
    if events.empty:
        return external_events
    existing_keys = set(zip(events["symbol"].astype(str), pd.to_datetime(events["event_date"]).dt.date))
    external = external_events[
        [
            (str(row["symbol"]), pd.to_datetime(row["event_date"]).date()) not in existing_keys
            for _, row in external_events.iterrows()
        ]
    ]
    if external.empty:
        return events
    combined = pd.concat([events, external], ignore_index=True, sort=False)
    return combined.sort_values(["event_date", "symbol"]).reset_index(drop=True)


def _latest_model_run(conn: psycopg.Connection[Any]) -> tuple[str, str]:
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT model_run_id, model_path
            FROM lb_limit_up_model_runs
            ORDER BY trained_at DESC
            LIMIT 1
            """
        )
        row = cur.fetchone()
    if not row:
        raise ValueError("No limit-up model run found. Run train-limit-up-model first.")
    return str(row[0]), str(row[1])


def _resolve_prediction_date(
    conn: psycopg.Connection[Any],
    event_date: str | date | None,
    *,
    predictions: bool = False,
) -> date | None:
    if event_date:
        return pd.to_datetime(event_date).date()
    return datetime.now(ZoneInfo("Asia/Shanghai")).date() - timedelta(days=1)


def _upsert_limit_up_predictions(
    conn: psycopg.Connection[Any],
    model_run_id: str,
    predictions: pd.DataFrame,
) -> None:
    if predictions.empty:
        return
    with conn.cursor() as cur:
        for row in predictions.to_dict("records"):
            features = {name: _safe_float(row.get(name)) for name in FEATURE_NAMES if name in row}
            cur.execute(
                """
                INSERT INTO lb_limit_up_predictions (
                    model_run_id, symbol, event_date, open_buy_probability, open_buy_score,
                    decision, reason, features, created_at
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, NOW())
                ON CONFLICT (model_run_id, symbol, event_date) DO UPDATE SET
                    open_buy_probability = EXCLUDED.open_buy_probability,
                    open_buy_score = EXCLUDED.open_buy_score,
                    decision = EXCLUDED.decision,
                    reason = EXCLUDED.reason,
                    features = EXCLUDED.features,
                    created_at = NOW()
                """,
                (
                    model_run_id,
                    row["symbol"],
                    row["event_date"],
                    _safe_float(row.get("open_buy_probability")),
                    _safe_float(row.get("open_buy_score")),
                    row.get("decision"),
                    row.get("reason"),
                    Jsonb(_json_ready(features)),
                ),
            )


def _records(frame: pd.DataFrame) -> list[dict[str, Any]]:
    return [_json_ready(row) for row in frame.to_dict("records")]


def _json_ready(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _json_ready(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_json_ready(item) for item in value]
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, (np.bool_, bool)):
        return bool(value)
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        if not math.isfinite(float(value)):
            return None
        return float(value)
    if pd.isna(value):
        return None
    return value


def _safe_float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(number):
        return None
    return number


def _safe_bool(value: Any) -> bool | None:
    if value is None or pd.isna(value):
        return None
    return bool(value)


def _date_string(value: Any) -> str | None:
    if value is None or pd.isna(value):
        return None
    return str(pd.to_datetime(value).date())


def summary_to_dict(summary: Any) -> dict[str, Any]:
    if hasattr(summary, "__dataclass_fields__"):
        return _json_ready(asdict(summary))
    if isinstance(summary, dict):
        return _json_ready(summary)
    payload = dict(vars(summary))
    for name in dir(summary):
        if name.startswith("_") or name in payload:
            continue
        value = getattr(summary, name)
        if not callable(value):
            payload[name] = value
    return _json_ready(payload)

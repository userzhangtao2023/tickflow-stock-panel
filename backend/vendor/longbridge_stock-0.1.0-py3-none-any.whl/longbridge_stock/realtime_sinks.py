from __future__ import annotations

import json
import os
import socket
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Any
from urllib import request
from urllib.parse import quote, urlparse


@dataclass(frozen=True)
class RealtimeSinkConfig:
    sinks: tuple[str, ...]
    clickhouse_url: str
    clickhouse_database: str
    clickhouse_user: str
    clickhouse_password: str
    redis_url: str

    @classmethod
    def from_env(cls) -> "RealtimeSinkConfig":
        raw_sinks = os.getenv("LONGBRIDGE_REALTIME_SINKS", "postgres")
        sinks = tuple(item.strip().lower() for item in raw_sinks.split(",") if item.strip())
        return cls(
            sinks=sinks or ("postgres",),
            clickhouse_url=os.getenv("CLICKHOUSE_URL", "http://127.0.0.1:8123").rstrip("/"),
            clickhouse_database=os.getenv("CLICKHOUSE_DATABASE", "longbridge"),
            clickhouse_user=os.getenv("CLICKHOUSE_USER", "default"),
            clickhouse_password=os.getenv("CLICKHOUSE_PASSWORD", ""),
            redis_url=os.getenv("REDIS_URL", "redis://127.0.0.1:6379/0"),
        )

    @property
    def postgres_enabled(self) -> bool:
        return "postgres" in self.sinks or "pg" in self.sinks

    @property
    def clickhouse_enabled(self) -> bool:
        return "clickhouse" in self.sinks or "ch" in self.sinks

    @property
    def redis_enabled(self) -> bool:
        return "redis" in self.sinks


class RealtimeSinkRouter:
    def __init__(self, config: RealtimeSinkConfig | None = None) -> None:
        self.config = config or RealtimeSinkConfig.from_env()
        self._clickhouse = ClickHouseRealtimeSink(self.config) if self.config.clickhouse_enabled else None
        self._redis = RedisLatestSink(self.config.redis_url) if self.config.redis_enabled else None

    def ensure_schema(self) -> None:
        if self._clickhouse is not None:
            self._clickhouse.ensure_schema()

    def write_quotes(self, rows: list[dict[str, Any]], snapshot_minute: datetime, fetched_at: datetime) -> int:
        if not rows:
            return 0
        if self._clickhouse is not None:
            self._clickhouse.write_quotes(rows, snapshot_minute, fetched_at)
        if self._redis is not None:
            self._redis.write_quotes(rows, snapshot_minute, fetched_at)
        return len(rows)

    def write_capital(
        self,
        row: dict[str, Any],
        payload: dict[str, Any],
        flow_rows: list[dict[str, Any]],
        snapshot_minute: datetime,
        fetched_at: datetime,
    ) -> None:
        if self._clickhouse is not None:
            self._clickhouse.write_capital(row, payload, flow_rows, snapshot_minute, fetched_at)
        if self._redis is not None:
            self._redis.write_capital(row, payload, flow_rows, snapshot_minute, fetched_at)

    def write_intraday_lines(self, rows: list[dict[str, Any]], fetched_at: datetime) -> int:
        if not rows:
            return 0
        if self._clickhouse is not None:
            self._clickhouse.write_intraday_lines(rows, fetched_at)
        return len(rows)

    def write_trades(self, rows: list[dict[str, Any]], fetched_at: datetime) -> int:
        if not rows:
            return 0
        if self._clickhouse is not None:
            self._clickhouse.write_trades(rows, fetched_at)
        return len(rows)

    def write_depth(self, row: dict[str, Any], payload: dict[str, Any], fetched_at: datetime) -> None:
        if self._clickhouse is not None:
            self._clickhouse.write_depth(row, payload, fetched_at)

    def write_profit_predictions(self, rows: list[dict[str, Any]]) -> int:
        if not rows:
            return 0
        if self._clickhouse is not None:
            self._clickhouse.write_profit_predictions(rows)
        return len(rows)

    def write_us_fast_profit_predictions(self, rows: list[dict[str, Any]]) -> int:
        if not rows:
            return 0
        if self._clickhouse is not None:
            self._clickhouse.write_us_fast_profit_predictions(rows)
        return len(rows)


class ClickHouseRealtimeSink:
    def __init__(self, config: RealtimeSinkConfig) -> None:
        self.config = config

    def ensure_schema(self) -> None:
        database = _ident(self.config.clickhouse_database)
        self._execute(f"create database if not exists {database}")
        self._execute(
            f"""
            create table if not exists {database}.lb_realtime_quotes (
              snapshot_minute DateTime64(3, 'Asia/Shanghai'),
              symbol LowCardinality(String),
              market LowCardinality(String),
              last_done Nullable(Float64),
              prev_close Nullable(Float64),
              open Nullable(Float64),
              high Nullable(Float64),
              low Nullable(Float64),
              change_value Nullable(Float64),
              change_percentage Nullable(Float64),
              volume Nullable(Float64),
              turnover Nullable(Float64),
              trade_status LowCardinality(String),
              payload String,
              fetched_at DateTime64(3, 'Asia/Shanghai'),
              inserted_at DateTime64(3, 'Asia/Shanghai') default now64(3)
            )
            engine = MergeTree
            partition by toYYYYMMDD(snapshot_minute)
            order by (market, symbol, snapshot_minute)
            ttl toDateTime(snapshot_minute) + interval 180 day
            """
        )
        self._execute(
            f"""
            create table if not exists {database}.lb_realtime_capital (
              snapshot_minute DateTime64(3, 'Asia/Shanghai'),
              symbol LowCardinality(String),
              market LowCardinality(String),
              large_in Nullable(Float64),
              large_out Nullable(Float64),
              large_net Nullable(Float64),
              medium_in Nullable(Float64),
              medium_out Nullable(Float64),
              medium_net Nullable(Float64),
              small_in Nullable(Float64),
              small_out Nullable(Float64),
              small_net Nullable(Float64),
              total_in Nullable(Float64),
              total_out Nullable(Float64),
              total_net Nullable(Float64),
              large_net_ratio Nullable(Float64),
              small_net_ratio Nullable(Float64),
              provider_timestamp Nullable(DateTime64(3, 'Asia/Shanghai')),
              payload String,
              fetched_at DateTime64(3, 'Asia/Shanghai'),
              inserted_at DateTime64(3, 'Asia/Shanghai') default now64(3)
            )
            engine = MergeTree
            partition by toYYYYMMDD(snapshot_minute)
            order by (market, symbol, snapshot_minute)
            ttl toDateTime(snapshot_minute) + interval 180 day
            """
        )
        self._execute(
            f"""
            create table if not exists {database}.lb_realtime_capital_flow (
              symbol LowCardinality(String),
              market LowCardinality(String),
              flow_time DateTime64(3, 'Asia/Shanghai'),
              inflow Nullable(Float64),
              payload String,
              fetched_at DateTime64(3, 'Asia/Shanghai'),
              inserted_at DateTime64(3, 'Asia/Shanghai') default now64(3)
            )
            engine = MergeTree
            partition by toYYYYMMDD(flow_time)
            order by (market, symbol, flow_time)
            ttl toDateTime(flow_time) + interval 180 day
            """
        )
        self._execute(
            f"""
            create table if not exists {database}.lb_intraday_lines (
              symbol LowCardinality(String),
              market LowCardinality(String),
              line_time DateTime64(3, 'Asia/Shanghai'),
              price Nullable(Float64),
              avg_price Nullable(Float64),
              volume Nullable(Float64),
              turnover Nullable(Float64),
              payload String,
              fetched_at DateTime64(3, 'Asia/Shanghai'),
              updated_at DateTime64(3, 'Asia/Shanghai'),
              inserted_at DateTime64(3, 'Asia/Shanghai') default now64(3)
            )
            engine = MergeTree
            partition by toYYYYMMDD(line_time)
            order by (market, symbol, line_time)
            """
        )
        self._execute(
            f"""
            create table if not exists {database}.lb_realtime_trades (
              symbol LowCardinality(String),
              market LowCardinality(String),
              trade_time DateTime64(3, 'Asia/Shanghai'),
              price Nullable(Float64),
              volume Nullable(Float64),
              trade_type LowCardinality(String),
              direction LowCardinality(String),
              trade_session LowCardinality(String),
              payload String,
              fetched_at DateTime64(3, 'Asia/Shanghai'),
              updated_at DateTime64(3, 'Asia/Shanghai'),
              inserted_at DateTime64(3, 'Asia/Shanghai') default now64(3)
            )
            engine = MergeTree
            partition by toYYYYMMDD(trade_time)
            order by (market, symbol, trade_time)
            """
        )
        self._execute(
            f"""
            create table if not exists {database}.lb_realtime_depth (
              snapshot_minute DateTime64(3, 'Asia/Shanghai'),
              symbol LowCardinality(String),
              market LowCardinality(String),
              bid_volume Nullable(Float64),
              ask_volume Nullable(Float64),
              bid_order_count Nullable(Float64),
              ask_order_count Nullable(Float64),
              imbalance Nullable(Float64),
              payload String,
              fetched_at DateTime64(3, 'Asia/Shanghai'),
              updated_at DateTime64(3, 'Asia/Shanghai'),
              inserted_at DateTime64(3, 'Asia/Shanghai') default now64(3)
            )
            engine = MergeTree
            partition by toYYYYMMDD(snapshot_minute)
            order by (market, symbol, snapshot_minute)
            """
        )
        self._execute(
            f"""
            create table if not exists {database}.lb_realtime_profit_predictions (
              model_run_id String,
              predicted_at DateTime64(3, 'Asia/Shanghai'),
              symbol LowCardinality(String),
              market LowCardinality(String),
              name String,
              horizon_minutes UInt16,
              target_return Nullable(Float64),
              entry_price Nullable(Float64),
              profit_probability Nullable(Float64),
              expected_return Nullable(Float64),
              risk_score Nullable(Float64),
              decision LowCardinality(String),
              validation_due_at Nullable(DateTime64(3, 'Asia/Shanghai')),
              feature_snapshot String,
              inserted_at DateTime64(3, 'Asia/Shanghai') default now64(3)
            )
            engine = ReplacingMergeTree(inserted_at)
            partition by toYYYYMMDD(predicted_at)
            order by (market, model_run_id, symbol, predicted_at, horizon_minutes)
            ttl toDateTime(predicted_at) + interval 180 day
            """
        )
        self._execute(
            f"""
            create table if not exists {database}.lb_us_fast_profit_predictions (
              model_run_id String,
              predicted_at DateTime64(3, 'Asia/Shanghai'),
              symbol LowCardinality(String),
              market LowCardinality(String),
              name String,
              horizon_minutes UInt16,
              target_return Nullable(Float64),
              entry_price Nullable(Float64),
              profit_probability Nullable(Float64),
              expected_return Nullable(Float64),
              risk_score Nullable(Float64),
              decision LowCardinality(String),
              validation_due_at Nullable(DateTime64(3, 'Asia/Shanghai')),
              feature_snapshot String,
              inserted_at DateTime64(3, 'Asia/Shanghai') default now64(3)
            )
            engine = ReplacingMergeTree(inserted_at)
            partition by toYYYYMMDD(predicted_at)
            order by (model_run_id, symbol, predicted_at, horizon_minutes)
            ttl toDateTime(predicted_at) + interval 180 day
            """
        )

    def write_quotes(self, rows: list[dict[str, Any]], snapshot_minute: datetime, fetched_at: datetime) -> None:
        documents = []
        for row in rows:
            symbol = str(row.get("symbol") or "")
            if not symbol:
                continue
            last_done = _num(row.get("last") or row.get("last_done"))
            prev_close = _num(row.get("prev_close") or row.get("prev_close_price"))
            documents.append(
                {
                    "snapshot_minute": _dt(snapshot_minute),
                    "symbol": symbol,
                    "market": _market_from_symbol(symbol),
                    "last_done": last_done,
                    "prev_close": prev_close,
                    "open": _num(row.get("open")),
                    "high": _num(row.get("high")),
                    "low": _num(row.get("low")),
                    "change_value": _num(row.get("change_value")),
                    "change_percentage": _change_pct(row.get("change_percentage"), last_done, prev_close),
                    "volume": _num(row.get("volume")),
                    "turnover": _num(row.get("turnover")),
                    "trade_status": str(row.get("status") or row.get("trade_status") or ""),
                    "payload": json.dumps(row, ensure_ascii=False, default=_json_default),
                    "fetched_at": _dt(fetched_at),
                }
            )
        self._insert_json_each_row("lb_realtime_quotes", documents)

    def write_capital(
        self,
        row: dict[str, Any],
        payload: dict[str, Any],
        flow_rows: list[dict[str, Any]],
        snapshot_minute: datetime,
        fetched_at: datetime,
    ) -> None:
        self._insert_json_each_row(
            "lb_realtime_capital",
            [
                {
                    "snapshot_minute": _dt(snapshot_minute),
                    "symbol": row["symbol"],
                    "market": row["market"],
                    "large_in": _num(row.get("large_in")),
                    "large_out": _num(row.get("large_out")),
                    "large_net": _num(row.get("large_net")),
                    "medium_in": _num(row.get("medium_in")),
                    "medium_out": _num(row.get("medium_out")),
                    "medium_net": _num(row.get("medium_net")),
                    "small_in": _num(row.get("small_in")),
                    "small_out": _num(row.get("small_out")),
                    "small_net": _num(row.get("small_net")),
                    "total_in": _num(row.get("total_in")),
                    "total_out": _num(row.get("total_out")),
                    "total_net": _num(row.get("total_net")),
                    "large_net_ratio": _num(row.get("large_net_ratio")),
                    "small_net_ratio": _num(row.get("small_net_ratio")),
                    "provider_timestamp": _dt_or_none(row.get("provider_timestamp")),
                    "payload": json.dumps(payload, ensure_ascii=False, default=_json_default),
                    "fetched_at": _dt(fetched_at),
                }
            ],
        )
        self._insert_json_each_row(
            "lb_realtime_capital_flow",
            [
                {
                    "symbol": flow["symbol"],
                    "market": flow["market"],
                    "flow_time": _dt(flow["flow_time"]),
                    "inflow": _num(flow.get("inflow")),
                    "payload": json.dumps(flow.get("payload") or {}, ensure_ascii=False, default=_json_default),
                    "fetched_at": _dt(fetched_at),
                }
                for flow in flow_rows
            ],
        )

    def write_intraday_lines(self, rows: list[dict[str, Any]], fetched_at: datetime) -> None:
        self._insert_json_each_row(
            "lb_intraday_lines",
            [
                {
                    "symbol": row["symbol"],
                    "market": row["market"],
                    "line_time": _dt(row["line_time"]),
                    "price": _num(row.get("price")),
                    "avg_price": _num(row.get("avg_price")),
                    "volume": _num(row.get("volume")),
                    "turnover": _num(row.get("turnover")),
                    "payload": json.dumps(row.get("payload") or {}, ensure_ascii=False, default=_json_default),
                    "fetched_at": _dt(fetched_at),
                    "updated_at": _dt(fetched_at),
                }
                for row in rows
            ],
        )

    def write_trades(self, rows: list[dict[str, Any]], fetched_at: datetime) -> None:
        self._insert_json_each_row(
            "lb_realtime_trades",
            [
                {
                    "symbol": row["symbol"],
                    "market": row["market"],
                    "trade_time": _dt(row["trade_time"]),
                    "price": _num(row.get("price")),
                    "volume": _num(row.get("volume")),
                    "trade_type": str(row.get("trade_type") or ""),
                    "direction": str(row.get("direction") or ""),
                    "trade_session": str(row.get("trade_session") or ""),
                    "payload": json.dumps(row.get("payload") or {}, ensure_ascii=False, default=_json_default),
                    "fetched_at": _dt(fetched_at),
                    "updated_at": _dt(fetched_at),
                }
                for row in rows
            ],
        )

    def write_depth(self, row: dict[str, Any], payload: dict[str, Any], fetched_at: datetime) -> None:
        self._insert_json_each_row(
            "lb_realtime_depth",
            [
                {
                    "snapshot_minute": _dt(row["snapshot_minute"]),
                    "symbol": row["symbol"],
                    "market": row["market"],
                    "bid_volume": _num(row.get("bid_volume")),
                    "ask_volume": _num(row.get("ask_volume")),
                    "bid_order_count": _num(row.get("bid_order_count")),
                    "ask_order_count": _num(row.get("ask_order_count")),
                    "imbalance": _num(row.get("imbalance")),
                    "payload": json.dumps(payload, ensure_ascii=False, default=_json_default),
                    "fetched_at": _dt(fetched_at),
                    "updated_at": _dt(fetched_at),
                }
            ],
        )

    def write_profit_predictions(self, rows: list[dict[str, Any]]) -> None:
        self._write_profit_predictions("lb_realtime_profit_predictions", rows)

    def write_us_fast_profit_predictions(self, rows: list[dict[str, Any]]) -> None:
        self._write_profit_predictions("lb_us_fast_profit_predictions", rows)

    def _write_profit_predictions(self, table: str, rows: list[dict[str, Any]]) -> None:
        self._insert_json_each_row(
            table,
            [
                {
                    "model_run_id": str(row.get("model_run_id") or ""),
                    "predicted_at": _dt(row.get("predicted_at")),
                    "symbol": str(row.get("symbol") or ""),
                    "market": str(row.get("market") or "").lower(),
                    "name": str(row.get("name") or ""),
                    "horizon_minutes": int(row.get("horizon_minutes") or 0),
                    "target_return": _num(row.get("target_return")),
                    "entry_price": _num(row.get("entry_price")),
                    "profit_probability": _num(row.get("profit_probability")),
                    "expected_return": _num(row.get("expected_return")),
                    "risk_score": _num(row.get("risk_score")),
                    "decision": str(row.get("decision") or ""),
                    "validation_due_at": _dt_or_none(row.get("validation_due_at")),
                    "feature_snapshot": json.dumps(row.get("feature_snapshot") or {}, ensure_ascii=False, default=_json_default),
                }
                for row in rows
                if row.get("model_run_id") and row.get("predicted_at") and row.get("symbol")
            ],
        )

    def _insert_json_each_row(self, table: str, documents: list[dict[str, Any]]) -> None:
        if not documents:
            return
        database = _ident(self.config.clickhouse_database)
        payload = "\n".join(json.dumps(document, ensure_ascii=False) for document in documents).encode("utf-8")
        self._execute(f"insert into {database}.{_ident(table)} format JSONEachRow", payload=payload)

    def _execute(self, sql: str, payload: bytes | None = None) -> None:
        url = f"{self.config.clickhouse_url}/?query={quote(sql)}"
        req = request.Request(url, data=payload, method="POST")
        if self.config.clickhouse_user:
            req.add_header("X-ClickHouse-User", self.config.clickhouse_user)
        if self.config.clickhouse_password:
            req.add_header("X-ClickHouse-Key", self.config.clickhouse_password)
        with request.urlopen(req, timeout=10) as response:
            response.read()


class RedisLatestSink:
    def __init__(self, redis_url: str) -> None:
        parsed = urlparse(redis_url)
        self.host = parsed.hostname or "127.0.0.1"
        self.port = parsed.port or 6379
        self.db = int((parsed.path or "/0").strip("/") or "0")

    def write_quotes(self, rows: list[dict[str, Any]], snapshot_minute: datetime, fetched_at: datetime) -> None:
        commands: list[tuple[str, ...]] = []
        for row in rows:
            symbol = str(row.get("symbol") or "")
            if not symbol:
                continue
            key = f"lb:latest:quote:{symbol}"
            document = dict(row)
            document["snapshot_minute"] = _dt(snapshot_minute)
            document["fetched_at"] = _dt(fetched_at)
            commands.extend(
                [
                    ("SET", key, json.dumps(document, ensure_ascii=False, default=_json_default)),
                    ("SADD", f"lb:latest:quote:symbols:{_market_from_symbol(symbol)}", symbol),
                ]
            )
        self._pipeline(commands)

    def write_capital(
        self,
        row: dict[str, Any],
        payload: dict[str, Any],
        flow_rows: list[dict[str, Any]],
        snapshot_minute: datetime,
        fetched_at: datetime,
    ) -> None:
        document = {
            **row,
            "snapshot_minute": _dt(snapshot_minute),
            "payload": payload,
            "fetched_at": _dt(fetched_at),
        }
        commands = [
            ("SET", f"lb:latest:capital:{row['symbol']}", json.dumps(document, ensure_ascii=False, default=_json_default)),
            ("SADD", f"lb:latest:capital:symbols:{row['market']}", row["symbol"]),
        ]
        if flow_rows:
            commands.append(
                (
                    "SET",
                    f"lb:latest:capital_flow:{row['symbol']}",
                    json.dumps(flow_rows[-1], ensure_ascii=False, default=_json_default),
                )
            )
        self._pipeline(commands)

    def _pipeline(self, commands: list[tuple[str, ...]]) -> None:
        if not commands:
            return
        with socket.create_connection((self.host, self.port), timeout=5) as conn:
            if self.db:
                conn.sendall(_resp(("SELECT", str(self.db))))
                _read_resp(conn)
            for command in commands:
                conn.sendall(_resp(command))
                _read_resp(conn)


def _resp(parts: tuple[str, ...]) -> bytes:
    encoded = [part.encode("utf-8") for part in parts]
    payload = f"*{len(encoded)}\r\n".encode("ascii")
    for item in encoded:
        payload += f"${len(item)}\r\n".encode("ascii") + item + b"\r\n"
    return payload


def _read_resp(conn: socket.socket) -> bytes:
    data = conn.recv(4096)
    if data.startswith(b"-"):
        raise RuntimeError(data.decode("utf-8", errors="replace").strip())
    return data


def _ident(value: str) -> str:
    if not value.replace("_", "").isalnum():
        raise ValueError(f"unsafe ClickHouse identifier: {value!r}")
    return value


def _market_from_symbol(symbol: str) -> str:
    suffix = symbol.rsplit(".", 1)[-1].lower() if "." in symbol else ""
    if suffix in {"sh", "sz"}:
        return "cn"
    return suffix


def _num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _change_pct(value: Any, last_done: float | None, prev_close: float | None) -> float | None:
    parsed = _num(value)
    if parsed is not None:
        return parsed
    if last_done is None or prev_close in (None, 0):
        return None
    return round((last_done - prev_close) / prev_close * 100, 4)


def _dt(value: Any) -> str:
    if isinstance(value, datetime):
        return value.isoformat()
    return str(value)


def _dt_or_none(value: Any) -> str | None:
    if value is None:
        return None
    return _dt(value)


def _json_default(value: Any) -> Any:
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, Decimal):
        return float(value)
    return str(value)

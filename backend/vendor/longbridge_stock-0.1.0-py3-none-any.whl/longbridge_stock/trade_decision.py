from __future__ import annotations

from dataclasses import dataclass
from typing import Any


SUPPORTIVE_CAPITAL = {"强流入", "温和流入", "大单承接"}
BLOCK_BUY_CAPITAL = {"大单流出", "加速流出"}
SUPPORTIVE_SHAPES = {"回踩承接", "突破确认", "强趋势延续"}
BLOCK_BUY_SHAPES = {"冲高衰竭", "趋势转弱"}


@dataclass(frozen=True)
class RuleDecision:
    action: str
    label: str
    allow_buy: bool
    risk_alert: bool
    capital_status: str
    reasons: list[str]

    def to_dict(self) -> dict[str, Any]:
        return {
            "action": self.action,
            "label": self.label,
            "allow_buy": self.allow_buy,
            "risk_alert": self.risk_alert,
            "capital_status": self.capital_status,
            "reasons": self.reasons,
        }


def classify_capital_status(row: dict[str, Any]) -> str:
    total_net = _num(row.get("total_net"))
    large_net = _num(row.get("large_net"))
    flow_15m = _num(row.get("flow_15m"))
    flow_30m = _num(row.get("flow_30m"))
    large_net_ratio = _num(row.get("large_net_ratio"))

    if total_net < 0 and large_net < 0 and flow_15m < 0 and flow_30m < 0:
        return "加速流出"
    if large_net <= -10_000_000 or (large_net < 0 and flow_30m < 0):
        return "大单流出"
    if total_net < 0 or flow_30m < 0:
        return "温和流出"
    if total_net > 0 and large_net < 0:
        return "资金分歧"
    if total_net < 0 and large_net > 0:
        return "大单承接"
    if total_net >= 30_000_000 and large_net >= 10_000_000 and flow_30m >= 0:
        return "强流入"
    if large_net > 0 and (total_net >= 0 or flow_30m >= 0):
        return "大单承接"
    if total_net > 0 or flow_30m > 0 or large_net_ratio > 0:
        return "温和流入"
    return "无明显资金"


def build_rule_decision(
    *,
    is_holding: bool,
    trigger_event: str | None,
    shape: dict[str, Any] | None,
    quote: dict[str, Any],
) -> RuleDecision:
    capital_status = classify_capital_status(quote)
    shape_label = str((shape or {}).get("label") or "")
    shape_action = str((quote.get("intraday_shape") or {}).get("action") or "")
    reasons: list[str] = []

    if shape_label:
        reasons.append(f"盘中形态 {shape_label}")
    reasons.append(f"资金状态 {capital_status}")

    if is_holding and (shape_label in BLOCK_BUY_SHAPES or shape_action == "block_buy") and capital_status in BLOCK_BUY_CAPITAL | {"温和流出"}:
        reasons.append("持仓股形态与资金同时转弱")
        return RuleDecision("sell_risk", "持仓风险", False, True, capital_status, reasons)

    if trigger_event in {"buy_zone", "breakout"}:
        if shape_label in BLOCK_BUY_SHAPES or shape_action == "block_buy":
            reasons.append("形态不支持买入")
            return RuleDecision("block_buy", "不买", False, False, capital_status, reasons)
        if capital_status in BLOCK_BUY_CAPITAL:
            reasons.append("资金不支持买入")
            return RuleDecision("block_buy", "不买", False, False, capital_status, reasons)
        if shape_label in SUPPORTIVE_SHAPES and capital_status in SUPPORTIVE_CAPITAL:
            label = "可小仓低吸" if trigger_event == "buy_zone" else "突破跟随"
            reasons.append("模型、形态、资金满足确认")
            return RuleDecision(trigger_event, label, True, False, capital_status, reasons)
        reasons.append("形态或资金未形成三重确认")
        return RuleDecision("watch", "观察", False, False, capital_status, reasons)

    return RuleDecision("watch", "观察", False, False, capital_status, reasons)


def decision_summary(decision: RuleDecision) -> str:
    reason = "；".join(decision.reasons[:3])
    return f"{decision.label}；{reason}"


def _num(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0

from __future__ import annotations

from dataclasses import dataclass
from statistics import median
from typing import Any

import pandas as pd

from longbridge_stock.pattern_fingerprint import (
    PatternFingerprintConfig,
    build_pattern_windows,
    find_similar_patterns,
    summarize_match_outcomes,
)


@dataclass(frozen=True)
class StockPatternLibraryConfig:
    window_days: int = 40
    forward_days: tuple[int, ...] = (5, 10, 20)
    path_samples: int = 8
    scoring_horizon: int = 20
    top_matches: int = 30
    min_match_count: int = 5
    min_close: float = 2.0
    min_turnover: float = 5_000_000.0
    up_threshold: float = 0.08
    down_threshold: float = -0.08
    fingerprint_version: str = "daily_v1"


def build_stock_pattern_library(
    frame: pd.DataFrame,
    config: StockPatternLibraryConfig | None = None,
) -> pd.DataFrame:
    cfg = config or StockPatternLibraryConfig()
    windows = build_pattern_windows(
        frame,
        PatternFingerprintConfig(
            window_days=cfg.window_days,
            forward_days=cfg.forward_days,
            path_samples=cfg.path_samples,
            min_history_days=cfg.window_days,
        ),
    )
    if windows.empty:
        return windows
    output = windows.copy()
    output.insert(1, "market", output["symbol"].map(infer_market))
    output.insert(2, "fingerprint_version", cfg.fingerprint_version)
    latest_turnover = _latest_turnover_by_key(frame)
    output["latest_turnover"] = [
        latest_turnover.get((str(row["symbol"]), str(row["end_date"])), None)
        for row in output[["symbol", "end_date"]].to_dict("records")
    ]
    return output


def screen_pattern_potential(
    library: pd.DataFrame,
    config: StockPatternLibraryConfig | None = None,
    *,
    as_of: str | None = None,
    market: str | None = None,
) -> dict[str, Any]:
    cfg = config or StockPatternLibraryConfig()
    data = _prepare_library(library)
    if data.empty:
        return _empty_report()
    if market and market != "all":
        data = data[data["market"].astype(str).str.lower() == market.lower()]
    if as_of:
        data = data[data["end_date"].astype(str) <= as_of]
    if data.empty:
        return _empty_report()

    latest = _latest_rows(data)
    candidates = [_score_latest_row(row, data, cfg) for row in latest.to_dict("records")]
    candidates = [candidate for candidate in candidates if candidate is not None]
    pools = {"trend_pool": [], "rebound_pool": [], "anomaly_pool": [], "avoid_pool": []}
    for candidate in candidates:
        pools[f"{candidate['pool']}_pool"].append(candidate)
    for rows in pools.values():
        rows.sort(key=lambda item: item["score"], reverse=True)
    scan_date = str(latest["end_date"].max()) if not latest.empty else None
    return {
        "summary": {
            "scan_date": scan_date,
            "symbol_count": int(latest["symbol"].nunique()) if not latest.empty else 0,
            "candidate_count": len(candidates),
            "trend_pool_count": len(pools["trend_pool"]),
            "rebound_pool_count": len(pools["rebound_pool"]),
            "anomaly_pool_count": len(pools["anomaly_pool"]),
            "avoid_pool_count": len(pools["avoid_pool"]),
        },
        **pools,
    }


def format_candidate_report(report: dict[str, Any], *, limit: int = 10) -> str:
    summary = report.get("summary") or {}
    lines = [
        f"stock pattern potential {summary.get('scan_date') or '-'} candidates={summary.get('candidate_count') or 0}",
    ]
    for pool_name in ("trend_pool", "rebound_pool", "anomaly_pool", "avoid_pool"):
        rows = list(report.get(pool_name) or [])[:limit]
        lines.append(f"[{pool_name}]")
        if not rows:
            lines.append("-")
            continue
        lines.append("symbol score type up max_return max_dd matches")
        for row in rows:
            horizon = row.get("scoring_horizon") or 20
            lines.append(
                " ".join(
                    str(value)
                    for value in [
                        row.get("symbol"),
                        row.get("score"),
                        row.get("pattern_type"),
                        row.get(f"up_probability_{horizon}d"),
                        row.get(f"median_max_return_{horizon}d"),
                        row.get(f"median_max_drawdown_{horizon}d"),
                        row.get("match_count"),
                    ]
                )
            )
    return "\n".join(lines)


def infer_market(symbol: Any) -> str:
    value = str(symbol).upper()
    if value.endswith(".US"):
        return "us"
    if value.endswith(".HK"):
        return "hk"
    if value.endswith(".SH") or value.endswith(".SZ"):
        return "cn"
    return "unknown"


def _score_latest_row(row: dict[str, Any], library: pd.DataFrame, cfg: StockPatternLibraryConfig) -> dict[str, Any] | None:
    historical = library[library["end_date"].astype(str) < str(row.get("end_date"))]
    if historical.empty:
        return None
    matches = find_similar_patterns(row, historical, top_n=cfg.top_matches, exclude_same_symbol=True)
    if not matches:
        return None
    summary = summarize_match_outcomes(
        matches,
        forward_days=cfg.forward_days,
        up_threshold=cfg.up_threshold,
        down_threshold=cfg.down_threshold,
    )
    horizon_key = f"{cfg.scoring_horizon}d"
    horizon = summary.get("horizons", {}).get(horizon_key, {})
    match_count = int(horizon.get("sample_count") or summary.get("match_count") or 0)
    up_prob = _num(horizon.get("up_probability")) or 0.0
    down_prob = _num(horizon.get("down_probability")) or 0.0
    median_max_return = _num(horizon.get("median_max_return")) or 0.0
    median_max_drawdown = _num(horizon.get("median_max_drawdown")) or 0.0
    score = _candidate_score(
        up_prob=up_prob,
        down_prob=down_prob,
        median_max_return=median_max_return,
        median_max_drawdown=median_max_drawdown,
        match_count=match_count,
        pattern_type=str(row.get("pattern_type") or ""),
        cfg=cfg,
    )
    risk_flags = _risk_flags(row, match_count, cfg)
    reasons = _reasons(row, up_prob, down_prob, median_max_return, median_max_drawdown, match_count, cfg)
    pool = _pool_name(
        pattern_type=str(row.get("pattern_type") or ""),
        score=score,
        up_prob=up_prob,
        down_prob=down_prob,
        median_max_drawdown=median_max_drawdown,
        risk_flags=risk_flags,
        cfg=cfg,
    )
    return {
        "symbol": row.get("symbol"),
        "market": row.get("market") or infer_market(row.get("symbol")),
        "scan_date": row.get("end_date"),
        "pool": pool,
        "score": _round(score),
        "pattern_type": row.get("pattern_type"),
        "latest_close": _round(row.get("latest_close")),
        "latest_turnover": _round(row.get("latest_turnover")),
        "return_total": _round(row.get("return_total")),
        "max_drawdown": _round(row.get("max_drawdown")),
        "volume_ratio": _round(row.get("volume_ratio")),
        "match_count": match_count,
        f"up_probability_{cfg.scoring_horizon}d": _round(up_prob),
        f"down_probability_{cfg.scoring_horizon}d": _round(down_prob),
        f"median_max_return_{cfg.scoring_horizon}d": _round(median_max_return),
        f"median_max_drawdown_{cfg.scoring_horizon}d": _round(median_max_drawdown),
        f"median_final_return_{cfg.scoring_horizon}d": _round(horizon.get("median_final_return")),
        "scoring_horizon": cfg.scoring_horizon,
        "reasons": reasons,
        "risk_flags": risk_flags,
        "top_matches": matches[:5],
    }


def _candidate_score(
    *,
    up_prob: float,
    down_prob: float,
    median_max_return: float,
    median_max_drawdown: float,
    match_count: int,
    pattern_type: str,
    cfg: StockPatternLibraryConfig,
) -> float:
    score = 0.0
    score += up_prob * 45.0
    score += max(0.0, min(0.35, median_max_return)) / 0.35 * 30.0
    score += max(0.0, min(0.15, 0.15 + median_max_drawdown)) / 0.15 * 15.0
    score += min(match_count, cfg.top_matches) / max(cfg.top_matches, 1) * 10.0
    score -= down_prob * 25.0
    if pattern_type == "trend_run":
        score += 8.0
    elif pattern_type in {"rebound", "washout"}:
        score += 5.0
    elif pattern_type == "breakdown":
        score -= 15.0
    return max(0.0, min(100.0, score))


def _pool_name(
    *,
    pattern_type: str,
    score: float,
    up_prob: float,
    down_prob: float,
    median_max_drawdown: float,
    risk_flags: list[str],
    cfg: StockPatternLibraryConfig,
) -> str:
    if risk_flags and score >= 45.0:
        return "anomaly"
    if down_prob >= 0.5 or median_max_drawdown <= cfg.down_threshold or score < 35.0:
        return "avoid"
    if pattern_type in {"rebound", "washout"} and up_prob >= 0.45:
        return "rebound"
    if pattern_type == "trend_run" and up_prob >= 0.45:
        return "trend"
    if score >= 60.0:
        return "trend"
    return "avoid"


def _risk_flags(row: dict[str, Any], match_count: int, cfg: StockPatternLibraryConfig) -> list[str]:
    flags: list[str] = []
    if (_num(row.get("latest_close")) or 0.0) < cfg.min_close:
        flags.append("risk_low_price")
    turnover = _num(row.get("latest_turnover"))
    if turnover is not None and turnover < cfg.min_turnover:
        flags.append("risk_low_turnover")
    if (_num(row.get("return_total")) or 0.0) >= 0.8:
        flags.append("risk_extreme_run")
    if match_count < cfg.min_match_count:
        flags.append("risk_low_match_count")
    return flags


def _reasons(
    row: dict[str, Any],
    up_prob: float,
    down_prob: float,
    median_max_return: float,
    median_max_drawdown: float,
    match_count: int,
    cfg: StockPatternLibraryConfig,
) -> list[str]:
    reasons: list[str] = []
    if up_prob >= 0.6:
        reasons.append("historical_up_probability_high")
    elif up_prob >= 0.45:
        reasons.append("historical_up_probability_ok")
    if down_prob <= 0.25:
        reasons.append("historical_down_probability_low")
    if median_max_return >= cfg.up_threshold:
        reasons.append("historical_median_upside_ok")
    if median_max_drawdown > cfg.down_threshold:
        reasons.append("historical_drawdown_controlled")
    if match_count >= cfg.min_match_count:
        reasons.append("match_sample_ok")
    if row.get("pattern_type"):
        reasons.append(f"pattern_{row.get('pattern_type')}")
    return reasons


def _prepare_library(library: pd.DataFrame) -> pd.DataFrame:
    data = library.copy()
    if data.empty:
        return data
    if "market" not in data.columns:
        data["market"] = data["symbol"].map(infer_market)
    if "latest_turnover" not in data.columns:
        data["latest_turnover"] = None
    data["end_date"] = pd.to_datetime(data["end_date"], errors="coerce").dt.date.astype(str)
    return data.dropna(subset=["symbol", "end_date"]).sort_values(["symbol", "end_date"]).reset_index(drop=True)


def _latest_rows(data: pd.DataFrame) -> pd.DataFrame:
    if "scan_target" in data.columns:
        targets = data[data["scan_target"].map(_truthy)]
        return targets.sort_values(["symbol", "end_date"]).groupby("symbol", as_index=False, sort=False).tail(1).reset_index(drop=True)
    return data.sort_values(["symbol", "end_date"]).groupby("symbol", as_index=False, sort=False).tail(1).reset_index(drop=True)


def _latest_turnover_by_key(frame: pd.DataFrame) -> dict[tuple[str, str], float | None]:
    if frame.empty or "turnover" not in frame.columns:
        return {}
    data = frame.copy()
    data["trade_date"] = pd.to_datetime(data["trade_date"], errors="coerce").dt.date.astype(str)
    data["turnover"] = pd.to_numeric(data["turnover"], errors="coerce")
    output: dict[tuple[str, str], float | None] = {}
    for row in data[["symbol", "trade_date", "turnover"]].to_dict("records"):
        output[(str(row["symbol"]), str(row["trade_date"]))] = _num(row.get("turnover"))
    return output


def _empty_report() -> dict[str, Any]:
    return {
        "summary": {
            "scan_date": None,
            "symbol_count": 0,
            "candidate_count": 0,
            "trend_pool_count": 0,
            "rebound_pool_count": 0,
            "anomaly_pool_count": 0,
            "avoid_pool_count": 0,
        },
        "trend_pool": [],
        "rebound_pool": [],
        "anomaly_pool": [],
        "avoid_pool": [],
    }


def _num(value: Any) -> float | None:
    if value is None or pd.isna(value):
        return None
    return float(value)


def _truthy(value: Any) -> bool:
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "t", "yes", "y"}
    return bool(value)


def _round(value: Any, digits: int = 4) -> float | None:
    number = _num(value)
    return round(number, digits) if number is not None else None

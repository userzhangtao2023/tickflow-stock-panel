from __future__ import annotations

import time
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from typing import Any, Iterable

import pandas as pd
import psycopg

from longbridge_stock.postgres_store import LongbridgePostgresStore


# Adapted from HKUDS/Vibe-Trading's MIT-licensed AKShare loader.
# We keep this intentionally small: A-share and listed ETF/LOF daily bars only.

_INTERVAL_MAP_DAILY = {"1D": "daily", "1W": "weekly", "1M": "monthly"}
_ETF_PREFIXES = frozenset({"15", "16", "50", "51", "52", "56", "58"})


@dataclass(frozen=True)
class AkshareSyncSummary:
    source: str
    requested: int
    fetched: int
    written: int
    failed: int
    start_date: str
    end_date: str
    elapsed_seconds: float
    errors: list[dict[str, str]]

    def to_dict(self) -> dict[str, Any]:
        return {
            "source": self.source,
            "requested": self.requested,
            "fetched": self.fetched,
            "written": self.written,
            "failed": self.failed,
            "startDate": self.start_date,
            "endDate": self.end_date,
            "elapsedSeconds": round(self.elapsed_seconds, 3),
            "errors": self.errors,
        }


class AkshareDailyBarProvider:
    source = "akshare"

    def __init__(self, ak_module: Any | None = None) -> None:
        self._ak = ak_module

    def fetch(
        self,
        symbols: Iterable[str],
        start_date: str,
        end_date: str,
        *,
        interval: str = "1D",
        adjust: str = "qfq",
    ) -> dict[str, list[dict[str, Any]]]:
        _validate_date_range(start_date, end_date)
        ak = self._ak or _import_akshare()
        result: dict[str, list[dict[str, Any]]] = {}
        for symbol in symbols:
            normalized = _normalize_symbol(symbol)
            frame = self.fetch_one(ak, normalized, start_date, end_date, interval=interval, adjust=adjust)
            if frame is not None and not frame.empty:
                result[normalized] = _frame_to_payload(frame, normalized, self.source)
        return result

    def fetch_one(
        self,
        ak: Any,
        symbol: str,
        start_date: str,
        end_date: str,
        *,
        interval: str = "1D",
        adjust: str = "qfq",
    ) -> pd.DataFrame | None:
        if _is_listed_etf(symbol):
            return self._fetch_etf(ak, symbol, start_date, end_date)
        if not _is_cn_symbol(symbol):
            raise ValueError(f"AKShare supplemental sync only supports A-share symbols for now: {symbol}")
        return self._fetch_a_share(ak, symbol, start_date, end_date, interval=interval, adjust=adjust)

    def _fetch_a_share(
        self,
        ak: Any,
        symbol: str,
        start_date: str,
        end_date: str,
        *,
        interval: str,
        adjust: str,
    ) -> pd.DataFrame | None:
        period = _INTERVAL_MAP_DAILY.get(interval, "daily")
        code = symbol.split(".")[0]
        errors: list[Exception] = []
        try:
            frame = ak.stock_zh_a_hist(
                symbol=code,
                period=period,
                start_date=start_date.replace("-", ""),
                end_date=end_date.replace("-", ""),
                adjust=adjust,
            )
            normalized = _normalize_akshare_frame(frame, date_col="日期")
            if normalized is not None and not normalized.empty:
                return normalized
        except Exception as exc:
            errors.append(exc)

        if interval == "1D":
            try:
                frame = ak.stock_zh_a_daily(
                    symbol=_akshare_exchange_symbol(symbol),
                    start_date=start_date.replace("-", ""),
                    end_date=end_date.replace("-", ""),
                    adjust=adjust,
                )
                normalized = _normalize_akshare_frame(frame, date_col="date")
                if normalized is not None and not normalized.empty:
                    return normalized
            except Exception as exc:
                errors.append(exc)

            try:
                frame = ak.stock_zh_a_hist_tx(
                    symbol=_akshare_exchange_symbol(symbol),
                    start_date=start_date.replace("-", ""),
                    end_date=end_date.replace("-", ""),
                    adjust=adjust,
                )
                if frame is not None and "amount" in frame.columns and "volume" not in frame.columns:
                    frame = frame.rename(columns={"amount": "volume"})
                normalized = _normalize_akshare_frame(frame, date_col="date")
                if normalized is not None and not normalized.empty:
                    return normalized
            except Exception as exc:
                errors.append(exc)
        if errors:
            raise RuntimeError("; ".join(str(error) for error in errors[-3:]))
        return None

    def _fetch_etf(self, ak: Any, symbol: str, start_date: str, end_date: str) -> pd.DataFrame | None:
        code, _, suffix = symbol.upper().partition(".")
        frame = ak.fund_etf_hist_sina(symbol=f"{suffix.lower()}{code}")
        normalized = _normalize_akshare_frame(frame, date_col="date")
        if normalized is None:
            return None
        return normalized.loc[start_date:end_date]


class AkshareDailySync:
    def __init__(
        self,
        dsn: str,
        provider: AkshareDailyBarProvider | None = None,
        store: LongbridgePostgresStore | None = None,
    ) -> None:
        self.dsn = dsn
        self.provider = provider or AkshareDailyBarProvider()
        self.store = store or LongbridgePostgresStore(dsn)

    def load_symbols(self, limit: int | None = None) -> list[str]:
        query = """
            select symbol
            from lb_symbols
            where market = 'cn'
              and symbol ~ '^[0-9]{6}\\.(SH|SZ|BJ)$'
            order by symbol
        """
        if limit is not None:
            query += " limit %s"
            params: tuple[Any, ...] = (limit,)
        else:
            params = ()
        with psycopg.connect(self.dsn) as conn:
            rows = conn.execute(query, params).fetchall()
        return [str(row[0]) for row in rows]

    def sync_once(
        self,
        symbols: list[str],
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        interval: str = "1D",
        adjust: str = "qfq",
        merge_to_daily: bool = False,
    ) -> AkshareSyncSummary:
        end_date = end_date or date.today().isoformat()
        start_date = start_date or (date.fromisoformat(end_date) - timedelta(days=370)).isoformat()
        started = time.monotonic()
        fetched_at = _now()
        fetched = 0
        written = 0
        errors: list[dict[str, str]] = []
        for symbol in symbols:
            try:
                payloads = self.provider.fetch([symbol], start_date, end_date, interval=interval, adjust=adjust)
                payload = payloads.get(_normalize_symbol(symbol), [])
                if not payload:
                    continue
                fetched += 1
                if merge_to_daily:
                    self.store.upsert_dataset(_normalize_symbol(symbol), "cn", "kline", payload, fetched_at)
                    written += len(payload)
                else:
                    written += self.store.upsert_external_daily_bars(
                        self.provider.source,
                        _normalize_symbol(symbol),
                        "cn",
                        payload,
                        fetched_at,
                    )
            except Exception as exc:
                errors.append({"symbol": symbol, "error": str(exc)})
        return AkshareSyncSummary(
            source=self.provider.source,
            requested=len(symbols),
            fetched=fetched,
            written=written,
            failed=len(errors),
            start_date=start_date,
            end_date=end_date,
            elapsed_seconds=time.monotonic() - started,
            errors=errors[:20],
        )


def _normalize_akshare_frame(frame: pd.DataFrame | None, *, date_col: str) -> pd.DataFrame | None:
    if frame is None or frame.empty:
        return None
    df = frame.copy()
    if date_col in df.columns:
        df = df.rename(columns={date_col: "trade_date"})
    elif "日期" in df.columns:
        df = df.rename(columns={"日期": "trade_date"})
    elif "date" in df.columns:
        df = df.rename(columns={"date": "trade_date"})
    else:
        return None

    df = df.rename(
        columns={
            "开盘": "open",
            "最高": "high",
            "最低": "low",
            "收盘": "close",
            "成交量": "volume",
            "成交额": "turnover",
            "date": "trade_date",
            "amount": "turnover",
        }
    )
    required = ["trade_date", "open", "high", "low", "close"]
    if any(col not in df.columns for col in required):
        return None
    df["trade_date"] = pd.to_datetime(df["trade_date"])
    df = df.set_index("trade_date").sort_index()
    for col in ["open", "high", "low", "close", "volume", "turnover"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    if "volume" not in df.columns:
        df["volume"] = 0.0
    if "turnover" not in df.columns:
        df["turnover"] = None
    return df[["open", "high", "low", "close", "volume", "turnover"]].dropna(
        subset=["open", "high", "low", "close"]
    )


def _frame_to_payload(frame: pd.DataFrame, symbol: str, source: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for trade_date, row in frame.iterrows():
        rows.append(
            {
                "time": pd.Timestamp(trade_date).date().isoformat(),
                "open": _float_or_none(row.get("open")),
                "high": _float_or_none(row.get("high")),
                "low": _float_or_none(row.get("low")),
                "close": _float_or_none(row.get("close")),
                "volume": _float_or_none(row.get("volume")),
                "turnover": _float_or_none(row.get("turnover")),
                "source": source,
                "symbol": symbol,
            }
        )
    return rows


def _float_or_none(value: Any) -> float | None:
    if pd.isna(value):
        return None
    return float(value)


def _normalize_symbol(symbol: str) -> str:
    return symbol.strip().upper()


def _is_cn_symbol(symbol: str) -> bool:
    return _normalize_symbol(symbol).endswith((".SH", ".SZ", ".BJ"))


def _is_listed_etf(symbol: str) -> bool:
    normalized = _normalize_symbol(symbol)
    if not normalized.endswith((".SH", ".SZ")):
        return False
    code = normalized.split(".")[0]
    return len(code) == 6 and code.isdigit() and code[:2] in _ETF_PREFIXES


def _akshare_exchange_symbol(symbol: str) -> str:
    code, _, suffix = _normalize_symbol(symbol).partition(".")
    if suffix in {"SH", "SZ"}:
        return f"{suffix.lower()}{code}"
    return code


def _validate_date_range(start_date: str, end_date: str) -> None:
    if pd.Timestamp(start_date) > pd.Timestamp(end_date):
        raise ValueError("start_date must be <= end_date")


def _import_akshare() -> Any:
    try:
        import akshare as ak
    except ImportError as exc:
        raise RuntimeError("akshare is not installed; install longbridge-stock[external] or pip install akshare") from exc
    return ak


def _now() -> datetime:
    return datetime.now(timezone.utc).astimezone()

from __future__ import annotations

import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import date, datetime, timezone
from typing import Any
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import psycopg
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb


DEFAULT_DSN = "dbname=longbridge_stock user=alwin host=/var/run/postgresql"
SOURCE = "eastmoney_f10"
DATACENTER_URL = "https://datacenter.eastmoney.com/securities/api/data/v1/get"
ASHARE_BUSINESS_URL = "https://emweb.securities.eastmoney.com/PC_HSF10/BusinessAnalysis/PageAjax"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36"


@dataclass(frozen=True)
class EastmoneyF10Summary:
    source: str
    total: int
    succeeded: int
    failed: int
    written: dict[str, int]
    elapsed_seconds: float
    failures: dict[str, str]

    def to_dict(self) -> dict[str, Any]:
        return {
            "source": self.source,
            "total": self.total,
            "succeeded": self.succeeded,
            "failed": self.failed,
            "written": self.written,
            "elapsedSeconds": round(self.elapsed_seconds, 3),
            "failures": self.failures,
        }


class EastmoneyF10Sync:
    def __init__(
        self,
        dsn: str = DEFAULT_DSN,
        *,
        max_workers: int = 5,
        request_interval_seconds: float = 0.05,
        timeout_seconds: int = 15,
    ) -> None:
        self.dsn = dsn
        self.max_workers = max(1, max_workers)
        self.request_interval_seconds = max(0.0, request_interval_seconds)
        self.timeout_seconds = timeout_seconds

    def sync_once(
        self,
        *,
        markets: list[str] | None = None,
        symbols: list[str] | None = None,
        limit: int | None = None,
    ) -> EastmoneyF10Summary:
        started = time.monotonic()
        self.ensure_tables()
        targets = self.load_symbols(markets=markets, symbols=symbols, limit=limit)
        if not targets:
            return EastmoneyF10Summary(SOURCE, 0, 0, 0, {}, time.monotonic() - started, {})

        rows: list[dict[str, Any]] = []
        failures: dict[str, str] = {}
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {}
            for index, target in enumerate(targets):
                if index and self.request_interval_seconds:
                    time.sleep(self.request_interval_seconds)
                futures[executor.submit(self.fetch_symbol, target)] = target
            for future in as_completed(futures):
                target = futures[future]
                symbol = target["symbol"]
                try:
                    rows.append(future.result())
                except Exception as exc:  # pragma: no cover - network defensive path
                    failures[symbol] = str(exc)[:500]

        written = self.write_results(rows)
        return EastmoneyF10Summary(
            source=SOURCE,
            total=len(targets),
            succeeded=len(rows),
            failed=len(failures),
            written=written,
            elapsed_seconds=time.monotonic() - started,
            failures=failures,
        )

    def ensure_tables(self) -> None:
        with psycopg.connect(self.dsn) as conn:
            conn.execute(
                """
                create table if not exists lb_eastmoney_f10_raw (
                  symbol text not null,
                  market text not null,
                  eastmoney_code text not null,
                  dataset text not null,
                  report_name text not null,
                  payload jsonb not null,
                  fetched_at timestamptz not null,
                  updated_at timestamptz not null default now(),
                  primary key (symbol, dataset, report_name)
                )
                """
            )
            conn.execute(
                """
                create table if not exists lb_eastmoney_f10_profiles (
                  symbol text primary key,
                  market text not null,
                  eastmoney_code text not null,
                  company_name text,
                  company_name_en text,
                  industry text,
                  chairman text,
                  founded_at text,
                  employees numeric,
                  website text,
                  address text,
                  registered_place text,
                  business_scope text,
                  company_profile text,
                  latest_report_date date,
                  payload jsonb,
                  fetched_at timestamptz not null,
                  updated_at timestamptz not null default now()
                )
                """
            )
            conn.execute(
                """
                create table if not exists lb_eastmoney_f10_business_segments (
                  symbol text not null,
                  market text not null,
                  eastmoney_code text not null,
                  report_date date not null,
                  segment_type text not null,
                  segment_name text not null,
                  currency text,
                  revenue numeric,
                  revenue_ratio numeric,
                  cost numeric,
                  cost_ratio numeric,
                  profit numeric,
                  profit_ratio numeric,
                  gross_margin numeric,
                  rank integer,
                  payload jsonb,
                  fetched_at timestamptz not null,
                  updated_at timestamptz not null default now(),
                  primary key (symbol, report_date, segment_type, segment_name)
                )
                """
            )
            conn.execute(
                """
                create table if not exists lb_eastmoney_f10_business_reviews (
                  symbol text not null,
                  market text not null,
                  eastmoney_code text not null,
                  report_date date not null,
                  business_review text,
                  future_expect text,
                  payload jsonb,
                  fetched_at timestamptz not null,
                  updated_at timestamptz not null default now(),
                  primary key (symbol, report_date)
                )
                """
            )
            conn.execute(
                """
                create table if not exists lb_eastmoney_f10_industry_rank (
                  symbol text not null,
                  market text not null,
                  eastmoney_code text not null,
                  report_date date,
                  type_name text not null,
                  peer_symbol text not null,
                  peer_name text,
                  market_cap numeric,
                  revenue numeric,
                  gross_profit numeric,
                  market_cap_rank integer,
                  revenue_rank integer,
                  gross_profit_rank integer,
                  payload jsonb,
                  fetched_at timestamptz not null,
                  updated_at timestamptz not null default now(),
                  primary key (symbol, type_name, peer_symbol)
                )
                """
            )

    def load_symbols(
        self,
        *,
        markets: list[str] | None = None,
        symbols: list[str] | None = None,
        limit: int | None = None,
    ) -> list[dict[str, str]]:
        if symbols:
            rows = [{"symbol": _normalize_symbol(item), "market": _market_from_symbol(item)} for item in symbols]
            return [row for row in rows if row["market"] in {"cn", "hk", "us"}]

        markets = [_normalize_market(item) for item in (markets or ["cn", "hk", "us"])]
        markets = [item for item in markets if item in {"cn", "hk", "us"}]
        params: list[Any] = [markets]
        limit_clause = ""
        if limit:
            limit_clause = " limit %s"
            params.append(limit)
        with psycopg.connect(self.dsn, row_factory=dict_row) as conn:
            records = conn.execute(
                f"""
                with latest as (
                  select distinct on (symbol) symbol, lower(market) as market, trade_date
                  from lb_daily_bars
                  where lower(market) = any(%s)
                  order by symbol, trade_date desc
                )
                select symbol, market
                from latest
                order by market, symbol
                {limit_clause}
                """,
                params,
            ).fetchall()
        return [{"symbol": row["symbol"], "market": row["market"]} for row in records]

    def fetch_symbol(self, target: dict[str, str]) -> dict[str, Any]:
        symbol = target["symbol"]
        market = target["market"]
        eastmoney_code = _eastmoney_code(symbol, market)
        if market == "cn":
            return self._fetch_cn(symbol, market, eastmoney_code)
        if market == "us":
            return self._fetch_us(symbol, market, eastmoney_code)
        if market == "hk":
            return self._fetch_hk(symbol, market, eastmoney_code)
        raise ValueError(f"unsupported market: {market}")

    def _fetch_cn(self, symbol: str, market: str, eastmoney_code: str) -> dict[str, Any]:
        payload = _fetch_json(
            f"{ASHARE_BUSINESS_URL}?{urlencode({'code': eastmoney_code})}",
            timeout_seconds=self.timeout_seconds,
            referer="https://emweb.securities.eastmoney.com/",
        )
        segments = [_cn_segment(row) for row in payload.get("zygcfx") or []]
        reviews = [_cn_review(row) for row in payload.get("jyps") or []]
        profile = {
            "business_scope": _first_text(payload.get("zyfw") or [], "BUSINESS_SCOPE"),
            "latest_report_date": _latest_date([item.get("report_date") for item in segments + reviews]),
            "payload": payload,
        }
        return {
            "symbol": symbol,
            "market": market,
            "eastmoney_code": eastmoney_code,
            "profile": profile,
            "segments": segments,
            "reviews": reviews,
            "industry_rank": [],
            "raw": {"business_analysis": ("PC_HSF10_BusinessAnalysis", payload)},
        }

    def _fetch_us(self, symbol: str, market: str, eastmoney_code: str) -> dict[str, Any]:
        profile_payload = self._datacenter(
            "RPT_USF10_INFO_ORGPROFILE",
            "SECUCODE,SECURITY_CODE,ORG_CODE,SECURITY_INNER_CODE,ORG_NAME,ORG_EN_ABBR,BELONG_INDUSTRY,FOUND_DATE,CHAIRMAN,REG_PLACE,ADDRESS,EMP_NUM,ORG_TEL,ORG_FAX,ORG_EMAIL,ORG_WEB,ORG_PROFILE",
            f'(SECURITY_CODE="{eastmoney_code}")',
            referer="https://emweb.eastmoney.com/",
        )
        profile_row = _first_result(profile_payload)
        secucode = profile_row.get("SECUCODE") or eastmoney_code
        dates_payload = self._datacenter(
            "RPT_USF10_INFO_PRODUCTSTRUCTURE_ENDATE",
            "SECUCODE,REPORT_DATE,NAME",
            f'(SECUCODE="{secucode}")',
            page_size=200,
            sort_types="-1",
            sort_columns="REPORT_DATE",
            referer="https://emweb.eastmoney.com/",
        )
        latest_report_date = _date_only((_first_result(dates_payload) or {}).get("REPORT_DATE"))
        product_payload = region_payload = {"result": {"data": []}}
        if latest_report_date:
            report_filter = f'(SECUCODE="{secucode}")(REPORT_DATE=\'{latest_report_date}\')(IS_TOTAL="0")'
            product_payload = self._datacenter(
                "RPT_USF10_INFO_PRODUCTSTRUCTURE",
                "SECUCODE,SECURITY_CODE,SECURITY_NAME_ABBR,ORG_CODE,REPORT_DATE,CURRENCY,PRODUCT_NAME,MAIN_BUSINESS_INCOME,MBI_RATIO,IS_TOTAL",
                report_filter,
                page_size=200,
                referer="https://emweb.eastmoney.com/",
            )
            region_payload = self._datacenter(
                "RPT_USF10_INFO_REGIONSTRUCTURE",
                "SECUCODE,SECURITY_CODE,SECURITY_NAME_ABBR,ORG_CODE,REPORT_DATE,CURRENCY,REGION_NAME,MAIN_BUSINESS_INCOME,MBI_RATIO,IS_TOTAL",
                report_filter,
                page_size=200,
                referer="https://emweb.eastmoney.com/",
            )
        segments = [_us_segment(row, "product") for row in _result_rows(product_payload)]
        segments.extend(_us_segment(row, "region") for row in _result_rows(region_payload))
        profile = _profile_from_row(profile_row, latest_report_date)
        return {
            "symbol": symbol,
            "market": market,
            "eastmoney_code": secucode,
            "profile": profile,
            "segments": segments,
            "reviews": [],
            "industry_rank": [],
            "raw": {
                "profile": ("RPT_USF10_INFO_ORGPROFILE", profile_payload),
                "report_dates": ("RPT_USF10_INFO_PRODUCTSTRUCTURE_ENDATE", dates_payload),
                "product_structure": ("RPT_USF10_INFO_PRODUCTSTRUCTURE", product_payload),
                "region_structure": ("RPT_USF10_INFO_REGIONSTRUCTURE", region_payload),
            },
        }

    def _fetch_hk(self, symbol: str, market: str, eastmoney_code: str) -> dict[str, Any]:
        profile_payload = self._datacenter(
            "RPT_HKF10_INFO_ORGPROFILE",
            "SECUCODE,SECURITY_CODE,ORG_NAME,ORG_EN_ABBR,BELONG_INDUSTRY,FOUND_DATE,CHAIRMAN,REG_ADDRESS,ADDRESS,YEAR_SETTLE_DAY,EMP_NUM,ORG_TEL,ORG_FAX,ORG_EMAIL,ORG_WEB,ORG_PROFILE,REG_PLACE",
            f'(SECUCODE="{eastmoney_code}")',
            referer="https://emweb.securities.eastmoney.com/",
        )
        business_payload = self._datacenter(
            "RPT_HKF10_ORG_BUSSINESS",
            "SECUCODE,SECURITY_CODE,SECURITY_NAME_ABBR,ORG_CODE,SECURITY_INNER_CODE,REPORT_DATE,BUSINESS_REVIEW,FUTURE_EXPECT",
            f'(SECUCODE="{eastmoney_code}")',
            page_size=9,
            sort_types="-1",
            sort_columns="REPORT_DATE",
            referer="https://emweb.securities.eastmoney.com/",
        )
        indicator_payload = self._datacenter(
            "RPT_HKF10_FN_MAININDICATOR",
            "HKF10_FN_MAININDICATOR_DATA",
            f'(SECUCODE="{eastmoney_code}")',
            page_size=3,
            sort_types="-1",
            sort_columns="STD_REPORT_DATE",
            referer="https://emweb.securities.eastmoney.com/",
        )
        industry_payload = self._datacenter(
            "RPT_PCF10_INDUSTRY_SCALE",
            "SECURITY_CODE,SECUCODE,TYPE_ID,TYPE_TYPE,TYPE_NAME,TYPE_NAME_EN,CORRE_SECURITY_CODE,CORRE_SECUCODE,CORRE_SECURITY_NAME,MAXSTDREPORTDATE,HKSDQMV,HKTOTAL_MARKET_CAP,OPERATE_INCOME,GROSS_PROFIT,HKSDQMV_RANK,HKTOTAL_CAP_RANK,OPERATE_INCOME_RANK,GROSS_PROFIT_RANK",
            f'(SECUCODE="{eastmoney_code}")',
            page_size=50,
            referer="https://emweb.securities.eastmoney.com/",
        )
        latest_report_date = _latest_date([row.get("REPORT_DATE") for row in _result_rows(business_payload)])
        profile = _profile_from_row(_first_result(profile_payload), latest_report_date)
        reviews = [_hk_review(row) for row in _result_rows(business_payload)]
        industry_rank = [_hk_industry_rank(row) for row in _result_rows(industry_payload)]
        return {
            "symbol": symbol,
            "market": market,
            "eastmoney_code": eastmoney_code,
            "profile": profile,
            "segments": [],
            "reviews": reviews,
            "industry_rank": industry_rank,
            "raw": {
                "profile": ("RPT_HKF10_INFO_ORGPROFILE", profile_payload),
                "business": ("RPT_HKF10_ORG_BUSSINESS", business_payload),
                "main_indicator": ("RPT_HKF10_FN_MAININDICATOR", indicator_payload),
                "industry_scale": ("RPT_PCF10_INDUSTRY_SCALE", industry_payload),
            },
        }

    def _datacenter(
        self,
        report_name: str,
        columns: str,
        filter_expr: str,
        *,
        page_size: int = 200,
        sort_types: str = "",
        sort_columns: str = "",
        referer: str,
    ) -> dict[str, Any]:
        params = {
            "reportName": report_name,
            "columns": columns,
            "quoteColumns": "",
            "filter": filter_expr,
            "pageNumber": 1,
            "pageSize": page_size,
            "sortTypes": sort_types,
            "sortColumns": sort_columns,
            "source": "SECURITIES",
            "client": "PC",
        }
        return _fetch_json(
            f"{DATACENTER_URL}?{urlencode(params)}",
            timeout_seconds=self.timeout_seconds,
            referer=referer,
        )

    def write_results(self, rows: list[dict[str, Any]]) -> dict[str, int]:
        counts = {"raw": 0, "profiles": 0, "segments": 0, "reviews": 0, "industryRank": 0}
        fetched_at = datetime.now(timezone.utc)
        with psycopg.connect(self.dsn) as conn:
            for item in rows:
                symbol = item["symbol"]
                market = item["market"]
                eastmoney_code = item["eastmoney_code"]
                for dataset, (report_name, payload) in item["raw"].items():
                    conn.execute(
                        """
                        insert into lb_eastmoney_f10_raw
                          (symbol, market, eastmoney_code, dataset, report_name, payload, fetched_at, updated_at)
                        values (%s, %s, %s, %s, %s, %s, %s, now())
                        on conflict (symbol, dataset, report_name) do update set
                          market=excluded.market, eastmoney_code=excluded.eastmoney_code,
                          payload=excluded.payload, fetched_at=excluded.fetched_at, updated_at=excluded.updated_at
                        """,
                        (symbol, market, eastmoney_code, dataset, report_name, Jsonb(payload), fetched_at),
                    )
                    counts["raw"] += 1
                profile = item["profile"]
                conn.execute(
                    """
                    insert into lb_eastmoney_f10_profiles
                      (symbol, market, eastmoney_code, company_name, company_name_en, industry, chairman,
                       founded_at, employees, website, address, registered_place, business_scope,
                       company_profile, latest_report_date, payload, fetched_at, updated_at)
                    values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, now())
                    on conflict (symbol) do update set
                      market=excluded.market, eastmoney_code=excluded.eastmoney_code,
                      company_name=excluded.company_name, company_name_en=excluded.company_name_en,
                      industry=excluded.industry, chairman=excluded.chairman, founded_at=excluded.founded_at,
                      employees=excluded.employees, website=excluded.website, address=excluded.address,
                      registered_place=excluded.registered_place, business_scope=excluded.business_scope,
                      company_profile=excluded.company_profile, latest_report_date=excluded.latest_report_date,
                      payload=excluded.payload, fetched_at=excluded.fetched_at, updated_at=excluded.updated_at
                    """,
                    (
                        symbol,
                        market,
                        eastmoney_code,
                        profile.get("company_name"),
                        profile.get("company_name_en"),
                        profile.get("industry"),
                        profile.get("chairman"),
                        profile.get("founded_at"),
                        _num(profile.get("employees")),
                        profile.get("website"),
                        profile.get("address"),
                        profile.get("registered_place"),
                        profile.get("business_scope"),
                        profile.get("company_profile"),
                        profile.get("latest_report_date"),
                        Jsonb(profile.get("payload") or {}),
                        fetched_at,
                    ),
                )
                counts["profiles"] += 1
                for segment in item["segments"]:
                    conn.execute(
                        """
                        insert into lb_eastmoney_f10_business_segments
                          (symbol, market, eastmoney_code, report_date, segment_type, segment_name, currency,
                           revenue, revenue_ratio, cost, cost_ratio, profit, profit_ratio, gross_margin,
                           rank, payload, fetched_at, updated_at)
                        values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, now())
                        on conflict (symbol, report_date, segment_type, segment_name) do update set
                          market=excluded.market, eastmoney_code=excluded.eastmoney_code, currency=excluded.currency,
                          revenue=excluded.revenue, revenue_ratio=excluded.revenue_ratio, cost=excluded.cost,
                          cost_ratio=excluded.cost_ratio, profit=excluded.profit, profit_ratio=excluded.profit_ratio,
                          gross_margin=excluded.gross_margin, rank=excluded.rank, payload=excluded.payload,
                          fetched_at=excluded.fetched_at, updated_at=excluded.updated_at
                        """,
                        (
                            symbol,
                            market,
                            eastmoney_code,
                            segment["report_date"],
                            segment["segment_type"],
                            segment["segment_name"],
                            segment.get("currency"),
                            _num(segment.get("revenue")),
                            _num(segment.get("revenue_ratio")),
                            _num(segment.get("cost")),
                            _num(segment.get("cost_ratio")),
                            _num(segment.get("profit")),
                            _num(segment.get("profit_ratio")),
                            _num(segment.get("gross_margin")),
                            _int(segment.get("rank")),
                            Jsonb(segment.get("payload") or {}),
                            fetched_at,
                        ),
                    )
                    counts["segments"] += 1
                for review in item["reviews"]:
                    conn.execute(
                        """
                        insert into lb_eastmoney_f10_business_reviews
                          (symbol, market, eastmoney_code, report_date, business_review, future_expect,
                           payload, fetched_at, updated_at)
                        values (%s, %s, %s, %s, %s, %s, %s, %s, now())
                        on conflict (symbol, report_date) do update set
                          market=excluded.market, eastmoney_code=excluded.eastmoney_code,
                          business_review=excluded.business_review, future_expect=excluded.future_expect,
                          payload=excluded.payload, fetched_at=excluded.fetched_at, updated_at=excluded.updated_at
                        """,
                        (
                            symbol,
                            market,
                            eastmoney_code,
                            review["report_date"],
                            review.get("business_review"),
                            review.get("future_expect"),
                            Jsonb(review.get("payload") or {}),
                            fetched_at,
                        ),
                    )
                    counts["reviews"] += 1
                for row in item["industry_rank"]:
                    conn.execute(
                        """
                        insert into lb_eastmoney_f10_industry_rank
                          (symbol, market, eastmoney_code, report_date, type_name, peer_symbol, peer_name,
                           market_cap, revenue, gross_profit, market_cap_rank, revenue_rank, gross_profit_rank,
                           payload, fetched_at, updated_at)
                        values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, now())
                        on conflict (symbol, type_name, peer_symbol) do update set
                          market=excluded.market, eastmoney_code=excluded.eastmoney_code,
                          report_date=excluded.report_date, peer_name=excluded.peer_name,
                          market_cap=excluded.market_cap, revenue=excluded.revenue,
                          gross_profit=excluded.gross_profit, market_cap_rank=excluded.market_cap_rank,
                          revenue_rank=excluded.revenue_rank, gross_profit_rank=excluded.gross_profit_rank,
                          payload=excluded.payload, fetched_at=excluded.fetched_at, updated_at=excluded.updated_at
                        """,
                        (
                            symbol,
                            market,
                            eastmoney_code,
                            row.get("report_date"),
                            row["type_name"],
                            row["peer_symbol"],
                            row.get("peer_name"),
                            _num(row.get("market_cap")),
                            _num(row.get("revenue")),
                            _num(row.get("gross_profit")),
                            _int(row.get("market_cap_rank")),
                            _int(row.get("revenue_rank")),
                            _int(row.get("gross_profit_rank")),
                            Jsonb(row.get("payload") or {}),
                            fetched_at,
                        ),
                    )
                    counts["industryRank"] += 1
        return counts


def _fetch_json(url: str, *, timeout_seconds: int, referer: str) -> dict[str, Any]:
    request = Request(url, headers={"User-Agent": USER_AGENT, "Referer": referer})
    with urlopen(request, timeout=timeout_seconds) as response:
        body = response.read().decode("utf-8")
    return json.loads(body)


def _result_rows(payload: dict[str, Any]) -> list[dict[str, Any]]:
    data = ((payload or {}).get("result") or {}).get("data") or []
    return [row for row in data if isinstance(row, dict)]


def _first_result(payload: dict[str, Any]) -> dict[str, Any]:
    rows = _result_rows(payload)
    return rows[0] if rows else {}


def _profile_from_row(row: dict[str, Any], latest_report_date: str | None) -> dict[str, Any]:
    return {
        "company_name": row.get("ORG_NAME"),
        "company_name_en": row.get("ORG_EN_ABBR"),
        "industry": row.get("BELONG_INDUSTRY"),
        "chairman": row.get("CHAIRMAN"),
        "founded_at": _text(row.get("FOUND_DATE")),
        "employees": row.get("EMP_NUM"),
        "website": row.get("ORG_WEB"),
        "address": row.get("ADDRESS") or row.get("REG_ADDRESS"),
        "registered_place": row.get("REG_PLACE"),
        "company_profile": row.get("ORG_PROFILE"),
        "latest_report_date": latest_report_date,
        "payload": row,
    }


def _cn_segment(row: dict[str, Any]) -> dict[str, Any]:
    segment_type = {"1": "industry", "2": "product", "3": "region"}.get(str(row.get("MAINOP_TYPE")), "other")
    return {
        "report_date": _date_only(row.get("REPORT_DATE")),
        "segment_type": segment_type,
        "segment_name": _text(row.get("ITEM_NAME")) or "UNKNOWN",
        "currency": row.get("CURRENCY"),
        "revenue": row.get("MAIN_BUSINESS_INCOME"),
        "revenue_ratio": row.get("MBI_RATIO"),
        "cost": row.get("MAIN_BUSINESS_COST"),
        "cost_ratio": row.get("MBC_RATIO"),
        "profit": row.get("MAIN_BUSINESS_RPOFIT"),
        "profit_ratio": row.get("MBR_RATIO"),
        "gross_margin": row.get("GROSS_RPOFIT_RATIO"),
        "rank": row.get("RANK"),
        "payload": row,
    }


def _us_segment(row: dict[str, Any], segment_type: str) -> dict[str, Any]:
    name_key = "PRODUCT_NAME" if segment_type == "product" else "REGION_NAME"
    return {
        "report_date": _date_only(row.get("REPORT_DATE")),
        "segment_type": segment_type,
        "segment_name": _text(row.get(name_key)) or "UNKNOWN",
        "currency": row.get("CURRENCY"),
        "revenue": row.get("MAIN_BUSINESS_INCOME"),
        "revenue_ratio": row.get("MBI_RATIO"),
        "payload": row,
    }


def _cn_review(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "report_date": _date_only(row.get("REPORT_DATE")),
        "business_review": row.get("BUSINESS_REVIEW"),
        "future_expect": row.get("FUTURE_EXPECT"),
        "payload": row,
    }


def _hk_review(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "report_date": _date_only(row.get("REPORT_DATE")),
        "business_review": row.get("BUSINESS_REVIEW"),
        "future_expect": row.get("FUTURE_EXPECT"),
        "payload": row,
    }


def _hk_industry_rank(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "report_date": _date_only(row.get("MAXSTDREPORTDATE")),
        "type_name": _text(row.get("TYPE_NAME")) or "UNKNOWN",
        "peer_symbol": _hk_peer_symbol(row.get("CORRE_SECUCODE") or row.get("CORRE_SECURITY_CODE")),
        "peer_name": row.get("CORRE_SECURITY_NAME"),
        "market_cap": row.get("HKTOTAL_MARKET_CAP") or row.get("HKSDQMV"),
        "revenue": row.get("OPERATE_INCOME"),
        "gross_profit": row.get("GROSS_PROFIT"),
        "market_cap_rank": row.get("HKTOTAL_CAP_RANK") or row.get("HKSDQMV_RANK"),
        "revenue_rank": row.get("OPERATE_INCOME_RANK"),
        "gross_profit_rank": row.get("GROSS_PROFIT_RANK"),
        "payload": row,
    }


def _eastmoney_code(symbol: str, market: str) -> str:
    symbol = _normalize_symbol(symbol)
    code, _, suffix = symbol.partition(".")
    if market == "cn":
        if suffix in {"SH", "SZ", "BJ"}:
            return f"{suffix}{code}"
        return symbol
    if market == "hk":
        return f"{code.zfill(5)}.HK"
    if market == "us":
        return code.upper()
    return symbol


def _normalize_symbol(symbol: str) -> str:
    return (symbol or "").strip().upper()


def _market_from_symbol(symbol: str) -> str:
    suffix = _normalize_symbol(symbol).split(".")[-1]
    if suffix in {"SH", "SZ", "BJ"}:
        return "cn"
    if suffix == "HK":
        return "hk"
    if suffix == "US":
        return "us"
    return suffix.lower()


def _normalize_market(market: str) -> str:
    value = (market or "").strip().lower()
    if value in {"a", "ashare", "cn", "sh", "sz", "bj"}:
        return "cn"
    if value in {"hk", "hkg"}:
        return "hk"
    if value in {"us", "usa"}:
        return "us"
    return value


def _hk_peer_symbol(value: Any) -> str:
    text = _text(value) or ""
    if text.endswith(".HK"):
        code = text.split(".")[0].lstrip("0") or "0"
        return f"{code}.HK"
    if text:
        return f"{text.lstrip('0') or '0'}.HK"
    return "UNKNOWN.HK"


def _latest_date(values: list[Any]) -> str | None:
    dates = [_date_only(value) for value in values]
    dates = [value for value in dates if value]
    return max(dates) if dates else None


def _date_only(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    return text[:10]


def _first_text(rows: list[dict[str, Any]], key: str) -> str | None:
    for row in rows:
        value = _text(row.get(key))
        if value:
            return value
    return None


def _text(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _int(value: Any) -> int | None:
    if value is None or value == "":
        return None
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None

from __future__ import annotations

import time
from dataclasses import dataclass
from datetime import date, datetime, timezone
from typing import Any

import pandas as pd
import psycopg
from psycopg.types.json import Jsonb


SOURCE = "eastmoney"

CODE = "\u4ee3\u7801"
NAME = "\u540d\u79f0"
PCT_CHANGE = "\u6da8\u8dcc\u5e45"
LATEST_PRICE = "\u6700\u65b0\u4ef7"
CLOSE_PRICE = "\u6536\u76d8\u4ef7"
TURNOVER = "\u6210\u4ea4\u989d"
FLOAT_MARKET_CAP = "\u6d41\u901a\u5e02\u503c"
TOTAL_MARKET_CAP = "\u603b\u5e02\u503c"
TURNOVER_RATE = "\u6362\u624b\u7387"
SEAL_AMOUNT = "\u5c01\u677f\u8d44\u91d1"
FIRST_SEAL_TIME = "\u9996\u6b21\u5c01\u677f\u65f6\u95f4"
LAST_SEAL_TIME = "\u6700\u540e\u5c01\u677f\u65f6\u95f4"
BREAK_COUNT = "\u70b8\u677f\u6b21\u6570"
LIMIT_UP_STAT = "\u6da8\u505c\u7edf\u8ba1"
CONSECUTIVE_BOARDS = "\u8fde\u677f\u6570"
INDUSTRY = "\u6240\u5c5e\u884c\u4e1a"
TODAY = "\u4eca\u65e5"
BOARD_NAME = "\u677f\u5757\u540d\u79f0"
BOARD_CODE = "\u677f\u5757\u4ee3\u7801"

MAIN_NET_FLOW = "\u4e3b\u529b\u51c0\u6d41\u5165-\u51c0\u989d"
TODAY_MAIN_NET_FLOW = "\u4eca\u65e5\u4e3b\u529b\u51c0\u6d41\u5165-\u51c0\u989d"
MAIN_NET_AMOUNT = "\u4e3b\u529b\u51c0\u989d"
MAIN_NET_FLOW_RATIO = "\u4e3b\u529b\u51c0\u6d41\u5165-\u51c0\u5360\u6bd4"
TODAY_MAIN_NET_FLOW_RATIO = "\u4eca\u65e5\u4e3b\u529b\u51c0\u6d41\u5165-\u51c0\u5360\u6bd4"
MAIN_NET_RATIO = "\u4e3b\u529b\u51c0\u5360\u6bd4"
SUPER_LARGE_NET_FLOW = "\u8d85\u5927\u5355\u51c0\u6d41\u5165-\u51c0\u989d"
TODAY_SUPER_LARGE_NET_FLOW = "\u4eca\u65e5\u8d85\u5927\u5355\u51c0\u6d41\u5165-\u51c0\u989d"
LARGE_NET_FLOW = "\u5927\u5355\u51c0\u6d41\u5165-\u51c0\u989d"
TODAY_LARGE_NET_FLOW = "\u4eca\u65e5\u5927\u5355\u51c0\u6d41\u5165-\u51c0\u989d"
MEDIUM_NET_FLOW = "\u4e2d\u5355\u51c0\u6d41\u5165-\u51c0\u989d"
TODAY_MEDIUM_NET_FLOW = "\u4eca\u65e5\u4e2d\u5355\u51c0\u6d41\u5165-\u51c0\u989d"
SMALL_NET_FLOW = "\u5c0f\u5355\u51c0\u6d41\u5165-\u51c0\u989d"
TODAY_SMALL_NET_FLOW = "\u4eca\u65e5\u5c0f\u5355\u51c0\u6d41\u5165-\u51c0\u989d"


@dataclass(frozen=True)
class EastmoneySyncSummary:
    source: str
    trade_date: str
    datasets: list[str]
    written: dict[str, int]
    failed: dict[str, str]
    elapsed_seconds: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "source": self.source,
            "tradeDate": self.trade_date,
            "datasets": self.datasets,
            "written": self.written,
            "failed": self.failed,
            "elapsedSeconds": round(self.elapsed_seconds, 3),
        }


class EastmoneyExternalSync:
    def __init__(self, dsn: str, ak_module: Any | None = None) -> None:
        self.dsn = dsn
        self.ak = ak_module or _import_akshare()

    def sync_once(
        self,
        *,
        trade_date: str | None = None,
        datasets: list[str] | None = None,
        include_components: bool = False,
        component_limit: int | None = None,
    ) -> EastmoneySyncSummary:
        trade_date = trade_date or date.today().isoformat()
        datasets = datasets or ["limit-pool", "fund-flow", "industry", "concept"]
        started = time.monotonic()
        self.ensure_tables()
        written: dict[str, int] = {}
        failed: dict[str, str] = {}
        for dataset in datasets:
            try:
                if dataset == "limit-pool":
                    written[dataset] = self.sync_limit_pools(trade_date)
                elif dataset == "fund-flow":
                    written[dataset] = self.sync_fund_flow_rank(trade_date)
                elif dataset == "industry":
                    written[dataset] = self.sync_boards("industry", include_components, component_limit)
                elif dataset == "concept":
                    written[dataset] = self.sync_boards("concept", include_components, component_limit)
                else:
                    failed[dataset] = f"unknown dataset: {dataset}"
            except Exception as exc:
                failed[dataset] = str(exc)
        return EastmoneySyncSummary(
            source=SOURCE,
            trade_date=trade_date,
            datasets=datasets,
            written=written,
            failed=failed,
            elapsed_seconds=time.monotonic() - started,
        )

    def ensure_tables(self) -> None:
        with psycopg.connect(self.dsn) as conn:
            conn.execute(
                """
                create table if not exists lb_external_limit_pools (
                  source text not null,
                  pool text not null,
                  trade_date date not null,
                  symbol text not null,
                  name text,
                  pct_change numeric,
                  last_price numeric,
                  turnover numeric,
                  float_market_cap numeric,
                  total_market_cap numeric,
                  turnover_rate numeric,
                  seal_amount numeric,
                  first_seal_time text,
                  last_seal_time text,
                  break_count integer,
                  limit_up_stat text,
                  consecutive_boards integer,
                  industry text,
                  payload jsonb,
                  fetched_at timestamptz not null,
                  updated_at timestamptz not null default now(),
                  primary key (source, pool, trade_date, symbol)
                )
                """
            )
            conn.execute(
                """
                create table if not exists lb_external_fund_flow_rank (
                  source text not null,
                  trade_date date not null,
                  period text not null,
                  symbol text not null,
                  name text,
                  latest_price numeric,
                  pct_change numeric,
                  main_net_flow numeric,
                  main_net_flow_ratio numeric,
                  super_large_net_flow numeric,
                  large_net_flow numeric,
                  medium_net_flow numeric,
                  small_net_flow numeric,
                  payload jsonb,
                  fetched_at timestamptz not null,
                  updated_at timestamptz not null default now(),
                  primary key (source, trade_date, period, symbol)
                )
                """
            )
            conn.execute(
                """
                create table if not exists lb_external_boards (
                  source text not null,
                  board_type text not null,
                  board_code text not null,
                  board_name text not null,
                  latest_price numeric,
                  pct_change numeric,
                  turnover_rate numeric,
                  turnover numeric,
                  payload jsonb,
                  fetched_at timestamptz not null,
                  updated_at timestamptz not null default now(),
                  primary key (source, board_type, board_code)
                )
                """
            )
            conn.execute(
                """
                create table if not exists lb_external_board_components (
                  source text not null,
                  board_type text not null,
                  board_name text not null,
                  symbol text not null,
                  name text,
                  payload jsonb,
                  fetched_at timestamptz not null,
                  updated_at timestamptz not null default now(),
                  primary key (source, board_type, board_name, symbol)
                )
                """
            )

    def sync_limit_pools(self, trade_date: str) -> int:
        ymd = trade_date.replace("-", "")
        pool_calls = {
            "limit_up": lambda: self.ak.stock_zt_pool_em(date=ymd),
            "previous_limit_up": lambda: self.ak.stock_zt_pool_previous_em(date=ymd),
            "strong": lambda: self.ak.stock_zt_pool_strong_em(date=ymd),
            "open_board": lambda: self.ak.stock_zt_pool_zbgc_em(date=ymd),
            "limit_down": lambda: self.ak.stock_zt_pool_dtgc_em(date=ymd),
        }
        fetched_at = _now()
        written = 0
        with psycopg.connect(self.dsn) as conn:
            for pool, fn in pool_calls.items():
                frame = fn()
                for row in _records(frame):
                    symbol = _cn_symbol(row.get(CODE))
                    if not symbol:
                        continue
                    conn.execute(
                        """
                        insert into lb_external_limit_pools
                          (source, pool, trade_date, symbol, name, pct_change, last_price, turnover,
                           float_market_cap, total_market_cap, turnover_rate, seal_amount,
                           first_seal_time, last_seal_time, break_count, limit_up_stat,
                           consecutive_boards, industry, payload, fetched_at, updated_at)
                        values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, now())
                        on conflict (source, pool, trade_date, symbol) do update set
                          name=excluded.name, pct_change=excluded.pct_change, last_price=excluded.last_price,
                          turnover=excluded.turnover, float_market_cap=excluded.float_market_cap,
                          total_market_cap=excluded.total_market_cap, turnover_rate=excluded.turnover_rate,
                          seal_amount=excluded.seal_amount, first_seal_time=excluded.first_seal_time,
                          last_seal_time=excluded.last_seal_time, break_count=excluded.break_count,
                          limit_up_stat=excluded.limit_up_stat, consecutive_boards=excluded.consecutive_boards,
                          industry=excluded.industry, payload=excluded.payload, fetched_at=excluded.fetched_at,
                          updated_at=excluded.updated_at
                        """,
                        (
                            SOURCE,
                            pool,
                            trade_date,
                            symbol,
                            _text(row.get(NAME)),
                            _num(row.get(PCT_CHANGE)),
                            _num(row.get(LATEST_PRICE)),
                            _num(row.get(TURNOVER)),
                            _num(row.get(FLOAT_MARKET_CAP)),
                            _num(row.get(TOTAL_MARKET_CAP)),
                            _num(row.get(TURNOVER_RATE)),
                            _num(row.get(SEAL_AMOUNT)),
                            _text(row.get(FIRST_SEAL_TIME)),
                            _text(row.get(LAST_SEAL_TIME)),
                            _int(row.get(BREAK_COUNT)),
                            _text(row.get(LIMIT_UP_STAT)),
                            _int(row.get(CONSECUTIVE_BOARDS)),
                            _text(row.get(INDUSTRY)),
                            Jsonb(row),
                            fetched_at,
                        ),
                    )
                    written += 1
        return written

    def sync_fund_flow_rank(self, trade_date: str, period: str = TODAY) -> int:
        frame = self.ak.stock_individual_fund_flow_rank(indicator=period)
        fetched_at = _now()
        written = 0
        with psycopg.connect(self.dsn) as conn:
            for row in _records(frame):
                symbol = _cn_symbol(row.get(CODE))
                if not symbol:
                    continue
                conn.execute(
                    """
                    insert into lb_external_fund_flow_rank
                      (source, trade_date, period, symbol, name, latest_price, pct_change,
                       main_net_flow, main_net_flow_ratio, super_large_net_flow, large_net_flow,
                       medium_net_flow, small_net_flow, payload, fetched_at, updated_at)
                    values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, now())
                    on conflict (source, trade_date, period, symbol) do update set
                      name=excluded.name, latest_price=excluded.latest_price, pct_change=excluded.pct_change,
                      main_net_flow=excluded.main_net_flow, main_net_flow_ratio=excluded.main_net_flow_ratio,
                      super_large_net_flow=excluded.super_large_net_flow, large_net_flow=excluded.large_net_flow,
                      medium_net_flow=excluded.medium_net_flow, small_net_flow=excluded.small_net_flow,
                      payload=excluded.payload, fetched_at=excluded.fetched_at, updated_at=excluded.updated_at
                    """,
                    (
                        SOURCE,
                        trade_date,
                        period,
                        symbol,
                        _text(row.get(NAME)),
                        _first_num(row, [LATEST_PRICE, CLOSE_PRICE]),
                        _first_num(row, [PCT_CHANGE]),
                        _first_num(row, [MAIN_NET_FLOW, TODAY_MAIN_NET_FLOW, MAIN_NET_AMOUNT]),
                        _first_num(row, [MAIN_NET_FLOW_RATIO, TODAY_MAIN_NET_FLOW_RATIO, MAIN_NET_RATIO]),
                        _first_num(row, [SUPER_LARGE_NET_FLOW, TODAY_SUPER_LARGE_NET_FLOW]),
                        _first_num(row, [LARGE_NET_FLOW, TODAY_LARGE_NET_FLOW]),
                        _first_num(row, [MEDIUM_NET_FLOW, TODAY_MEDIUM_NET_FLOW]),
                        _first_num(row, [SMALL_NET_FLOW, TODAY_SMALL_NET_FLOW]),
                        Jsonb(row),
                        fetched_at,
                    ),
                )
                written += 1
        return written

    def sync_boards(self, board_type: str, include_components: bool, component_limit: int | None) -> int:
        if board_type == "industry":
            frame = self.ak.stock_board_industry_name_em()
            component_fn = self.ak.stock_board_industry_cons_em
        elif board_type == "concept":
            frame = self.ak.stock_board_concept_name_em()
            component_fn = self.ak.stock_board_concept_cons_em
        else:
            raise ValueError(f"unsupported board type: {board_type}")
        fetched_at = _now()
        records = _records(frame)
        written = self._upsert_boards(board_type, records, fetched_at)
        if include_components:
            limited_records = records if component_limit is None else records[:component_limit]
            for row in limited_records:
                board_name = _text(row.get(BOARD_NAME) or row.get(NAME))
                if not board_name:
                    continue
                component_rows = _records(component_fn(symbol=board_name))
                written += self._upsert_board_components(board_type, board_name, component_rows, fetched_at)
        return written

    def _upsert_boards(self, board_type: str, rows: list[dict[str, Any]], fetched_at: datetime) -> int:
        written = 0
        with psycopg.connect(self.dsn) as conn:
            for row in rows:
                board_name = _text(row.get(BOARD_NAME) or row.get(NAME))
                if not board_name:
                    continue
                board_code = _text(row.get(BOARD_CODE) or row.get(CODE)) or board_name
                conn.execute(
                    """
                    insert into lb_external_boards
                      (source, board_type, board_code, board_name, latest_price, pct_change,
                       turnover_rate, turnover, payload, fetched_at, updated_at)
                    values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, now())
                    on conflict (source, board_type, board_code) do update set
                      board_name=excluded.board_name, latest_price=excluded.latest_price,
                      pct_change=excluded.pct_change, turnover_rate=excluded.turnover_rate,
                      turnover=excluded.turnover, payload=excluded.payload, fetched_at=excluded.fetched_at,
                      updated_at=excluded.updated_at
                    """,
                    (
                        SOURCE,
                        board_type,
                        board_code,
                        board_name,
                        _first_num(row, [LATEST_PRICE, CLOSE_PRICE]),
                        _first_num(row, [PCT_CHANGE]),
                        _first_num(row, [TURNOVER_RATE]),
                        _first_num(row, [TURNOVER]),
                        Jsonb(row),
                        fetched_at,
                    ),
                )
                written += 1
        return written

    def _upsert_board_components(
        self, board_type: str, board_name: str, rows: list[dict[str, Any]], fetched_at: datetime
    ) -> int:
        written = 0
        with psycopg.connect(self.dsn) as conn:
            for row in rows:
                symbol = _cn_symbol(row.get(CODE))
                if not symbol:
                    continue
                conn.execute(
                    """
                    insert into lb_external_board_components
                      (source, board_type, board_name, symbol, name, payload, fetched_at, updated_at)
                    values (%s, %s, %s, %s, %s, %s, %s, now())
                    on conflict (source, board_type, board_name, symbol) do update set
                      name=excluded.name, payload=excluded.payload, fetched_at=excluded.fetched_at,
                      updated_at=excluded.updated_at
                    """,
                    (SOURCE, board_type, board_name, symbol, _text(row.get(NAME)), Jsonb(row), fetched_at),
                )
                written += 1
        return written


def _records(frame: Any) -> list[dict[str, Any]]:
    if frame is None:
        return []
    if isinstance(frame, pd.DataFrame):
        return frame.where(pd.notnull(frame), None).to_dict("records")
    if isinstance(frame, list):
        return [row for row in frame if isinstance(row, dict)]
    return []


def _cn_symbol(code: Any) -> str | None:
    if code is None:
        return None
    digits = str(code).strip()
    if "." in digits:
        return digits.upper()
    if not digits.isdigit():
        return None
    if digits.startswith("6"):
        return f"{digits}.SH"
    if digits.startswith(("0", "2", "3")):
        return f"{digits}.SZ"
    if digits.startswith(("4", "8", "9")):
        return f"{digits}.BJ"
    return f"{digits}.SZ"


def _num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        if pd.isna(value):
            return None
    except TypeError:
        pass
    try:
        return float(str(value).replace(",", "").replace("%", ""))
    except ValueError:
        return None


def _first_num(row: dict[str, Any], keys: list[str]) -> float | None:
    for key in keys:
        value = _num(row.get(key))
        if value is not None:
            return value
    return None


def _int(value: Any) -> int | None:
    parsed = _num(value)
    return int(parsed) if parsed is not None else None


def _text(value: Any) -> str | None:
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except TypeError:
        pass
    text = str(value).strip()
    return text or None


def _import_akshare() -> Any:
    try:
        import akshare as ak
    except ImportError as exc:
        raise RuntimeError("akshare is not installed; install longbridge-stock[external] or pip install akshare") from exc
    return ak


def _now() -> datetime:
    return datetime.now(timezone.utc).astimezone()

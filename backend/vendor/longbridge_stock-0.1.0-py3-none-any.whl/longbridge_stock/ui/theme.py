from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping


@dataclass(frozen=True)
class NavItem:
    key: str
    label: str
    icon: str
    description: str


NAV_ITEMS: tuple[NavItem, ...] = (
    NavItem("overview", "总览", "OV", "查看数据、实验、模型和评分的整体状态"),
    NavItem("data", "数据中心", "DB", "检查长桥与 Qlib 数据是否完整可用"),
    NavItem("qlib", "Qlib 工作流", "QL", "可视化操作 Qlib 原生研究流程"),
    NavItem("factors", "因子工坊", "FA", "管理因子、策略草稿和后续 LLM 扩展入口"),
    NavItem("experiments", "实验中心", "EX", "运行基线实验并保存结果"),
    NavItem("compare", "实验对比", "CP", "横向比较多次实验的关键指标"),
    NavItem("pool", "今日股票池", "SC", "查看全市场评分和单票画像"),
    NavItem("ai", "AI 分析助手", "AI", "复用模型配置做解释、总结和辅助分析"),
)

UI_COPY: Mapping[str, str] = {
    "app_title": "Longbridge Quant Console",
    "app_subtitle": "长桥数据 + Qlib 研究 + LLM 分析",
    "overview_title": "研究驾驶舱",
    "overview_subtitle": "把数据状态、实验表现、模型接入和最新评分集中在一个可操作页面里。",
    "data_title": "数据中心",
    "data_subtitle": "检查永久数据目录、Qlib Provider 和 CSV 回退链路是否可用。",
    "qlib_title": "Qlib 工作流",
    "qlib_subtitle": "把数据标准化、特征工程、模型训练、信号分析、组合回测和实验记录串成一条完整研究链路。",
    "factor_lab_title": "因子工坊",
    "factor_lab_subtitle": "管理内置因子，并预留 LLM 生成与人工审核入口。",
    "experiment_title": "实验中心",
    "experiment_subtitle": "选择数据源，运行 baseline 回测，并保存可复用的实验产物。",
    "compare_title": "实验对比",
    "compare_subtitle": "横向比较多次实验结果，快速定位更稳定的策略配置。",
    "pool_title": "今日股票池",
    "pool_subtitle": "从最近一次实验或最新评分中提取候选股票，供后续人工或自动流程使用。",
    "ai_title": "AI 分析助手",
    "ai_subtitle": "复用现有模型配置，后续用于因子生成、实验解释和风险摘要。",
}


def format_percent(value: float | int | None) -> str:
    if value is None:
        return "-"
    return f"{float(value) * 100:.2f}%"


def format_number(value: float | int | None, digits: int = 2) -> str:
    if value is None:
        return "-"
    if isinstance(value, int):
        return f"{value:,}"
    return f"{float(value):,.{digits}f}"


def find_nav_item(key: str) -> NavItem:
    for item in NAV_ITEMS:
        if item.key == key:
            return item
    raise KeyError(f"Unknown navigation key: {key}")

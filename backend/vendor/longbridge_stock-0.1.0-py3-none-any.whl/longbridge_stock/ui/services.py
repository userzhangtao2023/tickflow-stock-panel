from __future__ import annotations

import json
import os
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol

import pandas as pd
from psycopg.conninfo import conninfo_to_dict, make_conninfo

from longbridge_stock.backtest import run_topk_backtest
from longbridge_stock.config import load_data_config, load_experiment_config
from longbridge_stock.data import load_market_data
from longbridge_stock.experiments import create_experiment_dir, save_backtest_result
from longbridge_stock.factors import compute_factor_set, list_factors
from longbridge_stock.llm.ozon_config import OzonModelConfigClient
from longbridge_stock.qlib_native import (
    QlibCoreStep,
    QlibEnvironmentStatus,
    RemoteQlibRun,
    RemoteQlibRunStatus,
    RemoteQlibRunSummary,
    QlibWorkflowSpec,
    list_remote_qrun_runs,
    qlib_environment_status,
    qlib_core_steps,
    remote_qrun_status,
    save_qlib_workflow_config,
    start_remote_qrun,
)
from longbridge_stock.scoring import (
    DEFAULT_SCORE_DSN,
    fetch_score_leaderboard,
    fetch_stock_score_detail,
    refresh_stock_scores,
)
from longbridge_stock.stock_pool_snapshot import fetch_stock_pool_snapshot


@dataclass(frozen=True)
class DataSummary:
    rows: int
    instruments: int
    start: str
    end: str
    columns: list[str]
    source: str


@dataclass(frozen=True)
class ExperimentRun:
    name: str
    path: Path
    metrics: dict[str, float] = field(default_factory=dict)


@dataclass(frozen=True)
class ModelConfigStatus:
    text_model: str
    text_base_url: str
    text_api_key_configured: bool
    image_model: str
    preset_count: int


class ModelConfigClient(Protocol):
    def load(self): ...


def default_score_dsn() -> str:
    dsn = os.getenv("LONGBRIDGE_PG_DSN", DEFAULT_SCORE_DSN)
    timeout_ms = int(os.getenv("LONGBRIDGE_API_STATEMENT_TIMEOUT_MS", "60000"))
    return _with_statement_timeout(dsn, timeout_ms)


def default_score_remote_host() -> str:
    return os.getenv("LONGBRIDGE_SCORE_REMOTE_HOST", "192.168.10.28")


def default_score_remote_user() -> str:
    return os.getenv("LONGBRIDGE_SCORE_REMOTE_USER", "alwin")


def _with_statement_timeout(dsn: str, timeout_ms: int) -> str:
    if timeout_ms <= 0:
        return dsn
    try:
        values = conninfo_to_dict(dsn)
        options = str(values.get("options") or "")
        if "statement_timeout" not in options:
            options = f"{options} -c statement_timeout={timeout_ms}".strip()
        if "idle_in_transaction_session_timeout" not in options:
            options = f"{options} -c idle_in_transaction_session_timeout={max(timeout_ms * 2, 10000)}".strip()
        values["options"] = options
        values.setdefault("connect_timeout", "5")
        return make_conninfo(**values)
    except Exception:
        return dsn


def default_score_remote_app_dir() -> str:
    return os.getenv("LONGBRIDGE_SCORE_REMOTE_APP_DIR", "/home/alwin/apps/longbridge-stock")


def build_data_summary(
    data_config_path: str | Path,
    experiment_config_path: str | Path,
    source: str = "auto",
) -> DataSummary:
    remote_host = os.getenv("QLIB_REMOTE_HOST")
    if remote_host and source in {"auto", "qlib"}:
        remote_user = os.getenv("QLIB_REMOTE_USER")
        return _remote_data_summary(data_config_path, experiment_config_path, remote_host, remote_user)
    data_config = load_data_config(data_config_path)
    experiment = load_experiment_config(experiment_config_path)
    data = load_market_data(data_config, experiment.start_time, experiment.end_time, source=source)
    dates = data.index.get_level_values("datetime")
    instruments = data.index.get_level_values("instrument")
    return DataSummary(
        rows=int(len(data)),
        instruments=int(instruments.nunique()),
        start=str(dates.min().date()),
        end=str(dates.max().date()),
        columns=list(map(str, data.columns)),
        source=source,
    )


def list_experiment_runs(root: str | Path = "experiments") -> list[ExperimentRun]:
    root = Path(root)
    if not root.exists():
        return []
    runs = []
    for path in sorted((item for item in root.iterdir() if item.is_dir()), key=lambda p: p.name, reverse=True):
        metrics_path = path / "metrics.json"
        metrics = {}
        if metrics_path.exists():
            metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
        runs.append(ExperimentRun(name=path.name, path=path, metrics=metrics))
    return runs


def get_model_config_status(client: ModelConfigClient | None = None) -> ModelConfigStatus:
    config = (client or OzonModelConfigClient()).load()
    return ModelConfigStatus(
        text_model=config.text_model,
        text_base_url=config.text_base_url,
        text_api_key_configured=bool(config.text_api_key_configured),
        image_model=config.image_model,
        preset_count=len(config.presets),
    )


def run_baseline_experiment(
    data_config_path: str | Path = "configs/data.yaml",
    experiment_config_path: str | Path = "configs/experiment.yaml",
    source: str = "auto",
    output_dir: str | Path = "experiments",
) -> ExperimentRun:
    data_config = load_data_config(data_config_path)
    experiment = load_experiment_config(experiment_config_path)
    data = load_market_data(data_config, experiment.start_time, experiment.end_time, source=source)
    factors = compute_factor_set(data, experiment.factor_set)
    scores = weighted_score(factors, experiment.score_weights)
    test_start = pd.Timestamp(experiment.test_start_time or experiment.start_time)
    test_end = pd.Timestamp(experiment.test_end_time or experiment.end_time)
    dates = scores.index.get_level_values("datetime")
    test_mask = (dates >= test_start) & (dates <= test_end)
    result = run_topk_backtest(
        market_data=data.loc[test_mask],
        scores=scores.loc[test_mask],
        top_k=experiment.backtest.top_k,
        cost_rate=experiment.backtest.cost_rate,
    )
    out = create_experiment_dir(output_dir, experiment.name)
    save_backtest_result(out, result, scores.loc[test_mask])
    return ExperimentRun(name=out.name, path=out, metrics=result.metrics)


def weighted_score(factors: pd.DataFrame, weights: dict[str, float]) -> pd.Series:
    missing = [name for name in weights if name not in factors.columns]
    if missing:
        raise KeyError(f"Score weights reference unknown factors: {', '.join(missing)}")
    normalized = factors[list(weights)].groupby(level="datetime").rank(pct=True)
    score = sum(normalized[name].fillna(0.5) * weight for name, weight in weights.items())
    return score.rename("score")


def latest_stock_pool(root: str | Path = "experiments", limit: int = 30) -> pd.DataFrame:
    runs = list_experiment_runs(root)
    for run in runs:
        scores_path = run.path / "scores.csv"
        if scores_path.exists():
            scores = pd.read_csv(scores_path, parse_dates=["datetime"])
            if scores.empty:
                continue
            latest_date = scores["datetime"].max()
            latest = scores[scores["datetime"] == latest_date].sort_values("score", ascending=False).head(limit)
            return latest.reset_index(drop=True)
    return pd.DataFrame(columns=["datetime", "instrument", "score"])


def available_factors() -> list[str]:
    return list_factors()


def refresh_stock_scores_table(dsn: str | None = None):
    try:
        return refresh_stock_scores(dsn or default_score_dsn())
    except Exception:
        payload = _run_remote_score_service("refresh")
        return type("RemoteScoreSummary", (), payload)()


def latest_market_scores(market: str = "all", limit: int = 30, dsn: str | None = None, strategy: str = "trend_follow") -> pd.DataFrame:
    score_dsn = dsn or default_score_dsn()
    if os.getenv("LONGBRIDGE_STOCK_POOL_SNAPSHOT", "1") != "0":
        try:
            snapshot = fetch_stock_pool_snapshot(
                score_dsn,
                market=market,
                limit=limit,
                strategy=strategy,
                max_age_seconds=int(os.getenv("LONGBRIDGE_STOCK_POOL_SNAPSHOT_MAX_AGE", "900")),
            )
            if not snapshot.empty:
                return snapshot
        except Exception:
            pass
        try:
            snapshot = fetch_stock_pool_snapshot(
                score_dsn,
                market=market,
                limit=limit,
                strategy=strategy,
                max_age_seconds=int(os.getenv("LONGBRIDGE_STOCK_POOL_STALE_MAX_AGE", "86400")),
            )
            if not snapshot.empty:
                return snapshot
        except Exception:
            pass
    try:
        return fetch_score_leaderboard(score_dsn, market=market, limit=limit, strategy=strategy)
    except Exception:
        payload = _run_remote_score_service("leaderboard", market=market, limit=limit, strategy=strategy)
        return pd.DataFrame(payload)


def stock_score_detail(symbol: str, dsn: str | None = None) -> dict | None:
    try:
        return fetch_stock_score_detail(dsn or default_score_dsn(), symbol)
    except Exception:
        return _run_remote_score_service("detail", symbol=symbol)


def _run_remote_score_service(action: str, **kwargs):
    target = f"{default_score_remote_user()}@{default_score_remote_host()}"
    app_dir = default_score_remote_app_dir()
    payload = json.dumps({"action": action, "kwargs": kwargs}, ensure_ascii=False)
    script = "\n".join(
        [
            f"cd {app_dir} && .venv/bin/python - <<'PY'",
            "import json",
            "from longbridge_stock.scoring import fetch_score_leaderboard, fetch_stock_score_detail, refresh_stock_scores",
            f"request = json.loads({payload!r})",
            "action = request['action']",
            "kwargs = request['kwargs']",
            "dsn = 'dbname=longbridge_stock user=alwin host=/var/run/postgresql'",
            "if action == 'refresh':",
            "    summary = refresh_stock_scores(dsn)",
            "    print(json.dumps({'score_date': summary.score_date, 'total': summary.total, 'by_market': summary.by_market}, ensure_ascii=False))",
            "elif action == 'leaderboard':",
            "    frame = fetch_score_leaderboard(dsn, market=kwargs.get('market', 'all'), limit=int(kwargs.get('limit', 30)), strategy=kwargs.get('strategy', 'trend_follow'))",
            "    print(frame.to_json(orient='records', force_ascii=False, date_format='iso'))",
            "elif action == 'detail':",
            "    detail = fetch_stock_score_detail(dsn, kwargs['symbol'])",
            "    print(json.dumps(detail, ensure_ascii=False, default=str))",
            "else:",
            "    raise RuntimeError(f'Unknown remote score action: {action}')",
            "PY",
        ]
    )
    result = subprocess.run(
        ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=10", target, script],
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=90,
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or f"Remote score service failed on {target}")
    text = result.stdout.strip().splitlines()[-1] if result.stdout.strip() else ""
    return json.loads(text) if text else None


def _remote_data_summary(
    data_config_path: str | Path,
    experiment_config_path: str | Path,
    remote_host: str,
    remote_user: str | None = None,
) -> DataSummary:
    data_config = load_data_config(data_config_path)
    experiment = load_experiment_config(experiment_config_path)
    target = f"{remote_user}@{remote_host}" if remote_user else remote_host
    fields = [field if field.startswith("$") else f"${field}" for field in data_config.fields]
    probe = (
        "python3 - <<'PY'\n"
        "import json\n"
        "import qlib\n"
        "from qlib.data import D\n"
        f"qlib.init(provider_uri={data_config.provider_uri.as_posix()!r}, region={data_config.region!r})\n"
        f"instruments = D.instruments({data_config.market!r})\n"
        f"data = D.features(instruments, {fields!r}, start_time={experiment.start_time!r}, end_time={experiment.end_time!r}, freq='day')\n"
        "data.index = data.index.set_names(['instrument', 'datetime'])\n"
        "dates = data.index.get_level_values('datetime')\n"
        "inst = data.index.get_level_values('instrument')\n"
        "print(json.dumps({\n"
        "  'rows': int(len(data)),\n"
        "  'instruments': int(inst.nunique()),\n"
        "  'start': str(dates.min().date()),\n"
        "  'end': str(dates.max().date()),\n"
        "  'columns': [str(c).lstrip('$') for c in data.columns],\n"
        "}))\n"
        "PY"
    )
    result = subprocess.run(
        ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=10", target, probe],
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=60,
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or f"Unable to read Qlib data on {target}")
    payload = json.loads(result.stdout.strip().splitlines()[-1])
    return DataSummary(
        rows=int(payload["rows"]),
        instruments=int(payload["instruments"]),
        start=str(payload["start"]),
        end=str(payload["end"]),
        columns=list(map(str, payload["columns"])),
        source=f"remote qlib ({target})",
    )


def get_qlib_native_status() -> QlibEnvironmentStatus:
    return qlib_environment_status()


def get_qlib_core_steps() -> list[QlibCoreStep]:
    return qlib_core_steps()


def write_qlib_native_config(
    output_path: str | Path = "configs/qlib_lightgbm_alpha158.yaml",
    data_config_path: str | Path = "configs/data.yaml",
    experiment_config_path: str | Path = "configs/experiment.yaml",
) -> Path:
    data_config = load_data_config(data_config_path)
    experiment = load_experiment_config(experiment_config_path)
    spec = QlibWorkflowSpec(topk=experiment.backtest.top_k, close_cost=experiment.backtest.cost_rate)
    return save_qlib_workflow_config(output_path, data_config, experiment, spec)


def write_custom_qlib_config(
    handler: str,
    topk: int,
    n_drop: int,
    output_path: str | Path = "configs/qlib_lightgbm_alpha158.yaml",
    data_config_path: str | Path = "configs/data.yaml",
    experiment_config_path: str | Path = "configs/experiment.yaml",
) -> Path:
    data_config = load_data_config(data_config_path)
    experiment = load_experiment_config(experiment_config_path)
    spec = QlibWorkflowSpec(handler=handler, topk=topk, n_drop=n_drop, close_cost=experiment.backtest.cost_rate)
    return save_qlib_workflow_config(output_path, data_config, experiment, spec)


def start_remote_qlib_workflow(config_path: str | Path = "configs/qlib_lightgbm_alpha158.yaml") -> RemoteQlibRun:
    return start_remote_qrun(config_path)


def get_remote_qlib_workflow_status(run_id: str) -> RemoteQlibRunStatus:
    return remote_qrun_status(run_id)


def list_remote_qlib_workflow_runs(limit: int = 20) -> list[RemoteQlibRunSummary]:
    return list_remote_qrun_runs(limit=limit)

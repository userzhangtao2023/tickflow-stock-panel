from __future__ import annotations

import numpy as np


def rmse(y_true, y_pred) -> float:
    true, pred = _arrays(y_true, y_pred)
    return float(np.sqrt(np.mean((true - pred) ** 2)))


def mape(y_true, y_pred) -> float:
    true, pred = _arrays(y_true, y_pred)
    mask = true != 0
    if not np.any(mask):
        return float("nan")
    return float(np.mean(np.abs((true[mask] - pred[mask]) / true[mask])) * 100)


def quantile_coverage(y_true, y_pred_q, q: float) -> float:
    true, pred = _arrays(y_true, y_pred_q)
    return float(np.mean(true <= pred) if q < 0.5 else np.mean(true >= pred))


def value_at_risk(returns, alpha: float = 0.05) -> float:
    values = _clean_array(returns)
    if values.size == 0:
        return float("nan")
    return float(np.percentile(values, alpha * 100))


def cvar(returns, alpha: float = 0.05) -> float:
    values = _clean_array(returns)
    if values.size == 0:
        return float("nan")
    var = value_at_risk(values, alpha)
    tail = values[values <= var] if alpha < 0.5 else values[values >= var]
    return float(tail.mean()) if tail.size else float(var)


def metrics_report(y_true, y_pred, y_pred_qs=None, quantiles=(0.05, 0.5, 0.95)) -> dict[str, float]:
    report = {
        "rmse": rmse(y_true, y_pred),
        "mape": mape(y_true, y_pred),
        "var_5": value_at_risk(y_true, 0.05),
        "cvar_5": cvar(y_true, 0.05),
    }
    if y_pred_qs is not None:
        for index, q in enumerate(quantiles):
            report[f"quantile_coverage_{q}"] = quantile_coverage(y_true, y_pred_qs[index], q)
    return report


def distribution_report(y_true, y_pred) -> dict[str, float]:
    true, pred = _arrays(y_true, y_pred)
    if true.size == 0:
        return {
            "bias": float("nan"),
            "true_mean": float("nan"),
            "pred_mean": float("nan"),
            "true_std": float("nan"),
            "pred_std": float("nan"),
            "std_ratio": float("nan"),
            "corr": float("nan"),
            "mae": float("nan"),
            "rmse": float("nan"),
        }
    true_mean = float(np.mean(true))
    pred_mean = float(np.mean(pred))
    true_std = float(np.std(true))
    pred_std = float(np.std(pred))
    corr = 0.0 if true_std <= 1e-8 or pred_std <= 1e-8 else float(np.corrcoef(true, pred)[0, 1])
    return {
        "bias": pred_mean - true_mean,
        "true_mean": true_mean,
        "pred_mean": pred_mean,
        "true_std": true_std,
        "pred_std": pred_std,
        "std_ratio": float(pred_std / true_std) if true_std > 1e-8 else float("nan"),
        "corr": corr,
        "mae": float(np.mean(np.abs(pred - true))),
        "rmse": rmse(true, pred),
    }


def _arrays(y_true, y_pred) -> tuple[np.ndarray, np.ndarray]:
    true = _clean_array(y_true)
    pred = _clean_array(y_pred)
    if true.shape != pred.shape:
        raise ValueError("y_true and y_pred must have the same shape")
    return true, pred


def _clean_array(values) -> np.ndarray:
    return np.nan_to_num(np.asarray(values, dtype=float), nan=0.0, posinf=0.0, neginf=0.0)

"""Optional deep return-prediction models for Longbridge stock research.

The package is intentionally lazy: importing ``longbridge_stock.deep_prediction``
does not require PyTorch. Import model classes from ``torch_models`` only in
training or inference jobs that install the ``deep`` optional dependency.
"""

from longbridge_stock.deep_prediction.metrics import (
    cvar,
    distribution_report,
    mape,
    metrics_report,
    quantile_coverage,
    rmse,
    value_at_risk,
)

__all__ = [
    "cvar",
    "distribution_report",
    "mape",
    "metrics_report",
    "quantile_coverage",
    "rmse",
    "value_at_risk",
]

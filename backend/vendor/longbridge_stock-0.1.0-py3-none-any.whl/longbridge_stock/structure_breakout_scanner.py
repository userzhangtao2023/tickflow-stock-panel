from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import date, datetime
from types import MappingProxyType
from typing import Iterable, Mapping, Sequence

import numpy as np

from longbridge_stock.dow_pivot_detector import CausalPivotDetector, DetectedPivot


@dataclass(frozen=True)
class StructureBar:
    index: int
    trade_date: date
    open: float
    high: float
    low: float
    close: float
    volume: float
    turnover: float | None = None


@dataclass(frozen=True)
class StructureContext:
    bars: tuple[StructureBar, ...]
    pivots: tuple[DetectedPivot, ...]
    atr_14: tuple[float | None, ...]
    volume_ma_20: tuple[float | None, ...]
    turnover_ma_20: tuple[float | None, ...]


@dataclass(frozen=True)
class StructureCandidate:
    symbol: str
    market: str
    pattern_type: str
    phase: str
    quality: str
    start_index: int
    end_index: int
    known_at_index: int
    breakout_index: int | None
    retest_index: int | None
    upper_value: float
    lower_value: float
    invalidation_value: float
    measured_target: float | None
    score: float
    metrics: Mapping[str, object]
    evidence: tuple[str, ...]


@dataclass(frozen=True)
class LongBoxConfig:
    window_lengths: tuple[int, ...] = (120, 160, 200, 250, 320, 400, 500)
    recent_breakout_bars: int = 25
    max_width_ratio: float = 0.35
    min_inside_ratio: float = 0.80
    min_touch_clusters: int = 3
    touch_tolerance_ratio: float = 0.025
    max_boundary_drift_ratio: float = 0.75
    max_atr_contraction_ratio: float = 1.0
    max_volume_contraction_ratio: float = 1.0
    min_breakout_volume_ratio: float = 1.5


class LongBoxDetector:
    def __init__(self, config: LongBoxConfig | None = None) -> None:
        self.config = config or LongBoxConfig()

    def detect(
        self,
        symbol: str,
        market: str,
        context: StructureContext,
        as_of_index: int | None = None,
    ) -> tuple[StructureCandidate, ...]:
        bars = context.bars
        if not bars:
            return ()
        end = len(bars) - 1 if as_of_index is None else min(as_of_index, len(bars) - 1)
        if end < min(self.config.window_lengths):
            return ()
        start_breakout = max(min(self.config.window_lengths), end - self.config.recent_breakout_bars + 1)
        matches: list[StructureCandidate] = []
        breakout_indexes = _recent_volume_breakout_indexes(
            bars,
            start_breakout,
            end,
            self.config.min_breakout_volume_ratio,
        )
        for breakout_index in breakout_indexes:
            for window in self.config.window_lengths:
                if breakout_index < window:
                    continue
                candidate = self._candidate(
                    symbol,
                    market,
                    context,
                    breakout_index=breakout_index,
                    as_of_index=end,
                    window=window,
                )
                if candidate is not None:
                    matches.append(candidate)
        if not matches:
            return ()
        return (max(matches, key=lambda item: (item.score, item.known_at_index, item.start_index)),)

    def _candidate(
        self,
        symbol: str,
        market: str,
        context: StructureContext,
        *,
        breakout_index: int,
        as_of_index: int,
        window: int,
    ) -> StructureCandidate | None:
        bars = context.bars
        base = bars[breakout_index - window : breakout_index]
        highs = np.asarray([bar.high for bar in base], dtype=float)
        lows = np.asarray([bar.low for bar in base], dtype=float)
        closes = np.asarray([bar.close for bar in base], dtype=float)
        volumes = np.asarray([bar.volume for bar in base], dtype=float)
        upper = float(np.quantile(highs, 0.90))
        lower = float(np.quantile(lows, 0.10))
        middle = (upper + lower) / 2.0
        if lower <= 0 or middle <= 0 or upper <= lower:
            return None
        width_ratio = (upper - lower) / middle
        if width_ratio > self.config.max_width_ratio:
            return None
        tolerance = self.config.touch_tolerance_ratio
        inside_ratio = float(
            np.mean((closes >= lower * (1.0 - tolerance)) & (closes <= upper * (1.0 + tolerance)))
        )
        if inside_ratio < self.config.min_inside_ratio:
            return None
        upper_touches = _touch_cluster_count(highs >= upper * (1.0 - tolerance))
        lower_touches = _touch_cluster_count(lows <= lower * (1.0 + tolerance))
        if min(upper_touches, lower_touches) < self.config.min_touch_clusters:
            return None

        third = max(30, window // 3)
        early_upper = float(np.quantile(highs[:third], 0.90))
        late_upper = float(np.quantile(highs[-third:], 0.90))
        early_lower = float(np.quantile(lows[:third], 0.10))
        late_lower = float(np.quantile(lows[-third:], 0.10))
        boundary_drift = (
            abs(late_upper - early_upper) + abs(late_lower - early_lower)
        ) / max(upper - lower, 1e-9)
        if boundary_drift > self.config.max_boundary_drift_ratio:
            return None

        early_count = min(60, max(30, window // 3))
        early_atr = _mean_true_range(base[:early_count]) / max(
            float(np.mean(closes[:early_count])), 1e-9
        )
        late_atr = _mean_true_range(base[-40:]) / max(float(np.mean(closes[-40:])), 1e-9)
        atr_contraction = late_atr / max(early_atr, 1e-9)
        volume_contraction = float(np.mean(volumes[-40:])) / max(
            float(np.mean(volumes[:early_count])), 1e-9
        )
        if atr_contraction > self.config.max_atr_contraction_ratio:
            return None
        if volume_contraction > self.config.max_volume_contraction_ratio:
            return None

        breakout_bar = bars[breakout_index]
        atr = context.atr_14[breakout_index] or _mean_true_range(base[-14:])
        breakout_threshold = max(upper * 0.015, atr * 0.5)
        if breakout_bar.close <= upper + breakout_threshold:
            return None
        prior_volume = float(np.mean([bar.volume for bar in bars[max(0, breakout_index - 20) : breakout_index]]))
        volume_ratio = breakout_bar.volume / max(prior_volume, 1e-9)
        if volume_ratio < self.config.min_breakout_volume_ratio:
            return None

        phase = "BREAKOUT_CONFIRMED"
        retest_index: int | None = None
        consecutive_inside = 0
        retest_tolerance = max(upper * 0.03, atr)
        for index in range(breakout_index + 1, as_of_index + 1):
            bar = bars[index]
            if bar.close < upper * 0.99:
                consecutive_inside += 1
            else:
                consecutive_inside = 0
            if consecutive_inside >= 2:
                phase = "FAILED"
                break
            if retest_index is None and (
                abs(bar.low - upper) <= retest_tolerance
                and bar.close >= upper * 0.985
            ):
                retest_index = index
                phase = "RETEST_CONFIRMED"
            if retest_index is not None and bar.close > breakout_bar.close * 1.01:
                phase = "ACCELERATION"

        duration_score = min(window, 400) / 400.0 * 15.0
        touch_score = min(20.0, (upper_touches + lower_touches) * 2.0)
        stability_score = min(10.0, inside_ratio * 10.0)
        squeeze_score = max(0.0, 1.0 - atr_contraction) * 10.0 + max(
            0.0, 1.0 - volume_contraction
        ) * 10.0
        breakout_score = min(20.0, volume_ratio / 3.0 * 20.0)
        retest_score = 15.0 if retest_index is not None and phase != "FAILED" else 0.0
        score = min(100.0, duration_score + touch_score + stability_score + squeeze_score + breakout_score + retest_score)
        if phase == "FAILED":
            score = max(0.0, score - 30.0)
        quality = "STRONG" if score >= 80 else "NORMAL" if score >= 65 else "WEAK"
        metrics = _frozen_metrics(
            {
                "window_length": window,
                "width_ratio": round(width_ratio, 6),
                "inside_ratio": round(inside_ratio, 6),
                "upper_touches": upper_touches,
                "lower_touches": lower_touches,
                "boundary_drift_ratio": round(boundary_drift, 6),
                "atr_contraction_ratio": round(atr_contraction, 6),
                "volume_contraction_ratio": round(volume_contraction, 6),
                "breakout_volume_ratio": round(volume_ratio, 6),
            }
        )
        return StructureCandidate(
            symbol=symbol,
            market=market,
            pattern_type="LONG_BOX",
            phase=phase,
            quality=quality,
            start_index=breakout_index - window,
            end_index=breakout_index - 1,
            known_at_index=as_of_index,
            breakout_index=breakout_index,
            retest_index=retest_index,
            upper_value=upper,
            lower_value=lower,
            invalidation_value=upper - max(upper * 0.025, atr),
            measured_target=upper + (upper - lower),
            score=round(score, 3),
            metrics=metrics,
            evidence=(
                f"{window} bars inside long box",
                f"touches upper={upper_touches} lower={lower_touches}",
                f"breakout volume ratio={volume_ratio:.2f}",
            ),
        )


@dataclass(frozen=True)
class RightTriangleConfig:
    min_structure_bars: int = 60
    preferred_structure_bars: int = 120
    recent_breakout_bars: int = 12
    min_horizontal_touches: int = 3
    min_sloping_touches: int = 3
    horizontal_tolerance_ratio: float = 0.03
    min_width_contraction: float = 0.35
    min_breakout_volume_ratio: float = 1.5


class RightTriangleDetector:
    def __init__(self, config: RightTriangleConfig | None = None) -> None:
        self.config = config or RightTriangleConfig()

    def detect(
        self,
        symbol: str,
        market: str,
        context: StructureContext,
        as_of_index: int | None = None,
    ) -> tuple[StructureCandidate, ...]:
        if not context.bars:
            return ()
        end = len(context.bars) - 1 if as_of_index is None else min(as_of_index, len(context.bars) - 1)
        matches: list[StructureCandidate] = []
        start_breakout = max(0, end - self.config.recent_breakout_bars + 1)
        for breakout_index in _recent_volume_breakout_indexes(
            context.bars,
            start_breakout,
            end,
            self.config.min_breakout_volume_ratio,
        ):
            candidate = self._candidate(symbol, market, context, breakout_index, end)
            if candidate is not None:
                matches.append(candidate)
        if not matches:
            return ()
        return (max(matches, key=lambda item: (item.score, item.known_at_index)),)

    def _candidate(
        self,
        symbol: str,
        market: str,
        context: StructureContext,
        breakout_index: int,
        as_of_index: int,
    ) -> StructureCandidate | None:
        visible = [
            pivot
            for pivot in context.pivots
            if pivot.confirmed_index < breakout_index and pivot.bar_index < breakout_index
        ]
        highs = [pivot for pivot in visible if pivot.kind == "HIGH"][-6:]
        lows = [pivot for pivot in visible if pivot.kind == "LOW"][-6:]
        if len(highs) < self.config.min_horizontal_touches or len(lows) < self.config.min_sloping_touches:
            return None
        high_group = _best_horizontal_suffix(highs, self.config.horizontal_tolerance_ratio)
        if len(high_group) < self.config.min_horizontal_touches:
            return None
        resistance = float(np.median([pivot.price for pivot in high_group]))
        start_index = min(high_group[0].bar_index, lows[0].bar_index)
        low_group = [pivot for pivot in lows if pivot.bar_index >= start_index]
        if len(low_group) < self.config.min_sloping_touches:
            return None
        low_x = np.asarray([pivot.bar_index for pivot in low_group], dtype=float)
        low_y = np.asarray([pivot.price for pivot in low_group], dtype=float)
        support_slope, support_intercept = np.polyfit(low_x, low_y, 1)
        if support_slope <= 0:
            return None
        structure_bars = breakout_index - start_index
        if structure_bars < self.config.min_structure_bars:
            return None
        start_width = resistance - (support_slope * start_index + support_intercept)
        end_width = resistance - (support_slope * (breakout_index - 1) + support_intercept)
        if start_width <= 0 or end_width <= 0:
            return None
        width_contraction = 1.0 - end_width / start_width
        if width_contraction < self.config.min_width_contraction:
            return None
        base_bars = context.bars[start_index:breakout_index]
        early_count = min(20, max(5, len(base_bars) // 3))
        recent_count = min(20, len(base_bars))
        early_volume = float(np.mean([bar.volume for bar in base_bars[:early_count]]))
        recent_volume = float(np.mean([bar.volume for bar in base_bars[-recent_count:]]))
        volume_contraction = recent_volume / max(early_volume, 1e-9)
        if volume_contraction > 1.0:
            return None

        bar = context.bars[breakout_index]
        atr = context.atr_14[breakout_index] or _mean_true_range(base_bars[-14:])
        if bar.close <= resistance + max(resistance * 0.01, atr * 0.5):
            return None
        prior_volume = float(
            np.mean([item.volume for item in context.bars[max(0, breakout_index - 20) : breakout_index]])
        )
        breakout_volume_ratio = bar.volume / max(prior_volume, 1e-9)
        if breakout_volume_ratio < self.config.min_breakout_volume_ratio:
            return None

        phase = "BREAKOUT_CONFIRMED"
        retest_index: int | None = None
        consecutive_inside = 0
        for index in range(breakout_index + 1, as_of_index + 1):
            current = context.bars[index]
            if current.close < resistance * 0.99:
                consecutive_inside += 1
            else:
                consecutive_inside = 0
            if consecutive_inside >= 2:
                phase = "FAILED"
                break
            if retest_index is None and abs(current.low - resistance) <= max(resistance * 0.03, atr) and current.close >= resistance * 0.985:
                retest_index = index
                phase = "RETEST_CONFIRMED"
            if retest_index is not None and current.close > bar.close * 1.01:
                phase = "ACCELERATION"

        duration_score = min(15.0, structure_bars / self.config.preferred_structure_bars * 15.0)
        touch_score = min(20.0, (len(high_group) + len(low_group)) * 2.5)
        contraction_score = min(20.0, width_contraction / 0.70 * 20.0)
        squeeze_score = max(0.0, 1.0 - volume_contraction) * 10.0
        breakout_score = min(20.0, breakout_volume_ratio / 3.0 * 20.0)
        retest_score = 15.0 if retest_index is not None and phase != "FAILED" else 0.0
        score = min(100.0, duration_score + touch_score + contraction_score + squeeze_score + breakout_score + retest_score)
        if phase == "FAILED":
            score = max(0.0, score - 30.0)
        quality = "STRONG" if score >= 80 else "NORMAL" if score >= 65 else "WEAK"
        support_at_breakout = float(support_slope * breakout_index + support_intercept)
        return StructureCandidate(
            symbol=symbol,
            market=market,
            pattern_type="RIGHT_TRIANGLE",
            phase=phase,
            quality=quality,
            start_index=start_index,
            end_index=breakout_index - 1,
            known_at_index=as_of_index,
            breakout_index=breakout_index,
            retest_index=retest_index,
            upper_value=resistance,
            lower_value=support_at_breakout,
            invalidation_value=resistance - max(resistance * 0.025, atr),
            measured_target=resistance + start_width,
            score=round(score, 3),
            metrics=_frozen_metrics(
                {
                    "horizontal_touch_count": len(high_group),
                    "sloping_touch_count": len(low_group),
                    "support_slope": round(float(support_slope), 8),
                    "width_contraction": round(width_contraction, 6),
                    "volume_contraction_ratio": round(volume_contraction, 6),
                    "breakout_volume_ratio": round(breakout_volume_ratio, 6),
                }
            ),
            evidence=(
                f"horizontal resistance touches={len(high_group)}",
                f"rising support touches={len(low_group)}",
                f"breakout volume ratio={breakout_volume_ratio:.2f}",
            ),
        )


@dataclass(frozen=True)
class SymmetricTriangleConfig:
    min_structure_bars: int = 60
    recent_breakout_bars: int = 12
    min_high_pivots: int = 3
    min_low_pivots: int = 3
    max_residual_height_ratio: float = 0.12
    max_apex_distance_ratio: float = 0.80
    min_width_contraction: float = 0.40
    min_breakout_volume_ratio: float = 1.5


class SymmetricTriangleDetector:
    def __init__(self, config: SymmetricTriangleConfig | None = None) -> None:
        self.config = config or SymmetricTriangleConfig()

    def detect(
        self,
        symbol: str,
        market: str,
        context: StructureContext,
        as_of_index: int | None = None,
    ) -> tuple[StructureCandidate, ...]:
        if not context.bars:
            return ()
        end = len(context.bars) - 1 if as_of_index is None else min(as_of_index, len(context.bars) - 1)
        matches: list[StructureCandidate] = []
        start_breakout = max(0, end - self.config.recent_breakout_bars + 1)
        for breakout_index in _recent_volume_breakout_indexes(
            context.bars,
            start_breakout,
            end,
            self.config.min_breakout_volume_ratio,
        ):
            candidate = self._candidate(symbol, market, context, breakout_index, end)
            if candidate is not None:
                matches.append(candidate)
        if not matches:
            return ()
        return (max(matches, key=lambda item: (item.score, item.known_at_index)),)

    def _candidate(
        self,
        symbol: str,
        market: str,
        context: StructureContext,
        breakout_index: int,
        as_of_index: int,
    ) -> StructureCandidate | None:
        visible = [
            pivot
            for pivot in context.pivots
            if pivot.confirmed_index < breakout_index and pivot.bar_index < breakout_index
        ]
        highs = [pivot for pivot in visible if pivot.kind == "HIGH"][-6:]
        lows = [pivot for pivot in visible if pivot.kind == "LOW"][-6:]
        if len(highs) < self.config.min_high_pivots or len(lows) < self.config.min_low_pivots:
            return None
        high_x = np.asarray([pivot.bar_index for pivot in highs], dtype=float)
        high_y = np.asarray([pivot.price for pivot in highs], dtype=float)
        low_x = np.asarray([pivot.bar_index for pivot in lows], dtype=float)
        low_y = np.asarray([pivot.price for pivot in lows], dtype=float)
        resistance_slope, resistance_intercept = np.polyfit(high_x, high_y, 1)
        support_slope, support_intercept = np.polyfit(low_x, low_y, 1)
        if resistance_slope >= 0 or support_slope <= 0:
            return None
        start_index = min(highs[0].bar_index, lows[0].bar_index)
        last_anchor = max(highs[-1].bar_index, lows[-1].bar_index)
        structure_bars = breakout_index - start_index
        if structure_bars < self.config.min_structure_bars:
            return None
        start_upper = resistance_slope * start_index + resistance_intercept
        start_lower = support_slope * start_index + support_intercept
        start_width = start_upper - start_lower
        breakout_upper = resistance_slope * breakout_index + resistance_intercept
        breakout_lower = support_slope * breakout_index + support_intercept
        end_width = breakout_upper - breakout_lower
        if start_width <= 0 or end_width <= 0:
            return None
        width_contraction = 1.0 - end_width / start_width
        if width_contraction < self.config.min_width_contraction:
            return None
        high_residual = max(abs(high_y - (resistance_slope * high_x + resistance_intercept)))
        low_residual = max(abs(low_y - (support_slope * low_x + support_intercept)))
        if max(high_residual, low_residual) / start_width > self.config.max_residual_height_ratio:
            return None
        denominator = resistance_slope - support_slope
        if abs(denominator) < 1e-12:
            return None
        apex_index = (support_intercept - resistance_intercept) / denominator
        if apex_index <= last_anchor:
            return None
        if apex_index - last_anchor > structure_bars * self.config.max_apex_distance_ratio:
            return None
        if breakout_index >= apex_index:
            return None

        base_bars = context.bars[start_index:breakout_index]
        early_count = min(20, max(5, len(base_bars) // 3))
        recent_count = min(20, len(base_bars))
        early_volume = float(np.mean([bar.volume for bar in base_bars[:early_count]]))
        recent_volume = float(np.mean([bar.volume for bar in base_bars[-recent_count:]]))
        volume_contraction = recent_volume / max(early_volume, 1e-9)
        early_atr = _mean_true_range(base_bars[:early_count]) / max(
            float(np.mean([bar.close for bar in base_bars[:early_count]])), 1e-9
        )
        recent_atr = _mean_true_range(base_bars[-recent_count:]) / max(
            float(np.mean([bar.close for bar in base_bars[-recent_count:]])), 1e-9
        )
        atr_contraction = recent_atr / max(early_atr, 1e-9)
        if volume_contraction > 1.0 or atr_contraction > 1.0:
            return None

        breakout_bar = context.bars[breakout_index]
        atr = context.atr_14[breakout_index] or _mean_true_range(base_bars[-14:])
        if breakout_bar.close <= breakout_upper + max(breakout_upper * 0.01, atr * 0.5):
            return None
        prior_volume = float(
            np.mean([item.volume for item in context.bars[max(0, breakout_index - 20) : breakout_index]])
        )
        breakout_volume_ratio = breakout_bar.volume / max(prior_volume, 1e-9)
        if breakout_volume_ratio < self.config.min_breakout_volume_ratio:
            return None

        phase = "BREAKOUT_CONFIRMED"
        retest_index: int | None = None
        consecutive_inside = 0
        for index in range(breakout_index + 1, as_of_index + 1):
            current = context.bars[index]
            upper_at_index = resistance_slope * index + resistance_intercept
            if current.close < upper_at_index * 0.99:
                consecutive_inside += 1
            else:
                consecutive_inside = 0
            if consecutive_inside >= 2:
                phase = "FAILED"
                break
            if retest_index is None and abs(current.low - upper_at_index) <= max(upper_at_index * 0.03, atr) and current.close >= upper_at_index * 0.985:
                retest_index = index
                phase = "RETEST_CONFIRMED"
            if retest_index is not None and current.close > breakout_bar.close * 1.01:
                phase = "ACCELERATION"

        score = min(
            100.0,
            min(15.0, structure_bars / 120.0 * 15.0)
            + min(20.0, (len(highs) + len(lows)) * 2.5)
            + min(20.0, width_contraction / 0.70 * 20.0)
            + max(0.0, 1.0 - atr_contraction) * 10.0
            + max(0.0, 1.0 - volume_contraction) * 10.0
            + min(20.0, breakout_volume_ratio / 3.0 * 20.0)
            + (15.0 if retest_index is not None and phase != "FAILED" else 0.0),
        )
        if phase == "FAILED":
            score = max(0.0, score - 30.0)
        quality = "STRONG" if score >= 80 else "NORMAL" if score >= 65 else "WEAK"
        return StructureCandidate(
            symbol=symbol,
            market=market,
            pattern_type="SYMMETRIC_TRIANGLE",
            phase=phase,
            quality=quality,
            start_index=start_index,
            end_index=breakout_index - 1,
            known_at_index=as_of_index,
            breakout_index=breakout_index,
            retest_index=retest_index,
            upper_value=float(breakout_upper),
            lower_value=float(breakout_lower),
            invalidation_value=float(breakout_upper - max(breakout_upper * 0.025, atr)),
            measured_target=float(breakout_upper + start_width),
            score=round(score, 3),
            metrics=_frozen_metrics(
                {
                    "high_touch_count": len(highs),
                    "low_touch_count": len(lows),
                    "resistance_slope": round(float(resistance_slope), 8),
                    "support_slope": round(float(support_slope), 8),
                    "width_contraction": round(float(width_contraction), 6),
                    "apex_index": round(float(apex_index), 6),
                    "atr_contraction_ratio": round(float(atr_contraction), 6),
                    "volume_contraction_ratio": round(float(volume_contraction), 6),
                    "breakout_volume_ratio": round(float(breakout_volume_ratio), 6),
                }
            ),
            evidence=(
                f"falling highs={len(highs)} rising lows={len(lows)}",
                f"width contraction={width_contraction:.1%}",
                f"breakout volume ratio={breakout_volume_ratio:.2f}",
            ),
        )


def scan_history(
    symbol: str,
    market: str,
    rows: Sequence[Mapping[str, object]],
    *,
    detectors: Sequence[object],
) -> tuple[StructureCandidate, ...]:
    bars = normalize_bars(rows)
    context = build_structure_context(bars)
    history: list[StructureCandidate] = []
    seen: set[tuple[object, ...]] = set()
    for as_of_index in range(len(bars)):
        for detector in detectors:
            detected = detector.detect(symbol, market, context, as_of_index=as_of_index)
            for candidate in detected:
                key = (
                    candidate.pattern_type,
                    candidate.phase,
                    candidate.start_index,
                    candidate.breakout_index,
                    candidate.known_at_index,
                )
                if key not in seen:
                    seen.add(key)
                    history.append(candidate)
    return tuple(history)


DEFAULT_DETECTORS: tuple[object, ...] = (
    LongBoxDetector(),
    RightTriangleDetector(),
    SymmetricTriangleDetector(),
)

_DEFAULT_CANDIDATE_PHASES = {
    "BREAKOUT_CONFIRMED",
    "RETEST_CONFIRMED",
    "ACCELERATION",
}

_PHASE_MATURITY = {
    "FORMING": 0,
    "SQUEEZE": 1,
    "BREAKOUT_WATCH": 2,
    "BREAKOUT_CONFIRMED": 3,
    "RETEST_CONFIRMED": 4,
    "ACCELERATION": 5,
    "INVALIDATED": -1,
    "FAILED": -2,
}


def scan_symbol(
    symbol: str,
    market: str,
    rows: Sequence[Mapping[str, object]],
    *,
    include_debug: bool = False,
    detectors: Sequence[object] = DEFAULT_DETECTORS,
) -> tuple[StructureCandidate, ...]:
    bars = normalize_bars(rows)
    return scan_normalized_symbol(
        symbol,
        market,
        bars,
        include_debug=include_debug,
        detectors=detectors,
    )


def scan_normalized_symbol(
    symbol: str,
    market: str,
    bars: Sequence[StructureBar],
    *,
    include_debug: bool = False,
    detectors: Sequence[object] = DEFAULT_DETECTORS,
) -> tuple[StructureCandidate, ...]:
    bars = tuple(bars)
    if not bars:
        return ()
    recent_start = max(0, len(bars) - 25)
    if not _recent_volume_breakout_indexes(bars, recent_start, len(bars) - 1, 1.5):
        return ()
    context = build_structure_context(bars)
    candidates: list[StructureCandidate] = []
    for detector in detectors:
        candidates.extend(detector.detect(symbol, market, context))
    if not include_debug:
        candidates = [
            candidate for candidate in candidates if candidate.phase in _DEFAULT_CANDIDATE_PHASES
        ]
    return tuple(
        sorted(
            candidates,
            key=lambda item: (
                _PHASE_MATURITY.get(item.phase, -99),
                item.score,
                item.known_at_index,
                item.pattern_type,
            ),
            reverse=True,
        )
    )


def rank_candidates(
    candidates: Iterable[StructureCandidate], top_n: int = 5
) -> tuple[StructureCandidate, ...]:
    grouped: dict[tuple[str, str], list[StructureCandidate]] = {}
    for candidate in candidates:
        grouped.setdefault((candidate.market.lower(), candidate.symbol.upper()), []).append(candidate)
    primary: list[StructureCandidate] = []
    for values in grouped.values():
        ordered = sorted(
            values,
            key=lambda item: (
                _PHASE_MATURITY.get(item.phase, -99),
                item.score,
                item.known_at_index,
                item.pattern_type,
            ),
            reverse=True,
        )
        winner = ordered[0]
        alternates = tuple(
            dict.fromkeys(item.pattern_type for item in ordered[1:] if item.pattern_type != winner.pattern_type)
        )
        metrics = dict(winner.metrics)
        metrics["alternate_patterns"] = alternates
        primary.append(replace(winner, metrics=_frozen_metrics(metrics)))
    primary.sort(
        key=lambda item: (
            _PHASE_MATURITY.get(item.phase, -99),
            item.score,
            item.known_at_index,
            item.symbol,
        ),
        reverse=True,
    )
    return tuple(primary[: max(0, top_n)])


def normalize_bars(rows: Sequence[Mapping[str, object]]) -> tuple[StructureBar, ...]:
    by_date: dict[date, tuple[float, float, float, float, float, float | None]] = {}
    for raw in rows:
        try:
            trade_date = _as_date(raw.get("trade_date", raw.get("date")))
            open_ = float(raw["open"])
            high = float(raw["high"])
            low = float(raw["low"])
            close = float(raw["close"])
            volume = float(raw.get("volume", 0.0) or 0.0)
            turnover_raw = raw.get("turnover")
            turnover = None if turnover_raw is None else float(turnover_raw)
        except (KeyError, TypeError, ValueError, OverflowError):
            continue
        values = (open_, high, low, close, volume)
        if not all(np.isfinite(value) for value in values):
            continue
        if min(open_, high, low, close) <= 0 or volume < 0:
            continue
        if not (low <= min(open_, close) <= max(open_, close) <= high):
            continue
        if turnover is not None and (not np.isfinite(turnover) or turnover < 0):
            turnover = None
        by_date[trade_date] = (open_, high, low, close, volume, turnover)

    normalized: list[StructureBar] = []
    previous_signature: tuple[float, float, float, float, float] | None = None
    for trade_date in sorted(by_date):
        open_, high, low, close, volume, turnover = by_date[trade_date]
        signature = (open_, high, low, close, volume)
        if signature == previous_signature:
            continue
        normalized.append(
            StructureBar(
                index=len(normalized),
                trade_date=trade_date,
                open=open_,
                high=high,
                low=low,
                close=close,
                volume=volume,
                turnover=turnover,
            )
        )
        previous_signature = signature
    return tuple(normalized)


def build_structure_context(bars: Sequence[StructureBar]) -> StructureContext:
    values = tuple(replace(bar, index=index) for index, bar in enumerate(bars))
    turnovers = tuple(
        bar.turnover if bar.turnover is not None else bar.close * bar.volume for bar in values
    )
    return StructureContext(
        bars=values,
        pivots=CausalPivotDetector().detect(values),
        atr_14=_rolling_atr(values, 14),
        volume_ma_20=_rolling_mean(tuple(bar.volume for bar in values), 20),
        turnover_ma_20=_rolling_mean(turnovers, 20),
    )


def _as_date(value: object) -> date:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value)[:10])


def _rolling_mean(values: Sequence[float], period: int) -> tuple[float | None, ...]:
    output: list[float | None] = []
    total = 0.0
    for index, value in enumerate(values):
        total += float(value)
        if index >= period:
            total -= float(values[index - period])
        output.append(total / period if index + 1 >= period else None)
    return tuple(output)


def _rolling_atr(bars: Sequence[StructureBar], period: int) -> tuple[float | None, ...]:
    true_ranges: list[float] = []
    previous_close: float | None = None
    for bar in bars:
        true_ranges.append(
            bar.high - bar.low
            if previous_close is None
            else max(
                bar.high - bar.low,
                abs(bar.high - previous_close),
                abs(bar.low - previous_close),
            )
        )
        previous_close = bar.close
    return _rolling_mean(true_ranges, period)


def _mean_true_range(bars: Sequence[StructureBar]) -> float:
    if not bars:
        return 0.0
    ranges: list[float] = []
    previous_close: float | None = None
    for bar in bars:
        ranges.append(
            bar.high - bar.low
            if previous_close is None
            else max(
                bar.high - bar.low,
                abs(bar.high - previous_close),
                abs(bar.low - previous_close),
            )
        )
        previous_close = bar.close
    return float(np.mean(ranges))


def _touch_cluster_count(mask: np.ndarray, gap: int = 5) -> int:
    indexes = np.flatnonzero(mask)
    if len(indexes) == 0:
        return 0
    return 1 + int(np.sum(np.diff(indexes) >= gap))


def _recent_volume_breakout_indexes(
    bars: Sequence[StructureBar],
    start_index: int,
    end_index: int,
    min_volume_ratio: float,
    period: int = 20,
) -> tuple[int, ...]:
    eligible: list[int] = []
    for index in range(max(period, start_index), min(end_index, len(bars) - 1) + 1):
        prior = bars[index - period : index]
        average = sum(bar.volume for bar in prior) / period
        if average > 0 and bars[index].volume / average >= min_volume_ratio:
            eligible.append(index)
    return tuple(eligible)


def _best_horizontal_suffix(
    pivots: Sequence[DetectedPivot], tolerance_ratio: float
) -> tuple[DetectedPivot, ...]:
    best: tuple[DetectedPivot, ...] = ()
    for size in range(3, len(pivots) + 1):
        group = tuple(pivots[-size:])
        median_price = float(np.median([pivot.price for pivot in group]))
        dispersion = max(abs(pivot.price - median_price) for pivot in group) / max(
            abs(median_price), 1e-9
        )
        if dispersion <= tolerance_ratio:
            best = group
    return best


def _frozen_metrics(values: Mapping[str, object]) -> Mapping[str, object]:
    return MappingProxyType(dict(values))

from __future__ import annotations

from datetime import date, datetime
from math import erf, exp, floor, log, pi, sqrt
from typing import Any, Iterable

from longbridge_stock.asset_allocation import cap_contracts_by_allocation
from longbridge_stock.push_output import render_key_value_table


DEFAULT_TARGET_MONTHLY_INCOME = 5000.0


def build_option_income_plan(
    *,
    account: dict[str, Any],
    positions: list[dict[str, Any]],
    underlying_quotes: dict[str, float],
    option_quotes: list[dict[str, Any]],
    as_of: date | datetime,
    allocation_budget: dict[str, Any] | None = None,
    daily_bars_by_symbol: dict[str, list[dict[str, Any]]] | None = None,
    target_monthly_income: float = DEFAULT_TARGET_MONTHLY_INCOME,
    min_underlying_safe_rate: float = 0.72,
    min_underlying_samples: int = 20,
    min_iv_hv_ratio: float = 0.95,
    min_abs_delta: float = 0.05,
    max_abs_delta: float = 0.40,
    max_covered_call_contracts: int = 20,
    max_put_contracts_per_symbol: int = 1,
    max_put_buy_power_pct: float = 0.35,
    max_put_notional_pct: float = 0.08,
    max_recommendations: int = 5,
) -> dict[str, Any]:
    current_date = as_of.date() if isinstance(as_of, datetime) else as_of
    net_assets = _num(account.get("net_assets") or account.get("total_asset"))
    buy_power = _num(account.get("buy_power"))
    init_margin = _num(account.get("init_margin"))
    monthly_target = max(0.0, float(target_monthly_income))
    weekly_target = round(monthly_target / 4)
    shares = _share_positions(positions)
    risk = _risk_state(net_assets=net_assets, buy_power=buy_power, init_margin=init_margin)

    covered_calls = []
    puts = []
    rejected = []
    for row in option_quotes:
        normalized = _candidate_from_row(row, underlying_quotes=underlying_quotes, as_of=current_date)
        if not normalized:
            continue
        option_features = normalized.get("option_features") or {}
        iv_hv_ratio = option_features.get("iv_hv_ratio")
        if iv_hv_ratio is not None and float(iv_hv_ratio) < min_iv_hv_ratio:
            rejected.append({**normalized, "reason": "iv_hv_ratio_too_low"})
            continue
        delta = option_features.get("delta")
        if delta is not None:
            abs_delta = abs(float(delta))
            if abs_delta < min_abs_delta or abs_delta > max_abs_delta:
                rejected.append({**normalized, "reason": "delta_out_of_range"})
                continue
        safety = None
        if daily_bars_by_symbol and normalized["underlying_symbol"] in daily_bars_by_symbol:
            safety = backtest_option_safety(
                daily_bars_by_symbol[normalized["underlying_symbol"]],
                strategy=normalized["strategy"],
                spot=normalized["spot"],
                strike=normalized["strike_price"],
                dte=normalized["dte"],
            )
            normalized["underlying_safety"] = safety
            if safety["sample_count"] >= min_underlying_samples and safety["safe_rate"] < min_underlying_safe_rate:
                rejected.append({**normalized, "reason": "underlying_backtest_unsafe"})
                continue
        if normalized["strategy"] == "Covered Call":
            owned_contracts = floor(shares.get(normalized["underlying_symbol"], 0.0) / 100.0)
            if owned_contracts <= 0:
                continue
            suggested = min(owned_contracts, max(1, int(max_covered_call_contracts)))
            normalized["suggested_contracts"] = suggested
            normalized["estimated_income"] = round(normalized["premium"] * 100 * suggested, 2)
            normalized["score"] = _covered_call_score(normalized)
            covered_calls.append(normalized)
        elif normalized["strategy"] == "Sell Put" and risk["allow_new_puts"]:
            notional = normalized["strike_price"] * 100
            if notional <= 0:
                continue
            max_symbol_notional = net_assets * max_put_notional_pct if net_assets > 0 else notional
            max_buy_power_notional = buy_power * max_put_buy_power_pct if buy_power > 0 else notional
            suggested = floor(min(max_symbol_notional, max_buy_power_notional) / notional)
            suggested = min(max(0, suggested), max(1, int(max_put_contracts_per_symbol)))
            if allocation_budget:
                suggested = cap_contracts_by_allocation(
                    requested_contracts=suggested,
                    strategy=normalized["strategy"],
                    underlying_symbol=normalized["underlying_symbol"],
                    strike_price=normalized["strike_price"],
                    budget=allocation_budget,
                )
            if suggested <= 0:
                continue
            normalized["suggested_contracts"] = suggested
            normalized["estimated_income"] = round(normalized["premium"] * 100 * suggested, 2)
            normalized["score"] = _put_score(normalized)
            puts.append(normalized)

    covered_calls.sort(key=lambda row: row["score"], reverse=True)
    puts.sort(key=lambda row: row["score"], reverse=True)
    covered_calls = _best_per_underlying(covered_calls)
    puts = _best_per_underlying(puts)
    recommendations = sorted([*covered_calls, *puts], key=lambda row: row["score"], reverse=True)[:max_recommendations]
    estimated_income = round(sum(row["estimated_income"] for row in recommendations), 2)
    return {
        "target_monthly_income": round(monthly_target, 2),
        "weekly_target": weekly_target,
        "account": {
            "net_assets": round(net_assets, 2),
            "buy_power": round(buy_power, 2),
            "init_margin": round(init_margin, 2),
            "cash_usd": round(_num(account.get("cash_usd")), 2),
        },
        "risk": risk,
        "covered_calls": covered_calls[:max_recommendations],
        "puts": puts[:max_recommendations],
        "rejected": rejected,
        "recommendations": recommendations,
        "allocation_budget": allocation_budget,
        "estimated_income": estimated_income,
        "progress_pct": round(estimated_income / weekly_target * 100, 1) if weekly_target else 0.0,
    }


def build_option_income_message(plan: dict[str, Any], *, as_of_label: str) -> str:
    account = plan.get("account") or {}
    allocation_budget = plan.get("allocation_budget") or {}
    option_limit = (allocation_budget.get("strategy_limits") or {}).get("option_income") or {}
    rows: list[tuple[str, Any]] = [
        ("月目标", f"${plan.get('target_monthly_income', 0):,.0f}"),
        ("周目标", f"${plan.get('weekly_target', 0):,.0f}"),
        ("本轮候选收入", f"${plan.get('estimated_income', 0):,.0f} ({plan.get('progress_pct', 0)}%)"),
        ("买力/净资产", f"${_num(account.get('buy_power')):,.0f} / ${_num(account.get('net_assets')):,.0f}"),
        ("保证金状态", (plan.get("risk") or {}).get("note", "-")),
    ]
    if allocation_budget:
        rows.append(("资产配置", f"{_allocation_status_text(allocation_budget.get('status'))}, 现金保留${_num(allocation_budget.get('reserve_cash')):,.0f}"))
    if option_limit:
        rows.append(
            (
                "期权收入预算",
                f"已用${_num(option_limit.get('current')):,.0f} / 目标${_num(option_limit.get('target')):,.0f}，剩余${_num(option_limit.get('remaining')):,.0f}",
            )
        )
    for index, row in enumerate(plan.get("recommendations") or [], start=1):
        rows.append((f"#{index} {row['strategy']}", _recommendation_line(row)))
    if not plan.get("recommendations"):
        if option_limit and _num(option_limit.get("remaining")) <= 0:
            rows.append(("候选", "期权收入预算已满，暂停新增卖 Put，只保留降风险/滚仓机会"))
        else:
            rows.append(("候选", "当前没有满足风控条件的卖权候选"))
    return render_key_value_table(f"【美股卖权计划】{as_of_label}", rows)


def summarize_existing_short_options(portfolio_holdings: Iterable[dict[str, Any]]) -> dict[str, Any]:
    sold_premium = 0.0
    mark_to_close = 0.0
    count = 0
    for row in portfolio_holdings:
        symbol = str(row.get("symbol") or "").upper()
        quantity = _num(row.get("quantity"))
        if quantity >= 0 or not _looks_like_us_option(symbol):
            continue
        contracts = abs(quantity)
        sold_premium += _num(row.get("cost_price")) * contracts * 100
        mark_to_close += _num(row.get("market_price")) * contracts * 100
        count += 1
    return {
        "count": count,
        "sold_premium": round(sold_premium, 2),
        "mark_to_close": round(mark_to_close, 2),
        "unrealized_credit_left": round(sold_premium - mark_to_close, 2),
    }


def backtest_option_safety(
    bars: list[dict[str, Any]],
    *,
    strategy: str,
    spot: float,
    strike: float,
    dte: int,
) -> dict[str, Any]:
    ordered = sorted(bars, key=lambda row: str(row.get("trade_date") or ""))
    window = max(1, int(dte))
    ratio = _num(strike) / _num(spot) if _num(spot) > 0 else 0.0
    if ratio <= 0 or len(ordered) <= window:
        return {"sample_count": 0, "safe_count": 0, "safe_rate": 0.0, "breach_count": 0, "worst_breach_pct": None}
    safe_count = 0
    worst_breach_pct: float | None = None
    sample_count = 0
    for index in range(0, len(ordered) - window):
        close = _num(ordered[index].get("close"))
        if close <= 0:
            continue
        threshold = close * ratio
        future = ordered[index + 1 : index + 1 + window]
        if not future:
            continue
        sample_count += 1
        if strategy == "Sell Put":
            future_low = min(_num(row.get("low")) for row in future)
            safe = future_low >= threshold
            breach_pct = (future_low / threshold - 1.0) * 100 if threshold > 0 else 0.0
        else:
            future_high = max(_num(row.get("high")) for row in future)
            safe = future_high <= threshold
            breach_pct = (threshold / future_high - 1.0) * 100 if future_high > 0 else 0.0
        if safe:
            safe_count += 1
        else:
            worst_breach_pct = breach_pct if worst_breach_pct is None else min(worst_breach_pct, breach_pct)
    return {
        "sample_count": sample_count,
        "safe_count": safe_count,
        "safe_rate": round(safe_count / sample_count, 4) if sample_count else 0.0,
        "breach_count": sample_count - safe_count,
        "worst_breach_pct": round(worst_breach_pct, 2) if worst_breach_pct is not None else None,
    }


def estimate_option_greeks(
    *,
    option_type: str,
    spot: float,
    strike: float,
    dte: int,
    implied_volatility: float,
    risk_free_rate: float = 0.04,
) -> dict[str, float | None]:
    spot_value = _num(spot)
    strike_value = _num(strike)
    volatility = _num(implied_volatility)
    time_to_expiry = max(_num(dte), 1.0) / 365.0
    if spot_value <= 0 or strike_value <= 0 or volatility <= 0 or time_to_expiry <= 0:
        return {"delta": None, "gamma": None, "theta": None, "vega": None}

    sqrt_time = sqrt(time_to_expiry)
    d1 = (
        log(spot_value / strike_value)
        + (risk_free_rate + 0.5 * volatility * volatility) * time_to_expiry
    ) / (volatility * sqrt_time)
    d2 = d1 - volatility * sqrt_time
    pdf_d1 = _normal_pdf(d1)

    if option_type == "Call":
        delta = _normal_cdf(d1)
        theta = (
            -(spot_value * pdf_d1 * volatility) / (2.0 * sqrt_time)
            - risk_free_rate * strike_value * exp(-risk_free_rate * time_to_expiry) * _normal_cdf(d2)
        ) / 365.0
    else:
        delta = _normal_cdf(d1) - 1.0
        theta = (
            -(spot_value * pdf_d1 * volatility) / (2.0 * sqrt_time)
            + risk_free_rate * strike_value * exp(-risk_free_rate * time_to_expiry) * _normal_cdf(-d2)
        ) / 365.0

    gamma = pdf_d1 / (spot_value * volatility * sqrt_time)
    vega = spot_value * pdf_d1 * sqrt_time / 100.0
    return {
        "delta": round(delta, 4),
        "gamma": round(gamma, 6),
        "theta": round(theta, 4),
        "vega": round(vega, 4),
    }


def _candidate_from_row(row: dict[str, Any], *, underlying_quotes: dict[str, float], as_of: date) -> dict[str, Any] | None:
    symbol = str(row.get("underlying_symbol") or "").strip().upper()
    contract_symbol = str(row.get("contract_symbol") or row.get("symbol") or "").strip().upper()
    direction = str(row.get("direction") or "").strip()
    spot = _num(underlying_quotes.get(symbol))
    strike = _num(row.get("strike_price"))
    premium = _num(row.get("last"))
    if not symbol or not contract_symbol or spot <= 0 or strike <= 0 or premium <= 0:
        return None
    expiry = _parse_date(row.get("expiry_date"))
    if not expiry:
        return None
    dte = max((expiry - as_of).days, 1)
    if dte < 5 or dte > 35:
        return None
    strategy = ""
    if direction == "Call" and 1.04 * spot <= strike <= 1.35 * spot and premium >= 0.08:
        strategy = "Covered Call"
    elif direction == "Put" and 0.78 * spot <= strike <= 0.94 * spot and premium >= 0.15:
        strategy = "Sell Put"
    if not strategy:
        return None
    annual_yield = premium / strike * 365 / dte if strike > 0 else 0.0
    cushion_pct = (strike / spot - 1.0) * 100 if strategy == "Covered Call" else (1.0 - strike / spot) * 100
    implied_volatility = _num(row.get("implied_volatility"))
    historical_volatility = _num(row.get("historical_volatility"))
    greeks = estimate_option_greeks(
        option_type=direction,
        spot=spot,
        strike=strike,
        dte=dte,
        implied_volatility=implied_volatility,
    )
    iv_hv_ratio = (
        round(implied_volatility / historical_volatility, 3)
        if implied_volatility > 0 and historical_volatility > 0
        else None
    )
    open_interest = int(_num(row.get("open_interest")))
    volume = int(_num(row.get("volume")))
    return {
        "strategy": strategy,
        "contract_symbol": contract_symbol,
        "underlying_symbol": symbol,
        "expiry_date": expiry.isoformat(),
        "dte": dte,
        "spot": round(spot, 4),
        "strike_price": strike,
        "premium": premium,
        "open_interest": open_interest,
        "volume": volume,
        "implied_volatility": implied_volatility,
        "historical_volatility": historical_volatility,
        "option_features": {
            **greeks,
            "iv_hv_ratio": iv_hv_ratio,
            "premium_collateral_yield_pct": round(premium / strike * 100, 3) if strike > 0 else 0.0,
            "theta_income_per_contract": (
                round(abs(_num(greeks.get("theta"))) * 100, 2) if greeks.get("theta") is not None else None
            ),
            "volume_oi_ratio": round(volume / open_interest, 3) if open_interest > 0 else None,
        },
        "annual_yield_pct": round(annual_yield * 100, 1),
        "cushion_pct": round(cushion_pct, 1),
    }


def _risk_state(*, net_assets: float, buy_power: float, init_margin: float) -> dict[str, Any]:
    init_margin_ratio = init_margin / net_assets if net_assets > 0 else 0.0
    buy_power_ratio = buy_power / net_assets if net_assets > 0 else 0.0
    allow_new_puts = init_margin_ratio < 0.85 and buy_power_ratio >= 0.12
    if not allow_new_puts:
        note = "暂停新增卖 Put：保证金或买力接近风控线，只做 Covered Call/减仓管理"
    elif init_margin_ratio >= 0.78 or buy_power_ratio < 0.22:
        note = "谨慎：只允许小张数卖 Put，优先 Covered Call"
    else:
        note = "正常：可按小仓位滚动卖 Put/Call"
    return {
        "allow_new_puts": allow_new_puts,
        "init_margin_ratio": round(init_margin_ratio, 4),
        "buy_power_ratio": round(buy_power_ratio, 4),
        "note": note,
    }


def _covered_call_score(row: dict[str, Any]) -> float:
    liquidity = min(row["open_interest"], 5000) / 5000 * 80 + min(row["volume"], 2000) / 2000 * 40
    safety = (row.get("underlying_safety") or {}).get("safe_rate")
    safety_bonus = float(safety) * 100 if safety is not None else 0.0
    return row["premium"] * 100 + liquidity + row["cushion_pct"] + safety_bonus + _option_feature_score(row)


def _put_score(row: dict[str, Any]) -> float:
    liquidity = min(row["open_interest"], 5000) / 5000 * 30 + min(row["volume"], 2000) / 2000 * 15
    safety = (row.get("underlying_safety") or {}).get("safe_rate")
    safety_bonus = float(safety) * 160 if safety is not None else 0.0
    return (
        row["annual_yield_pct"] * 2
        + liquidity
        + row["premium"] * 10
        + row["cushion_pct"]
        + safety_bonus
        + _option_feature_score(row)
    )


def _option_feature_score(row: dict[str, Any]) -> float:
    features = row.get("option_features") or {}
    delta = abs(_num(features.get("delta")))
    theta_income = _num(features.get("theta_income_per_contract"))
    iv_hv_ratio = features.get("iv_hv_ratio")
    delta_target = 0.22 if row.get("strategy") == "Covered Call" else 0.18
    delta_bonus = max(0.0, 1.0 - abs(delta - delta_target) / max(delta_target, 0.01)) * 45
    theta_bonus = min(theta_income, 25.0) * 2
    iv_bonus = min(max(_num(iv_hv_ratio) - 1.0, 0.0), 1.0) * 35 if iv_hv_ratio is not None else 0.0
    return delta_bonus + theta_bonus + iv_bonus


def _recommendation_line(row: dict[str, Any]) -> str:
    safety = row.get("underlying_safety") or {}
    safety_text = ""
    if safety:
        safety_text = f"，正股回测安全率{float(safety.get('safe_rate') or 0) * 100:.0f}%/{int(safety.get('sample_count') or 0)}次"
    features = row.get("option_features") or {}
    feature_parts = []
    if features.get("delta") is not None:
        feature_parts.append(f"Delta {float(features['delta']):.2f}")
    if features.get("theta_income_per_contract") is not None:
        feature_parts.append(f"Theta收入${float(features['theta_income_per_contract']):.0f}/张/天")
    if features.get("iv_hv_ratio") is not None:
        feature_parts.append(f"IV/HV {float(features['iv_hv_ratio']):.2f}")
    features_text = f"，{'，'.join(feature_parts)}" if feature_parts else ""
    return (
        f"{row['underlying_symbol']} {row['contract_symbol']}，"
        f"{row['suggested_contracts']}张，权利金约${row['estimated_income']:,.0f}，"
        f"现价{row['spot']:.2f}，行权{row['strike_price']:.2f}，"
        f"{row['expiry_date']}到期，DTE {row['dte']}，缓冲{row['cushion_pct']}%"
        f"{safety_text}"
        f"{features_text}"
    )


def _allocation_status_text(status: Any) -> str:
    return {
        "normal": "正常",
        "caution": "谨慎",
        "blocked": "暂停新增",
    }.get(str(status or ""), str(status or "-"))


def _best_per_underlying(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    selected: list[dict[str, Any]] = []
    seen: set[str] = set()
    for row in rows:
        symbol = str(row.get("underlying_symbol") or "")
        if symbol in seen:
            continue
        seen.add(symbol)
        selected.append(row)
    return selected


def _share_positions(positions: Iterable[dict[str, Any]]) -> dict[str, float]:
    shares: dict[str, float] = {}
    for row in positions:
        symbol = str(row.get("symbol") or "").strip().upper()
        if not symbol.endswith(".US") or _looks_like_us_option(symbol):
            continue
        quantity = _num(row.get("quantity"))
        if quantity > 0:
            shares[symbol] = shares.get(symbol, 0.0) + quantity
    return shares


def _looks_like_us_option(symbol: str) -> bool:
    core = symbol.removesuffix(".US")
    return any(marker in core for marker in ("C", "P")) and any(char.isdigit() for char in core)


def _parse_date(value: Any) -> date | None:
    if isinstance(value, date) and not isinstance(value, datetime):
        return value
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return date.fromisoformat(text[:10])
    except ValueError:
        return None


def _num(value: Any) -> float:
    if value is None or value == "":
        return 0.0
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _normal_cdf(value: float) -> float:
    return 0.5 * (1.0 + erf(value / sqrt(2.0)))


def _normal_pdf(value: float) -> float:
    return exp(-0.5 * value * value) / sqrt(2.0 * pi)

from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Iterable


ASIA_SHANGHAI = timezone(timedelta(hours=8))


@dataclass(frozen=True)
class CompanyFundamentalTagConfig:
    symbols: list[str]
    include_valuation: bool = True


def build_company_fundamental_tags(config: CompanyFundamentalTagConfig) -> dict[str, Any]:
    items = [build_company_fundamental_tag(symbol, include_valuation=config.include_valuation) for symbol in config.symbols]
    return {
        "generatedAt": datetime.now(ASIA_SHANGHAI).isoformat(timespec="seconds"),
        "total": len(items),
        "items": items,
    }


def build_company_fundamental_tag(symbol: str, *, include_valuation: bool = True) -> dict[str, Any]:
    normalized = _normalize_symbol(symbol)
    company = _run_longbridge_json(["company", normalized])
    calc_rows = _run_longbridge_json(
        ["calc-index", normalized, "--fields", "pe,pb,dps_rate,turnover_rate,mktcap"]
    )
    calc_index = calc_rows[0] if isinstance(calc_rows, list) and calc_rows else {}
    financial_report = _run_longbridge_json(["financial-report", normalized])
    valuation = _run_longbridge_json(["valuation", normalized]) if include_valuation else {}
    return classify_company_fundamentals(
        normalized,
        company=company if isinstance(company, dict) else {},
        calc_index=calc_index if isinstance(calc_index, dict) else {},
        financial_report=financial_report if isinstance(financial_report, dict) else {},
        valuation=valuation if isinstance(valuation, dict) else {},
    )


def refresh_company_fundamental_tag_store(
    *,
    dsn: str,
    symbols: list[str] | None = None,
    markets: list[str] | None = None,
    limit_per_market: int | None = None,
    batch_size: int = 200,
    include_valuation: bool = False,
    use_offline: bool = True,
    connect: Callable[[str], Any] | None = None,
) -> dict[str, Any]:
    if connect is None:
        import psycopg

        connect = psycopg.connect
    normalized_symbols = [_normalize_symbol(symbol) for symbol in symbols or [] if symbol.strip()]
    as_of = datetime.now(ASIA_SHANGHAI)
    with connect(dsn) as conn:
        ensure_company_fundamental_tag_table(conn)
        if not normalized_symbols:
            normalized_symbols = load_company_profile_symbols(
                conn,
                markets=[item.strip().lower() for item in markets or ["hk", "us", "cn"] if item.strip()],
                limit_per_market=limit_per_market,
            )
        updated = 0
        failed: list[dict[str, str]] = []
        pending_commits = 0
        if use_offline:
            for batch in _chunks(normalized_symbols, max(1, int(batch_size or 200))):
                financial_reports = load_company_fundamental_financial_reports(conn, batch)
                for row in load_company_fundamental_offline_rows(conn, batch):
                    symbol = _normalize_symbol(str(_row_get(row, "symbol") or ""))
                    try:
                        item = build_company_fundamental_tag_from_offline_row(
                            row, financial_report=financial_reports.get(symbol)
                        )
                        upsert_company_fundamental_tag(conn, item, as_of=as_of)
                        updated += 1
                        pending_commits += 1
                        if pending_commits >= 100:
                            _commit_quietly(conn)
                            pending_commits = 0
                    except Exception as exc:  # pragma: no cover - summarized for scheduler logs.
                        _rollback_quietly(conn)
                        pending_commits = 0
                        failed.append({"symbol": symbol, "error": str(exc)})
        else:
            for symbol in normalized_symbols:
                try:
                    item = build_company_fundamental_tag(symbol, include_valuation=include_valuation)
                    upsert_company_fundamental_tag(conn, item, as_of=as_of)
                    updated += 1
                    pending_commits += 1
                    if pending_commits >= 100:
                        _commit_quietly(conn)
                        pending_commits = 0
                except Exception as exc:  # pragma: no cover - live API failures are summarized for scheduler logs.
                    _rollback_quietly(conn)
                    pending_commits = 0
                    failed.append({"symbol": symbol, "error": str(exc)})
        if pending_commits:
            _commit_quietly(conn)
    return {
        "asOf": as_of.isoformat(timespec="seconds"),
        "updated": updated,
        "failed": failed,
        "total": len(normalized_symbols),
        "batchSize": batch_size if use_offline else None,
        "symbols": normalized_symbols,
    }


def ensure_company_fundamental_tag_table(conn: Any) -> None:
    conn.execute(
        """
        create table if not exists lb_company_fundamental_tags (
          symbol text primary key,
          market text not null,
          name text,
          composite_label text,
          labels jsonb not null,
          metrics jsonb not null,
          evidence jsonb not null,
          data_quality jsonb not null,
          payload jsonb not null,
          as_of timestamptz not null,
          updated_at timestamptz not null default now()
        )
        """
    )
    conn.execute("create index if not exists idx_lb_company_fundamental_tags_market on lb_company_fundamental_tags(market)")
    conn.execute(
        "create index if not exists idx_lb_company_fundamental_tags_composite on lb_company_fundamental_tags(composite_label)"
    )


def load_company_profile_symbols(conn: Any, *, markets: list[str], limit_per_market: int | None = 200) -> list[str]:
    symbols: list[str] = []
    seen: set[str] = set()
    for market in markets:
        suffixes = _market_suffixes(market)
        if not suffixes:
            continue
        rows = conn.execute(
            """
            select symbol
            from lb_company_profiles
            where upper(symbol) like any(%s)
            order by updated_at desc nulls last, symbol
            limit %s
            """,
            ([f"%{suffix}" for suffix in suffixes], int(limit_per_market) if limit_per_market and limit_per_market > 0 else 1000000),
        ).fetchall()
        for row in rows:
            symbol = _normalize_symbol(row[0])
            if symbol and symbol not in seen:
                seen.add(symbol)
                symbols.append(symbol)
    return symbols


OFFLINE_ROW_COLUMNS = (
    "symbol",
    "market",
    "name",
    "profile",
    "calc_trade_date",
    "calc_updated_at",
    "last_done",
    "turnover",
    "turnover_rate",
    "mktcap",
    "pe",
    "pb",
    "dps_rate",
    "valuation_trade_date",
    "valuation_updated_at",
    "valuation_pe",
    "valuation_pb",
    "ps",
    "roe",
    "roa",
    "net_margin",
    "liabilities_assets",
    "leverage",
    "market_value",
    "sales",
    "net_income",
    "industry_median_pe",
    "industry_rank",
)

FINANCIAL_REPORT_FIELDS = (
    "OperatingRevenue",
    "Revenue",
    "TotalRevenue",
    "NetProfit",
    "NetIncome",
    "NetIncomeCommonStockholders",
    "GrossMgn",
    "GrossMargin",
    "GrossProfitMargin",
    "NetProfitMargin",
    "NetMargin",
    "ROE",
    "ReturnOnEquity",
    "ROA",
    "ReturnOnAssets",
    "ProfitQuality",
    "TotalAssets",
    "TotalLiability",
    "TotalLiabilities",
)

FINANCIAL_ROW_COLUMNS = ("symbol", "field", "name", "value", "ratio", "yoy", "fp_end", "updated_at")


def load_company_fundamental_offline_rows(conn: Any, symbols: list[str]) -> list[Any]:
    if not symbols:
        return []
    return conn.execute(
        """
        select
          c.symbol,
          coalesce(c.market, case when c.symbol like '%%.HK' then 'hk' when c.symbol like '%%.US' then 'us' else 'cn' end) market,
          coalesce(c.name, c.company_name) name,
          c.profile,
          ci.trade_date calc_trade_date,
          ci.updated_at calc_updated_at,
          ci.last_done,
          ci.turnover,
          ci.turnover_rate,
          ci.mktcap,
          ci.pe,
          ci.pb,
          ci.dps_rate,
          v.trade_date valuation_trade_date,
          v.updated_at valuation_updated_at,
          v.pe valuation_pe,
          v.pb valuation_pb,
          v.ps,
          v.roe,
          v.roa,
          v.net_margin,
          v.liabilities_assets,
          v.leverage,
          v.market_value,
          v.sales,
          v.net_income,
          v.industry_median_pe,
          v.industry_rank
        from lb_company_profiles c
        left join lateral (
          select *
          from lb_calc_index ci
          where ci.symbol = c.symbol
          order by ci.trade_date desc
          limit 1
        ) ci on true
        left join lateral (
          select *
          from lb_valuation v
          where v.symbol = c.symbol
          order by v.trade_date desc
          limit 1
        ) v on true
        where c.symbol = any(%s)
        order by c.symbol
        """,
        (symbols,),
    ).fetchall()


def load_company_fundamental_financial_reports(conn: Any, symbols: list[str]) -> dict[str, dict[str, Any]]:
    if not symbols:
        return {}
    rows = conn.execute(
        """
        select distinct on (symbol, field)
          symbol, field, name, value, ratio, yoy, fp_end, updated_at
        from lb_financial_report
        where symbol = any(%s)
          and field = any(%s)
        order by symbol, field, fp_end desc nulls last, updated_at desc nulls last
        """,
        (symbols, list(FINANCIAL_REPORT_FIELDS)),
    ).fetchall()
    accounts_by_symbol: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        symbol = _normalize_symbol(str(_financial_row_get(row, "symbol") or ""))
        if not symbol:
            continue
        accounts_by_symbol.setdefault(symbol, []).append(
            {
                "field": _financial_row_get(row, "field"),
                "name": _financial_row_get(row, "name"),
                "values": [
                    {
                        "period": _iso_or_none(_financial_row_get(row, "fp_end")),
                        "value": _financial_row_get(row, "value"),
                        "yoy": _financial_row_get(row, "yoy"),
                    }
                ],
            }
        )
    return {symbol: {"accounts": accounts} for symbol, accounts in accounts_by_symbol.items()}


def build_company_fundamental_tag_from_offline_row(
    row: Any, *, financial_report: dict[str, Any] | None = None
) -> dict[str, Any]:
    symbol = _normalize_symbol(str(_row_get(row, "symbol") or ""))
    calc_index = {
        "mktcap": _row_get(row, "mktcap") or _row_get(row, "market_value"),
        "pe": _row_get(row, "pe") or _row_get(row, "valuation_pe"),
        "pb": _row_get(row, "pb") or _row_get(row, "valuation_pb"),
        "dps_rate": _row_get(row, "dps_rate"),
    }
    valuation = {
        "overview": {
            "date": _row_get(row, "valuation_trade_date"),
            "industryMedianPe": _row_get(row, "industry_median_pe"),
            "industryRank": _row_get(row, "industry_rank"),
        }
    }
    financial_report = financial_report or _offline_financial_report(row)
    item = classify_company_fundamentals(
        symbol,
        company={"name": _row_get(row, "name"), "profile": _row_get(row, "profile")},
        calc_index=calc_index,
        financial_report=financial_report,
        valuation=valuation,
    )
    item["dataQuality"] = {
        **item.get("dataQuality", {}),
        "source": "offline",
        "calcIndexTradeDate": _iso_or_none(_row_get(row, "calc_trade_date")),
        "calcIndexUpdatedAt": _iso_or_none(_row_get(row, "calc_updated_at")),
        "valuationTradeDate": _iso_or_none(_row_get(row, "valuation_trade_date")),
        "valuationUpdatedAt": _iso_or_none(_row_get(row, "valuation_updated_at")),
    }
    return item


def _offline_financial_report(row: Any) -> dict[str, Any]:
    return {
        "accounts": [
            {"field": "Revenue", "values": [{"value": _row_get(row, "sales")}]},
            {"field": "NetIncome", "values": [{"value": _row_get(row, "net_income")}]},
            {"field": "NetProfitMargin", "values": [{"value": _row_get(row, "net_margin")}]},
            {"field": "ROE", "values": [{"value": _row_get(row, "roe")}]},
            {"field": "ROA", "values": [{"value": _row_get(row, "roa")}]},
            {"field": "DebtToAssetRatio", "values": [{"value": _row_get(row, "liabilities_assets")}]},
        ]
    }


def upsert_company_fundamental_tag(conn: Any, item: dict[str, Any], *, as_of: datetime) -> None:
    symbol = _normalize_symbol(str(item.get("symbol") or ""))
    labels = item.get("labels") if isinstance(item.get("labels"), dict) else {}
    conn.execute(
        """
        insert into lb_company_fundamental_tags
          (symbol, market, name, composite_label, labels, metrics, evidence, data_quality, payload, as_of, updated_at)
        values (%s, %s, %s, %s, %s::jsonb, %s::jsonb, %s::jsonb, %s::jsonb, %s::jsonb, %s, now())
        on conflict (symbol) do update set
          market = excluded.market,
          name = excluded.name,
          composite_label = excluded.composite_label,
          labels = excluded.labels,
          metrics = excluded.metrics,
          evidence = excluded.evidence,
          data_quality = excluded.data_quality,
          payload = excluded.payload,
          as_of = excluded.as_of,
          updated_at = now()
        """,
        (
            symbol,
            _market_from_symbol(symbol),
            item.get("name"),
            labels.get("composite"),
            json.dumps(labels, ensure_ascii=False),
            json.dumps(item.get("metrics") or {}, ensure_ascii=False),
            json.dumps(item.get("evidence") or [], ensure_ascii=False),
            json.dumps(item.get("dataQuality") or {}, ensure_ascii=False),
            json.dumps(item, ensure_ascii=False, default=str),
            as_of,
        ),
    )


def classify_company_fundamentals(
    symbol: str,
    *,
    company: dict[str, Any] | None = None,
    calc_index: dict[str, Any] | None = None,
    financial_report: dict[str, Any] | None = None,
    valuation: dict[str, Any] | None = None,
) -> dict[str, Any]:
    normalized = _normalize_symbol(symbol)
    company = company or {}
    calc_index = calc_index or {}
    financial_report = financial_report or {}
    valuation = valuation or {}

    market_cap = _num_or_none(calc_index.get("mktcap") or calc_index.get("market_cap"))
    pe = _num_or_none(calc_index.get("pe"))
    pb = _num_or_none(calc_index.get("pb"))
    dividend_yield = _num_or_none(calc_index.get("dps_rate") or calc_index.get("dividend_yield"))

    accounts = list(_iter_financial_accounts(financial_report))
    revenue = _metric(accounts, fields={"Revenue", "OperatingRevenue", "TotalRevenue"}, names={"营业收入", "总收入"})
    net_profit = _metric(
        accounts,
        fields={"NetIncome", "NetProfit", "ProfitAttributableToOwners", "NetIncomeCommonStockholders"},
        names={"净利润", "归母净利润", "股东应占溢利"},
    )
    gross_margin = _metric(accounts, fields={"GrossMgn", "GrossMargin", "GrossProfitMargin"}, names={"毛利率"})
    net_margin = _metric(accounts, fields={"NetProfitMargin", "NetMargin"}, names={"净利率"})
    roe = _metric(accounts, fields={"ROE", "ReturnOnEquity"}, names={"净资产收益率", "ROE"})
    roa = _metric(accounts, fields={"ROA", "ReturnOnAssets"}, names={"总资产收益率", "ROA"})
    debt_to_asset = _metric(accounts, fields={"DebtToAssetRatio", "LiabilityToAsset"}, names={"资产负债率"})
    if debt_to_asset.get("value") is None:
        total_assets = _metric(accounts, fields={"TotalAssets"}, names={"总资产"})
        total_liability = _metric(accounts, fields={"TotalLiability", "TotalLiabilities"}, names={"总负债"})
        debt_to_asset = {"value": _ratio_pct(total_liability.get("value"), total_assets.get("value")), "yoy": None}
    profit_quality = _metric(accounts, fields={"ProfitQuality"}, names={"营业利润/经营现金流", "利润含金量"})

    labels = {
        "size": _size_label(market_cap),
        "valuation": _valuation_label(pe=pe, pb=pb, dividend_yield=dividend_yield),
        "growth": _growth_label(revenue_yoy=revenue.get("yoy"), profit_yoy=net_profit.get("yoy")),
        "profitability": _profitability_label(
            net_profit=net_profit.get("value"), roe=roe.get("value"), net_margin=net_margin.get("value")
        ),
        "balanceSheet": _balance_sheet_label(debt_to_asset.get("value")),
        "cashFlow": _cash_flow_label(profit_quality.get("value")),
        "shareholderReturn": _shareholder_return_label(dividend_yield),
    }
    labels["composite"] = _composite_label(labels)

    metrics = {
        "marketCap": market_cap,
        "pe": pe,
        "pb": pb,
        "dividendYield": dividend_yield,
        "revenue": revenue.get("value"),
        "revenueYoy": revenue.get("yoy"),
        "netProfit": net_profit.get("value"),
        "netProfitYoy": net_profit.get("yoy"),
        "grossMargin": gross_margin.get("value"),
        "netMargin": net_margin.get("value"),
        "roe": roe.get("value"),
        "roa": roa.get("value"),
        "debtToAsset": debt_to_asset.get("value"),
        "profitQuality": profit_quality.get("value"),
    }
    return {
        "symbol": normalized,
        "name": str(company.get("name") or company.get("company_name") or normalized),
        "profile": str(company.get("profile") or ""),
        "labels": labels,
        "metrics": metrics,
        "valuationSummary": _valuation_summary(valuation),
        "evidence": _evidence(metrics, labels),
        "dataQuality": _data_quality(metrics),
    }


def _run_longbridge_json(args: list[str]) -> Any:
    completed = subprocess.run(
        ["longbridge", *args, "--format", "json"],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=120,
        check=True,
    )
    return json.loads(completed.stdout or "null")


def _iter_financial_accounts(payload: Any) -> Iterable[dict[str, Any]]:
    if isinstance(payload, dict):
        accounts = payload.get("accounts")
        if isinstance(accounts, list):
            for account in accounts:
                if isinstance(account, dict):
                    yield account
        for value in payload.values():
            yield from _iter_financial_accounts(value)
    elif isinstance(payload, list):
        for item in payload:
            yield from _iter_financial_accounts(item)


def _metric(accounts: list[dict[str, Any]], *, fields: set[str], names: set[str]) -> dict[str, float | None]:
    for account in accounts:
        field = str(account.get("field") or "").strip()
        name = str(account.get("name") or "").strip()
        if field not in fields and name not in names:
            continue
        values = account.get("values")
        if not isinstance(values, list) or not values:
            continue
        latest = values[0] if isinstance(values[0], dict) else {}
        value = _num_or_none(latest.get("value"))
        yoy = _num_or_none(latest.get("yoy"))
        if yoy is None:
            yoy = _computed_yoy(values)
        return {"value": value, "yoy": yoy}
    return {"value": None, "yoy": None}


def _computed_yoy(values: list[Any]) -> float | None:
    if len(values) < 2 or not isinstance(values[0], dict) or not isinstance(values[1], dict):
        return None
    latest = _num_or_none(values[0].get("value"))
    previous = _num_or_none(values[1].get("value"))
    if latest is None or previous in (None, 0):
        return None
    return round((latest / previous - 1.0) * 100.0, 2)


def _ratio_pct(numerator: float | None, denominator: float | None) -> float | None:
    if numerator is None or denominator in (None, 0):
        return None
    return round(numerator / denominator * 100.0, 2)


def _size_label(market_cap: float | None) -> str:
    if market_cap is None:
        return "市值待确认"
    if market_cap >= 1_000_000_000_000:
        return "超大市值"
    if market_cap >= 100_000_000_000:
        return "大盘"
    if market_cap >= 10_000_000_000:
        return "中盘"
    return "小盘"


def _valuation_label(*, pe: float | None, pb: float | None, dividend_yield: float | None) -> str:
    if pe is not None and pe <= 0:
        return "亏损估值风险"
    if pe is None and pb is None:
        return "估值待确认"
    if pe is not None and pe < 12 and (pb is None or pb < 2.0):
        return "低估值"
    if pe is not None and pe > 45:
        return "高估值"
    if pb is not None and pb > 10 and (dividend_yield is None or dividend_yield < 1.0):
        return "高估值"
    return "合理估值"


def _growth_label(*, revenue_yoy: float | None, profit_yoy: float | None) -> str:
    if profit_yoy is not None and profit_yoy <= -20:
        return "利润承压"
    if revenue_yoy is None and profit_yoy is None:
        return "增长待确认"
    if (revenue_yoy or 0) >= 20 and (profit_yoy is None or profit_yoy >= 20):
        return "高增长"
    if (revenue_yoy or 0) >= 8 or (profit_yoy or 0) >= 8:
        return "稳健增长"
    if (revenue_yoy or 0) < 0 or (profit_yoy or 0) < 0:
        return "增长承压"
    return "低速增长"


def _profitability_label(*, net_profit: float | None, roe: float | None, net_margin: float | None) -> str:
    if net_profit is not None and net_profit <= 0:
        return "亏损/低盈利"
    if roe is not None and roe >= 15 and (net_margin is None or net_margin >= 10):
        return "高质量盈利"
    if roe is not None and roe >= 8:
        return "稳健盈利"
    if net_profit is None and roe is None:
        return "盈利待确认"
    return "亏损/低盈利"


def _balance_sheet_label(debt_to_asset: float | None) -> str:
    if debt_to_asset is None:
        return "资产负债待确认"
    if debt_to_asset <= 45:
        return "资产负债健康"
    if debt_to_asset <= 70:
        return "杠杆中性"
    return "高杠杆"


def _cash_flow_label(profit_quality: float | None) -> str:
    if profit_quality is None:
        return "现金流待确认"
    if profit_quality >= 80:
        return "现金流质量高"
    if profit_quality >= 50:
        return "现金流质量一般"
    return "现金流质量偏弱"


def _shareholder_return_label(dividend_yield: float | None) -> str:
    if dividend_yield is None:
        return "分红待确认"
    if dividend_yield >= 4:
        return "高股息"
    if dividend_yield >= 1:
        return "有分红"
    return "低股息"


def _composite_label(labels: dict[str, str]) -> str:
    if labels.get("profitability") == "亏损/低盈利" or labels.get("valuation") == "亏损估值风险":
        return "高风险观察"
    if labels.get("profitability") == "高质量盈利" and labels.get("growth") in {"高增长", "稳健增长"}:
        return "质量成长型"
    if labels.get("valuation") == "低估值" and labels.get("shareholderReturn") in {"高股息", "有分红"}:
        return "价值分红型"
    if labels.get("balanceSheet") == "高杠杆" or labels.get("cashFlow") == "现金流质量偏弱":
        return "财务风险观察"
    return "均衡型"


def _valuation_summary(valuation: dict[str, Any]) -> str:
    overview = valuation.get("overview") if isinstance(valuation, dict) else {}
    if isinstance(overview, dict):
        return str(overview.get("ai_summary") or overview.get("date") or "")
    return ""


def _evidence(metrics: dict[str, float | None], labels: dict[str, str]) -> list[str]:
    evidence: list[str] = []
    if metrics.get("marketCap") is not None:
        evidence.append(f"市值 {metrics['marketCap']:.0f}，归类为{labels['size']}")
    if metrics.get("pe") is not None or metrics.get("pb") is not None:
        evidence.append(f"PE { _fmt(metrics.get('pe')) }，PB { _fmt(metrics.get('pb')) }，估值={labels['valuation']}")
    if metrics.get("revenueYoy") is not None or metrics.get("netProfitYoy") is not None:
        evidence.append(
            f"营收同比 { _fmt_pct(metrics.get('revenueYoy')) }，净利润同比 { _fmt_pct(metrics.get('netProfitYoy')) }"
        )
    if metrics.get("roe") is not None or metrics.get("netMargin") is not None:
        evidence.append(f"ROE {_fmt_pct(metrics.get('roe'))}，净利率 {_fmt_pct(metrics.get('netMargin'))}")
    if metrics.get("debtToAsset") is not None:
        evidence.append(f"资产负债率 {_fmt_pct(metrics.get('debtToAsset'))}")
    if metrics.get("profitQuality") is not None:
        evidence.append(f"利润现金流质量 {_fmt_pct(metrics.get('profitQuality'))}")
    return evidence or ["财报和估值字段不足，标签置信度较低"]


def _data_quality(metrics: dict[str, float | None]) -> dict[str, Any]:
    available = sum(1 for value in metrics.values() if value is not None)
    return {"availableMetrics": available, "totalMetrics": len(metrics), "coverage": round(available / len(metrics), 3)}


def _normalize_symbol(symbol: str) -> str:
    return symbol.strip().upper()


def _market_from_symbol(symbol: str) -> str:
    value = _normalize_symbol(symbol)
    if value.endswith(".HK"):
        return "hk"
    if value.endswith(".US"):
        return "us"
    if value.endswith(".SH") or value.endswith(".SZ"):
        return "cn"
    if value.endswith(".SG"):
        return "sg"
    return "unknown"


def _market_suffixes(market: str) -> tuple[str, ...]:
    normalized = market.strip().lower()
    if normalized == "hk":
        return (".HK",)
    if normalized == "us":
        return (".US",)
    if normalized == "cn":
        return (".SH", ".SZ")
    if normalized == "sg":
        return (".SG",)
    return ()


def _num_or_none(value: Any) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _row_get(row: Any, key: str) -> Any:
    if isinstance(row, dict):
        return row.get(key)
    if hasattr(row, "keys"):
        try:
            return row[key]
        except (KeyError, TypeError):
            return None
    try:
        index = OFFLINE_ROW_COLUMNS.index(key)
    except ValueError:
        return None
    if isinstance(row, (list, tuple)) and index < len(row):
        return row[index]
    return None


def _financial_row_get(row: Any, key: str) -> Any:
    if isinstance(row, dict):
        return row.get(key)
    if hasattr(row, "keys"):
        try:
            return row[key]
        except (KeyError, TypeError):
            return None
    try:
        index = FINANCIAL_ROW_COLUMNS.index(key)
    except ValueError:
        return None
    if isinstance(row, (list, tuple)) and index < len(row):
        return row[index]
    return None


def _iso_or_none(value: Any) -> str | None:
    if value is None:
        return None
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return str(value)


def _chunks(items: list[str], size: int) -> Iterable[list[str]]:
    for start in range(0, len(items), size):
        yield items[start : start + size]


def _commit_quietly(conn: Any) -> None:
    commit = getattr(conn, "commit", None)
    if callable(commit):
        commit()


def _rollback_quietly(conn: Any) -> None:
    rollback = getattr(conn, "rollback", None)
    if callable(rollback):
        rollback()


def _fmt(value: float | None) -> str:
    return "-" if value is None else f"{value:.2f}"


def _fmt_pct(value: float | None) -> str:
    return "-" if value is None else f"{value:.1f}%"

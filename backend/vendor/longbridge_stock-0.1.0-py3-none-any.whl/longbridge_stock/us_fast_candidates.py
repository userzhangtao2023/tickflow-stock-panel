from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Iterable

from longbridge_stock.us_fast_alerts import _is_excluded_us_fast_instrument


def ensure_us_fast_candidate_pool_table(conn: Any) -> None:
    conn.execute(
        """
        create table if not exists lb_us_fast_candidate_pool (
          trade_date date not null,
          run_time timestamptz not null,
          rank integer not null,
          symbol text not null,
          name text,
          score numeric,
          output_stage text not null,
          decision text,
          risk_score numeric,
          profit_probability numeric,
          expected_return numeric,
          entry_price numeric,
          status text not null default 'watching',
          payload jsonb,
          created_at timestamptz not null default now(),
          updated_at timestamptz not null default now(),
          primary key (trade_date, run_time, rank)
        )
        """
    )
    conn.execute("create index if not exists idx_us_fast_candidate_pool_symbol_date on lb_us_fast_candidate_pool (symbol, trade_date)")
    conn.execute("create index if not exists idx_us_fast_candidate_pool_stage on lb_us_fast_candidate_pool (trade_date, output_stage)")
    conn.commit()


def classify_us_fast_output_stage(row: dict[str, Any], *, min_probability: float = 0.70) -> str:
    probability = number(row.get("profit_probability"))
    if probability is None or probability < min_probability:
        return "blocked"
    if str(row.get("market") or "").lower() not in {"", "us"}:
        return "blocked"
    symbol = str(row.get("symbol") or "")
    name = str(row.get("name") or symbol)
    if _is_excluded_us_fast_instrument(symbol, name):
        return "blocked"
    if str(row.get("decision") or "").lower() == "avoid":
        return "blocked"
    risk_score = number(row.get("risk_score"))
    if risk_score is not None and risk_score >= 80.0:
        return "blocked"
    entry = number(row.get("entry_price"))
    ma5 = number(row.get("ma5"))
    if str(row.get("decision") or "") == "buy_zone" and entry is not None and ma5 is not None and entry > ma5:
        return "buy_point"
    if is_technical_breakout_watch(row):
        return "technical_breakout_watch"
    return "watch"


def is_technical_breakout_watch(row: dict[str, Any]) -> bool:
    risk_score = number(row.get("risk_score"))
    if risk_score is not None and risk_score >= 50.0:
        return False
    change_pct = _feature_number(row, "change_percentage")
    return_15m = _feature_number(row, "return_15m")
    intraday_position = _feature_number(row, "intraday_position")
    volume_ratio_5m = _feature_number(row, "volume_ratio_5m")
    turnover_ratio_5m = _feature_number(row, "turnover_ratio_5m")
    entry = number(row.get("entry_price"))
    ma5 = number(row.get("ma5"))
    if change_pct is None or return_15m is None or intraday_position is None or entry is None or ma5 is None:
        return False
    volume_ratio = max(volume_ratio_5m or 0.0, turnover_ratio_5m or 0.0)
    return change_pct >= 3.0 and return_15m >= 0.02 and intraday_position >= 0.85 and volume_ratio >= 0.75 and entry > ma5


def rank_us_fast_candidates(
    rows: Iterable[dict[str, Any]],
    *,
    limit: int,
    min_probability: float = 0.70,
) -> list[dict[str, Any]]:
    eligible: list[dict[str, Any]] = []
    for row in rows:
        output_stage = classify_us_fast_output_stage(row, min_probability=min_probability)
        item = dict(row)
        item["output_stage"] = output_stage
        eligible.append(item)
    ranked = sorted(
        eligible,
        key=lambda item: (
            number(item.get("profit_probability")) or 0.0,
            number(item.get("expected_return")) or 0.0,
            str(item.get("symbol") or ""),
        ),
        reverse=True,
    )
    output: list[dict[str, Any]] = []
    for rank, item in enumerate(ranked[: max(1, limit)], 1):
        updated = dict(item)
        updated["rank"] = rank
        output.append(updated)
    return output


def build_us_fast_pool_rows(ranked: list[dict[str, Any]], *, now: datetime) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for item in ranked:
        rows.append(
                {
                "trade_date": now.date(),
                "run_time": now,
                "rank": int(item.get("rank") or len(rows) + 1),
                "symbol": str(item.get("symbol") or ""),
                "name": str(item.get("name") or item.get("symbol") or ""),
                "score": number(item.get("profit_probability")),
                   "output_stage": str(item.get("output_stage") or "watch"),
                   "status": "blocked" if str(item.get("output_stage") or "") == "blocked" else "watching",
                   "decision": str(item.get("decision") or ""),
                "risk_score": number(item.get("risk_score")),
                "profit_probability": number(item.get("profit_probability")),
                "expected_return": number(item.get("expected_return")),
                "entry_price": number(item.get("entry_price")),
                "payload": json.dumps(item, ensure_ascii=False, default=str),
            }
        )
    return rows


def save_us_fast_candidate_pool(conn: Any, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    with conn.cursor() as cur:
            cur.executemany(
               """
               insert into lb_us_fast_candidate_pool (
                 trade_date, run_time, rank, symbol, name, score, output_stage, decision,
                 risk_score, profit_probability, expected_return, entry_price, status, payload
               ) values (
                 %(trade_date)s, %(run_time)s, %(rank)s, %(symbol)s, %(name)s, %(score)s, %(output_stage)s, %(decision)s,
                 %(risk_score)s, %(profit_probability)s, %(expected_return)s, %(entry_price)s, %(status)s, %(payload)s::jsonb
               )
               on conflict (trade_date, run_time, rank) do update set
                 symbol = excluded.symbol,
              name = excluded.name,
              score = excluded.score,
              output_stage = excluded.output_stage,
              decision = excluded.decision,
              risk_score = excluded.risk_score,
                 profit_probability = excluded.profit_probability,
                 expected_return = excluded.expected_return,
                 entry_price = excluded.entry_price,
                 status = excluded.status,
                 payload = excluded.payload,
                 updated_at = now()
               """,
            rows,
        )
    conn.commit()


def number(value: Any) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _feature_number(row: dict[str, Any], key: str) -> float | None:
    value = row.get(key)
    if value is None and isinstance(row.get("feature_snapshot"), dict):
        value = row["feature_snapshot"].get(key)
    return number(value)

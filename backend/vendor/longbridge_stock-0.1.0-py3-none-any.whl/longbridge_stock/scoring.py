from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
import numpy as np


DEFAULT_SCORE_DSN = "dbname=longbridge_stock user=alwin host=192.168.10.28"
DEFAULT_QLIB_RUNS_ROOT = Path("/home/alwin/data/longbridge/qlib_runs")
DEFAULT_SCORE_WEIGHTS: dict[str, float] = {
    "trend_score": 0.18,
    "momentum_score": 0.18,
    "volume_score": 0.12,
    "risk_score": 0.14,
    "valuation_score": 0.16,
    "quality_score": 0.16,
    "model_score": 0.06,
}
COMPONENT_COLUMNS = [
    "trend_score",
    "momentum_score",
    "volume_score",
    "risk_score",
    "valuation_score",
    "quality_score",
    "model_score",
]
MIN_MODEL_HISTORY = 120
BREAKOUT_PAYLOAD_COLUMNS = [
    "prev_high_60",
    "prev_high_120",
    "prev_high_250",
    "fresh_breakout_over_60",
    "fresh_breakout_over_120",
    "fresh_breakout_over_250",
    "breakout_age_days",
    "breakout_over_60",
    "breakout_over_120",
    "breakout_over_250",
    "breakout_price_gap_60",
    "breakout_price_gap_120",
    "breakout_price_gap_250",
    "breakout_volume_ratio_20",
    "breakout_turnover_ratio_20",
    "breakout_trade_activity_score",
    "breakout_kline_quality_score",
    "breakout_liquidity_score",
    "breakout_chase_risk_score",
    "breakout_observation_score",
    "volume_breakout_score",
]


@dataclass(frozen=True)
class ScoreRefreshSummary:
    score_date: str
    total: int
    by_market: dict[str, int]


def build_market_score_frame(frame: pd.DataFrame) -> pd.DataFrame:
    if frame.empty:
        return frame.copy()

    scored = frame.copy()
    scored["trend_score"] = _average_scores(_rank_score(scored["half_year_change_rate"], higher_is_better=True))
    scored["momentum_score"] = _average_scores(
        _rank_score(scored["five_day_change_rate"], higher_is_better=True),
        _rank_score(scored["ten_day_change_rate"], higher_is_better=True),
    )
    scored["volume_score"] = _average_scores(
        _rank_score(scored["turnover_rate"], higher_is_better=True),
        _rank_score(scored["volume_ratio"], higher_is_better=True),
    )
    scored["risk_score"] = _average_scores(
        _rank_score(scored["amplitude"], higher_is_better=False),
        _rank_score(scored["liabilities_assets"], higher_is_better=False),
        _rank_score(scored["leverage"], higher_is_better=False),
    )
    scored["valuation_score"] = _average_scores(
        _rank_score(_positive_only(scored["pe"]), higher_is_better=False),
        _rank_score(_positive_only(scored["pb"]), higher_is_better=False),
        _rank_score(_positive_only(scored["ps"]), higher_is_better=False),
    )
    scored["quality_score"] = _average_scores(
        _rank_score(scored["roe"], higher_is_better=True),
        _rank_score(scored["roa"], higher_is_better=True),
        _rank_score(scored["net_margin"], higher_is_better=True),
        _rank_score(scored["eps_ttm"], higher_is_better=True),
        _rank_score(scored["bps"], higher_is_better=True),
    )
    proxy_model_score = _average_scores(
        scored["trend_score"],
        scored["momentum_score"],
        scored["quality_score"],
    )
    input_model_score = pd.to_numeric(scored.get("model_score_input"), errors="coerce") if "model_score_input" in scored else None
    scored["model_score"] = input_model_score.fillna(proxy_model_score).round(2) if input_model_score is not None else proxy_model_score
    model_meta = scored.apply(_model_meta_from_row, axis=1, result_type="expand")
    scored["model_status"] = model_meta["model_status"]
    scored["model_reason"] = model_meta["model_reason"]
    scored = _add_volume_breakout_features(scored)
    scored["total_score"] = sum(scored[column] * weight for column, weight in DEFAULT_SCORE_WEIGHTS.items()).round(2)
    scored["rank_in_market"] = scored["total_score"].rank(method="first", ascending=False).astype(int)
    scored["decision"] = scored["total_score"].map(_decision_from_score)
    scored["explanation"] = scored.apply(_build_explanation, axis=1)
    scored["payload"] = scored.apply(_payload_from_row, axis=1)
    return scored


def refresh_stock_scores(dsn: str = DEFAULT_SCORE_DSN) -> ScoreRefreshSummary:
    psycopg, Jsonb = _load_psycopg()
    latest = _load_latest_metrics(dsn)
    if latest.empty:
        return ScoreRefreshSummary(score_date="", total=0, by_market={})
    latest = latest.merge(_load_latest_qlib_model_scores(), on="symbol", how="left")

    batches: list[pd.DataFrame] = []
    for market, frame in latest.groupby("market", sort=True):
        scored = build_market_score_frame(frame)
        scored["market"] = market
        batches.append(scored)
    combined = pd.concat(batches, ignore_index=True)

    with psycopg.connect(dsn) as conn:
        for row in combined.to_dict("records"):
            conn.execute(
                """
                insert into lb_stock_scores
                  (symbol, market, score_date, total_score, trend_score, momentum_score, volume_score,
                   risk_score, valuation_score, quality_score, model_score, rank_in_market,
                   decision, explanation, payload, updated_at)
                values
                  (%(symbol)s, %(market)s, %(score_date)s, %(total_score)s, %(trend_score)s, %(momentum_score)s, %(volume_score)s,
                   %(risk_score)s, %(valuation_score)s, %(quality_score)s, %(model_score)s, %(rank_in_market)s,
                   %(decision)s, %(explanation)s, %(payload)s, %(updated_at)s)
                on conflict (symbol, score_date) do update set
                  market = excluded.market,
                  total_score = excluded.total_score,
                  trend_score = excluded.trend_score,
                  momentum_score = excluded.momentum_score,
                  volume_score = excluded.volume_score,
                  risk_score = excluded.risk_score,
                  valuation_score = excluded.valuation_score,
                  quality_score = excluded.quality_score,
                  model_score = excluded.model_score,
                  rank_in_market = excluded.rank_in_market,
                  decision = excluded.decision,
                  explanation = excluded.explanation,
                  payload = excluded.payload,
                  updated_at = excluded.updated_at
                """,
                {
                    **row,
                    "payload": Jsonb(row["payload"]),
                    "updated_at": _now(),
                },
            )

    score_date = str(combined["score_date"].max()) if "score_date" in combined else ""
    by_market = {str(market): int(count) for market, count in combined.groupby("market")["symbol"].count().items()}
    return ScoreRefreshSummary(score_date=score_date, total=int(len(combined)), by_market=by_market)


def fetch_score_leaderboard(
    dsn: str = DEFAULT_SCORE_DSN,
    market: str = "all",
    limit: int = 50,
    strategy: str = "trend_follow",
) -> pd.DataFrame:
    where_clause = ""
    params: list[Any] = []
    if market != "all":
        where_clause = "where scored.market = %s"
        params.append(market)
    query = f"""
        with latest_score_date as (
            select max(score_date) as score_date from lb_stock_scores
        ),
        latest_scores as (
            select scored.*
            from lb_stock_scores scored
            join latest_score_date latest on latest.score_date = scored.score_date
        ),
        latest_limit_up_model as (
            select model_run_id
            from lb_limit_up_model_runs
            order by trained_at desc
            limit 1
        ),
        latest_limit_up as (
            select distinct on (p.symbol)
                   p.symbol, p.model_run_id, p.event_date, p.open_buy_probability, p.open_buy_score,
                   p.decision as limit_up_decision, p.reason as limit_up_reason, e.pct_change,
                   e.close_price, e.target_open_buy
            from lb_limit_up_predictions p
            join latest_limit_up_model m on m.model_run_id = p.model_run_id
            left join lb_limit_up_events e on e.symbol = p.symbol and e.event_date = p.event_date
            where p.event_date = ((now() at time zone 'Asia/Shanghai')::date - 1)
            order by p.symbol, p.event_date desc
        ),
        latest_deep as (
            select distinct on (symbol) *
            from lb_deep_predictions
            order by symbol, as_of_date desc, updated_at desc
        )
        select scored.symbol, scored.market, sym.name, scored.score_date, scored.total_score,
               scored.trend_score, scored.momentum_score, scored.volume_score, scored.risk_score,
               scored.valuation_score, scored.quality_score, scored.model_score,
               scored.rank_in_market, scored.decision, scored.payload->>'model_run_id' as model_run_id,
               scored.payload->>'model_pred_date' as model_pred_date, scored.payload->>'model_status' as model_status,
               scored.payload->>'model_reason' as model_reason, calc.last_done, calc.five_day_change_rate,
               calc.ten_day_change_rate, calc.half_year_change_rate, val.pe, val.pb, val.roe,
               val.net_margin, val.market_value, limit_up.model_run_id as limit_up_model_run_id,
               limit_up.event_date as limit_up_event_date, limit_up.open_buy_probability as limit_up_probability,
               limit_up.open_buy_score as limit_up_score, limit_up.limit_up_decision, limit_up.limit_up_reason,
               limit_up.pct_change as limit_up_pct_change, limit_up.close_price as limit_up_close_price,
               limit_up.target_open_buy as limit_up_target_open_buy,
               deep.model_run_id as deep_model_run_id, deep.model_name as deep_model_name,
               deep.expected_return_5d as deep_expected_return_5d, deep.return_p10 as deep_return_p10,
               deep.return_p50 as deep_return_p50, deep.return_p90 as deep_return_p90,
               deep.upside_probability as deep_upside_probability, deep.var_5 as deep_var_5,
               deep.cvar_5 as deep_cvar_5, deep.regime as deep_regime, deep.confidence as deep_confidence,
               deep.signal as deep_signal, deep.explanation as deep_explanation, deep.updated_at as deep_updated_at,
               (scored.payload->>'volume_breakout_score')::numeric as volume_breakout_score,
               (scored.payload->>'breakout_observation_score')::numeric as breakout_observation_score,
               (scored.payload->>'fresh_breakout_over_60')::boolean as fresh_breakout_over_60,
               (scored.payload->>'fresh_breakout_over_120')::boolean as fresh_breakout_over_120,
               (scored.payload->>'fresh_breakout_over_250')::boolean as fresh_breakout_over_250,
               (scored.payload->>'breakout_age_days')::numeric as breakout_age_days,
               (scored.payload->>'breakout_over_60')::boolean as breakout_over_60,
               (scored.payload->>'breakout_over_120')::boolean as breakout_over_120,
               (scored.payload->>'breakout_over_250')::boolean as breakout_over_250,
               (scored.payload->>'prev_high_60')::numeric as prev_high_60,
               (scored.payload->>'prev_high_120')::numeric as prev_high_120,
               (scored.payload->>'prev_high_250')::numeric as prev_high_250,
               (scored.payload->>'breakout_price_gap_60')::numeric as breakout_price_gap_60,
               (scored.payload->>'breakout_price_gap_120')::numeric as breakout_price_gap_120,
               (scored.payload->>'breakout_price_gap_250')::numeric as breakout_price_gap_250,
               (scored.payload->>'breakout_volume_ratio_20')::numeric as breakout_volume_ratio_20,
               (scored.payload->>'breakout_turnover_ratio_20')::numeric as breakout_turnover_ratio_20,
               (scored.payload->>'breakout_trade_activity_score')::numeric as breakout_trade_activity_score,
               (scored.payload->>'breakout_kline_quality_score')::numeric as breakout_kline_quality_score,
               (scored.payload->>'breakout_liquidity_score')::numeric as breakout_liquidity_score,
               (scored.payload->>'breakout_chase_risk_score')::numeric as breakout_chase_risk_score
        from latest_scores scored
        left join lb_symbols sym on sym.symbol = scored.symbol
        left join lateral (
            select symbol, trade_date, last_done, turnover_rate, volume_ratio,
                   five_day_change_rate, ten_day_change_rate, half_year_change_rate
            from lb_calc_index
            where symbol = scored.symbol
            order by trade_date desc, updated_at desc
            limit 1
        ) calc on true
        left join lateral (
            select symbol, pe, pb, roe, net_margin, market_value
            from lb_valuation
            where symbol = scored.symbol
            order by trade_date desc, updated_at desc
            limit 1
        ) val on true
        left join latest_limit_up limit_up on limit_up.symbol = scored.symbol
        left join latest_deep deep on deep.symbol = scored.symbol
        {where_clause}
    """
    frame = _query_frame(dsn, query, params)
    if frame.empty:
        return frame
    ranked = _apply_leaderboard_strategy(frame, strategy)
    return ranked.head(limit)


def fetch_stock_score_detail(dsn: str, symbol: str) -> dict[str, Any] | None:
    query = """
        with latest_scores as (
            select distinct on (symbol) *
            from lb_stock_scores
            where symbol = %s
            order by symbol, score_date desc, updated_at desc
        ),
        latest_calc as (
            select distinct on (symbol) *
            from lb_calc_index
            where symbol = %s
            order by symbol, trade_date desc, updated_at desc
        ),
        latest_val as (
            select distinct on (symbol) *
            from lb_valuation
            where symbol = %s
            order by symbol, trade_date desc, updated_at desc
        ),
        latest_symbol as (
            select *
            from lb_symbols
            where symbol = %s
        ),
        latest_limit_up_model as (
            select model_run_id
            from lb_limit_up_model_runs
            order by trained_at desc
            limit 1
        ),
        latest_limit_up as (
            select distinct on (p.symbol)
                   p.symbol, p.model_run_id, p.event_date, p.open_buy_probability, p.open_buy_score,
                   p.decision as limit_up_decision, p.reason as limit_up_reason, e.pct_change,
                   e.close_price, e.target_open_buy
            from lb_limit_up_predictions p
            join latest_limit_up_model m on m.model_run_id = p.model_run_id
            left join lb_limit_up_events e on e.symbol = p.symbol and e.event_date = p.event_date
            where p.symbol = %s
              and p.event_date = ((now() at time zone 'Asia/Shanghai')::date - 1)
            order by p.symbol, p.event_date desc
        ),
        latest_deep as (
            select distinct on (symbol) *
            from lb_deep_predictions
            where symbol = %s
            order by symbol, as_of_date desc, updated_at desc
        )
        select scored.symbol, scored.market, sym.name, scored.score_date, scored.total_score,
               scored.trend_score, scored.momentum_score, scored.volume_score, scored.risk_score,
               scored.valuation_score, scored.quality_score, scored.model_score, scored.rank_in_market,
               scored.decision, scored.explanation, scored.payload->>'model_run_id' as model_run_id,
               scored.payload->>'model_pred_date' as model_pred_date, scored.payload->>'model_status' as model_status,
               scored.payload->>'model_reason' as model_reason, calc.last_done, calc.turnover_rate, calc.volume_ratio,
               calc.amplitude, calc.five_day_change_rate, calc.ten_day_change_rate, calc.half_year_change_rate,
               val.pe, val.pb, val.ps, val.roe, val.roa, val.net_margin, val.liabilities_assets,
               val.leverage, val.market_value, sym.exchange, sym.currency, sym.eps_ttm, sym.bps, sym.dividend,
               limit_up.model_run_id as limit_up_model_run_id, limit_up.event_date as limit_up_event_date,
               limit_up.open_buy_probability as limit_up_probability, limit_up.open_buy_score as limit_up_score,
               limit_up.limit_up_decision, limit_up.limit_up_reason, limit_up.pct_change as limit_up_pct_change,
               limit_up.close_price as limit_up_close_price, limit_up.target_open_buy as limit_up_target_open_buy,
               deep.model_run_id as deep_model_run_id, deep.model_name as deep_model_name,
               deep.expected_return_5d as deep_expected_return_5d, deep.return_p10 as deep_return_p10,
               deep.return_p50 as deep_return_p50, deep.return_p90 as deep_return_p90,
               deep.upside_probability as deep_upside_probability, deep.var_5 as deep_var_5,
               deep.cvar_5 as deep_cvar_5, deep.regime as deep_regime, deep.confidence as deep_confidence,
               deep.signal as deep_signal, deep.explanation as deep_explanation, deep.updated_at as deep_updated_at,
               (scored.payload->>'volume_breakout_score')::numeric as volume_breakout_score,
               (scored.payload->>'breakout_observation_score')::numeric as breakout_observation_score,
               (scored.payload->>'fresh_breakout_over_60')::boolean as fresh_breakout_over_60,
               (scored.payload->>'fresh_breakout_over_120')::boolean as fresh_breakout_over_120,
               (scored.payload->>'fresh_breakout_over_250')::boolean as fresh_breakout_over_250,
               (scored.payload->>'breakout_age_days')::numeric as breakout_age_days,
               (scored.payload->>'breakout_over_60')::boolean as breakout_over_60,
               (scored.payload->>'breakout_over_120')::boolean as breakout_over_120,
               (scored.payload->>'breakout_over_250')::boolean as breakout_over_250,
               (scored.payload->>'prev_high_60')::numeric as prev_high_60,
               (scored.payload->>'prev_high_120')::numeric as prev_high_120,
               (scored.payload->>'prev_high_250')::numeric as prev_high_250,
               (scored.payload->>'breakout_price_gap_60')::numeric as breakout_price_gap_60,
               (scored.payload->>'breakout_price_gap_120')::numeric as breakout_price_gap_120,
               (scored.payload->>'breakout_price_gap_250')::numeric as breakout_price_gap_250,
               (scored.payload->>'breakout_volume_ratio_20')::numeric as breakout_volume_ratio_20,
               (scored.payload->>'breakout_turnover_ratio_20')::numeric as breakout_turnover_ratio_20,
               (scored.payload->>'breakout_trade_activity_score')::numeric as breakout_trade_activity_score,
               (scored.payload->>'breakout_kline_quality_score')::numeric as breakout_kline_quality_score,
               (scored.payload->>'breakout_liquidity_score')::numeric as breakout_liquidity_score,
               (scored.payload->>'breakout_chase_risk_score')::numeric as breakout_chase_risk_score
        from latest_scores scored
        left join latest_symbol sym on sym.symbol = scored.symbol
        left join latest_calc calc on calc.symbol = scored.symbol
        left join latest_val val on val.symbol = scored.symbol
        left join latest_limit_up limit_up on limit_up.symbol = scored.symbol
        left join latest_deep deep on deep.symbol = scored.symbol
    """
    frame = _query_frame(dsn, query, [symbol, symbol, symbol, symbol, symbol, symbol])
    if frame.empty:
        return None
    return frame.iloc[0].to_dict()


def _apply_leaderboard_strategy(frame: pd.DataFrame, strategy: str) -> pd.DataFrame:
    ranked = frame.copy()
    ranked["early_signal_score"] = _early_signal_score(ranked)
    ranked["trend_compounder_score"] = _trend_compounder_score(ranked)
    if "volume_breakout_score" not in ranked:
        ranked["volume_breakout_score"] = _volume_breakout_score(ranked)
    if strategy == "limit_up":
        ranked = ranked[ranked["limit_up_score"].notna()].copy()
        if ranked.empty:
            return ranked
        ranked["limit_up_strategy_score"] = pd.to_numeric(ranked["limit_up_score"], errors="coerce").fillna(0)
        ranked = ranked.sort_values(
            ["limit_up_strategy_score", "limit_up_probability", "total_score"],
            ascending=[False, False, False],
        )
        ranked["rank_in_market"] = range(1, len(ranked) + 1)
        ranked["decision"] = ranked["limit_up_decision"].map(_limit_up_decision_label).fillna("观察")
        return ranked
    if strategy == "early_signal":
        ranked = ranked.sort_values(["early_signal_score", "total_score"], ascending=[False, False])
        ranked["rank_in_market"] = range(1, len(ranked) + 1)
        ranked["decision"] = ranked["early_signal_score"].map(_decision_from_score)
        return ranked
    if strategy == "trend_compounder":
        ranked = ranked.sort_values(["trend_compounder_score", "total_score"], ascending=[False, False])
        ranked["rank_in_market"] = range(1, len(ranked) + 1)
        ranked["decision"] = ranked["trend_compounder_score"].map(_decision_from_score)
        return ranked
    if strategy == "volume_breakout":
        breakout_mask = ranked.get("fresh_breakout_over_60", ranked.get("breakout_over_60", False))
        active_volume_mask = (
            (_numeric_column(ranked, "breakout_volume_ratio_20", 0) >= 1.5)
            | (_numeric_column(ranked, "breakout_turnover_ratio_20", 0) >= 1.5)
        )
        ranked = ranked[
            pd.Series(breakout_mask, index=ranked.index).fillna(False).astype(bool)
            & active_volume_mask
        ].copy()
        if ranked.empty:
            return ranked
        ranked = ranked.sort_values(["breakout_observation_score", "volume_breakout_score", "total_score"], ascending=[False, False, False])
        ranked["rank_in_market"] = range(1, len(ranked) + 1)
        ranked["decision"] = ranked["breakout_observation_score"].map(_decision_from_score)
        return ranked
    return ranked.sort_values(["total_score", "rank_in_market"], ascending=[False, True])


def _limit_up_decision_label(decision: object) -> str:
    return {
        "strong_candidate": "强候选",
        "candidate": "候选",
        "watch": "观察",
        "avoid": "回避",
    }.get(str(decision or ""), "观察")


def _early_signal_score(frame: pd.DataFrame) -> pd.Series:
    five_day = pd.to_numeric(frame.get("five_day_change_rate"), errors="coerce")
    ten_day = pd.to_numeric(frame.get("ten_day_change_rate"), errors="coerce")
    half_year = pd.to_numeric(frame.get("half_year_change_rate"), errors="coerce")
    volume = pd.to_numeric(frame.get("volume_score"), errors="coerce").fillna(50)
    valuation = pd.to_numeric(frame.get("valuation_score"), errors="coerce").fillna(50)
    risk = pd.to_numeric(frame.get("risk_score"), errors="coerce").fillna(50)
    quality = pd.to_numeric(frame.get("quality_score"), errors="coerce").fillna(50)
    model = pd.to_numeric(frame.get("model_score"), errors="coerce").fillna(50)

    moderate_short_momentum = (100 - (ten_day.fillna(0) - 6).abs() * 4).clip(0, 100)
    early_turn = (100 - (five_day.fillna(0) - 2).abs() * 8).clip(0, 100)
    low_position = (100 - (half_year.fillna(0) - 5).abs() * 1.4).clip(0, 100)
    chase_penalty = ((half_year.fillna(0) - 45).clip(lower=0) * 1.2 + (ten_day.fillna(0) - 18).clip(lower=0) * 2).clip(0, 35)

    score = (
        volume * 0.22
        + moderate_short_momentum * 0.18
        + early_turn * 0.14
        + low_position * 0.18
        + valuation * 0.10
        + risk * 0.08
        + quality * 0.05
        + model * 0.05
        - chase_penalty
    )
    return score.clip(0, 100).round(2)


def _trend_compounder_score(frame: pd.DataFrame) -> pd.Series:
    five_day = _numeric_column(frame, "five_day_change_rate", 0)
    ten_day = _numeric_column(frame, "ten_day_change_rate", 0)
    half_year = _numeric_column(frame, "half_year_change_rate", 0)
    trend = _numeric_column(frame, "trend_score", 50)
    momentum = _numeric_column(frame, "momentum_score", 50)
    volume = _numeric_column(frame, "volume_score", 50)
    valuation = _numeric_column(frame, "valuation_score", 50)
    quality = _numeric_column(frame, "quality_score", 50)
    model = _numeric_column(frame, "model_score", 50)
    total = _numeric_column(frame, "total_score", 50)
    volume_ratio = _numeric_column(frame, "volume_ratio", 1)
    bar_days = _numeric_column(frame, "bar_days", MIN_MODEL_HISTORY)

    medium_trend_fit = (100 - (half_year - 65).abs() * 0.7).clip(0, 100)
    trend_structure = _average_scores(trend, momentum, medium_trend_fit)
    relative_strength = _average_scores(
        _rank_score(total, higher_is_better=True),
        _rank_score(model, higher_is_better=True),
        _rank_score(half_year, higher_is_better=True),
    )
    not_overheated = (
        100
        - (five_day - 12).clip(lower=0) * 4
        - (ten_day - 25).clip(lower=0) * 2
        - (half_year - 120).clip(lower=0) * 0.8
    ).clip(0, 100)
    healthy_volume_ratio = (100 - (volume_ratio - 2.5).abs() * 10).clip(0, 100)
    volume_health = _average_scores(volume, healthy_volume_ratio)
    history_penalty = (MIN_MODEL_HISTORY - bar_days).clip(lower=0) * 0.35

    score = (
        trend_structure * 0.25
        + relative_strength * 0.20
        + not_overheated * 0.15
        + volume_health * 0.10
        + quality * 0.15
        + valuation * 0.05
        + model * 0.10
        - history_penalty
    )
    return score.clip(0, 100).round(2)


def _add_volume_breakout_features(frame: pd.DataFrame) -> pd.DataFrame:
    scored = frame.copy()
    last_done = _numeric_column(scored, "last_done", np.nan)
    for window in (60, 120, 250):
        previous_high = _numeric_column(scored, f"prev_high_{window}", np.nan)
        previous_close = _numeric_column(scored, "previous_close", np.nan)
        scored[f"breakout_price_gap_{window}"] = (last_done / previous_high.replace(0, np.nan) - 1).round(4)
        scored[f"breakout_over_{window}"] = (
            (last_done > previous_high) & previous_high.notna()
        ).map(lambda value: bool(value)).astype(object)
        scored[f"fresh_breakout_over_{window}"] = (
            (last_done > previous_high) & (previous_close <= previous_high) & previous_high.notna()
        ).map(lambda value: bool(value)).astype(object)

    latest_volume = _numeric_column(scored, "latest_volume", np.nan)
    volume_ma20 = _numeric_column(scored, "volume_ma20_prev", np.nan)
    latest_turnover = _numeric_column(scored, "latest_turnover", np.nan)
    turnover_ma20 = _numeric_column(scored, "turnover_ma20_prev", np.nan)
    scored["breakout_volume_ratio_20"] = (latest_volume / volume_ma20.replace(0, np.nan)).round(4)
    scored["breakout_turnover_ratio_20"] = (latest_turnover / turnover_ma20.replace(0, np.nan)).round(4)
    scored["breakout_age_days"] = _numeric_column(scored, "breakout_age_days_input", np.nan).clip(lower=0).round(0)
    scored["breakout_trade_activity_score"] = _breakout_trade_activity_score(scored)
    scored["breakout_kline_quality_score"] = _breakout_kline_quality_score(scored)
    scored["breakout_liquidity_score"] = _breakout_liquidity_score(scored)
    scored["breakout_chase_risk_score"] = _breakout_chase_risk_score(scored)
    scored["breakout_observation_score"] = _breakout_observation_score(scored)
    scored["volume_breakout_score"] = _volume_breakout_score(scored)
    return scored


def _volume_breakout_score(frame: pd.DataFrame) -> pd.Series:
    breakout_60 = _bool_column(frame, "breakout_over_60")
    breakout_120 = _bool_column(frame, "breakout_over_120")
    breakout_250 = _bool_column(frame, "breakout_over_250")
    volume_ratio = _numeric_column(frame, "breakout_volume_ratio_20", 1)
    turnover_ratio = _numeric_column(frame, "breakout_turnover_ratio_20", 1)
    price_gap = _numeric_column(frame, "breakout_price_gap_60", 0)
    trend = _numeric_column(frame, "trend_score", 50)
    momentum = _numeric_column(frame, "momentum_score", 50)
    volume = _numeric_column(frame, "volume_score", 50)
    model = _numeric_column(frame, "model_score", 50)
    five_day = _numeric_column(frame, "five_day_change_rate", 0)

    breakout_layer = (
        breakout_60.astype(float) * 45
        + breakout_120.astype(float) * 18
        + breakout_250.astype(float) * 12
    )
    volume_confirm = ((pd.concat([volume_ratio, turnover_ratio], axis=1).max(axis=1) - 1.0) * 18).clip(0, 22)
    healthy_gap = (100 - (price_gap.clip(lower=0) - 0.08).clip(lower=0) * 500).clip(0, 100)
    chase_penalty = (five_day - 18).clip(lower=0) * 1.5

    score = (
        breakout_layer
        + volume_confirm
        + trend * 0.12
        + momentum * 0.08
        + volume * 0.08
        + model * 0.05
        + healthy_gap * 0.10
        - chase_penalty
    )
    return score.clip(0, 100).round(2)


def _breakout_trade_activity_score(frame: pd.DataFrame) -> pd.Series:
    volume_ratio = _numeric_column(frame, "breakout_volume_ratio_20", 1)
    turnover_ratio = _numeric_column(frame, "breakout_turnover_ratio_20", 1)
    calc_volume_ratio = _numeric_column(frame, "volume_ratio", 1)
    turnover_rate = _numeric_column(frame, "turnover_rate", 0)
    volume_boost = ((pd.concat([volume_ratio, turnover_ratio, calc_volume_ratio], axis=1).max(axis=1) - 1) * 30).clip(0, 70)
    turnover_boost = (turnover_rate * 6).clip(0, 30)
    return (volume_boost + turnover_boost).clip(0, 100).round(2)


def _breakout_kline_quality_score(frame: pd.DataFrame) -> pd.Series:
    close_position = _numeric_column(frame, "latest_close_position", 0.5).clip(0, 1)
    body_pct = _numeric_column(frame, "latest_body_pct", 0).clip(0, 0.2)
    upper_shadow_pct = _numeric_column(frame, "latest_upper_shadow_pct", 0).clip(0, 0.2)
    quality = close_position * 55 + (body_pct * 900).clip(0, 25) + (20 - upper_shadow_pct * 700).clip(0, 20)
    return quality.clip(0, 100).round(2)


def _breakout_liquidity_score(frame: pd.DataFrame) -> pd.Series:
    turnover = _numeric_column(frame, "latest_turnover", 0)
    market_value = _numeric_column(frame, "market_value", np.nan)
    circulating_shares = _numeric_column(frame, "circulating_shares", np.nan)
    last_done = _numeric_column(frame, "last_done", np.nan)
    free_float_value = circulating_shares * last_done
    value_base = market_value.where(market_value.notna() & (market_value > 0), free_float_value)
    liquidity_turnover = (np.log10(turnover.clip(lower=1)) - 6).clip(0, 3) / 3 * 65
    liquidity_depth = ((turnover / value_base.replace(0, np.nan)).fillna(0) * 1500).clip(0, 35)
    return (liquidity_turnover + liquidity_depth).clip(0, 100).round(2)


def _breakout_chase_risk_score(frame: pd.DataFrame) -> pd.Series:
    event_ret = _numeric_column(frame, "latest_day_return", 0)
    gap = _numeric_column(frame, "breakout_price_gap_60", 0)
    upper_shadow = _numeric_column(frame, "latest_upper_shadow_pct", 0)
    turnover_rate = _numeric_column(frame, "turnover_rate", 0)
    extreme_volume = pd.concat(
        [
            _numeric_column(frame, "breakout_volume_ratio_20", 1),
            _numeric_column(frame, "breakout_turnover_ratio_20", 1),
        ],
        axis=1,
    ).max(axis=1)
    penalty = (
        (event_ret - 0.08).clip(lower=0) * 280
        + (gap - 0.08).clip(lower=0) * 220
        + upper_shadow.clip(lower=0) * 450
        + (turnover_rate - 12).clip(lower=0) * 3
        + (extreme_volume - 4).clip(lower=0) * 5
    )
    return (100 - penalty).clip(0, 100).round(2)


def _breakout_observation_score(frame: pd.DataFrame) -> pd.Series:
    fresh_60 = _bool_column(frame, "fresh_breakout_over_60").astype(float)
    fresh_120 = _bool_column(frame, "fresh_breakout_over_120").astype(float)
    fresh_250 = _bool_column(frame, "fresh_breakout_over_250").astype(float)
    layer_score = fresh_60 * 35 + fresh_120 * 15 + fresh_250 * 15
    score = (
        layer_score
        + _numeric_column(frame, "breakout_trade_activity_score", 50) * 0.18
        + _numeric_column(frame, "breakout_kline_quality_score", 50) * 0.18
        + _numeric_column(frame, "breakout_liquidity_score", 50) * 0.09
        + _numeric_column(frame, "breakout_chase_risk_score", 50) * 0.15
        + _numeric_column(frame, "model_score", 50) * 0.05
        + _numeric_column(frame, "trend_score", 50) * 0.05
    )
    return score.clip(0, 100).round(2)


def _bool_column(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame.columns:
        return pd.Series(False, index=frame.index, dtype=bool)
    return frame[column].fillna(False).astype(bool)


def _numeric_column(frame: pd.DataFrame, column: str, default: float) -> pd.Series:
    if column not in frame.columns:
        return pd.Series(default, index=frame.index, dtype="float64")
    return pd.to_numeric(frame[column], errors="coerce").fillna(default)


def _load_latest_metrics(dsn: str) -> pd.DataFrame:
    query = """
        with latest_calc as (
            select distinct on (symbol) symbol, market, trade_date, last_done, turnover_rate, amplitude,
                   volume_ratio, five_day_change_rate, ten_day_change_rate, half_year_change_rate
            from lb_calc_index
            order by symbol, trade_date desc, updated_at desc
        ),
        latest_val as (
            select distinct on (symbol) symbol, market, trade_date, pe, pb, ps, roe, roa,
                   net_margin, liabilities_assets, leverage, market_value
            from lb_valuation
            order by symbol, trade_date desc, updated_at desc
        ),
        bar_stats as (
            select symbol, market, count(*) as bar_days, min(trade_date) as bar_start_date, max(trade_date) as bar_end_date
            from lb_daily_bars
            group by symbol, market
        ),
        latest_bar as (
            select distinct on (symbol) symbol, market, trade_date, open, close, high, low, volume, turnover
            from lb_daily_bars
            order by symbol, trade_date desc
        ),
        breakout_stats as (
            select lb.symbol,
                   high60.prev_high_60,
                   high120.prev_high_120,
                   high250.prev_high_250,
                   vol20.volume_ma20_prev,
                   vol20.turnover_ma20_prev,
                   lb.volume as latest_volume,
                   lb.turnover as latest_turnover,
                   prev.close as previous_close,
                   (lb.close / nullif(prev.close, 0) - 1) as latest_day_return,
                   ((lb.close - lb.low) / nullif(lb.high - lb.low, 0)) as latest_close_position,
                   (abs(lb.close - lb.open) / nullif(prev.close, 0)) as latest_body_pct,
                   ((lb.high - greatest(lb.open, lb.close)) / nullif(prev.close, 0)) as latest_upper_shadow_pct,
                   age.breakout_age_days as breakout_age_days_input
            from latest_bar lb
            left join lateral (
                select close
                from lb_daily_bars b
                where b.symbol = lb.symbol and b.trade_date < lb.trade_date
                order by b.trade_date desc
                limit 1
            ) prev on true
            left join lateral (
                select max(high) as prev_high_60
                from (
                    select high
                    from lb_daily_bars b
                    where b.symbol = lb.symbol and b.trade_date < lb.trade_date
                    order by b.trade_date desc
                    limit 60
                ) w
            ) high60 on true
            left join lateral (
                select max(high) as prev_high_120
                from (
                    select high
                    from lb_daily_bars b
                    where b.symbol = lb.symbol and b.trade_date < lb.trade_date
                    order by b.trade_date desc
                    limit 120
                ) w
            ) high120 on true
            left join lateral (
                select max(high) as prev_high_250
                from (
                    select high
                    from lb_daily_bars b
                    where b.symbol = lb.symbol and b.trade_date < lb.trade_date
                    order by b.trade_date desc
                    limit 250
                ) w
            ) high250 on true
            left join lateral (
                select avg(volume) as volume_ma20_prev, avg(turnover) as turnover_ma20_prev
                from (
                    select volume, turnover
                    from lb_daily_bars b
                    where b.symbol = lb.symbol and b.trade_date < lb.trade_date
                    order by b.trade_date desc
                    limit 20
                ) w
            ) vol20 on true
            left join lateral (
                select count(*) - 1 as breakout_age_days
                from (
                    select close, trade_date
                    from lb_daily_bars b
                    where b.symbol = lb.symbol and b.trade_date <= lb.trade_date
                    order by b.trade_date desc
                    limit 20
                ) recent
                where recent.close > coalesce(high60.prev_high_60, 0)
            ) age on true
        ),
        latest_sym as (
            select symbol, market, name, exchange, currency, eps_ttm, bps, dividend, circulating_shares
            from lb_symbols
        )
        select calc.symbol, calc.market, calc.trade_date as score_date, sym.name, sym.exchange, sym.currency,
               calc.last_done, calc.turnover_rate, calc.amplitude, calc.volume_ratio,
               calc.five_day_change_rate, calc.ten_day_change_rate, calc.half_year_change_rate,
               val.pe, val.pb, val.ps, val.roe, val.roa, val.net_margin, val.liabilities_assets,
               val.leverage, val.market_value, sym.eps_ttm, sym.bps, sym.dividend,
               bars.bar_days, bars.bar_start_date, bars.bar_end_date,
               breakout.prev_high_60, breakout.prev_high_120, breakout.prev_high_250,
               breakout.volume_ma20_prev, breakout.turnover_ma20_prev,
               breakout.latest_volume, breakout.latest_turnover, breakout.previous_close,
               breakout.latest_day_return, breakout.latest_close_position, breakout.latest_body_pct,
               breakout.latest_upper_shadow_pct, breakout.breakout_age_days_input,
               sym.circulating_shares
        from latest_calc calc
        left join latest_val val on val.symbol = calc.symbol
        left join latest_sym sym on sym.symbol = calc.symbol
        left join bar_stats bars on bars.symbol = calc.symbol and bars.market = calc.market
        left join breakout_stats breakout on breakout.symbol = calc.symbol
    """
    return _query_frame(dsn, query)


def _query_frame(dsn: str, query: str, params: list[Any] | None = None) -> pd.DataFrame:
    psycopg, _ = _load_psycopg()
    with psycopg.connect(dsn) as conn:
        with conn.cursor() as cur:
            cur.execute(query, params or [])
            rows = cur.fetchall()
            columns = [desc.name for desc in cur.description]
    return pd.DataFrame(rows, columns=columns)


def _rank_score(series: pd.Series, higher_is_better: bool) -> pd.Series:
    numeric = pd.to_numeric(series, errors="coerce")
    valid = numeric.dropna()
    if valid.empty:
        return pd.Series(50.0, index=series.index, dtype="float64")
    ranks = valid.rank(pct=True, ascending=higher_is_better) * 100.0
    scored = pd.Series(50.0, index=series.index, dtype="float64")
    scored.loc[valid.index] = ranks.round(2)
    return scored


def _average_scores(*scores: pd.Series) -> pd.Series:
    frame = pd.concat(scores, axis=1)
    return frame.mean(axis=1).fillna(50.0).round(2)


def _positive_only(series: pd.Series) -> pd.Series:
    numeric = pd.to_numeric(series, errors="coerce")
    return numeric.where(numeric > 0)


def _decision_from_score(score: float) -> str:
    if score >= 80:
        return "\u5165\u6c60"
    if score >= 65:
        return "\u5019\u9009"
    if score >= 50:
        return "\u89c2\u5bdf"
    return "\u5254\u9664"


def _build_explanation(row: pd.Series) -> str:
    label_map = {
        "trend_score": "\u8d8b\u52bf",
        "momentum_score": "\u52a8\u91cf",
        "volume_score": "\u91cf\u80fd",
        "risk_score": "\u98ce\u9669\u63a7\u5236",
        "valuation_score": "\u4f30\u503c",
        "quality_score": "\u8d28\u91cf",
        "model_score": "\u6a21\u578b\u5224\u65ad",
    }
    pairs = sorted(((label, float(row[label])) for label in COMPONENT_COLUMNS), key=lambda item: item[1], reverse=True)
    strongest_labels = [label_map.get(label, label.replace("_score", "")) for label, _ in pairs[:2]]
    weakest_label = label_map.get(pairs[-1][0], pairs[-1][0].replace("_score", ""))
    decision = str(row.get("decision") or "")
    model_status = str(row.get("model_status") or "")
    model_reason = str(row.get("model_reason") or "")

    decision_text = {
        "\u5165\u6c60": "\u7efc\u5408\u8868\u73b0\u9760\u524d\uff0c\u8fdb\u5165\u5019\u9009\u6c60\u3002",
        "\u5019\u9009": "\u7efc\u5408\u5f97\u5206\u4e0d\u9519\uff0c\u503c\u5f97\u7ee7\u7eed\u8ddf\u8e2a\u3002",
        "\u89c2\u5bdf": "\u5206\u6570\u4e2d\u6027\uff0c\u5efa\u8bae\u5148\u89c2\u5bdf\u3002",
        "\u5254\u9664": "\u5f53\u524d\u7efc\u5408\u5438\u5f15\u529b\u504f\u5f31\u3002",
        "???": "\u7efc\u5408\u8868\u73b0\u9760\u524d\uff0c\u8fdb\u5165\u5019\u9009\u6c60\u3002",
        "????": "\u7efc\u5408\u5f97\u5206\u4e0d\u9519\uff0c\u503c\u5f97\u7ee7\u7eed\u8ddf\u8e2a\u3002",
        "???": "\u5206\u6570\u4e2d\u6027\uff0c\u5efa\u8bae\u5148\u89c2\u5bdf\u3002",
        "???": "\u5f53\u524d\u7efc\u5408\u5438\u5f15\u529b\u504f\u5f31\u3002",
    }.get(decision, "\u5f53\u524d\u6839\u636e\u7efc\u5408\u5206\u8fdb\u5165\u672c\u8f6e\u8bc4\u4f30\u7ed3\u679c\u3002")

    model_text = {
        "qlib": "\u6a21\u578b\u7aef\u6709\u771f\u5b9e Qlib \u9884\u6d4b\u5206\u652f\u6491\u3002",
        "proxy_fallback": "\u6a21\u578b\u5206\u6682\u65f6\u4f7f\u7528\u89c4\u5219\u4ee3\u7406\u5206\u3002",
        "insufficient_history": "\u5386\u53f2\u884c\u60c5\u957f\u5ea6\u4e0d\u8db3\uff0c\u6a21\u578b\u5206\u53ef\u4fe1\u5ea6\u53d7\u9650\u3002",
        "no_kline": "\u7f3a\u5c11\u65e5\u7ebf\u6570\u636e\uff0c\u6a21\u578b\u4fa7\u6682\u65f6\u65e0\u6cd5\u5b8c\u6574\u5224\u65ad\u3002",
    }.get(model_status, "")
    strongest_text = "\u3001".join(strongest_labels)

    explanation_parts = [
        decision_text,
        f"\u5f53\u524d\u66f4\u7a81\u51fa\u7684\u4f18\u52bf\u96c6\u4e2d\u5728\uff1a{strongest_text}\u3002",
        f"\u76f8\u5bf9\u504f\u5f31\u7684\u77ed\u677f\u4e3b\u8981\u5728\uff1a{weakest_label}\u3002",
    ]
    if model_text:
        explanation_parts.append(model_text)
    if model_reason and model_reason not in model_text:
        explanation_parts.append(f"\u6a21\u578b\u8bf4\u660e\uff1a{model_reason}\u3002")
    return " ".join(part for part in explanation_parts if part)


def _payload_from_row(row: pd.Series) -> dict[str, Any]:
    payload: dict[str, Any] = {}
    for key in [
        "name",
        "exchange",
        "currency",
        "last_done",
        "turnover_rate",
        "amplitude",
        "volume_ratio",
        "five_day_change_rate",
        "ten_day_change_rate",
        "half_year_change_rate",
        "pe",
        "pb",
        "ps",
        "roe",
        "roa",
        "net_margin",
        "liabilities_assets",
        "leverage",
        "market_value",
        "eps_ttm",
        "bps",
        "dividend",
        "bar_days",
        "bar_start_date",
        "bar_end_date",
        "model_score_input",
        "model_pred_date",
        "model_run_id",
        "model_status",
        "model_reason",
    ] + BREAKOUT_PAYLOAD_COLUMNS + COMPONENT_COLUMNS:
        payload[key] = _json_value(row.get(key))
    return payload


def _json_value(value: Any) -> Any:
    if pd.isna(value):
        return None
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, date):
        return value.isoformat()
    if hasattr(value, "isoformat"):
        return value.isoformat()
    if isinstance(value, pd.Timestamp):
        return value.isoformat()
    return value


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _load_psycopg():
    import psycopg
    from psycopg.types.json import Jsonb

    return psycopg, Jsonb


def _load_latest_qlib_model_scores(runs_root: Path = DEFAULT_QLIB_RUNS_ROOT) -> pd.DataFrame:
    pred_files = sorted(runs_root.glob("*/mlruns/*/*/artifacts/pred.pkl"), key=lambda path: path.stat().st_mtime, reverse=True)
    if not pred_files:
        return pd.DataFrame(columns=["symbol", "model_score_input", "model_pred_date", "model_run_id"])
    batches: list[pd.DataFrame] = []
    for pred_path in pred_files:
        frame = pd.read_pickle(pred_path)
        if frame.empty:
            continue
        latest = (
            frame.reset_index()
            .sort_values(["instrument", "datetime"])
            .groupby("instrument", as_index=False, sort=False)
            .tail(1)
            .copy()
        )
        latest["symbol"] = latest["instrument"].map(_qlib_instrument_to_symbol)
        latest["model_score_input"] = _rank_score(latest["score"], higher_is_better=True)
        latest["model_pred_date"] = pd.to_datetime(latest["datetime"]).dt.date
        latest["model_run_id"] = pred_path.parents[4].name
        latest["__mtime"] = pred_path.stat().st_mtime
        batches.append(latest[["symbol", "model_score_input", "model_pred_date", "model_run_id", "__mtime"]])
    if not batches:
        return pd.DataFrame(columns=["symbol", "model_score_input", "model_pred_date", "model_run_id"])
    combined = pd.concat(batches, ignore_index=True)
    combined = combined.sort_values(["symbol", "model_pred_date", "__mtime"], ascending=[True, False, False])
    combined = combined.drop_duplicates(subset=["symbol"], keep="first")
    return combined[["symbol", "model_score_input", "model_pred_date", "model_run_id"]]


def _model_meta_from_row(row: pd.Series) -> pd.Series:
    if pd.notna(row.get("model_score_input")):
        return pd.Series({"model_status": "qlib", "model_reason": "Qlib latest prediction"})
    days = pd.to_numeric(row.get("bar_days"), errors="coerce")
    if pd.isna(days) or float(days) <= 0:
        return pd.Series({"model_status": "no_kline", "model_reason": "Longbridge returned no daily bars"})
    if float(days) < MIN_MODEL_HISTORY:
        return pd.Series({"model_status": "insufficient_history", "model_reason": f"Daily bars shorter than {MIN_MODEL_HISTORY} sessions"})
    return pd.Series({"model_status": "proxy_fallback", "model_reason": "Qlib prediction missing for this symbol"})


def _qlib_instrument_to_symbol(instrument: str) -> str:
    code = str(instrument)
    if "." in code:
        return code
    if code.startswith("SH"):
        return f"{code[2:]}.SH"
    if code.startswith("SZ"):
        return f"{code[2:]}.SZ"
    return code

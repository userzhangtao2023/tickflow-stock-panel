from __future__ import annotations

from pathlib import Path

import pandas as pd


def load_qlib_features(
    provider_uri: str | Path,
    market: str,
    fields: list[str],
    start_time: str,
    end_time: str,
    region: str = "cn",
) -> pd.DataFrame:
    """Load features through Qlib if pyqlib is installed on the current machine."""
    try:
        import qlib
        from qlib.data import D
    except ImportError as exc:
        raise RuntimeError("pyqlib is not installed; use local_csv_dir or install the qlib extra.") from exc

    provider_uri = Path(provider_uri)
    if not provider_uri.exists():
        raise FileNotFoundError(f"Qlib provider_uri does not exist: {provider_uri}")

    qlib.init(provider_uri=str(provider_uri), region=region)
    instruments = D.instruments(market)
    qlib_fields = [field if field.startswith("$") else f"${field}" for field in fields]
    data = D.features(instruments, qlib_fields, start_time=start_time, end_time=end_time, freq="day")
    data = data.rename(columns={field: field.lstrip("$") for field in data.columns})
    data.index = data.index.set_names(["instrument", "datetime"])
    return data.reorder_levels(["datetime", "instrument"]).sort_index()

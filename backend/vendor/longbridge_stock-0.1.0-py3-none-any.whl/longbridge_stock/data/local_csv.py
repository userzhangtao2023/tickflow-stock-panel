from __future__ import annotations

from pathlib import Path

import pandas as pd


def load_csv_dir(csv_dir: str | Path, start_time: str | None = None, end_time: str | None = None) -> pd.DataFrame:
    """Load Longbridge-generated Qlib CSV files into a normalized MultiIndex frame."""
    csv_dir = Path(csv_dir)
    if not csv_dir.exists():
        raise FileNotFoundError(f"CSV directory does not exist: {csv_dir}")

    frames = []
    for path in sorted(csv_dir.glob("*.csv")):
        frame = pd.read_csv(path)
        if frame.empty:
            continue
        frames.append(frame)
    if not frames:
        raise ValueError(f"No CSV files found in {csv_dir}")

    data = pd.concat(frames, ignore_index=True)
    data["datetime"] = pd.to_datetime(data.pop("date"))
    data["instrument"] = data.pop("symbol").map(_normalize_csv_symbol)
    for column in ["open", "high", "low", "close", "volume", "turnover", "factor"]:
        if column in data.columns:
            data[column] = pd.to_numeric(data[column], errors="coerce")

    if start_time:
        data = data[data["datetime"] >= pd.Timestamp(start_time)]
    if end_time:
        data = data[data["datetime"] <= pd.Timestamp(end_time)]

    data = data.sort_values(["datetime", "instrument"])
    return data.set_index(["datetime", "instrument"])


def _normalize_csv_symbol(symbol: str) -> str:
    symbol = str(symbol)
    if symbol.startswith("sh"):
        return "SH" + symbol[2:]
    if symbol.startswith("sz"):
        return "SZ" + symbol[2:]
    return symbol.upper()

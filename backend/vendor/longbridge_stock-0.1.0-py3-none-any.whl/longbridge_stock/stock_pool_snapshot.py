from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from math import isfinite
from typing import Any, Iterable

import pandas as pd

from longbridge_stock.scoring import fetch_score_leaderboard


ASIA_SHANGHAI = timezone(timedelta(hours=8))
DEFAULT_MARKETS = ("all", "cn", "hk", "us")
DEFAULT_STRATEGIES = ("trend_follow", "early_signal", "trend_compounder", "limit_up", "volume_breakout")


@dataclass(frozen=True)
class StockPoolSnapshotSummary:
    markets: list[str]
    strategies: list[str]
    limit: int
    written: int
    generated_at: str


def ensure_stock_pool_snapshot_table(dsn: str) -> None:
    psycopg, _ = _load_psycopg()
    with psycopg.connect(dsn) as conn:
        conn.execute(
            """
            create table if not exists lb_stock_pool_snapshot (
              snapshot_market text not null,
              strategy text not null,
              rank integer not null,
              symbol text not null,
              market text,
              score_date date,
              row_data jsonb not null,
              generated_at timestamptz not null default now(),
              primary key (snapshot_market, strategy, rank)
            )
            """
        )
        conn.execute(
            """
            create index if not exists idx_lb_stock_pool_snapshot_lookup
            on lb_stock_pool_snapshot (snapshot_market, strategy, generated_at desc, rank)
            """
        )
        conn.execute(
            """
            create index if not exists idx_lb_stock_pool_snapshot_symbol
            on lb_stock_pool_snapshot (symbol, generated_at desc)
            """
        )


def refresh_stock_pool_snapshots(
    dsn: str,
    markets: Iterable[str] = DEFAULT_MARKETS,
    strategies: Iterable[str] = DEFAULT_STRATEGIES,
    limit: int = 300,
) -> StockPoolSnapshotSummary:
    psycopg, Jsonb = _load_psycopg()
    ensure_stock_pool_snapshot_table(dsn)
    generated_at = datetime.now(ASIA_SHANGHAI)
    normalized_markets = [_normalize_market(market) for market in markets]
    normalized_strategies = [_normalize_strategy(strategy) for strategy in strategies]
    written = 0

    with psycopg.connect(dsn) as conn:
        for market in normalized_markets:
            for strategy in normalized_strategies:
                frame = fetch_score_leaderboard(dsn=dsn, market=market, limit=limit, strategy=strategy)
                rows = _snapshot_rows(frame, market=market, strategy=strategy, generated_at=generated_at)
                with conn.transaction():
                    conn.execute(
                        "delete from lb_stock_pool_snapshot where snapshot_market = %s and strategy = %s",
                        (market, strategy),
                    )
                    if rows:
                        with conn.cursor() as cur:
                            cur.executemany(
                                """
                                insert into lb_stock_pool_snapshot
                                  (snapshot_market, strategy, rank, symbol, market, score_date, row_data, generated_at)
                                values
                                  (%(snapshot_market)s, %(strategy)s, %(rank)s, %(symbol)s, %(market)s,
                                   %(score_date)s, %(row_data)s, %(generated_at)s)
                                """,
                                [{**row, "row_data": Jsonb(row["row_data"])} for row in rows],
                            )
                    written += len(rows)

    return StockPoolSnapshotSummary(
        markets=normalized_markets,
        strategies=normalized_strategies,
        limit=limit,
        written=written,
        generated_at=generated_at.isoformat(),
    )


def fetch_stock_pool_snapshot(
    dsn: str,
    market: str = "all",
    strategy: str = "trend_follow",
    limit: int = 80,
    max_age_seconds: int = 600,
) -> pd.DataFrame:
    psycopg, _ = _load_psycopg()
    market = _normalize_market(market)
    strategy = _normalize_strategy(strategy)
    cutoff = datetime.now(ASIA_SHANGHAI) - timedelta(seconds=max_age_seconds)
    try:
        with psycopg.connect(dsn) as conn:
            rows = conn.execute(
                """
                select row_data
                from lb_stock_pool_snapshot
                where snapshot_market = %s
                  and strategy = %s
                  and generated_at >= %s
                order by rank
                limit %s
                """,
                (market, strategy, cutoff, limit),
            ).fetchall()
    except Exception:
        return pd.DataFrame()
    if not rows:
        return pd.DataFrame()
    return pd.DataFrame([dict(row[0]) for row in rows])


def _snapshot_rows(frame: pd.DataFrame, market: str, strategy: str, generated_at: datetime) -> list[dict[str, Any]]:
    if frame.empty:
        return []
    rows: list[dict[str, Any]] = []
    for index, row in enumerate(frame.to_dict("records"), start=1):
        payload = _json_ready(row)
        rows.append(
            {
                "snapshot_market": market,
                "strategy": strategy,
                "rank": index,
                "symbol": str(payload.get("symbol") or ""),
                "market": str(payload.get("market") or ""),
                "score_date": payload.get("score_date"),
                "row_data": payload,
                "generated_at": generated_at,
            }
        )
    return rows


def _json_ready(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _json_ready(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_json_ready(item) for item in value]
    if isinstance(value, tuple):
        return [_json_ready(item) for item in value]
    if isinstance(value, Decimal):
        number = float(value)
        return number if isfinite(number) else None
    if isinstance(value, pd.Timestamp):
        return value.isoformat()
    if isinstance(value, datetime):
        return value.isoformat()
    if hasattr(value, "isoformat"):
        return value.isoformat()
    if pd.isna(value):
        return None
    return value


def _normalize_market(market: str) -> str:
    market = str(market or "all").strip().lower()
    return market if market in {"all", "cn", "hk", "us"} else "all"


def _normalize_strategy(strategy: str) -> str:
    strategy = str(strategy or "trend_follow").strip().lower()
    return strategy if strategy in set(DEFAULT_STRATEGIES) else "trend_follow"


def _load_psycopg():
    try:
        import psycopg
        from psycopg.types.json import Jsonb
    except ImportError as exc:  # pragma: no cover - exercised only in missing optional dependency envs
        raise RuntimeError("psycopg is required for stock pool snapshots") from exc
    return psycopg, Jsonb

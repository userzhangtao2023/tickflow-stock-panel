from __future__ import annotations

import json
import subprocess
from datetime import datetime, timezone
from typing import Any


def normalize_symbol(value: str) -> str:
    text = str(value or "").strip().upper()
    if not text:
        return text
    if "." not in text:
        text = f"{text}.US"
    return text


def parse_longbridge_short_positions(
    payload: dict[str, Any],
    *,
    symbol: str,
    fetched_at: datetime | None = None,
) -> list[dict[str, Any]]:
    fetched_at = fetched_at or datetime.now().astimezone()
    normalized_symbol = normalize_symbol(symbol)
    counter_id = str(payload.get("counter_id") or "")
    rows = []
    for item in payload.get("data") or []:
        timestamp = int(_num(item.get("timestamp")))
        rows.append(
            {
                "symbol": normalized_symbol,
                "market": "us",
                "counter_id": counter_id,
                "report_date": datetime.fromtimestamp(timestamp, tz=timezone.utc).date().isoformat(),
                "timestamp": timestamp,
                "current_shares_short": int(_num(item.get("current_shares_short"))),
                "short_interest_ratio": _num_or_none(item.get("rate")),
                "days_to_cover": _num_or_none(item.get("days_to_cover")),
                "avg_daily_share_volume": int(_num(item.get("avg_daily_share_volume"))),
                "close": _num_or_none(item.get("close")),
                "source": "longbridge_short_positions",
                "fetched_at": fetched_at.isoformat(),
            }
        )
    return rows


def fetch_longbridge_short_positions(
    symbol: str,
    *,
    count: int = 100,
    runner=subprocess.run,
) -> dict[str, Any]:
    normalized_symbol = normalize_symbol(symbol)
    command = [
        "longbridge",
        "short-positions",
        normalized_symbol,
        "--count",
        str(max(1, min(100, int(count)))),
        "--format",
        "json",
    ]
    completed = runner(command, capture_output=True, text=True, check=True)
    return json.loads(completed.stdout)


def _num(value: Any) -> float:
    if value is None or value == "":
        return 0.0
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _num_or_none(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None

"""Standalone Longbridge/Qlib research toolkit."""

from longbridge_stock.system_patterns import (
    PatternDefinition,
    PatternMatch,
    PatternRole,
    scan_system_pattern,
    system_pattern_manifest,
)

__all__ = [
    "PatternDefinition",
    "PatternMatch",
    "PatternRole",
    "__version__",
    "scan_system_pattern",
    "system_pattern_manifest",
]

__version__ = "0.1.0"

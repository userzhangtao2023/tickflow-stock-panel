from __future__ import annotations

import csv
from pathlib import Path
from typing import Any

import pandas as pd


def export_market_frame_to_qlib_csv(frame: pd.DataFrame, output_dir: str | Path) -> list[dict[str, Any]]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest: list[dict[str, Any]] = []
    if frame.empty:
        return manifest

    required = {"symbol", "trade_date", "open", "high", "low", "close", "volume"}
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"Missing required columns for Qlib CSV export: {sorted(missing)}")

    normalized = frame.copy()
    normalized["trade_date"] = pd.to_datetime(normalized["trade_date"]).dt.strftime("%Y-%m-%d")
    normalized["symbol"] = normalized["symbol"].astype(str)
    normalized = normalized.sort_values(["symbol", "trade_date"])

    for symbol, symbol_frame in normalized.groupby("symbol", sort=True):
        output_path = output_dir / f"{symbol}.csv"
        rows = []
        for row in symbol_frame.to_dict("records"):
            rows.append(
                {
                    "date": row["trade_date"],
                    "symbol": symbol,
                    "open": _csv_num(row.get("open")),
                    "high": _csv_num(row.get("high")),
                    "low": _csv_num(row.get("low")),
                    "close": _csv_num(row.get("close")),
                    "volume": _csv_num(row.get("volume")),
                    "turnover": _csv_num(row.get("turnover")),
                    "factor": "1.0",
                }
            )
        with output_path.open("w", newline="", encoding="utf-8") as fp:
            writer = csv.DictWriter(
                fp,
                fieldnames=["date", "symbol", "open", "high", "low", "close", "volume", "turnover", "factor"],
            )
            writer.writeheader()
            writer.writerows(rows)
        manifest.append({"symbol": symbol, "rows": len(rows), "path": str(output_path)})
    return manifest


def _csv_num(value: Any) -> str:
    if value is None or pd.isna(value):
        return ""
    return str(value)


from __future__ import annotations

import json
import os
import shlex
import subprocess
import sys
from dataclasses import dataclass
from typing import Any, Callable, Iterable


DEFAULT_OPENCLAW_BIN = "/home/alwin/.npm-global/bin/openclaw"
DEFAULT_OPENCLAW_TARGETS = (
    "qqbot=qqbot:c2c:0F91F8A6B3A8E055F16F79D4454EC06D,"
    "qqbot@1904180973=qqbot:c2c:7B415DF71970173C57AB8F0277BDF20F,"
    "qqbot@1904878430=qqbot:c2c:0B273A85621A59857CF587BBF06E359F,"
    "feishu=open_id:ou_53bdbb0ffe5430a28669c7841f08c5d0"
)


@dataclass(frozen=True)
class TableRow:
    item: str
    content: Any


def render_key_value_table(title: str, rows: Iterable[tuple[str, Any] | TableRow]) -> str:
    lines = [title, "", "| 项目 | 内容 |", "| --- | --- |"]
    for row in rows:
        item, content = (row.item, row.content) if isinstance(row, TableRow) else row
        lines.append(f"| {escape_cell(item)} | {escape_cell(format_cell(content))} |")
    lines.append("")
    return "\n".join(lines)


def format_cell(value: Any) -> str:
    if value is None:
        return "-"
    text = str(value).strip()
    return text or "-"


def escape_cell(value: Any) -> str:
    return format_cell(value).replace("|", "｜").replace("\n", "；")


def send_openclaw(
    message: str,
    *,
    dry_run: bool = False,
    default_targets: str = DEFAULT_OPENCLAW_TARGETS,
    openclaw_bin: str | None = None,
    raw_targets: str | None = None,
    ssh_target: str | None = None,
    timeout_seconds: int | None = None,
    runner: Callable[..., Any] | None = None,
    raise_if_all_failed: bool = False,
) -> None:
    if dry_run:
        print(json.dumps({"dry_run_openclaw": message[:200]}, ensure_ascii=False), flush=True)
        return
    bin_path = openclaw_bin or os.getenv("OPENCLAW_BIN", DEFAULT_OPENCLAW_BIN)
    targets = raw_targets if raw_targets is not None else os.getenv("OPENCLAW_ALERT_TARGETS", default_targets)
    ssh = ssh_target if ssh_target is not None else os.getenv("OPENCLAW_SSH_TARGET", "").strip()
    timeout = timeout_seconds if timeout_seconds is not None else int(os.getenv("OPENCLAW_SEND_TIMEOUT_SECONDS", "90"))
    run = runner or subprocess.run
    failures: list[str] = []
    sent = 0
    for target in parse_openclaw_targets(targets):
        command = [
            bin_path,
            "message",
            "send",
            "--channel",
            target.channel,
        ]
        if target.account:
            command.extend(["--account", target.account])
        command.extend(["--target", normalize_openclaw_target(target.channel, target.target), "--message", message, "--json"])
        if ssh and ssh.lower() != "local":
            command = ["ssh", ssh, " ".join(shlex.quote(part) for part in command)]
        try:
            run(command, capture_output=True, text=True, timeout=timeout, check=True)
            sent += 1
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
            failures.append(f"{target.channel}={target.target}:{exc}")
            print(
                json.dumps(
                    {
                        "openclaw_send_failed": True,
                        "channel": target.channel,
                        "target": target.target,
                        "error": str(exc),
                    },
                    ensure_ascii=False,
                ),
                file=sys.stderr,
                flush=True,
            )
    if sent <= 0 and failures and raise_if_all_failed:
        raise RuntimeError("; ".join(failures))


@dataclass(frozen=True)
class OpenClawTarget:
    channel: str
    target: str
    account: str = ""


def parse_openclaw_targets(raw: str) -> list[OpenClawTarget]:
    targets: list[OpenClawTarget] = []
    for item in raw.split(","):
        channel, sep, target = item.partition("=")
        if sep and channel.strip() and target.strip():
            channel_name, _, account = channel.strip().partition("@")
            targets.append(OpenClawTarget(channel_name.strip(), target.strip(), account.strip()))
    if not targets:
        raise ValueError("OPENCLAW_ALERT_TARGETS is empty")
    return targets


def normalize_openclaw_target(channel: str, target: str) -> str:
    value = target.strip()
    prefix = f"{channel.strip()}:"
    if channel.strip() == "qqbot" and value.startswith(prefix):
        return value[len(prefix) :]
    return value

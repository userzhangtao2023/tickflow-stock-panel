from __future__ import annotations

import json
import os
import smtplib
import statistics
import subprocess
import time
import uuid
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from email.message import EmailMessage
from html import escape as html_escape
from pathlib import Path
from typing import Any, Iterable

from longbridge_stock import clickhouse_realtime
from longbridge_stock.llm.provider import LLMClient


DEFAULT_OUTPUT_DIR = Path(os.getenv("LONG_TERM_STOCK_REPORT_DIR", "reports/long_term_stock"))
DEFAULT_CONFIG_PATH = Path(os.getenv("LONG_TERM_STOCK_REPORT_CONFIG", "configs/long_term_stock_reports.json"))
DEFAULT_CRONICLE_CONFIG_PATH = Path(os.getenv("CRONICLE_CONFIG_PATH", "/home/alwin/apps/cronicle/conf/config.json"))
DEFAULT_TEMPLATE_VERSION = "long-term-stock-v1"
DEFAULT_FONT_CANDIDATES = (
    r"C:\Windows\Fonts\msyh.ttc",
    r"C:\Windows\Fonts\simhei.ttf",
    r"C:\Windows\Fonts\Deng.ttf",
    r"C:\Windows\Fonts\simsun.ttc",
    "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
)


@dataclass(frozen=True)
class ReportArtifacts:
    symbol: str
    markdown_path: Path
    image_path: Path | None
    title: str
    summary: dict[str, Any]


def load_report_config(path: str | Path) -> dict[str, Any]:
    config_path = Path(path)
    return json.loads(config_path.read_text(encoding="utf-8"))


def save_report_config(config: dict[str, Any], path: str | Path = DEFAULT_CONFIG_PATH) -> dict[str, Any]:
    config_path = Path(path)
    normalized = normalize_report_config(config)
    _write_json_atomic(config_path, normalized)
    return normalized


def normalize_report_config(config: dict[str, Any]) -> dict[str, Any]:
    mail = dict(config.get("mail") or {})
    llm = dict(config.get("llm") or {})
    recipients = mail.get("to") or []
    if isinstance(recipients, str):
        recipients = [item.strip() for item in recipients.replace(";", ",").split(",") if item.strip()]
    symbols = config.get("symbols") or []
    if isinstance(symbols, str):
        symbols = [item.strip() for item in symbols.replace("\n", ",").split(",") if item.strip()]
    return {
        "symbols": [normalize_symbol(str(item)) for item in symbols if str(item).strip()],
        "output_dir": str(config.get("output_dir") or DEFAULT_OUTPUT_DIR),
        "lookback_start": str(config.get("lookback_start") or "2023-01-01"),
        "news_limit": int(config.get("news_limit", 8)),
        "send_email": bool(config.get("send_email", False)),
        "llm": {
            "enabled": bool(llm.get("enabled", True)),
            "source": str(llm.get("source") or "tool_text_model"),
        },
        "mail": {
            "smtp_host": str(mail.get("smtp_host") or ""),
            "smtp_port": int(mail.get("smtp_port") or 465),
            "from": str(mail.get("from") or ""),
            "to": recipients,
            "subject": str(mail.get("subject") or ""),
            "username_env": str(mail.get("username_env") or "LONG_TERM_STOCK_REPORT_SMTP_USER"),
            "password_env": str(mail.get("password_env") or "LONG_TERM_STOCK_REPORT_SMTP_PASSWORD"),
            "ssl": bool(mail.get("ssl", True)),
            "starttls": bool(mail.get("starttls", True)),
            "timeout_seconds": int(mail.get("timeout_seconds") or 30),
        },
    }


def report_history_path(output_dir: str | Path = DEFAULT_OUTPUT_DIR) -> Path:
    configured = os.getenv("LONG_TERM_STOCK_REPORT_HISTORY")
    if configured:
        return Path(configured)
    return Path(output_dir) / "history.json"


def load_report_history(output_dir: str | Path = DEFAULT_OUTPUT_DIR, *, limit: int | None = None) -> list[dict[str, Any]]:
    path = report_history_path(output_dir)
    if not path.exists():
        return []
    try:
        rows = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []
    if not isinstance(rows, list):
        return []
    rows = sorted(rows, key=lambda item: str(item.get("generated_at") or ""), reverse=True)
    return rows[:limit] if limit else rows


def record_report_history(
    artifacts: Iterable[ReportArtifacts],
    *,
    output_dir: str | Path = DEFAULT_OUTPUT_DIR,
    as_of: str | None = None,
    email_result: dict[str, Any] | None = None,
) -> dict[str, Any]:
    artifacts = list(artifacts)
    generated_at = datetime.now().isoformat(timespec="seconds")
    record = {
        "id": f"ltr_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}",
        "template_version": DEFAULT_TEMPLATE_VERSION,
        "as_of": as_of or date.today().isoformat(),
        "generated_at": generated_at,
        "symbols": [item.symbol for item in artifacts],
        "artifacts": [_artifact_history_item(item) for item in artifacts],
        "email": email_result,
        "resend_history": [],
    }
    path = report_history_path(output_dir)
    history = load_report_history(output_dir)
    history.insert(0, record)
    _write_json_atomic(path, history[:500])
    return record


def find_report_history_record(record_id: str, output_dir: str | Path = DEFAULT_OUTPUT_DIR) -> dict[str, Any] | None:
    for record in load_report_history(output_dir):
        if record.get("id") == record_id:
            return record
    return None


def resend_report_history_record(
    record_id: str,
    *,
    output_dir: str | Path = DEFAULT_OUTPUT_DIR,
    mail_config: dict[str, Any],
    dry_run: bool = False,
) -> dict[str, Any]:
    path = report_history_path(output_dir)
    history = load_report_history(output_dir)
    record = next((item for item in history if item.get("id") == record_id), None)
    if record is None:
        raise KeyError(record_id)
    artifacts = [_history_artifact(item) for item in record.get("artifacts") or []]
    result = send_email_report(artifacts, mail_config=mail_config, dry_run=dry_run)
    resend = {"resent_at": datetime.now().isoformat(timespec="seconds"), "email": result}
    record.setdefault("resend_history", []).append(resend)
    record["email"] = result
    _write_json_atomic(path, history)
    return {"record": record, "email": result}


def normalize_symbol(symbol: str) -> str:
    value = symbol.strip().upper()
    if "." in value:
        return value
    if value.startswith(("0", "2", "3")):
        return f"{value}.SZ"
    if value.startswith(("6", "9")):
        return f"{value}.SH"
    return value


def build_long_term_report(
    symbol: str,
    *,
    as_of: date | None = None,
    name: str | None = None,
    lookback_start: str = "2023-01-01",
    lookback_end: str | None = None,
    news_limit: int = 8,
    llm_enabled: bool = True,
    llm_client: Any | None = None,
    runner: Any = subprocess.check_output,
) -> dict[str, Any]:
    normalized = normalize_symbol(symbol)
    as_of_date = as_of or date.today()
    end = lookback_end or as_of_date.isoformat()
    bars = fetch_daily_bars(normalized, start=lookback_start, end=end, runner=runner)
    quote = fetch_quote(normalized, runner=runner)
    news = fetch_news(normalized, runner=runner, limit=news_limit)
    names = clickhouse_realtime.fetch_eastmoney_company_names([normalized])
    display_name = name or names.get(normalized) or guess_name_from_news(news) or normalized
    indicators = compute_indicators(bars)
    capital = fetch_capital_summary(normalized)
    sector = fetch_stock_board(normalized)
    report = {
        "template_version": DEFAULT_TEMPLATE_VERSION,
        "symbol": normalized,
        "name": display_name,
        "as_of": as_of_date.isoformat(),
        "quote": quote,
        "indicators": indicators,
        "capital": capital,
        "sector": sector,
        "news": news,
    }
    report["analysis"] = build_analysis(report)
    report["llm"] = build_llm_analysis(report, enabled=llm_enabled, client=llm_client)
    return report


def build_llm_analysis(report: dict[str, Any], *, enabled: bool = True, client: Any | None = None) -> dict[str, Any]:
    if not enabled:
        return {"enabled": False, "source": "disabled", "summary": ""}
    llm_client = client or LLMClient.from_ozon_config()
    try:
        summary = llm_client.complete(build_llm_prompt(report)).strip()
    except Exception as exc:
        return {"enabled": True, "source": "tool_text_model", "summary": "", "error": str(exc)}
    model = getattr(getattr(llm_client, "config", None), "model", "")
    base_url = getattr(getattr(llm_client, "config", None), "base_url", "")
    return {
        "enabled": True,
        "source": "tool_text_model",
        "model": model,
        "base_url": base_url,
        "summary": summary,
    }


def build_llm_prompt(report: dict[str, Any]) -> str:
    evidence = {
        "symbol": report.get("symbol"),
        "name": report.get("name"),
        "as_of": report.get("as_of"),
        "quote": report.get("quote") or {},
        "indicators": report.get("indicators") or {},
        "capital": report.get("capital") or {},
        "sector": report.get("sector") or {},
        "news": report.get("news") or [],
        "rule_analysis": report.get("analysis") or {},
    }
    return (
        "你是一个谨慎的股票研究助理。请基于下面证据生成中文长期趋势分析，"
        "不要编造未给出的事实，不要给出确定收益承诺。\n"
        "输出必须使用 Markdown，结构固定为：\n"
        "## LLM综合结论\n"
        "- 一句话结论\n"
        "- 当前阶段判断\n"
        "- 买入条件\n"
        "- 放弃/止损条件\n"
        "## 长期趋势\n"
        "## 资金与技术\n"
        "## 新闻与基本面\n"
        "## 未来情景预测\n"
        "- 乐观情景\n"
        "- 中性情景\n"
        "- 悲观情景\n"
        "## 操作建议\n"
        "- 适合: 买入/观察/回避 三选一\n"
        "- 仓位建议\n"
        "- 关键跟踪点\n\n"
        "证据JSON：\n"
        f"{json.dumps(evidence, ensure_ascii=False, default=str)}"
    )


def fetch_daily_bars(symbol: str, *, start: str, end: str, runner: Any = subprocess.check_output) -> list[dict[str, Any]]:
    normalized = normalize_symbol(symbol)
    command = [
        "longbridge",
        "kline",
        "history",
        normalized,
        "--start",
        start,
        "--end",
        end,
        "--period",
        "day",
        "--format",
        "json",
    ]
    last_error: Exception | None = None
    output = ""
    rows: list[dict[str, Any]] = []
    for attempt in range(3):
        try:
            output = runner(command, text=True, encoding="utf-8", stderr=subprocess.STDOUT)
            parsed = json.loads(output)
            rows = parsed if isinstance(parsed, list) else []
            break
        except subprocess.CalledProcessError as exc:
            last_error = exc
            if attempt < 2:
                time.sleep(1.5 * (attempt + 1))
                continue
        except TypeError:
            output = runner(command, text=True, encoding="utf-8")
            parsed = json.loads(output)
            rows = parsed if isinstance(parsed, list) else []
            break
        except Exception as exc:
            last_error = exc
            if attempt < 2:
                time.sleep(1.5 * (attempt + 1))
                continue
    if not rows:
        rows = _fetch_clickhouse_daily_bars(normalized, start=start, end=end)
    rows = _merge_daily_bars(rows, _fetch_realtime_quote_daily_bars(normalized, start=start, end=end))
    if not isinstance(rows, list) or not rows:
        details = ""
        if isinstance(last_error, subprocess.CalledProcessError):
            details = str(last_error.output or last_error.stderr or "").strip()
        raise RuntimeError(f"No daily bars returned for {normalized}: {details or last_error or 'empty local and realtime sources'}")
    return rows


def _fetch_clickhouse_daily_bars(symbol: str, *, start: str, end: str) -> list[dict[str, Any]]:
    if not clickhouse_realtime.enabled():
        return []
    try:
        rows = clickhouse_realtime._query_json_each_row(
            f"""
            select trade_date, open, high, low, close, volume, turnover
            from {clickhouse_realtime._ident(clickhouse_realtime._database())}.lb_daily_bars
            prewhere market = '{_escape_sql(_market_from_symbol(symbol))}'
              and symbol = '{_escape_sql(symbol)}'
            where trade_date >= toDate('{_escape_sql(start)}')
              and trade_date <= toDate('{_escape_sql(end)}')
            order by trade_date
            """
        )
    except Exception:
        return []
    return [_daily_bar_payload(row.get("trade_date"), row) for row in rows]


def _fetch_realtime_quote_daily_bars(symbol: str, *, start: str, end: str) -> list[dict[str, Any]]:
    if not clickhouse_realtime.enabled():
        return []
    start_date = _parse_date(start)
    end_date = _parse_date(end)
    if not start_date or not end_date:
        return []
    # Realtime quotes are a short-lived high-volume source; keep the window tight.
    realtime_start = max(start_date, end_date - timedelta(days=14))
    try:
        rows = clickhouse_realtime._query_json_each_row(
            f"""
            select
              toDate(snapshot_minute) as trade_date,
              argMin(if(open > 0, open, last_done), snapshot_minute) as open,
              max(high) as high,
              minIf(low, low > 0) as low,
              argMax(last_done, tuple(snapshot_minute, inserted_at)) as close,
              argMax(volume, tuple(snapshot_minute, inserted_at)) as volume,
              argMax(turnover, tuple(snapshot_minute, inserted_at)) as turnover,
              count() as points
            from {clickhouse_realtime._ident(clickhouse_realtime._database())}.lb_realtime_quotes
            prewhere market = '{_escape_sql(_market_from_symbol(symbol))}'
              and symbol = '{_escape_sql(symbol)}'
            where snapshot_minute >= toDateTime64('{realtime_start.isoformat()} 00:00:00', 3, 'Asia/Shanghai')
              and snapshot_minute < toDateTime64('{(end_date + timedelta(days=1)).isoformat()} 00:00:00', 3, 'Asia/Shanghai')
              and last_done > 0
            group by trade_date
            having points >= 5
            order by trade_date
            """
        )
    except Exception:
        return []
    return [_daily_bar_payload(row.get("trade_date"), row) for row in rows]


def _daily_bar_payload(day: Any, row: dict[str, Any]) -> dict[str, Any]:
    return {
        "time": str(day),
        "open": row.get("open"),
        "high": row.get("high"),
        "low": row.get("low"),
        "close": row.get("close"),
        "volume": row.get("volume"),
        "turnover": row.get("turnover"),
    }


def _merge_daily_bars(primary: list[dict[str, Any]], supplemental: list[dict[str, Any]]) -> list[dict[str, Any]]:
    merged: dict[str, dict[str, Any]] = {}
    for row in primary:
        key = _bar_date_key(row)
        if key:
            merged[key] = row
    for row in supplemental:
        key = _bar_date_key(row)
        if key and key not in merged:
            merged[key] = row
    return [merged[key] for key in sorted(merged)]


def fetch_quote(symbol: str, *, runner: Any = subprocess.check_output) -> dict[str, Any]:
    try:
        output = runner(["longbridge", "quote", symbol, "--format", "json"], text=True, encoding="utf-8")
        rows = json.loads(output)
    except Exception:
        rows = []
    if isinstance(rows, list) and rows:
        return rows[0]
    return {}


def fetch_news(symbol: str, *, runner: Any = subprocess.check_output, limit: int) -> list[dict[str, Any]]:
    try:
        output = runner(["longbridge", "news", symbol, "--format", "json"], text=True, encoding="utf-8")
        rows = json.loads(output)
    except Exception:
        return []
    return rows[:limit] if isinstance(rows, list) else []


def compute_indicators(rows: list[dict[str, Any]]) -> dict[str, Any]:
    closes = [_float(row.get("close")) for row in rows]
    highs = [_float(row.get("high")) for row in rows]
    lows = [_float(row.get("low")) for row in rows]
    turnovers = [_float(row.get("turnover")) for row in rows]
    if len(closes) < 30:
        raise ValueError("At least 30 daily bars are required")
    close = closes[-1]
    ma = {f"ma{n}": _ma(closes, n) for n in (5, 10, 20, 60, 120, 250)}
    ema12 = _ema(closes, 12)
    ema26 = _ema(closes, 26)
    dif = [a - b for a, b in zip(ema12, ema26)]
    dea = _ema(dif, 9)
    macd = [(d - e) * 2 for d, e in zip(dif, dea)]
    mid = ma["ma20"]
    sd20 = statistics.pstdev(closes[-20:])
    high_year = max(highs[-250:]) if len(highs) >= 250 else max(highs)
    low_year = min(lows[-250:]) if len(lows) >= 250 else min(lows)
    return {
        "date": _bar_date_key(rows[-1]) or str(rows[-1].get("time") or "")[:10],
        "close": close,
        "high": highs[-1],
        "low": lows[-1],
        "ret_5d_pct": _return_pct(closes, 5),
        "ret_20d_pct": _return_pct(closes, 20),
        "ret_60d_pct": _return_pct(closes, 60),
        "ret_120d_pct": _return_pct(closes, 120),
        **ma,
        "macd_dif": dif[-1],
        "macd_dea": dea[-1],
        "macd": macd[-1],
        "macd_prev": macd[-2],
        "rsi14": _rsi(closes, 14),
        "boll_mid": mid,
        "boll_upper": mid + 2 * sd20,
        "boll_lower": mid - 2 * sd20,
        "high_lookback": max(highs),
        "low_lookback": min(lows),
        "high_250": high_year,
        "low_250": low_year,
        "turnover_ratio20": turnovers[-1] / (sum(turnovers[-21:-1]) / 20) if len(turnovers) > 20 else None,
        "close_vs_ma60_pct": _pct(close, ma["ma60"]),
        "close_vs_ma120_pct": _pct(close, ma["ma120"]),
        "close_vs_ma250_pct": _pct(close, ma["ma250"]),
    }


def fetch_capital_summary(symbol: str) -> dict[str, Any]:
    if not clickhouse_realtime.enabled():
        return {"available": False}
    try:
        rows = clickhouse_realtime._query_json_each_row(
            f"""
            select
              toDate(snapshot_minute) as d,
              max(snapshot_minute) as latest_snapshot_minute,
              argMax(total_net, tuple(snapshot_minute, inserted_at)) as total_net,
              argMax(large_net, tuple(snapshot_minute, inserted_at)) as large_net,
              argMax(medium_net, tuple(snapshot_minute, inserted_at)) as medium_net,
              argMax(small_net, tuple(snapshot_minute, inserted_at)) as small_net,
              argMax(large_net_ratio, tuple(snapshot_minute, inserted_at)) as large_net_ratio
            from {clickhouse_realtime._ident(clickhouse_realtime._database())}.lb_realtime_capital
            prewhere market = '{_escape_sql(_market_from_symbol(symbol))}'
              and symbol = '{_escape_sql(symbol)}'
            where 1 = 1
              and snapshot_minute >= now() - interval 20 day
            group by d
            order by d desc
            limit 20
            """
        )
    except Exception as exc:
        return {"available": False, "error": str(exc)}
    daily_rows: dict[str, dict[str, Any]] = {}
    for row in rows:
        day = _date_key(row.get("d") or row.get("latest_snapshot_minute") or row.get("snapshot_minute"))
        if day and day not in daily_rows:
            daily_rows[day] = {**row, "d": day}
    recent = list(daily_rows.values())[:8]
    summary = _capital_summary_from_daily_rows(daily_rows.values())
    return {"available": bool(daily_rows), "summary": summary, "recent": recent}


def fetch_stock_board(symbol: str) -> dict[str, Any]:
    if not clickhouse_realtime.enabled():
        return {}
    try:
        rows = clickhouse_realtime._query_json_each_row(
            f"""
            select name, exchange_board, industry, region_board, concepts, fetched_at
            from {clickhouse_realtime._ident(clickhouse_realtime._database())}.lb_eastmoney_stock_boards final
            where symbol = '{_escape_sql(symbol)}'
            order by fetched_at desc
            limit 1
            """
        )
    except Exception:
        rows = []
    return rows[0] if rows else {}


def build_analysis(report: dict[str, Any]) -> dict[str, Any]:
    indicators = report["indicators"]
    capital = report.get("capital") or {}
    score = 5.0
    notes: list[str] = []
    if indicators.get("macd", 0) > indicators.get("macd_prev", 0):
        score += 0.4
        notes.append("MACD柱体转强，下跌动能衰减。")
    if indicators.get("rsi14", 0) > 70:
        score -= 0.5
        notes.append("RSI进入偏热区，短线追高风险上升。")
    elif indicators.get("rsi14", 0) > 55:
        score += 0.2
        notes.append("RSI偏强但未极端。")
    ma60_gap = indicators.get("close_vs_ma60_pct")
    if ma60_gap is not None and ma60_gap < 0:
        score -= 0.3
        notes.append("股价仍低于60日线，中期趋势未完全修复。")
    summary = capital.get("summary") if isinstance(capital.get("summary"), dict) else {}
    if _float(summary.get("sum_large_net")) > 0:
        score += 0.4
        notes.append("近阶段大单资金为净流入。")
    elif _float(summary.get("sum_large_net")) < 0:
        score -= 0.4
        notes.append("近阶段大单资金仍为净流出。")
    recent = capital.get("recent") if isinstance(capital.get("recent"), list) else []
    if recent and _float(recent[0].get("large_net")) > 0:
        score += 0.5
        notes.append("最近交易日大单资金明显回补。")
    score = max(1.0, min(9.5, score))
    return {
        "score": round(score, 1),
        "phase": classify_phase(indicators),
        "notes": notes,
    }


def classify_phase(indicators: dict[str, Any]) -> str:
    close = _float(indicators.get("close"))
    ma20 = _float(indicators.get("ma20"))
    ma60 = _float(indicators.get("ma60"))
    ma120 = _float(indicators.get("ma120"))
    if close > ma20 > ma60 > ma120:
        return "右侧上升趋势"
    if close > ma20 and close < ma60:
        return "底部反弹观察"
    if close < ma20 < ma60:
        return "下跌趋势未修复"
    return "震荡修复"


def render_markdown_report(report: dict[str, Any]) -> str:
    symbol = report["symbol"]
    name = report["name"]
    ind = report["indicators"]
    capital = report.get("capital") or {}
    capital_summary = capital.get("summary") if isinstance(capital.get("summary"), dict) else {}
    recent = capital.get("recent") if isinstance(capital.get("recent"), list) else []
    sector = report.get("sector") or {}
    news = report.get("news") or []
    analysis = report.get("analysis") or {}
    llm = report.get("llm") or {}
    llm_summary = str(llm.get("summary") or "").strip()
    llm_error = str(llm.get("error") or "").strip()
    title = f"{name} {symbol} 长期趋势分析"
    lines = [
        f"# {title}",
        "",
        f"基于长桥历史行情、10.28 资金流、指标与近期新闻 | {report['as_of']}",
        "",
        "## 结论",
        "",
        f"{name}当前处于{analysis.get('phase', '观察')}阶段。",
        "",
        "短线资金和指标只用于判断买点质量，长期是否成立仍取决于行业周期、基本面改善和资金连续性。",
        "",
        "## 长期趋势",
        "",
        f"区间高点 {_fmt(ind.get('high_lookback'))}；区间低点 {_fmt(ind.get('low_lookback'))}；当前收盘约 {_fmt(ind.get('close'))}。",
        "",
        f"当前相对 60/120/250 日线分别为 {_fmt_pct(ind.get('close_vs_ma60_pct'))}、{_fmt_pct(ind.get('close_vs_ma120_pct'))}、{_fmt_pct(ind.get('close_vs_ma250_pct'))}。",
        "",
        f"判断：{analysis.get('phase', '-')}。",
        "",
        "## 指标状态",
        "",
        f"近 5 日 {_fmt_pct(ind.get('ret_5d_pct'))}，近 20 日 {_fmt_pct(ind.get('ret_20d_pct'))}，近 60 日 {_fmt_pct(ind.get('ret_60d_pct'))}，近 120 日 {_fmt_pct(ind.get('ret_120d_pct'))}。",
        "",
        f"RSI14 约 {_fmt(ind.get('rsi14'))}；MACD 柱体 {_fmt(ind.get('macd'))}，前值 {_fmt(ind.get('macd_prev'))}。",
        "",
        f"布林区间：下轨 {_fmt(ind.get('boll_lower'))}，中轨 {_fmt(ind.get('boll_mid'))}，上轨 {_fmt(ind.get('boll_upper'))}。",
        "",
        "## 历史资金流",
        "",
        _capital_summary_text(capital_summary),
        "",
        _recent_capital_text(recent),
        "",
        "## 新闻与基本面",
        "",
        _sector_text(sector),
        "",
        *[_news_line(item) for item in news[:5]],
        "",
        "## 情景预测",
        "",
        *_scenario_lines(report),
        "",
        "## 操作区间",
        "",
        *_operation_lines(report),
        "",
        f"综合评分：{analysis.get('score', '-')}/10。",
        "",
        "## LLM 综合分析",
        "",
        llm_summary if llm_summary else (f"LLM 分析未生成：{llm_error}" if llm_error else "LLM 分析未启用。"),
        "",
    ]
    return "\n".join(lines)


def write_report_artifacts(
    report: dict[str, Any],
    *,
    output_dir: str | Path = DEFAULT_OUTPUT_DIR,
    image: bool = True,
) -> ReportArtifacts:
    out_dir = Path(output_dir) / report["as_of"]
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{report['symbol'].replace('.', '_')}_long_term_{report['as_of']}"
    md_path = out_dir / f"{stem}.md"
    png_path = out_dir / f"{stem}.png"
    markdown = render_markdown_report(report)
    md_path.write_text(markdown, encoding="utf-8")
    image_path: Path | None = None
    if image:
        render_report_image(markdown, png_path)
        image_path = png_path
    return ReportArtifacts(
        symbol=report["symbol"],
        markdown_path=md_path,
        image_path=image_path,
        title=f"{report['name']} {report['symbol']} 长期趋势分析",
        summary=report.get("analysis") or {},
    )


def _artifact_history_item(item: ReportArtifacts) -> dict[str, Any]:
    markdown = item.markdown_path.read_text(encoding="utf-8") if item.markdown_path.exists() else ""
    return {
        "symbol": item.symbol,
        "title": item.title,
        "markdown": str(item.markdown_path),
        "image": str(item.image_path) if item.image_path else None,
        "summary": item.summary,
        "content": markdown,
        "excerpt": markdown.replace("\n", " ")[:280],
    }


def _history_artifact(item: dict[str, Any]) -> ReportArtifacts:
    return ReportArtifacts(
        symbol=str(item.get("symbol") or ""),
        markdown_path=Path(str(item.get("markdown") or "")),
        image_path=Path(str(item.get("image"))) if item.get("image") else None,
        title=str(item.get("title") or item.get("symbol") or ""),
        summary=dict(item.get("summary") or {}),
    )


def _write_json_atomic(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_suffix(path.suffix + ".tmp")
    tmp_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp_path.replace(path)


def render_report_image(markdown: str, output_path: str | Path) -> Path:
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError as exc:
        raise RuntimeError("Pillow is required to render report images") from exc
    font_path = _find_font()
    if not font_path:
        raise RuntimeError("No usable font found for report image rendering")
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    blocks = _parse_markdown_blocks(markdown)
    width = 1200
    pad_x = 46
    pad_y = 40
    bg = (36, 36, 36)
    card = (54, 54, 54)
    line = (82, 82, 82)
    white = (238, 238, 238)
    muted = (185, 185, 185)
    title_font = ImageFont.truetype(font_path, 36)
    meta_font = ImageFont.truetype(font_path, 20)
    heading_font = ImageFont.truetype(font_path, 26)
    body_font = ImageFont.truetype(font_path, 23)
    probe = Image.new("RGB", (width, 100), bg)
    draw = ImageDraw.Draw(probe)
    height = pad_y
    for kind, payload in blocks:
        if kind == "title":
            height += 50
        elif kind == "meta":
            height += 38
        else:
            height += 56
            for item in payload["items"]:
                height += len(_wrap_text(draw, "- " + item, body_font, width - pad_x * 2 - 20)) * 34 + 8
            height += 24
    height += pad_y
    img = Image.new("RGB", (width, height), bg)
    draw = ImageDraw.Draw(img)
    y = pad_y
    for kind, payload in blocks:
        if kind == "title":
            draw.text((pad_x, y), payload, font=title_font, fill=white)
            y += 50
        elif kind == "meta":
            draw.text((pad_x, y), payload, font=meta_font, fill=muted)
            y += 38
        else:
            draw.rounded_rectangle((pad_x - 14, y, width - pad_x + 14, y + 44), radius=8, fill=card)
            draw.text((pad_x, y + 8), payload["heading"], font=heading_font, fill=white)
            y += 56
            for item in payload["items"]:
                for index, row in enumerate(_wrap_text(draw, "- " + item, body_font, width - pad_x * 2 - 20)):
                    draw.text((pad_x + 8, y), row if index == 0 else "  " + row, font=body_font, fill=white)
                    y += 34
                y += 8
            draw.line((pad_x, y + 4, width - pad_x, y + 4), fill=line, width=1)
            y += 24
    img.save(output)
    return output


def send_email_report(
    artifacts: Iterable[ReportArtifacts],
    *,
    mail_config: dict[str, Any],
    dry_run: bool = False,
) -> dict[str, Any]:
    mail_config = _with_cronicle_mail_defaults(mail_config)
    artifacts = list(artifacts)
    recipients = mail_config.get("to") or []
    if isinstance(recipients, str):
        recipients = [recipients]
    if not recipients:
        return {"sent": False, "reason": "no_recipients"}
    host = str(mail_config.get("smtp_host") or "").strip()
    from_addr = str(mail_config.get("from") or "").strip()
    if not host or not from_addr:
        missing = []
        if not host:
            missing.append("smtp_host")
        if not from_addr:
            missing.append("from")
        return {"sent": False, "reason": "missing_smtp_config", "missing": missing, "to": recipients}
    subject = mail_config.get("subject") or f"长桥股票长期趋势报告 {date.today().isoformat()}"
    body_lines = ["本次生成的长期趋势分析报告：", ""]
    for item in artifacts:
        body_lines.append(f"- {item.title}: {item.markdown_path}")
    if dry_run:
        return {
            "sent": False,
            "dry_run": True,
            "to": recipients,
            "subject": subject,
            "attachments": 0,
            "html": True,
        }
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = from_addr
    msg["To"] = ", ".join(recipients)
    msg.set_content("\n".join(body_lines))
    msg.add_alternative(render_email_html(artifacts, subject=subject), subtype="html")
    port = int(mail_config.get("smtp_port", 465))
    username = mail_config.get("username") or os.getenv(str(mail_config.get("username_env") or ""))
    password = mail_config.get("password") or os.getenv(str(mail_config.get("password_env") or ""))
    use_ssl = bool(mail_config.get("ssl", True))
    client_cls = smtplib.SMTP_SSL if use_ssl else smtplib.SMTP
    with client_cls(host, port, timeout=int(mail_config.get("timeout_seconds", 30))) as smtp:
        if not use_ssl and mail_config.get("starttls", True):
            smtp.starttls()
        if username or password:
            smtp.login(username or "", password or "")
        smtp.send_message(msg)
    return {"sent": True, "to": recipients, "attachments": 0, "html": True}


def _with_cronicle_mail_defaults(mail_config: dict[str, Any]) -> dict[str, Any]:
    merged = dict(mail_config or {})
    needs_server_defaults = not merged.get("smtp_host") or not merged.get("from") or not (
        merged.get("username") or os.getenv(str(merged.get("username_env") or ""))
    ) or not (
        merged.get("password") or os.getenv(str(merged.get("password_env") or ""))
    )
    if not needs_server_defaults or not DEFAULT_CRONICLE_CONFIG_PATH.exists():
        return merged
    try:
        config = json.loads(DEFAULT_CRONICLE_CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return merged
    mail_options = config.get("mail_options") or {}
    auth = mail_options.get("auth") or {}
    if not merged.get("smtp_host") and config.get("smtp_hostname"):
        merged["smtp_host"] = config.get("smtp_hostname")
    if not merged.get("smtp_port") and config.get("smtp_port"):
        merged["smtp_port"] = config.get("smtp_port")
    if not merged.get("from") and config.get("email_from"):
        merged["from"] = config.get("email_from")
    if "ssl" not in merged and "secure" in mail_options:
        merged["ssl"] = bool(mail_options.get("secure"))
    if not merged.get("username") and auth.get("user"):
        merged["username"] = auth.get("user")
    if not merged.get("password") and auth.get("pass"):
        merged["password"] = auth.get("pass")
    return merged


def render_email_html(artifacts: Iterable[ReportArtifacts], *, subject: str | None = None) -> str:
    cards = []
    for item in artifacts:
        markdown = item.markdown_path.read_text(encoding="utf-8") if item.markdown_path.exists() else ""
        cards.append(_email_report_card(item, markdown))
    title = subject or f"长桥股票长期趋势报告 {date.today().isoformat()}"
    return "\n".join(
        [
            "<!doctype html>",
            '<html lang="zh-CN">',
            "<head>",
            '<meta charset="utf-8">',
            '<meta name="viewport" content="width=device-width, initial-scale=1">',
            f"<title>{html_escape(title)}</title>",
            "<style>",
            "body{margin:0;padding:0;background:#eef2f7;color:#111827;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','PingFang SC','Microsoft YaHei',Arial,sans-serif;}",
            ".wrap{width:100%;background:#eef2f7;padding:18px 0;}",
            ".container{max-width:760px;margin:0 auto;padding:0 14px;box-sizing:border-box;}",
            ".header{padding:14px 2px 18px;}",
            ".eyebrow{margin:0 0 6px;color:#2563eb;font-size:12px;font-weight:800;letter-spacing:.04em;text-transform:uppercase;}",
            "h1{margin:0;color:#0f172a;font-size:24px;line-height:1.25;font-weight:850;}",
            ".meta{margin:8px 0 0;color:#64748b;font-size:13px;line-height:1.6;}",
            ".card{margin:0 0 14px;background:#fff;border:1px solid #dbe3ef;border-radius:10px;overflow:hidden;box-shadow:0 8px 24px rgba(15,23,42,.06);}",
            ".card-title{padding:14px 16px;background:#0f172a;color:#fff;font-size:18px;line-height:1.35;font-weight:850;}",
            ".section{padding:14px 16px;border-top:1px solid #e5e7eb;}",
            ".section h2{margin:0 0 8px;color:#1d4ed8;font-size:15px;line-height:1.35;font-weight:850;}",
            ".section p{margin:0 0 8px;color:#1f2937;font-size:14px;line-height:1.72;word-break:break-word;}",
            ".section ul{margin:0;padding-left:18px;}",
            ".section li{margin:0 0 7px;color:#1f2937;font-size:14px;line-height:1.72;word-break:break-word;}",
            ".path{padding:10px 16px;background:#f8fafc;color:#64748b;font-size:12px;line-height:1.5;word-break:break-all;}",
            ".footer{padding:12px 2px;color:#64748b;font-size:12px;line-height:1.6;}",
            "@media screen and (max-width:600px){.wrap{padding:8px 0}.container{padding:0 8px}h1{font-size:20px}.card-title{font-size:16px;padding:12px}.section{padding:12px}.section p,.section li{font-size:13px}.path{padding:9px 12px}}",
            "</style>",
            "</head>",
            "<body>",
            '<div class="wrap"><div class="container">',
            '<div class="header">',
            '<p class="eyebrow">Longbridge Stock Report</p>',
            f"<h1>{html_escape(title)}</h1>",
            f'<p class="meta">生成时间：{html_escape(datetime.now().strftime("%Y-%m-%d %H:%M"))}。正文已按手机和 PC 邮箱客户端优化。</p>',
            "</div>",
            *cards,
            '<div class="footer">提示：本邮件仅为研究辅助，不构成确定收益承诺或投资建议。</div>',
            "</div></div>",
            "</body>",
            "</html>",
        ]
    )


def _email_report_card(item: ReportArtifacts, markdown: str) -> str:
    sections = _parse_markdown_blocks(markdown)
    parts = [f'<article class="card"><div class="card-title">{html_escape(item.title)}</div>']
    for kind, payload in sections:
        if kind in {"title", "meta"}:
            continue
        heading = str(payload.get("heading") or "报告内容")
        rows = [str(row).strip() for row in payload.get("items") or [] if str(row).strip()]
        if not rows:
            continue
        parts.append('<section class="section">')
        parts.append(f"<h2>{html_escape(heading)}</h2>")
        if len(rows) == 1:
            parts.append(f"<p>{html_escape(rows[0])}</p>")
        else:
            parts.append("<ul>")
            parts.extend(f"<li>{html_escape(row)}</li>" for row in rows[:12])
            if len(rows) > 12:
                parts.append(f"<li>其余 {len(rows) - 12} 条可在历史报告页面查看完整正文。</li>")
            parts.append("</ul>")
        parts.append("</section>")
    parts.append(f'<div class="path">本地 Markdown：{html_escape(str(item.markdown_path))}</div>')
    parts.append("</article>")
    return "\n".join(parts)


def guess_name_from_news(news: list[dict[str, Any]]) -> str | None:
    for item in news:
        title = str(item.get("title") or "")
        if "MUYUAN" in title.upper():
            return "牧原股份"
    return None


def _parse_markdown_blocks(markdown: str) -> list[tuple[str, Any]]:
    blocks: list[tuple[str, Any]] = []
    current: dict[str, Any] | None = None
    for raw in markdown.splitlines():
        text = raw.strip()
        if not text:
            continue
        if text.startswith("# "):
            blocks.append(("title", text[2:].strip()))
            current = None
        elif text.startswith("## "):
            current = {"heading": text[3:].strip(), "items": []}
            blocks.append(("section", current))
        elif current is None:
            blocks.append(("meta", text))
        else:
            current["items"].append(text.lstrip("- ").strip())
    return blocks


def _scenario_lines(report: dict[str, Any]) -> list[str]:
    ind = report["indicators"]
    close = _float(ind.get("close"))
    ma60 = _float(ind.get("ma60"))
    support = round(max(_float(ind.get("ma20")), close * 0.92), 2)
    return [
        f"乐观：资金连续流入并站稳 {round(max(ma60, close * 1.05), 2)}，趋势修复目标看 {round(close * 1.15, 2)}-{round(close * 1.23, 2)}。",
        f"中性：资金不连续，股价在 {support}-{round(max(ma60, close * 1.07), 2)} 区间震荡筑底。",
        f"悲观：基本面或资金转弱，回踩 {support} 甚至 {round(close * 0.86, 2)}。",
    ]


def _operation_lines(report: dict[str, Any]) -> list[str]:
    ind = report["indicators"]
    close = _float(ind.get("close"))
    ma20 = _float(ind.get("ma20"))
    ma60 = _float(ind.get("ma60"))
    return [
        f"不在连续大涨后追高；优先等回踩 {round(max(ma20, close * 0.95), 2)} 附近确认。",
        f"第一观察买点：回踩不破且大单资金不明显流出。",
        f"右侧确认：放量突破并站稳 {round(max(ma60, close * 1.05), 2)}。风险线：跌破 {round(close * 0.92, 2)} 降低判断。",
    ]


def _sector_text(sector: dict[str, Any]) -> str:
    if not sector:
        return "板块信息：未取到本地行业/概念缓存。"
    concepts = sector.get("concepts") or []
    if isinstance(concepts, str):
        concepts_text = concepts
    else:
        concepts_text = "、".join(str(item) for item in concepts[:6])
    return f"板块信息：{sector.get('exchange_board') or '-'}，行业 {sector.get('industry') or '-'}，概念 {concepts_text or '-'}。"


def _capital_summary_text(summary: dict[str, Any]) -> str:
    if not summary:
        return "历史资金流：本地 ClickHouse 暂无可用资金数据。"
    return (
        f"最近 {int(_float(summary.get('days')))} 个资金交易日："
        f"总净流入 {_money_10k(summary.get('sum_total_net'))}，"
        f"大单净流入 {_money_10k(summary.get('sum_large_net'))}，"
        f"大单净流入天数 {int(_float(summary.get('large_positive_days')))} 天。"
    )


def _recent_capital_text(recent: list[dict[str, Any]]) -> str:
    if not recent:
        return "最近交易日资金：暂无。"
    row = recent[0]
    return (
        f"最近交易日资金：总净流入 {_money_10k(row.get('total_net'))}，"
        f"大单净流入 {_money_10k(row.get('large_net'))}，"
        f"大单占比 {_fmt_pct(_float(row.get('large_net_ratio')) * 100)}。"
    )


def _news_line(item: dict[str, Any]) -> str:
    title = str(item.get("title") or "").strip()
    dt = str(item.get("published_at") or "")[:10]
    return f"- {dt} {title}"


def _find_font() -> str | None:
    configured = os.getenv("LONG_TERM_REPORT_FONT")
    candidates = [configured] if configured else []
    candidates.extend(DEFAULT_FONT_CANDIDATES)
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return candidate
    return None


def _wrap_text(draw: Any, text: str, font: Any, max_width: int) -> list[str]:
    lines: list[str] = []
    current = ""
    for char in text:
        test = current + char
        if draw.textbbox((0, 0), test, font=font)[2] <= max_width:
            current = test
        else:
            if current:
                lines.append(current)
            current = char
    if current:
        lines.append(current)
    return lines or [""]


def _ma(values: list[float], n: int) -> float | None:
    if len(values) < n:
        return None
    return sum(values[-n:]) / n


def _ema(values: list[float], n: int) -> list[float]:
    alpha = 2 / (n + 1)
    current = values[0]
    out: list[float] = []
    for value in values:
        current = alpha * value + (1 - alpha) * current
        out.append(current)
    return out


def _rsi(values: list[float], n: int) -> float | None:
    if len(values) <= n:
        return None
    gains: list[float] = []
    losses: list[float] = []
    for index in range(len(values) - n, len(values)):
        diff = values[index] - values[index - 1]
        gains.append(max(diff, 0))
        losses.append(max(-diff, 0))
    avg_loss = sum(losses) / n
    if avg_loss == 0:
        return 100.0
    rs = (sum(gains) / n) / avg_loss
    return 100 - 100 / (1 + rs)


def _return_pct(values: list[float], days: int) -> float | None:
    if len(values) <= days or values[-days - 1] == 0:
        return None
    return (values[-1] / values[-days - 1] - 1) * 100


def _pct(value: float, base: float | None) -> float | None:
    if base in (None, 0):
        return None
    return (value / base - 1) * 100


def _float(value: Any) -> float:
    if value is None or value == "":
        return 0.0
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _fmt(value: Any) -> str:
    if value is None:
        return "-"
    return f"{_float(value):.2f}"


def _fmt_pct(value: Any) -> str:
    if value is None:
        return "-"
    return f"{_float(value):+.1f}%"


def _money_10k(value: Any) -> str:
    number = _float(value)
    if abs(number) >= 10000:
        return f"{number / 10000:+.2f}亿"
    return f"{number:+.2f}万"


def _date_key(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    return text[:10]


def _bar_date_key(row: dict[str, Any]) -> str:
    value = row.get("trade_date") or row.get("time") or row.get("date")
    if isinstance(value, datetime):
        if value.tzinfo:
            return value.astimezone(timezone(timedelta(hours=8))).date().isoformat()
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    text = str(value or "").strip()
    if not text:
        return ""
    if text.endswith("Z") and "T" in text:
        try:
            parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
            return parsed.astimezone(timezone(timedelta(hours=8))).date().isoformat()
        except ValueError:
            return text[:10]
    return text[:10]


def _parse_date(value: str) -> date | None:
    try:
        return date.fromisoformat(str(value)[:10])
    except ValueError:
        return None


def _capital_summary_from_daily_rows(rows: Iterable[dict[str, Any]]) -> dict[str, Any]:
    daily = list(rows)
    if not daily:
        return {}
    large_ratios = [_float(row.get("large_net_ratio")) for row in daily if row.get("large_net_ratio") is not None]
    return {
        "days": len(daily),
        "sum_total_net": round(sum(_float(row.get("total_net")) for row in daily), 2),
        "sum_large_net": round(sum(_float(row.get("large_net")) for row in daily), 2),
        "sum_medium_net": round(sum(_float(row.get("medium_net")) for row in daily), 2),
        "sum_small_net": round(sum(_float(row.get("small_net")) for row in daily), 2),
        "avg_large_net_ratio": round(sum(large_ratios) / len(large_ratios), 4) if large_ratios else None,
        "positive_days": sum(1 for row in daily if _float(row.get("total_net")) > 0),
        "large_positive_days": sum(1 for row in daily if _float(row.get("large_net")) > 0),
    }


def _market_from_symbol(symbol: str) -> str:
    value = symbol.upper()
    if value.endswith((".HK", ".HS")):
        return "hk"
    if value.endswith(".US"):
        return "us"
    return "cn"


def _escape_sql(value: str) -> str:
    return value.replace("\\", "\\\\").replace("'", "\\'")

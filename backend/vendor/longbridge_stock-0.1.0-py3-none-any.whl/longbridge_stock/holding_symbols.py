from __future__ import annotations

import json
import subprocess
from typing import Any, Callable


def run_positions_json() -> Any:
    proc = subprocess.run(
        ["longbridge", "positions", "--format", "json"],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=45,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr or proc.stdout or "longbridge positions failed")
    return json.loads(proc.stdout or "[]")


def resolve_hk_holding_symbols(
    symbols_arg: str,
    *,
    positions_loader: Callable[[], Any] = run_positions_json,
    fallback_symbols_arg: str | None = None,
    include_shorts: bool = False,
) -> list[str]:
    if symbols_arg.strip().lower() == "auto":
        try:
            symbols = extract_hk_holding_symbols(positions_loader(), include_shorts=include_shorts)
        except Exception:
            if not fallback_symbols_arg:
                raise
            symbols = _parse_manual_symbols(fallback_symbols_arg)
    else:
        symbols = _parse_manual_symbols(symbols_arg)
    deduped: list[str] = []
    for symbol in symbols:
        if symbol and symbol not in deduped:
            deduped.append(symbol)
    return deduped


def resolve_equity_holding_symbols(
    symbols_arg: str,
    *,
    positions_loader: Callable[[], Any] = run_positions_json,
    fallback_symbols_arg: str | None = None,
    include_shorts: bool = False,
) -> list[str]:
    if symbols_arg.strip().lower() == "auto":
        try:
            symbols = extract_equity_holding_symbols(positions_loader(), include_shorts=include_shorts)
        except Exception:
            if not fallback_symbols_arg:
                raise
            symbols = _parse_manual_symbols(fallback_symbols_arg)
    else:
        symbols = _parse_manual_symbols(symbols_arg)
    deduped: list[str] = []
    for symbol in symbols:
        if symbol and symbol not in deduped:
            deduped.append(symbol)
    return deduped


def _parse_manual_symbols(symbols_arg: str) -> list[str]:
    return [item.strip().upper() for item in symbols_arg.split(",") if item.strip()]


def extract_hk_holding_symbols(rows: Any, *, include_shorts: bool = False) -> list[str]:
    output: list[str] = []
    for row in rows if isinstance(rows, list) else []:
        symbol = str(row.get("symbol") or "").strip().upper()
        if not symbol.endswith(".HK"):
            continue
        quantity = _to_float(row.get("quantity"))
        if quantity == 0 or (quantity < 0 and not include_shorts):
            continue
        if is_option_symbol(symbol, str(row.get("name") or "")):
            continue
        if symbol not in output:
            output.append(symbol)
    return output


def extract_equity_holding_symbols(rows: Any, *, include_shorts: bool = False) -> list[str]:
    output: list[str] = []
    for row in rows if isinstance(rows, list) else []:
        symbol = str(row.get("symbol") or "").strip().upper()
        if "." not in symbol:
            continue
        quantity = _to_float(row.get("quantity"))
        if quantity == 0 or (quantity < 0 and not include_shorts):
            continue
        if is_option_symbol(symbol, str(row.get("name") or "")):
            continue
        if symbol not in output:
            output.append(symbol)
    return output


def _to_float(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def is_option_symbol(symbol: str, name: str) -> bool:
    if name.endswith(" Put") or name.endswith(" Call"):
        return True
    code = symbol.rsplit(".", 1)[0]
    return any(flag in code for flag in ("260", "261")) and (
        code.endswith("P") or "P" in code[-8:] or "C" in code[-8:]
    )

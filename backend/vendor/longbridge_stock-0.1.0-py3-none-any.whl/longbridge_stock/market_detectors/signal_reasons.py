from __future__ import annotations

from dataclasses import dataclass

from .models import DetectionEvent


@dataclass(frozen=True)
class SignalReason:
    code: str
    text: str


def explain_signal(source: DetectionEvent) -> SignalReason:
    values = {item.name: item.actual for item in source.evidence}
    side = str(values.get("side", ""))
    line = _line_label(
        str(values.get("role", "MAIN")),
        int(values.get("generation", 0)),
    )
    templates = {
        "BREAK_CONFIRMED_EXIT": f"跌破{line}，确认离场",
        "BREAK_CONFIRMED_ENTRY": f"突破{line}及箱体上沿，放量确认",
        "BREAKOUT_PATTERN_CONFIRMED": f"突破{line}，三红兵确认",
        "ACTIVE_LINE_BOUNCE": f"回踩{line}，多头K线站稳",
        "ACTIVE_LINE_REJECTION": f"反抽{line}，空头K线受阻",
        "WEAK_FAILURE": (
            f"回踩{line}，突破保持有效"
            if side == "RESISTANCE"
            else f"反抽{line}失败，空头延续"
        ),
        "STRONG_RECLAIM": (
            f"跌破{line}后重新站回"
            if side == "SUPPORT"
            else f"突破{line}后重新跌回"
        ),
    }
    return SignalReason(source.event_type, templates.get(source.event_type, source.event_type))


def _line_label(role: str, generation: int) -> str:
    if role == "MAIN":
        return "主趋势线"
    numbers = {1: "一", 2: "二", 3: "三"}
    level = numbers.get(generation, str(generation))
    return f"{level}级加速线"

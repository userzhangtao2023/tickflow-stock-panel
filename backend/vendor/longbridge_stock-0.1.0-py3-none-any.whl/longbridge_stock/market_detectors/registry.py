from __future__ import annotations

from collections.abc import Iterable

from .models import DetectorCategory
from .protocols import MarketDetector


_CATEGORY_ORDER = {
    DetectorCategory.PRIMITIVE: 0,
    DetectorCategory.CANDLE_PATTERN: 1,
    DetectorCategory.LINE_STRUCTURE: 2,
    DetectorCategory.PRICE_STRUCTURE: 3,
    DetectorCategory.RETEST_STRUCTURE: 4,
    DetectorCategory.REGIME: 5,
    DetectorCategory.DECISION: 6,
}


class DetectorRegistry:
    def __init__(self, detectors: Iterable[MarketDetector] = ()) -> None:
        self._detectors: dict[str, MarketDetector] = {}
        for detector in detectors:
            self.register(detector)

    def register(self, detector: MarketDetector) -> None:
        detector_id = detector.manifest.detector_id
        if detector_id in self._detectors:
            raise ValueError(f"duplicate detector_id: {detector_id}")
        self._detectors[detector_id] = detector

    def get(self, detector_id: str) -> MarketDetector:
        return self._detectors[detector_id]

    def execution_order(self, timeframe: str) -> tuple[MarketDetector, ...]:
        self._validate_dependencies()
        for detector in self._detectors.values():
            supported = detector.manifest.supported_timeframes
            if "ANY" not in supported and timeframe not in supported:
                raise ValueError(
                    f"detector {detector.manifest.detector_id} does not support {timeframe}"
                )

        remaining = {
            detector_id: set(detector.manifest.requires)
            for detector_id, detector in self._detectors.items()
        }
        ordered: list[MarketDetector] = []
        while remaining:
            ready = [
                detector_id
                for detector_id, dependencies in remaining.items()
                if not dependencies
            ]
            if not ready:
                cycle = ", ".join(sorted(remaining))
                raise ValueError(f"circular detector dependencies: {cycle}")
            ready.sort(key=self._sort_key)
            detector_id = ready[0]
            ordered.append(self._detectors[detector_id])
            del remaining[detector_id]
            for dependencies in remaining.values():
                dependencies.discard(detector_id)
        return tuple(ordered)

    def _validate_dependencies(self) -> None:
        known = set(self._detectors)
        for detector in self._detectors.values():
            missing = set(detector.manifest.requires) - known
            if missing:
                names = ", ".join(sorted(missing))
                raise ValueError(
                    f"detector {detector.manifest.detector_id} missing dependencies: {names}"
                )

    def _sort_key(self, detector_id: str) -> tuple[int, str]:
        manifest = self._detectors[detector_id].manifest
        return (_CATEGORY_ORDER[manifest.category], detector_id)

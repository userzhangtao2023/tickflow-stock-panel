from __future__ import annotations

from dataclasses import asdict, dataclass

from longbridge_stock.dow_trend_replay import Bar

from .models import (
    DetectionContext, DetectionEvent, DetectorCategory, DetectorManifest,
    DetectorPhase, DetectorSnapshot, DetectedStructure, Evidence,
    SerializedDetectorState, make_stable_id,
)


@dataclass(frozen=True)
class BoxState:
    structure_id: str
    start_index: int
    created_index: int
    top: float
    bottom: float
    up_closes: int = 0
    down_closes: int = 0


class BoxPatternDetector:
    def __init__(self, *, window: int = 6, tolerance_ratio: float = 0.003) -> None:
        if window < 4:
            raise ValueError("box window must be at least 4")
        self.window = window
        self.tolerance_ratio = tolerance_ratio
        self._active: BoxState | None = None
        self._snapshot = DetectorSnapshot.empty("structure.box", -1)

    @property
    def manifest(self) -> DetectorManifest:
        return DetectorManifest(
            "structure.box", "1.0.0", DetectorCategory.PRICE_STRUCTURE, 1,
            warmup_bars=self.window,
        )

    def update(self, bar: Bar, context: DetectionContext) -> DetectorSnapshot:
        event: DetectionEvent | None = None
        just_created = False
        if self._active is None and len(context.history) >= self.window:
            candidate = self._detect_candidate(
                context.history[-self.window:], context.symbol, context.timeframe
            )
            if candidate:
                self._active = candidate
                just_created = True
                event = self._event(candidate, "BOX_CONFIRMED", bar.index)

        phase = DetectorPhase.IDLE
        local_state = "IDLE"
        structure: DetectedStructure | None = None
        if self._active:
            active = self._active
            if not just_created:
                up = active.up_closes + 1 if bar.close > active.top * (1 + self.tolerance_ratio) else 0
                down = active.down_closes + 1 if bar.close < active.bottom * (1 - self.tolerance_ratio) else 0
                active = BoxState(
                    active.structure_id, active.start_index, active.created_index,
                    active.top, active.bottom, up, down,
                )
                self._active = active
            if active.up_closes >= 2 or active.down_closes >= 2:
                broken_up = active.up_closes >= 2
                local_state = "BOX_BROKEN_UP" if broken_up else "BOX_BROKEN_DOWN"
                phase = DetectorPhase.COMPLETED
                event = self._event(
                    active,
                    "BOX_BREAKOUT_CONFIRMED" if broken_up else "BOX_BREAKDOWN_CONFIRMED",
                    bar.index,
                )
                structure = self._structure(active, phase, local_state, bar.index)
                self._active = None
            else:
                if just_created:
                    local_state, phase = "BOX_CONFIRMED", DetectorPhase.CONFIRMED
                elif active.up_closes == 1:
                    local_state, phase = "BOX_BREAKOUT_CANDIDATE", DetectorPhase.OBSERVING
                elif active.down_closes == 1:
                    local_state, phase = "BOX_BREAKDOWN_CANDIDATE", DetectorPhase.OBSERVING
                else:
                    local_state, phase = "BOX_ACTIVE", DetectorPhase.OBSERVING
                structure = self._structure(active, phase, local_state, bar.index)

        structures = (structure,) if structure else ()
        self._snapshot = DetectorSnapshot(
            self.manifest.detector_id, self.manifest.version, bar.index, phase,
            local_state, structures, (event,) if event else (),
            structure.evidence if structure else (),
        )
        return self._snapshot

    def _detect_candidate(self, bars, symbol: str, timeframe: str) -> BoxState | None:
        top, bottom = max(x.high for x in bars), min(x.low for x in bars)
        width = top - bottom
        average_range = sum(x.high - x.low for x in bars) / len(bars)
        midpoint = max((top + bottom) / 2, 1e-9)
        close_slope = abs(bars[-1].close - bars[0].close) / midpoint
        upper_touches = sum(x.high >= top - width * 0.2 for x in bars)
        lower_touches = sum(x.low <= bottom + width * 0.2 for x in bars)
        if not (
            width > 0 and width <= average_range * 4 and width / midpoint <= 0.30
            and close_slope <= max(average_range / midpoint, 0.01)
            and upper_touches >= 2 and lower_touches >= 2
        ):
            return None
        structure_id = make_stable_id(
            "structure.box", "1.0.0", symbol, timeframe, bars[-1].index, 1
        )
        return BoxState(structure_id, bars[0].index, bars[-1].index, top, bottom)

    def _structure(self, state: BoxState, phase: DetectorPhase, local: str, end: int) -> DetectedStructure:
        evidence = (Evidence("box_top", state.top), Evidence("box_bottom", state.bottom))
        return DetectedStructure(
            state.structure_id, "HORIZONTAL_BOX", "NEUTRAL", phase, local,
            state.start_index, end, state.created_index, "NORMAL", evidence,
            self.manifest.detector_id, self.manifest.version,
            invalidation="two consecutive closes outside either boundary",
        )

    def _event(self, state: BoxState, event_type: str, index: int) -> DetectionEvent:
        direction = "BULLISH" if "BREAKOUT" in event_type else "BEARISH" if "BREAKDOWN" in event_type else "NEUTRAL"
        return DetectionEvent(
            make_stable_id(state.structure_id, event_type, index),
            self.manifest.detector_id, self.manifest.version, event_type,
            index, index, state.structure_id, direction, True,
            "horizontal box boundary state changed",
        )

    def snapshot(self) -> DetectorSnapshot:
        return self._snapshot

    def export_state(self) -> SerializedDetectorState:
        return SerializedDetectorState(
            self.manifest.detector_id, self.manifest.version, 1,
            {"active": asdict(self._active) if self._active else None},
        )

    def restore_state(self, state: SerializedDetectorState) -> None:
        active = state.payload.get("active")
        self._active = BoxState(**active) if active else None

    def reset(self) -> None:
        self._active = None
        self._snapshot = DetectorSnapshot.empty(self.manifest.detector_id, -1)

from __future__ import annotations

from longbridge_stock.dow_trend_replay import Bar

from .models import (
    DetectionContext,
    DetectorCategory,
    DetectorManifest,
    DetectorPhase,
    DetectorSnapshot,
    Evidence,
    SerializedDetectorState,
)


class VolumePatternDetector:
    def __init__(
        self,
        *,
        window: int = 20,
        expansion_ratio: float = 1.2,
        contraction_ratio: float = 0.8,
    ) -> None:
        if window < 1:
            raise ValueError("window must be positive")
        self.window = window
        self.expansion_ratio = expansion_ratio
        self.contraction_ratio = contraction_ratio
        self._snapshot = DetectorSnapshot.empty("primitive.volume", -1)

    @property
    def manifest(self) -> DetectorManifest:
        return DetectorManifest(
            detector_id="primitive.volume",
            version="1.0.0",
            category=DetectorCategory.PRIMITIVE,
            state_schema_version=1,
            warmup_bars=1,
        )

    def update(self, bar: Bar, context: DetectionContext) -> DetectorSnapshot:
        prior = context.history[max(0, len(context.history) - self.window - 1) : -1]
        ratio: float | None = None
        if not prior:
            state = "INSUFFICIENT_HISTORY"
        else:
            average = sum(item.volume for item in prior) / len(prior)
            if average <= 0:
                state = "NO_VALID_BASELINE"
            else:
                ratio = bar.volume / average
                if ratio >= self.expansion_ratio:
                    state = "VOLUME_EXPANSION"
                elif ratio <= self.contraction_ratio:
                    state = "VOLUME_CONTRACTION"
                else:
                    state = "VOLUME_NORMAL"
        evidence = (
            Evidence(
                "volume_ratio",
                actual=ratio,
                threshold={
                    "expansion": self.expansion_ratio,
                    "contraction": self.contraction_ratio,
                },
                passed=ratio is not None,
            ),
        )
        self._snapshot = DetectorSnapshot(
            detector=self.manifest.detector_id,
            detector_version=self.manifest.version,
            bar_index=bar.index,
            phase=(
                DetectorPhase.CONFIRMED
                if state in {"VOLUME_EXPANSION", "VOLUME_CONTRACTION"}
                else DetectorPhase.IDLE
            ),
            local_state=state,
            evidence=evidence,
        )
        return self._snapshot

    def snapshot(self) -> DetectorSnapshot:
        return self._snapshot

    def export_state(self) -> SerializedDetectorState:
        return SerializedDetectorState("primitive.volume", "1.0.0", 1, {})

    def restore_state(self, state: SerializedDetectorState) -> None:
        if state.detector_id != "primitive.volume":
            raise ValueError("state belongs to a different detector")

    def reset(self) -> None:
        self._snapshot = DetectorSnapshot.empty("primitive.volume", -1)

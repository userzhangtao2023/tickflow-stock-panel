from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass

from longbridge_stock.dow_trend_replay import Bar

from .models import Evidence


@dataclass(frozen=True)
class BuyPointDetection:
    known_at_index: int
    score: float
    evidence: tuple[Evidence, ...]


@dataclass(frozen=True)
class SwingPoint:
    kind: str
    index: int
    price: float


def _body_ratio(bar: Bar) -> float:
    return abs(bar.close - bar.open) / max(bar.high - bar.low, 1e-9)


def _turning_points(bars: Sequence[Bar]) -> tuple[SwingPoint, ...]:
    if len(bars) < 2:
        return ()
    points: list[SwingPoint] = []

    def add(kind: str, index: int) -> None:
        price = bars[index].high if kind == "HIGH" else bars[index].low
        item = SwingPoint(kind, bars[index].index, price)
        if points and points[-1].kind == kind:
            previous = points[-1]
            better = item.price > previous.price if kind == "HIGH" else item.price < previous.price
            if better:
                points[-1] = item
            return
        points.append(item)

    add("HIGH" if bars[0].close > bars[1].close else "LOW", 0)
    for index in range(1, len(bars) - 1):
        previous = bars[index - 1].close
        current = bars[index].close
        following = bars[index + 1].close
        if current > previous and current > following:
            add("HIGH", index)
        elif current < previous and current < following:
            add("LOW", index)
    add("HIGH" if bars[-1].close > bars[-2].close else "LOW", len(bars) - 1)
    return tuple(points)


def detect_2b_reversal(
    bars: Sequence[Bar],
    *,
    body_ratio_min: float = 0.55,
    max_wave_span: int = 120,
) -> BuyPointDetection | None:
    if len(bars) < 7:
        return None
    wave_five, reclaim = bars[-2:]
    pivots = _turning_points(bars[:-2])
    if len(pivots) < 5:
        return None
    anchors = pivots[-5:]
    if tuple(item.kind for item in anchors) != ("HIGH", "LOW", "HIGH", "LOW", "HIGH"):
        return None
    highs = anchors[0].price, anchors[2].price, anchors[4].price
    lows = anchors[1].price, anchors[3].price
    if not (highs[0] > highs[1] > highs[2] and lows[0] > lows[1]):
        return None
    if anchors[-1].index - anchors[0].index > max_wave_span:
        return None
    broken_level = lows[-1]
    if not (
        wave_five.close < broken_level
        and wave_five.close < wave_five.open
        and _body_ratio(wave_five) >= body_ratio_min
        and reclaim.close > reclaim.open
        and reclaim.close > broken_level
        and _body_ratio(reclaim) >= body_ratio_min
        and reclaim.index == wave_five.index + 1
    ):
        return None
    return BuyPointDetection(
        reclaim.index,
        92.0,
        (
            Evidence("five_wave_decline", True),
            Evidence("broken_level", broken_level),
            Evidence("immediate_reclaim", True),
        ),
    )


def detect_second_test(
    bars: Sequence[Bar],
    *,
    tolerance_ratio: float = 0.03,
    min_gap: int = 3,
    max_gap: int = 40,
) -> BuyPointDetection | None:
    if len(bars) < min_gap + 2:
        return None
    current = bars[-1]
    pivot_lows = [item for item in _turning_points(bars[:-1]) if item.kind == "LOW"]
    eligible = [
        item
        for item in pivot_lows
        if min_gap <= current.index - item.index <= max_gap
        and abs(current.low - item.price) / max(abs(item.price), 1e-9) <= tolerance_ratio
    ]
    if not eligible:
        return None
    body = abs(current.close - current.open)
    lower_wick = min(current.open, current.close) - current.low
    previous = bars[-2]
    bullish_engulfing = (
        current.close > current.open
        and current.high > previous.high
        and current.low < previous.low
    )
    bullish_confirmation = current.close > current.open and (
        _body_ratio(current) >= 0.55
        or lower_wick >= max(body * 2, 1e-9)
        or bullish_engulfing
    )
    if not bullish_confirmation:
        return None
    level = min(eligible, key=lambda item: abs(current.low - item.price))
    return BuyPointDetection(
        current.index,
        86.0,
        (
            Evidence("support_level", level.price),
            Evidence("test_gap", current.index - level.index),
            Evidence("bullish_confirmation", True),
        ),
    )


def detect_strong_emergence(
    bars: Sequence[Bar],
    *,
    bottom_window: int = 60,
    bottom_fraction: float = 0.35,
    pressure_window: int = 5,
    body_ratio_min: float = 0.55,
    volume_ratio_min: float = 1.5,
) -> BuyPointDetection | None:
    if len(bars) < bottom_window + 1 or pressure_window < 1:
        return None
    current = bars[-1]
    history = bars[-(bottom_window + 1) : -1]
    range_high = max(item.high for item in history)
    range_low = min(item.low for item in history)
    bottom_limit = range_low + (range_high - range_low) * bottom_fraction
    if history[-1].close > bottom_limit:
        return None
    pressure = max(item.high for item in history[-pressure_window:])
    volume_history = history[-5:]
    average_volume = sum(item.volume for item in volume_history) / len(volume_history)
    volume_ratio = current.volume / max(average_volume, 1e-9)
    if not (
        current.close > current.open
        and _body_ratio(current) >= body_ratio_min
        and current.close > pressure
        and volume_ratio >= volume_ratio_min
    ):
        return None
    return BuyPointDetection(
        current.index,
        88.0,
        (
            Evidence("bottom_limit", bottom_limit),
            Evidence("pressure", pressure),
            Evidence("volume_ratio", volume_ratio, volume_ratio_min, True),
        ),
    )

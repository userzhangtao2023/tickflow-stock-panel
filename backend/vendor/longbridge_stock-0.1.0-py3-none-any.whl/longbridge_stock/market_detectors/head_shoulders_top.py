from __future__ import annotations

from dataclasses import asdict, dataclass, replace

from longbridge_stock.dow_trend_replay import Bar

from .models import (
    DetectionContext,
    DetectionEvent,
    DetectorCategory,
    DetectorManifest,
    DetectorPhase,
    DetectorSnapshot,
    DetectedStructure,
    Evidence,
    SerializedDetectorState,
    make_stable_id,
)


@dataclass(frozen=True)
class TopPoint:
    index: int
    price: float
    volume: float
    source_id: str


@dataclass(frozen=True)
class HeadShouldersTopState:
    local_state: str = "SEEK_LEFT_SHOULDER"
    left_shoulder: TopPoint | None = None
    first_neck: TopPoint | None = None
    head: TopPoint | None = None
    second_neck: TopPoint | None = None
    right_shoulder: TopPoint | None = None
    structure_id: str | None = None
    confirmed_index: int | None = None
    reclaim_closes: int = 0
    recent_box_breakout_index: int | None = None


class HeadShouldersTopDetector:
    def __init__(self, *, neckline_tolerance_ratio: float = 0.03) -> None:
        self.neckline_tolerance_ratio = neckline_tolerance_ratio
        self._state = HeadShouldersTopState()
        self._snapshot = DetectorSnapshot.empty(
            "structure.head_shoulders_top", -1
        )

    @property
    def manifest(self) -> DetectorManifest:
        return DetectorManifest(
            detector_id="structure.head_shoulders_top",
            version="1.0.0",
            category=DetectorCategory.PRICE_STRUCTURE,
            state_schema_version=1,
            requires=("pivot.causal", "primitive.volume"),
            optional_requires=("structure.box",),
        )

    def update(self, bar: Bar, context: DetectionContext) -> DetectorSnapshot:
        state = self._capture_box_breakout(self._state, context)
        event: DetectionEvent | None = None
        pivot = self._current_pivot(context.require("pivot.causal"), context)
        if (
            pivot
            and pivot[0] == "HIGH"
            and state.local_state in {"INVALIDATED", "COMPLETED", "FAILED"}
        ):
            recent_box = state.recent_box_breakout_index
            if recent_box is not None and bar.index - recent_box > 20:
                recent_box = None
            state = HeadShouldersTopState(
                local_state="SEEK_FIRST_NECK_LOW",
                left_shoulder=pivot[1],
                recent_box_breakout_index=recent_box,
            )
            pivot = None
        if pivot and state.local_state.startswith("SEEK_"):
            state = self._advance(state, pivot)

        if state.local_state == "WAIT_NECKLINE_BREAK":
            assert state.head is not None
            if bar.high > state.head.price * (1 + self.neckline_tolerance_ratio):
                state = replace(state, local_state="INVALIDATED")
                event = self._event(
                    state,
                    "HEAD_HIGH_BROKEN_BEFORE_NECKLINE",
                    bar.index,
                    confirmed=False,
                )
            else:
                neckline = self._neckline_at(state, bar.index)
                volume = context.require("primitive.volume")
                if (
                    bar.close < neckline
                    and volume.local_state == "VOLUME_EXPANSION"
                ):
                    structure_id = make_stable_id(
                        self.manifest.detector_id,
                        self.manifest.version,
                        context.symbol,
                        context.timeframe,
                        bar.index,
                        1,
                    )
                    state = replace(
                        state,
                        local_state="CONFIRMED",
                        structure_id=structure_id,
                        confirmed_index=bar.index,
                        reclaim_closes=0,
                    )
                    event = self._event(
                        state,
                        "NECKLINE_BREAKDOWN_CONFIRMED",
                        bar.index,
                    )
        elif state.local_state in {"CONFIRMED", "RETEST_RECLAIM_CANDIDATE"}:
            assert state.confirmed_index is not None
            if bar.index > state.confirmed_index:
                neckline = self._neckline_at(state, bar.index)
                reclaimed = bar.close > neckline * (
                    1 + self.neckline_tolerance_ratio / 10
                )
                reclaim_closes = state.reclaim_closes + 1 if reclaimed else 0
                touched = (
                    abs(bar.high - neckline) / max(abs(neckline), 1e-9)
                    <= self.neckline_tolerance_ratio
                )
                if reclaim_closes >= 2:
                    state = replace(
                        state,
                        local_state="FAILED",
                        reclaim_closes=reclaim_closes,
                    )
                    event = self._event(
                        state, "NECKLINE_BREAKDOWN_FAILED", bar.index
                    )
                elif reclaimed:
                    state = replace(
                        state,
                        local_state="RETEST_RECLAIM_CANDIDATE",
                        reclaim_closes=reclaim_closes,
                    )
                elif touched and bar.close <= neckline:
                    state = replace(
                        state,
                        local_state="COMPLETED",
                        reclaim_closes=0,
                    )
                    event = self._event(
                        state, "NECKLINE_RETEST_REJECTED", bar.index
                    )
                else:
                    state = replace(
                        state, local_state="CONFIRMED", reclaim_closes=0
                    )

        self._state = state
        phase = self._phase(state.local_state)
        structure = self._structure(state, bar.index, phase)
        self._snapshot = DetectorSnapshot(
            detector=self.manifest.detector_id,
            detector_version=self.manifest.version,
            bar_index=bar.index,
            phase=phase,
            local_state=state.local_state,
            structures=(structure,) if structure else (),
            events=(event,) if event else (),
            evidence=structure.evidence if structure else (),
        )
        return self._snapshot

    def _advance(
        self,
        state: HeadShouldersTopState,
        pivot: tuple[str, TopPoint],
    ) -> HeadShouldersTopState:
        kind, point = pivot
        if state.local_state == "SEEK_LEFT_SHOULDER" and kind == "HIGH":
            return replace(
                state,
                local_state="SEEK_FIRST_NECK_LOW",
                left_shoulder=point,
            )
        if state.local_state == "SEEK_FIRST_NECK_LOW" and kind == "LOW":
            return replace(state, local_state="SEEK_HEAD", first_neck=point)
        if state.local_state == "SEEK_HEAD" and kind == "HIGH":
            assert state.left_shoulder is not None
            if point.price > state.left_shoulder.price:
                return replace(
                    state,
                    local_state="SEEK_SECOND_NECK_LOW",
                    head=point,
                )
            return replace(state, left_shoulder=point)
        if state.local_state == "SEEK_SECOND_NECK_LOW" and kind == "LOW":
            return replace(
                state,
                local_state="SEEK_RIGHT_SHOULDER",
                second_neck=point,
            )
        if state.local_state == "SEEK_RIGHT_SHOULDER" and kind == "HIGH":
            assert state.head is not None
            if point.price >= state.head.price:
                return replace(
                    state,
                    local_state="INVALIDATED",
                    right_shoulder=point,
                )
            return replace(
                state,
                local_state="WAIT_NECKLINE_BREAK",
                right_shoulder=point,
            )
        return state

    @staticmethod
    def _current_pivot(
        snapshot: DetectorSnapshot,
        context: DetectionContext,
    ) -> tuple[str, TopPoint] | None:
        for structure in snapshot.structures:
            if structure.pattern_type not in {"PIVOT_LOW", "PIVOT_HIGH"}:
                continue
            price = next(
                item.actual for item in structure.evidence if item.name == "price"
            )
            pivot_bar = context.history[structure.end_index]
            return (
                structure.pattern_type.removeprefix("PIVOT_"),
                TopPoint(
                    structure.end_index,
                    float(price),
                    pivot_bar.volume,
                    structure.structure_id,
                ),
            )
        return None

    @staticmethod
    def _neckline_at(state: HeadShouldersTopState, index: int) -> float:
        assert state.first_neck is not None and state.second_neck is not None
        distance = state.second_neck.index - state.first_neck.index
        slope = (
            (state.second_neck.price - state.first_neck.price) / distance
            if distance
            else 0.0
        )
        return state.first_neck.price + slope * (index - state.first_neck.index)

    def _structure(
        self,
        state: HeadShouldersTopState,
        end_index: int,
        phase: DetectorPhase,
    ) -> DetectedStructure | None:
        if state.right_shoulder is None:
            return None
        points = (
            ("left_shoulder", state.left_shoulder),
            ("first_neck", state.first_neck),
            ("head", state.head),
            ("second_neck", state.second_neck),
            ("right_shoulder", state.right_shoulder),
        )
        existing = tuple((name, point) for name, point in points if point)
        volume_contraction = bool(
            state.left_shoulder
            and state.head
            and state.right_shoulder
            and state.left_shoulder.volume
            > state.head.volume
            > state.right_shoulder.volume
        )
        pattern_type = (
            "HEAD_SHOULDERS_TOP_BREAKOUT_REVERSAL"
            if state.recent_box_breakout_index is not None
            and state.left_shoulder is not None
            and state.recent_box_breakout_index >= state.left_shoulder.index
            else "HEAD_SHOULDERS_TOP"
        )
        structure_id = state.structure_id or make_stable_id(
            self.manifest.detector_id,
            self.manifest.version,
            state.left_shoulder.index if state.left_shoulder else 0,
            state.right_shoulder.index,
        )
        evidence = tuple(
            Evidence(name, point.price, source_ids=(point.source_id,))
            for name, point in existing
        ) + (
            Evidence(
                "shoulder_volume_contraction",
                actual=(
                    state.left_shoulder.volume,
                    state.head.volume,
                    state.right_shoulder.volume,
                )
                if state.left_shoulder and state.head and state.right_shoulder
                else None,
                threshold="left_shoulder > head > right_shoulder",
                passed=volume_contraction,
            ),
        )
        return DetectedStructure(
            structure_id=structure_id,
            pattern_type=pattern_type,
            direction="BEARISH",
            phase=phase,
            local_state=state.local_state,
            start_index=state.left_shoulder.index if state.left_shoulder else 0,
            end_index=end_index,
            known_at_index=(
                state.confirmed_index
                if state.confirmed_index is not None
                else state.right_shoulder.index
            ),
            quality=(
                "STRONG"
                if state.confirmed_index is not None and volume_contraction
                else "NORMAL"
            ),
            evidence=evidence,
            detector_id=self.manifest.detector_id,
            detector_version=self.manifest.version,
            source_ids=tuple(point.source_id for _, point in existing),
            invalidation=(
                "new high above head before breakdown or persistent neckline reclaim"
            ),
        )

    def _capture_box_breakout(
        self,
        state: HeadShouldersTopState,
        context: DetectionContext,
    ) -> HeadShouldersTopState:
        box = context.upstream.get("structure.box")
        if box is None:
            return state
        if any(event.event_type == "BOX_BREAKOUT_CONFIRMED" for event in box.events):
            return replace(state, recent_box_breakout_index=context.current_bar.index)
        return state

    def _event(
        self,
        state: HeadShouldersTopState,
        event_type: str,
        index: int,
        *,
        confirmed: bool = True,
    ) -> DetectionEvent:
        return DetectionEvent(
            event_id=make_stable_id(state.structure_id, event_type, index),
            detector_id=self.manifest.detector_id,
            detector_version=self.manifest.version,
            event_type=event_type,
            occurred_at_index=index,
            known_at_index=index,
            structure_id=state.structure_id,
            direction="BEARISH",
            confirmed=confirmed,
            reason="head shoulders top neckline state changed",
        )

    @staticmethod
    def _phase(local_state: str) -> DetectorPhase:
        if local_state.startswith("SEEK_"):
            return DetectorPhase.IDLE
        return {
            "WAIT_NECKLINE_BREAK": DetectorPhase.CANDIDATE,
            "CONFIRMED": DetectorPhase.CONFIRMED,
            "RETEST_RECLAIM_CANDIDATE": DetectorPhase.OBSERVING,
            "COMPLETED": DetectorPhase.COMPLETED,
            "FAILED": DetectorPhase.FAILED,
            "INVALIDATED": DetectorPhase.INVALIDATED,
        }.get(local_state, DetectorPhase.IDLE)

    def snapshot(self) -> DetectorSnapshot:
        return self._snapshot

    def export_state(self) -> SerializedDetectorState:
        return SerializedDetectorState(
            self.manifest.detector_id,
            self.manifest.version,
            1,
            asdict(self._state),
        )

    def restore_state(self, state: SerializedDetectorState) -> None:
        payload = dict(state.payload)
        for name in (
            "left_shoulder",
            "first_neck",
            "head",
            "second_neck",
            "right_shoulder",
        ):
            value = payload[name]
            payload[name] = TopPoint(**value) if value else None
        self._state = HeadShouldersTopState(**payload)

    def reset(self) -> None:
        self._state = HeadShouldersTopState()
        self._snapshot = DetectorSnapshot.empty(self.manifest.detector_id, -1)

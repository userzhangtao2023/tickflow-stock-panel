from __future__ import annotations

from longbridge_stock.dow_pivot_detector import CausalPivotDetector

from .box import BoxPatternDetector
from .candlestick import CandlestickPatternDetector
from .decision import SignalDecisionDetector
from .head_shoulders import HeadShouldersBottomDetector
from .head_shoulders_top import HeadShouldersTopDetector
from .line_position import LinePositionDetector
from .orchestrator import UnifiedMarketDetector
from .pivots import PivotDetectorAdapter
from .registry import DetectorRegistry
from .regime import RegimeDetector
from .retest import TrendlineRetestDetector
from .trend_lines import TrendLineDetector
from .volume import VolumePatternDetector


def build_default_registry(
    *,
    pivot_detector: CausalPivotDetector | None = None,
    minor_pivot_detector: CausalPivotDetector | None = None,
    initial_position: bool = False,
    head_shoulders_neckline_tolerance_ratio: float = 0.03,
) -> DetectorRegistry:
    return DetectorRegistry(
        [
            PivotDetectorAdapter(
                pivot_detector,
                minor_detector=minor_pivot_detector,
            ),
            VolumePatternDetector(),
            CandlestickPatternDetector(),
            TrendLineDetector(),
            LinePositionDetector(),
            BoxPatternDetector(),
            HeadShouldersBottomDetector(
                neckline_tolerance_ratio=head_shoulders_neckline_tolerance_ratio
            ),
            HeadShouldersTopDetector(
                neckline_tolerance_ratio=head_shoulders_neckline_tolerance_ratio
            ),
            TrendlineRetestDetector(),
            RegimeDetector(),
            SignalDecisionDetector(initial_position=initial_position),
        ]
    )


def build_default_market_detector(
    symbol: str,
    timeframe: str,
    *,
    pivot_detector: CausalPivotDetector | None = None,
    minor_pivot_detector: CausalPivotDetector | None = None,
    initial_position: bool = False,
    head_shoulders_neckline_tolerance_ratio: float = 0.03,
) -> UnifiedMarketDetector:
    return UnifiedMarketDetector(
        build_default_registry(
            pivot_detector=pivot_detector,
            minor_pivot_detector=minor_pivot_detector,
            initial_position=initial_position,
            head_shoulders_neckline_tolerance_ratio=(
                head_shoulders_neckline_tolerance_ratio
            ),
        ),
        symbol=symbol,
        timeframe=timeframe,
    )

from __future__ import annotations

from collections.abc import Callable, Sequence

from longbridge_stock.dow_trend_replay import Bar

from .models import (
    DetectionContext,
    DetectionEvent,
    DetectorCategory,
    DetectorManifest,
    DetectorPhase,
    DetectorSnapshot,
    DetectedStructure,
    Evidence,
    SerializedDetectorState,
    make_stable_id,
)


PatternFunction = Callable[
    [Sequence[Bar], str, str], DetectedStructure | None
]
_VERSION = "1.0.0"


def body_ratio(bar: Bar) -> float:
    return abs(bar.close - bar.open) / max(bar.high - bar.low, 1e-9)


def _structure(
    *,
    detector_id: str,
    pattern_type: str,
    direction: str,
    bars: Sequence[Bar],
    length: int,
    symbol: str,
    timeframe: str,
    evidence: tuple[Evidence, ...],
) -> DetectedStructure:
    current = bars[-1]
    start = bars[-length].index
    structure_id = make_stable_id(
        detector_id, _VERSION, symbol, timeframe, current.index, 1
    )
    return DetectedStructure(
        structure_id=structure_id,
        pattern_type=pattern_type,
        direction=direction,  # type: ignore[arg-type]
        phase=DetectorPhase.CONFIRMED,
        local_state="CONFIRMED",
        start_index=start,
        end_index=current.index,
        known_at_index=current.index,
        quality="NORMAL",
        evidence=evidence,
        detector_id=detector_id,
        detector_version=_VERSION,
    )


def detect_big_body(
    bars: Sequence[Bar], symbol: str, timeframe: str
) -> DetectedStructure | None:
    if not bars:
        return None
    current = bars[-1]
    ratio = body_ratio(current)
    if ratio < 0.55 or current.close == current.open:
        return None
    bullish = current.close > current.open
    return _structure(
        detector_id="pattern.candle.big_body",
        pattern_type="BIG_BULL" if bullish else "BIG_BEAR",
        direction="BULLISH" if bullish else "BEARISH",
        bars=bars,
        length=1,
        symbol=symbol,
        timeframe=timeframe,
        evidence=(Evidence("body_ratio", ratio, 0.55, True),),
    )


def detect_inside_bar(
    bars: Sequence[Bar], symbol: str, timeframe: str
) -> DetectedStructure | None:
    if len(bars) < 2:
        return None
    mother, current = bars[-2:]
    if current.high > mother.high or current.low < mother.low:
        return None
    return _structure(
        detector_id="pattern.candle.inside_bar",
        pattern_type="INSIDE_BAR",
        direction="NEUTRAL",
        bars=bars,
        length=2,
        symbol=symbol,
        timeframe=timeframe,
        evidence=(Evidence("range_inside_previous", True, True, True),),
    )


def detect_engulfing(
    bars: Sequence[Bar], symbol: str, timeframe: str
) -> DetectedStructure | None:
    if len(bars) < 2:
        return None
    previous, current = bars[-2:]
    bullish = (
        previous.close < previous.open
        and current.close > current.open
        and current.high > previous.high
        and current.low < previous.low
        and body_ratio(current) >= 0.55
    )
    bearish = (
        previous.close > previous.open
        and current.close < current.open
        and current.high > previous.high
        and current.low < previous.low
        and body_ratio(current) >= 0.55
    )
    if not bullish and not bearish:
        return None
    return _structure(
        detector_id="pattern.candle.engulfing",
        pattern_type="BULLISH_ENGULFING" if bullish else "BEARISH_ENGULFING",
        direction="BULLISH" if bullish else "BEARISH",
        bars=bars,
        length=2,
        symbol=symbol,
        timeframe=timeframe,
        evidence=(Evidence("full_range_engulfed", True, True, True),),
    )


def detect_morning_star(
    bars: Sequence[Bar],
    symbol: str,
    timeframe: str,
    *,
    body_ratio_min: float = 0.55,
) -> DetectedStructure | None:
    if len(bars) < 3:
        return None
    first, middle, current = bars[-3:]
    matched = (
        first.close < first.open
        and body_ratio(first) >= body_ratio_min
        and body_ratio(middle) <= 0.35
        and current.close > current.open
        and body_ratio(current) >= body_ratio_min
        and current.close > middle.high
        and current.close > (first.open + first.close) / 2
    )
    if not matched:
        return None
    return _structure(
        detector_id="pattern.candle.morning_star",
        pattern_type="MORNING_STAR",
        direction="BULLISH",
        bars=bars,
        length=3,
        symbol=symbol,
        timeframe=timeframe,
        evidence=(Evidence("third_close_above_first_midpoint", True, True, True),),
    )


def detect_evening_star(
    bars: Sequence[Bar],
    symbol: str,
    timeframe: str,
    *,
    body_ratio_min: float = 0.55,
) -> DetectedStructure | None:
    if len(bars) < 3:
        return None
    first, middle, current = bars[-3:]
    matched = (
        first.close > first.open
        and body_ratio(first) >= body_ratio_min
        and body_ratio(middle) <= 0.35
        and current.close < current.open
        and body_ratio(current) >= body_ratio_min
        and current.close < middle.low
        and current.close < (first.open + first.close) / 2
    )
    if not matched:
        return None
    return _structure(
        detector_id="pattern.candle.evening_star",
        pattern_type="EVENING_STAR",
        direction="BEARISH",
        bars=bars,
        length=3,
        symbol=symbol,
        timeframe=timeframe,
        evidence=(Evidence("third_close_below_first_midpoint", True, True, True),),
    )


def _detect_three(
    bars: Sequence[Bar],
    symbol: str,
    timeframe: str,
    *,
    bullish: bool,
    body_ratio_min: float = 0.5,
) -> DetectedStructure | None:
    if len(bars) < 3:
        return None
    items = bars[-3:]
    directions = [bar.close > bar.open for bar in items]
    closes = [bar.close for bar in items]
    matched = (
        all(directions) if bullish else not any(directions)
    ) and all(body_ratio(bar) >= body_ratio_min for bar in items)
    matched = matched and (
        closes[0] < closes[1] < closes[2]
        if bullish
        else closes[0] > closes[1] > closes[2]
    )
    if not matched:
        return None
    return _structure(
        detector_id=(
            "pattern.candle.three_soldiers"
            if bullish
            else "pattern.candle.three_crows"
        ),
        pattern_type="THREE_SOLDIERS" if bullish else "THREE_CROWS",
        direction="BULLISH" if bullish else "BEARISH",
        bars=bars,
        length=3,
        symbol=symbol,
        timeframe=timeframe,
        evidence=(Evidence("three_directional_bodies", True, True, True),),
    )


def detect_three_soldiers(
    bars: Sequence[Bar],
    symbol: str,
    timeframe: str,
    *,
    body_ratio_min: float = 0.5,
) -> DetectedStructure | None:
    return _detect_three(
        bars,
        symbol,
        timeframe,
        bullish=True,
        body_ratio_min=body_ratio_min,
    )


def detect_three_crows(
    bars: Sequence[Bar], symbol: str, timeframe: str
) -> DetectedStructure | None:
    return _detect_three(bars, symbol, timeframe, bullish=False)


def detect_old_note_pregnancy(
    bars: Sequence[Bar],
    symbol: str,
    timeframe: str,
    *,
    bullish: bool,
    small_body_max: float = 0.25,
    large_body_min: float = 0.55,
    volume_ratio_min: float = 1.5,
) -> DetectedStructure | None:
    """Detect the user's old-note "pregnancy" (a full-range engulfing bar)."""

    if len(bars) < 2:
        return None
    first, current = bars[-2:]
    if body_ratio(first) > small_body_max or body_ratio(current) < large_body_min:
        return None
    if not (current.high > first.high and current.low < first.low):
        return None
    volume_ratio = current.volume / max(first.volume, 1e-9)
    if volume_ratio < volume_ratio_min:
        return None
    if (current.close > current.open) != bullish:
        return None
    return _structure(
        detector_id="pattern.candle.old_note_pregnancy",
        pattern_type="BOTTOM_PREGNANCY" if bullish else "TOP_PREGNANCY",
        direction="BULLISH" if bullish else "BEARISH",
        bars=bars,
        length=2,
        symbol=symbol,
        timeframe=timeframe,
        evidence=(
            Evidence("full_range_engulfed", True, True, True),
            Evidence("volume_ratio", volume_ratio, volume_ratio_min, True),
        ),
    )


def detect_strong_weak_strong(
    bars: Sequence[Bar], symbol: str, timeframe: str
) -> DetectedStructure | None:
    if len(bars) < 4:
        return None
    first, middle_one, middle_two, current = bars[-4:]
    first_body = abs(first.close - first.open)
    middle_small = max(
        abs(middle_one.close - middle_one.open),
        abs(middle_two.close - middle_two.open),
    ) <= first_body * 0.55
    bullish = (
        first.close > first.open
        and body_ratio(first) >= 0.55
        and middle_small
        and current.close > current.open
        and body_ratio(current) >= 0.55
        and current.close > max(item.high for item in bars[-4:-1])
    )
    bearish = (
        first.close < first.open
        and body_ratio(first) >= 0.55
        and middle_small
        and current.close < current.open
        and body_ratio(current) >= 0.55
        and current.close < min(item.low for item in bars[-4:-1])
    )
    if not bullish and not bearish:
        return None
    return _structure(
        detector_id="pattern.candle.strong_weak_strong",
        pattern_type=(
            "BULL_STRONG_WEAK_STRONG" if bullish else "BEAR_STRONG_WEAK_STRONG"
        ),
        direction="BULLISH" if bullish else "BEARISH",
        bars=bars,
        length=4,
        symbol=symbol,
        timeframe=timeframe,
        evidence=(Evidence("middle_body_contraction", True, True, True),),
    )


class CandlestickPatternDetector:
    _functions: tuple[PatternFunction, ...] = (
        detect_big_body,
        detect_inside_bar,
        detect_engulfing,
        detect_morning_star,
        detect_evening_star,
        detect_three_soldiers,
        detect_three_crows,
        detect_strong_weak_strong,
    )

    def __init__(self) -> None:
        self._snapshot = DetectorSnapshot.empty("pattern.candle", -1)

    @property
    def manifest(self) -> DetectorManifest:
        return DetectorManifest(
            detector_id="pattern.candle",
            version=_VERSION,
            category=DetectorCategory.CANDLE_PATTERN,
            state_schema_version=1,
            warmup_bars=4,
        )

    def update(self, bar: Bar, context: DetectionContext) -> DetectorSnapshot:
        structures = tuple(
            result
            for function in self._functions
            if (result := function(context.history, context.symbol, context.timeframe))
            is not None
        )
        events = tuple(
            DetectionEvent(
                event_id=make_stable_id(
                    item.structure_id, "PATTERN_CONFIRMED", item.known_at_index
                ),
                detector_id=self.manifest.detector_id,
                detector_version=_VERSION,
                event_type="PATTERN_CONFIRMED",
                occurred_at_index=item.end_index,
                known_at_index=item.known_at_index,
                structure_id=item.structure_id,
                direction=item.direction,
                confirmed=True,
                reason=item.pattern_type,
                evidence=item.evidence,
            )
            for item in structures
        )
        evidence = tuple(item for structure in structures for item in structure.evidence)
        self._snapshot = DetectorSnapshot(
            detector=self.manifest.detector_id,
            detector_version=_VERSION,
            bar_index=bar.index,
            phase=DetectorPhase.CONFIRMED if structures else DetectorPhase.IDLE,
            local_state="CONFIRMED" if structures else "IDLE",
            structures=structures,
            events=events,
            evidence=evidence,
        )
        return self._snapshot

    def snapshot(self) -> DetectorSnapshot:
        return self._snapshot

    def export_state(self) -> SerializedDetectorState:
        return SerializedDetectorState("pattern.candle", _VERSION, 1, {})

    def restore_state(self, state: SerializedDetectorState) -> None:
        if state.detector_id != "pattern.candle":
            raise ValueError("state belongs to a different detector")

    def reset(self) -> None:
        self._snapshot = DetectorSnapshot.empty("pattern.candle", -1)

from __future__ import annotations

from longbridge_stock.dow_trend_replay import Bar

from .models import (
    DetectionContext,
    DetectionEvent,
    DetectorCategory,
    DetectorManifest,
    DetectorPhase,
    DetectorSnapshot,
    DetectedStructure,
    Evidence,
    SerializedDetectorState,
    make_stable_id,
)


class RegimeDetector:
    def __init__(self) -> None:
        self._regime = "UNKNOWN"
        self._snapshot = DetectorSnapshot.empty("regime.channel", -1)

    @property
    def manifest(self) -> DetectorManifest:
        return DetectorManifest(
            "regime.channel",
            "2.0.0",
            DetectorCategory.REGIME,
            2,
            requires=("line.trend", "line.position", "structure.trendline_retest", "structure.box"),
        )

    def update(self, bar: Bar, context: DetectionContext) -> DetectorSnapshot:
        previous = self._regime
        box = context.require("structure.box")
        lines = context.require("line.trend")
        retest = context.require("structure.trendline_retest")

        box_boundary_event = any(
            event.event_type in {"BOX_BREAKOUT_CONFIRMED", "BOX_BREAKDOWN_CONFIRMED"}
            for event in box.events
        )
        if box_boundary_event or box.local_state in {"BOX_CONFIRMED", "BOX_ACTIVE", "BOX_BREAKOUT_CANDIDATE", "BOX_BREAKDOWN_CANDIDATE"}:
            self._regime = "BOX"
        elif any(event.event_type == "SIDEWAYS_BOX" for event in retest.events):
            self._regime = "BOX"
        else:
            ended = next((event for event in lines.events if event.event_type == "MAIN_TREND_ENDED"), None)
            if ended:
                side = self._event_value(ended, "side")
                self._regime = "DOWN_TRANSITION" if side == "SUPPORT" else "UP_TRANSITION"
            else:
                has_market_marker = any(
                    self._value(item, "is_market_controlling") is not None
                    for item in lines.structures
                )
                marker = (
                    "is_market_controlling"
                    if has_market_marker
                    else "is_controlling"
                )
                controlling = next(
                    (
                        item for item in lines.structures
                        if self._value(item, marker) is True
                    ),
                    None,
                )
                if controlling:
                    self._regime = "UP_CHANNEL" if self._value(controlling, "side") == "SUPPORT" else "DOWN_CHANNEL"

        changed = self._regime != previous
        event = None
        if changed:
            event = DetectionEvent(
                make_stable_id("regime.channel", previous, self._regime, bar.index),
                "regime.channel",
                "2.0.0",
                "REGIME_CHANGED",
                bar.index,
                bar.index,
                None,
                "NEUTRAL",
                True,
                f"{previous}->{self._regime}",
                (Evidence("previous_regime", previous), Evidence("regime", self._regime)),
            )
        structure = DetectedStructure(
            make_stable_id("regime.channel", "2.0.0", context.symbol, context.timeframe, bar.index, self._regime),
            "CHANNEL_REGIME",
            "NEUTRAL",
            DetectorPhase.CONFIRMED,
            self._regime,
            bar.index,
            bar.index,
            bar.index,
            "NORMAL",
            (Evidence("regime", self._regime),),
            "regime.channel",
            "2.0.0",
        )
        self._snapshot = DetectorSnapshot(
            "regime.channel",
            "2.0.0",
            bar.index,
            DetectorPhase.CONFIRMED,
            self._regime,
            (structure,),
            (event,) if event else (),
            structure.evidence,
        )
        return self._snapshot

    @staticmethod
    def _value(structure: DetectedStructure, name: str):
        return next((item.actual for item in structure.evidence if item.name == name), None)

    @staticmethod
    def _event_value(event: DetectionEvent, name: str):
        return next((item.actual for item in event.evidence if item.name == name), None)

    def snapshot(self) -> DetectorSnapshot:
        return self._snapshot

    def export_state(self) -> SerializedDetectorState:
        return SerializedDetectorState("regime.channel", "2.0.0", 2, {"regime": self._regime})

    def restore_state(self, state: SerializedDetectorState) -> None:
        self._regime = str(state.payload["regime"])

    def reset(self) -> None:
        self._regime = "UNKNOWN"
        self._snapshot = DetectorSnapshot.empty("regime.channel", -1, detector_version="2.0.0")

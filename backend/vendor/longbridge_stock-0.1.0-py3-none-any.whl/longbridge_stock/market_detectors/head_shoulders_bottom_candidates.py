from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Iterable

from .models import make_stable_id


_ALLOWED_KINDS = {"LOW", "HIGH"}
_ALLOWED_SCALES = {"MAJOR", "STRUCTURAL"}
_SCALE_RANK = {"STRUCTURAL": 0, "MAJOR": 1}
_PATTERN_TYPE = "HEAD_SHOULDERS_BOTTOM"
_PATTERN_VERSION = "1.0.0"


@dataclass(frozen=True)
class BottomPivot:
    kind: str
    index: int
    confirmed_index: int
    price: float
    volume: float
    scale: str
    source_id: str
    scale_confirmed_index: int | None = None

    def __post_init__(self) -> None:
        if self.scale_confirmed_index is None:
            object.__setattr__(self, "scale_confirmed_index", self.confirmed_index)


@dataclass(frozen=True)
class BottomCandidate:
    candidate_id: str
    left_shoulder: BottomPivot
    first_neck: BottomPivot
    head: BottomPivot
    second_neck: BottomPivot
    right_shoulder: BottomPivot
    pattern_type: str = _PATTERN_TYPE

    @property
    def anchor_indexes(self) -> tuple[int, int, int, int, int]:
        return (
            self.left_shoulder.index,
            self.first_neck.index,
            self.head.index,
            self.second_neck.index,
            self.right_shoulder.index,
        )


@dataclass(frozen=True)
class CandidateGeometry:
    shoulder_gap_ratio: float
    span_ratio: float
    strong: bool


def generate_bottom_candidates(
    pivots: Iterable[BottomPivot],
    max_span_bars: int = 120,
    *,
    as_of_index: int | None = None,
) -> tuple[BottomCandidate, ...]:
    """Generate causal five-point head-and-shoulders bottom candidates.

    ``as_of_index`` is the causal observation point. When omitted, it is the
    confirmation horizon of the latest pivot index supplied by the input,
    including upgrades recorded at that index. Pivot identity is gated by
    ``confirmed_index`` while an upgraded scale is visible only after
    ``scale_confirmed_index``.
    """
    if max_span_bars <= 0:
        raise ValueError("max_span_bars must be positive")

    pivot_values = tuple(pivots)
    resolved_as_of_index = _resolve_as_of_index(pivot_values, as_of_index)
    unique_pivots = _deduplicate_pivots(pivot_values, resolved_as_of_index)
    lows = tuple(pivot for pivot in unique_pivots if pivot.kind == "LOW")
    highs = tuple(pivot for pivot in unique_pivots if pivot.kind == "HIGH")
    candidates: dict[tuple[int, int, int, int, int], BottomCandidate] = {}

    for right_shoulder in lows:
        for head in lows:
            if not (
                head.index < right_shoulder.index
                and head.confirmed_index <= resolved_as_of_index
                and head.price < right_shoulder.price
            ):
                continue
            for left_shoulder in lows:
                if not (
                    left_shoulder.index < head.index
                    and left_shoulder.confirmed_index <= resolved_as_of_index
                    and right_shoulder.index - left_shoulder.index <= max_span_bars
                    and head.price < left_shoulder.price
                ):
                    continue

                first_neck = _highest_confirmed_high(
                    highs,
                    left_shoulder.index,
                    head.index,
                    resolved_as_of_index,
                )
                second_neck = _highest_confirmed_high(
                    highs,
                    head.index,
                    right_shoulder.index,
                    resolved_as_of_index,
                )
                if first_neck is None or second_neck is None:
                    continue
                if first_neck.price <= head.price or second_neck.price <= head.price:
                    continue

                anchors = (
                    left_shoulder,
                    first_neck,
                    head,
                    second_neck,
                    right_shoulder,
                )
                if not _strictly_increasing(anchor.index for anchor in anchors):
                    continue
                if max(anchor.confirmed_index for anchor in anchors) > resolved_as_of_index:
                    continue

                anchor_indexes = tuple(anchor.index for anchor in anchors)
                candidates[anchor_indexes] = BottomCandidate(
                    candidate_id=make_stable_id(
                        "structure.head_shoulders_bottom",
                        _PATTERN_VERSION,
                        *anchor_indexes,
                    ),
                    left_shoulder=left_shoulder,
                    first_neck=first_neck,
                    head=head,
                    second_neck=second_neck,
                    right_shoulder=right_shoulder,
                )

    return tuple(candidates[indexes] for indexes in sorted(candidates))


def candidate_geometry(candidate: BottomCandidate) -> CandidateGeometry:
    shoulder_gap = abs(
        candidate.left_shoulder.price - candidate.right_shoulder.price
    ) / max(candidate.left_shoulder.price, candidate.right_shoulder.price)
    left_span = candidate.head.index - candidate.left_shoulder.index
    right_span = candidate.right_shoulder.index - candidate.head.index
    span_ratio = left_span / max(right_span, 1)
    return CandidateGeometry(
        shoulder_gap_ratio=shoulder_gap,
        span_ratio=span_ratio,
        strong=shoulder_gap <= 0.15 and 0.5 <= span_ratio <= 2.0,
    )


def _deduplicate_pivots(
    pivots: Iterable[BottomPivot],
    as_of_index: int,
) -> tuple[BottomPivot, ...]:
    grouped: dict[tuple[str, int], list[BottomPivot]] = {}
    for pivot in pivots:
        kind = pivot.kind.removeprefix("PIVOT_")
        if kind not in _ALLOWED_KINDS or pivot.scale not in _ALLOWED_SCALES:
            continue
        normalized = pivot if kind == pivot.kind else BottomPivot(
            kind=kind,
            index=pivot.index,
            confirmed_index=pivot.confirmed_index,
            price=pivot.price,
            volume=pivot.volume,
            scale=pivot.scale,
            source_id=pivot.source_id,
        )
        key = (kind, normalized.index)
        grouped.setdefault(key, []).append(normalized)

    deduplicated: list[BottomPivot] = []
    for key in sorted(grouped):
        group = grouped[key]
        first = min(group, key=_identity_sort_key)
        if first.confirmed_index > as_of_index:
            continue
        visible_scales = [
            pivot
            for pivot in group
            if pivot.confirmed_index <= as_of_index
            and _scale_confirmed_index(pivot) <= as_of_index
        ]
        if visible_scales:
            quality = max(visible_scales, key=_quality_sort_key)
            scale = quality.scale
            scale_confirmed_index = _scale_confirmed_index(quality)
        else:
            scale = "STRUCTURAL" if first.scale == "MAJOR" else first.scale
            scale_confirmed_index = first.confirmed_index
        deduplicated.append(
            replace(
                first,
                scale=scale,
                scale_confirmed_index=scale_confirmed_index,
            )
        )

    return tuple(
        sorted(
            deduplicated,
            key=lambda pivot: (pivot.index, pivot.confirmed_index, pivot.kind),
        )
    )


def _resolve_as_of_index(
    pivots: tuple[BottomPivot, ...],
    as_of_index: int | None,
) -> int:
    if as_of_index is not None:
        return as_of_index
    latest_pivot_index = max((pivot.index for pivot in pivots), default=None)
    if latest_pivot_index is None:
        return -1
    return max(
        (
            max(pivot.confirmed_index, _scale_confirmed_index(pivot))
            for pivot in pivots
            if pivot.index == latest_pivot_index
        ),
    )


def _scale_confirmed_index(pivot: BottomPivot) -> int:
    return (
        pivot.scale_confirmed_index
        if pivot.scale_confirmed_index is not None
        else pivot.confirmed_index
    )


def _identity_sort_key(pivot: BottomPivot) -> tuple[object, ...]:
    return (
        pivot.confirmed_index,
        pivot.source_id,
        pivot.price,
        pivot.volume,
        pivot.scale,
        _scale_confirmed_index(pivot),
    )


def _quality_sort_key(pivot: BottomPivot) -> tuple[object, ...]:
    return (
        _SCALE_RANK[pivot.scale],
        -_scale_confirmed_index(pivot),
        -pivot.confirmed_index,
        pivot.source_id,
        pivot.price,
        pivot.volume,
    )


def _highest_confirmed_high(
    highs: tuple[BottomPivot, ...],
    start_index: int,
    end_index: int,
    known_at_index: int,
) -> BottomPivot | None:
    interval = tuple(
        high
        for high in highs
        if start_index < high.index < end_index
        and high.confirmed_index <= known_at_index
    )
    if not interval:
        return None
    return max(interval, key=lambda high: (high.price, -high.index, -high.confirmed_index))


def _strictly_increasing(indexes: Iterable[int]) -> bool:
    values = tuple(indexes)
    return all(left < right for left, right in zip(values, values[1:]))


__all__ = [
    "BottomCandidate",
    "BottomPivot",
    "CandidateGeometry",
    "candidate_geometry",
    "generate_bottom_candidates",
]

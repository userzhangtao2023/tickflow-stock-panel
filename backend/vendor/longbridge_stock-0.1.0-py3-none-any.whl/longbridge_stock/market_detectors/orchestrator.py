from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType
from typing import Mapping, Sequence

from longbridge_stock.dow_trend_replay import Bar

from .models import (
    DetectionContext,
    DetectorCategory,
    DetectorPhase,
    DetectorSnapshot,
    SerializedDetectorState,
)
from .registry import DetectorRegistry


@dataclass(frozen=True)
class UnifiedDetectionSnapshot:
    bar_index: int
    snapshots: Mapping[str, DetectorSnapshot]
    failed: bool = False

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "snapshots", MappingProxyType(dict(self.snapshots))
        )


@dataclass(frozen=True)
class UnifiedDetectorState:
    symbol: str
    timeframe: str
    history: tuple[Bar, ...]
    detector_states: Mapping[str, SerializedDetectorState]

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "detector_states", MappingProxyType(dict(self.detector_states))
        )


class UnifiedMarketDetector:
    def __init__(
        self,
        registry: DetectorRegistry,
        *,
        symbol: str,
        timeframe: str,
    ) -> None:
        self.registry = registry
        self.symbol = symbol
        self.timeframe = timeframe
        self._order = registry.execution_order(timeframe)
        self._history: list[Bar] = []
        self._snapshots: list[UnifiedDetectionSnapshot] = []

    def update(self, bar: Bar) -> UnifiedDetectionSnapshot:
        if bar.index != len(self._history):
            raise ValueError(
                f"bar index must be sequential: expected {len(self._history)}, got {bar.index}"
            )
        self._history.append(bar)
        current: dict[str, DetectorSnapshot] = {}
        unavailable: set[str] = set()
        critical_failed = False

        for detector in self._order:
            manifest = detector.manifest
            detector_id = manifest.detector_id
            if (
                manifest.category == DetectorCategory.DECISION
                and critical_failed
            ):
                current[detector_id] = self._unavailable_snapshot(
                    detector_id, manifest.version, bar.index, "critical detector failed"
                )
                unavailable.add(detector_id)
                continue
            failed_dependencies = set(manifest.requires) & unavailable
            if failed_dependencies:
                current[detector_id] = self._unavailable_snapshot(
                    detector_id,
                    manifest.version,
                    bar.index,
                    "dependencies unavailable: "
                    + ", ".join(sorted(failed_dependencies)),
                )
                unavailable.add(detector_id)
                continue

            upstream_ids = manifest.requires + tuple(
                dependency
                for dependency in manifest.optional_requires
                if dependency in current and dependency not in unavailable
            )
            upstream = {
                dependency: current[dependency]
                for dependency in upstream_ids
            }
            context = DetectionContext(
                symbol=self.symbol,
                timeframe=self.timeframe,
                history=tuple(self._history),
                current_bar_index=bar.index,
                upstream=upstream,
            )
            previous_state = detector.export_state()
            try:
                current[detector_id] = detector.update(bar, context)
            except Exception as exc:
                detector.restore_state(previous_state)
                current[detector_id] = DetectorSnapshot(
                    detector=detector_id,
                    detector_version=manifest.version,
                    bar_index=bar.index,
                    phase=DetectorPhase.ERROR,
                    local_state="DETECTOR_ERROR",
                    error=f"{type(exc).__name__}: {exc}",
                )
                unavailable.add(detector_id)
                critical_failed = critical_failed or manifest.critical

        result = UnifiedDetectionSnapshot(
            bar_index=bar.index,
            snapshots=current,
            failed=critical_failed,
        )
        self._snapshots.append(result)
        return result

    def replay(self, bars: Sequence[Bar]) -> tuple[UnifiedDetectionSnapshot, ...]:
        return tuple(self.update(bar) for bar in bars)

    def export_state(self) -> UnifiedDetectorState:
        return UnifiedDetectorState(
            symbol=self.symbol,
            timeframe=self.timeframe,
            history=tuple(self._history),
            detector_states={
                detector.manifest.detector_id: detector.export_state()
                for detector in self._order
            },
        )

    def restore_state(self, state: UnifiedDetectorState) -> None:
        if state.symbol != self.symbol or state.timeframe != self.timeframe:
            raise ValueError("detector state symbol/timeframe does not match")
        expected = {detector.manifest.detector_id for detector in self._order}
        if set(state.detector_states) != expected:
            raise ValueError("detector state registry does not match")
        for detector in self._order:
            saved = state.detector_states[detector.manifest.detector_id]
            manifest = detector.manifest
            if (
                saved.detector_version != manifest.version
                or saved.state_schema_version != manifest.state_schema_version
            ):
                raise ValueError(
                    f"incompatible state for {manifest.detector_id}"
                )
            detector.restore_state(saved)
        self._history = list(state.history)
        self._snapshots = []

    @staticmethod
    def _unavailable_snapshot(
        detector_id: str,
        version: str,
        bar_index: int,
        reason: str,
    ) -> DetectorSnapshot:
        return DetectorSnapshot(
            detector=detector_id,
            detector_version=version,
            bar_index=bar_index,
            phase=DetectorPhase.ERROR,
            local_state="DEPENDENCY_UNAVAILABLE",
            error=reason,
        )

from __future__ import annotations

from longbridge_stock.dow_trend_replay import Bar

from .models import (
    DetectionContext,
    DetectorCategory,
    DetectorManifest,
    DetectorPhase,
    DetectorSnapshot,
    DetectedStructure,
    Evidence,
    SerializedDetectorState,
    make_stable_id,
)


class LinePositionDetector:
    """把当前控制线投影为位置快照，不重复维护破位生命周期。"""

    def __init__(self, *, tolerance_ratio: float = 0.003) -> None:
        self.tolerance_ratio = tolerance_ratio
        self._snapshot = DetectorSnapshot.empty("line.position", -1)

    @property
    def manifest(self) -> DetectorManifest:
        return DetectorManifest(
            "line.position",
            "2.0.0",
            DetectorCategory.LINE_STRUCTURE,
            1,
            requires=("line.trend",),
        )

    def update(self, bar: Bar, context: DetectionContext) -> DetectorSnapshot:
        structures = []
        line_structures = context.require("line.trend").structures
        has_market_marker = any(
            any(
                item.name == "is_market_controlling"
                for item in line.evidence
            )
            for line in line_structures
        )
        for line in line_structures:
            values = {item.name: item.actual for item in line.evidence}
            marker = (
                "is_market_controlling"
                if has_market_marker
                else "is_controlling"
            )
            if not values.get(marker, False):
                continue
            value = float(values["line_value"])
            side = str(values["side"])
            outside = (
                bar.close < value * (1 - self.tolerance_ratio)
                if side == "SUPPORT"
                else bar.close > value * (1 + self.tolerance_ratio)
            )
            wick = (
                bar.low < value * (1 - self.tolerance_ratio)
                if side == "SUPPORT"
                else bar.high > value * (1 + self.tolerance_ratio)
            )
            if outside:
                state = "OUTSIDE_CONTROL_LINE"
            elif wick:
                state = "WICK_PENETRATION"
            else:
                state = "ON_VALID_SIDE"
            evidence = (
                Evidence("line_id", line.structure_id),
                Evidence("line_value", value),
                Evidence("side", side),
                Evidence("line_state", line.local_state),
            )
            structures.append(DetectedStructure(
                make_stable_id("line.position", "2.0.0", line.structure_id, bar.index),
                "LINE_POSITION",
                "NEUTRAL",
                DetectorPhase.OBSERVING,
                state,
                bar.index,
                bar.index,
                bar.index,
                "NORMAL",
                evidence,
                "line.position",
                "2.0.0",
                source_ids=(line.structure_id,),
            ))
        local_state = structures[0].local_state if structures else "IDLE"
        self._snapshot = DetectorSnapshot(
            "line.position",
            "2.0.0",
            bar.index,
            DetectorPhase.OBSERVING if structures else DetectorPhase.IDLE,
            local_state,
            tuple(structures),
        )
        return self._snapshot

    def snapshot(self) -> DetectorSnapshot:
        return self._snapshot

    def export_state(self) -> SerializedDetectorState:
        return SerializedDetectorState("line.position", "2.0.0", 1, {})

    def restore_state(self, state: SerializedDetectorState) -> None:
        if state.detector_id != "line.position":
            raise ValueError("state belongs to a different detector")

    def reset(self) -> None:
        self._snapshot = DetectorSnapshot.empty("line.position", -1, detector_version="2.0.0")

from __future__ import annotations

from dataclasses import asdict, dataclass, replace

from longbridge_stock.dow_trend_replay import Bar

from .models import (
    DetectionContext,
    DetectionEvent,
    DetectorCategory,
    DetectorManifest,
    DetectorPhase,
    DetectorSnapshot,
    Evidence,
    SerializedDetectorState,
    make_stable_id,
)


_VERSION = "3.3.0"


@dataclass(frozen=True)
class RetestObservation:
    line_id: str
    start_index: int
    side: str
    role: str
    generation: int
    anchor_indexes: tuple[int, int]
    anchor_prices: tuple[float, float]
    touched_index: int | None = None

    def value_at(self, index: int) -> float:
        first_index, second_index = self.anchor_indexes
        first_price, second_price = self.anchor_prices
        return first_price + (second_price - first_price) / (second_index - first_index) * (index - first_index)


class TrendlineRetestDetector:
    def __init__(
        self,
        *,
        tolerance_ratio: float = 0.003,
        retest_proximity_ratio: float = 0.03,
        max_bars: int = 3,
    ) -> None:
        self.tolerance_ratio = tolerance_ratio
        self.retest_proximity_ratio = retest_proximity_ratio
        self.max_bars = max_bars
        self._observing: dict[str, RetestObservation] = {}
        self._emitted_interactions: set[str] = set()
        self._recent_bullish_expansion_index: int | None = None
        self._recent_box_breakout: tuple[int, float] | None = None
        self._previous_market_control_id: str | None = None
        self._snapshot = DetectorSnapshot.empty(
            "structure.trendline_retest", -1, detector_version=_VERSION
        )

    @property
    def manifest(self) -> DetectorManifest:
        return DetectorManifest(
            "structure.trendline_retest",
            _VERSION,
            DetectorCategory.RETEST_STRUCTURE,
            5,
            requires=(
                "line.trend",
                "line.position",
                "pattern.candle",
                "primitive.volume",
                "structure.box",
            ),
        )

    def update(self, bar: Bar, context: DetectionContext) -> DetectorSnapshot:
        self._record_breakout_context(bar, context)
        created: set[str] = set()
        events: list[DetectionEvent] = []
        for event in context.require("line.trend").events:
            if event.event_type != "LINE_BREAK_CONFIRMED" or not event.structure_id:
                continue
            if (
                self._previous_market_control_id is not None
                and event.structure_id != self._previous_market_control_id
            ):
                continue
            values = {item.name: item.actual for item in event.evidence}
            observation = RetestObservation(
                event.structure_id,
                bar.index,
                str(values["side"]),
                str(values["role"]),
                int(values["generation"]),
                tuple(values["anchor_indexes"]),
                tuple(values["anchor_prices"]),
            )
            self._observing[event.structure_id] = observation
            created.add(event.structure_id)
            raw_first_break = values.get("first_break_index")
            first_break_index = (
                bar.index
                if raw_first_break is None
                else int(raw_first_break)
            )
            if observation.side == "SUPPORT":
                events.append(self._event(
                    observation, "BREAK_CONFIRMED_EXIT", bar.index
                ))
            else:
                box_top = self._confirmed_breakout_box_top(
                    bar, first_break_index
                )
                if box_top is not None:
                    events.append(self._event(
                        observation,
                        "BREAK_CONFIRMED_ENTRY",
                        bar.index,
                        extra_evidence=(Evidence("box_top", box_top),),
                    ))

        completed: list[str] = []
        for line_id, observation in self._observing.items():
            if line_id in created:
                continue
            result, updated = self._classify(observation, bar, context)
            self._observing[line_id] = updated
            if result is None:
                continue
            events.append(self._event(updated, result, bar.index))
            completed.append(line_id)
        for line_id in completed:
            del self._observing[line_id]
        events.extend(self._active_line_interactions(bar, context))

        local = (
            "OBSERVING_RETEST"
            if self._observing
            else events[0].event_type
            if events
            else "IDLE"
        )
        phase = (
            DetectorPhase.OBSERVING
            if self._observing
            else DetectorPhase.COMPLETED
            if events
            else DetectorPhase.IDLE
        )
        evidence = tuple(
            Evidence("observed_line_id", line_id)
            for line_id in self._observing
        )
        self._snapshot = DetectorSnapshot(
            "structure.trendline_retest",
            _VERSION,
            bar.index,
            phase,
            local,
            events=tuple(events),
            evidence=evidence,
        )
        self._remember_market_control(context)
        return self._snapshot

    def _remember_market_control(self, context: DetectionContext) -> None:
        lines = context.require("line.trend").structures
        has_market_marker = any(
            any(item.name == "is_market_controlling" for item in line.evidence)
            for line in lines
        )
        if not has_market_marker:
            self._previous_market_control_id = None
            return
        control = next(
            (
                line for line in lines
                if any(
                    item.name == "is_market_controlling" and item.actual is True
                    for item in line.evidence
                )
            ),
            None,
        )
        self._previous_market_control_id = (
            control.structure_id if control is not None else ""
        )

    def _classify(
        self,
        observation: RetestObservation,
        bar: Bar,
        context: DetectionContext,
    ) -> tuple[str | None, RetestObservation]:
        value = observation.value_at(bar.index)
        touched = (
            bar.high >= value * (1 - self.retest_proximity_ratio)
            and bar.low <= value * (1 + self.retest_proximity_ratio)
        )
        if touched and observation.touched_index is None:
            observation = replace(observation, touched_index=bar.index)
        valid_side = (
            bar.close >= value * (1 - self.tolerance_ratio)
            if observation.side == "SUPPORT"
            else bar.close <= value * (1 + self.tolerance_ratio)
        )
        candle_directions = {
            item.direction for item in context.require("pattern.candle").structures
        }
        candle_patterns = {
            item.pattern_type
            for item in context.require("pattern.candle").structures
        }
        volume_expansion = context.require("primitive.volume").local_state == "VOLUME_EXPANSION"
        reclaim_direction = "BULLISH" if observation.side == "SUPPORT" else "BEARISH"
        failure_direction = "BEARISH" if observation.side == "SUPPORT" else "BULLISH"
        if (
            observation.side == "RESISTANCE"
            and not valid_side
            and "THREE_SOLDIERS" in candle_patterns
        ):
            return "BREAKOUT_PATTERN_CONFIRMED", observation
        if observation.touched_index is not None:
            if valid_side and (
                reclaim_direction in candle_directions and volume_expansion
            ):
                return "STRONG_RECLAIM", observation
            if (
                not valid_side
                and failure_direction in candle_directions
                and volume_expansion
            ):
                return "WEAK_FAILURE", observation
        if bar.index - observation.start_index >= self.max_bars:
            return "NO_RETEST", observation
        return None, observation

    def _active_line_interactions(
        self,
        bar: Bar,
        context: DetectionContext,
    ) -> list[DetectionEvent]:
        candle_directions = {
            item.direction
            for item in context.require("pattern.candle").structures
        }
        volume_expansion = (
            context.require("primitive.volume").local_state
            == "VOLUME_EXPANSION"
        )
        events: list[DetectionEvent] = []
        for line in context.require("line.trend").structures:
            if bar.index <= line.known_at_index:
                continue
            values = {item.name: item.actual for item in line.evidence}
            is_market_controlling = values.get(
                "is_market_controlling",
                values.get("is_controlling", False),
            )
            if not is_market_controlling:
                continue
            side = str(values["side"])
            generation = int(values["generation"])
            value = float(values["line_value"])
            if generation >= 2 and not volume_expansion:
                continue
            near = (
                bar.high >= value * (1 - self.retest_proximity_ratio)
                and bar.low <= value * (1 + self.retest_proximity_ratio)
            )
            if side == "SUPPORT":
                valid = bar.close >= value * (1 - self.tolerance_ratio)
                event_type = "ACTIVE_LINE_BOUNCE"
                pattern_ok = "BULLISH" in candle_directions
            else:
                valid = bar.close <= value * (1 + self.tolerance_ratio)
                event_type = "ACTIVE_LINE_REJECTION"
                pattern_ok = "BEARISH" in candle_directions
            if not (near and valid and pattern_ok):
                continue
            observation = RetestObservation(
                line.structure_id,
                bar.index,
                side,
                str(values["role"]),
                generation,
                tuple(values["anchor_indexes"]),
                tuple(values["anchor_prices"]),
                bar.index,
            )
            event = self._event(observation, event_type, bar.index)
            if event.event_id in self._emitted_interactions:
                continue
            self._emitted_interactions.add(event.event_id)
            events.append(event)
        return events

    def _record_breakout_context(
        self,
        bar: Bar,
        context: DetectionContext,
    ) -> None:
        bullish = any(
            item.direction == "BULLISH"
            for item in context.require("pattern.candle").structures
        )
        volume_expansion = (
            context.require("primitive.volume").local_state
            == "VOLUME_EXPANSION"
        )
        if bullish and volume_expansion:
            self._recent_bullish_expansion_index = bar.index
        for box in context.require("structure.box").structures:
            values = {item.name: item.actual for item in box.evidence}
            top = values.get("box_top")
            if top is None:
                continue
            price = float(top)
            if bar.close > price * (1 + self.tolerance_ratio):
                self._recent_box_breakout = (bar.index, price)

    def _confirmed_breakout_box_top(
        self,
        bar: Bar,
        first_break_index: int,
    ) -> float | None:
        impulse = self._recent_bullish_expansion_index
        box = self._recent_box_breakout
        if impulse is None or box is None:
            return None
        box_index, box_top = box
        if not (
            first_break_index <= impulse <= bar.index
            and first_break_index <= box_index <= bar.index
            and bar.index - impulse <= self.max_bars
            and bar.index - box_index <= self.max_bars
        ):
            return None
        return box_top

    @staticmethod
    def _event(
        observation: RetestObservation,
        event_type: str,
        index: int,
        *,
        extra_evidence: tuple[Evidence, ...] = (),
    ) -> DetectionEvent:
        if event_type in {"STRONG_RECLAIM", "ACTIVE_LINE_BOUNCE"}:
            direction = "BULLISH" if observation.side == "SUPPORT" else "BEARISH"
        else:
            direction = "BEARISH" if observation.side == "SUPPORT" else "BULLISH"
        return DetectionEvent(
            make_stable_id("structure.trendline_retest", observation.line_id, event_type, index),
            "structure.trendline_retest",
            _VERSION,
            event_type,
            index,
            index,
            observation.line_id,
            direction,
            True,
            event_type,
            (
                Evidence("side", observation.side),
                Evidence("role", observation.role),
                Evidence("generation", observation.generation),
            ) + extra_evidence,
        )

    def snapshot(self) -> DetectorSnapshot:
        return self._snapshot

    def export_state(self) -> SerializedDetectorState:
        return SerializedDetectorState(
            "structure.trendline_retest",
            _VERSION,
            5,
            {
                "observing": {
                    key: asdict(value) for key, value in self._observing.items()
                },
                "emitted_interactions": tuple(sorted(self._emitted_interactions)),
                "recent_bullish_expansion_index": self._recent_bullish_expansion_index,
                "recent_box_breakout": self._recent_box_breakout,
                "previous_market_control_id": self._previous_market_control_id,
            },
        )

    def restore_state(self, state: SerializedDetectorState) -> None:
        self._observing = {
            key: RetestObservation(
                **{
                    **dict(value),
                    "anchor_indexes": tuple(value["anchor_indexes"]),
                    "anchor_prices": tuple(value["anchor_prices"]),
                }
            )
            for key, value in state.payload["observing"].items()
        }
        self._emitted_interactions = set(
            state.payload.get("emitted_interactions", ())
        )
        self._recent_bullish_expansion_index = state.payload.get(
            "recent_bullish_expansion_index"
        )
        recent_box = state.payload.get("recent_box_breakout")
        self._recent_box_breakout = tuple(recent_box) if recent_box else None
        self._previous_market_control_id = state.payload.get(
            "previous_market_control_id"
        )

    def reset(self) -> None:
        self._observing.clear()
        self._emitted_interactions.clear()
        self._recent_bullish_expansion_index = None
        self._recent_box_breakout = None
        self._previous_market_control_id = None
        self._snapshot = DetectorSnapshot.empty(
            "structure.trendline_retest", -1, detector_version=_VERSION
        )

from __future__ import annotations

from typing import Protocol

from longbridge_stock.dow_trend_replay import Bar

from .models import (
    DetectionContext,
    DetectorManifest,
    DetectorSnapshot,
    SerializedDetectorState,
)


class MarketDetector(Protocol):
    @property
    def manifest(self) -> DetectorManifest: ...

    def update(self, bar: Bar, context: DetectionContext) -> DetectorSnapshot: ...

    def snapshot(self) -> DetectorSnapshot: ...

    def export_state(self) -> SerializedDetectorState: ...

    def restore_state(self, state: SerializedDetectorState) -> None: ...

    def reset(self) -> None: ...

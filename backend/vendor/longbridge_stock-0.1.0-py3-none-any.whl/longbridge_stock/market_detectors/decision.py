from __future__ import annotations

from dataclasses import asdict, dataclass

from longbridge_stock.dow_trend_replay import Bar

from .models import (
    DetectionContext,
    DetectionEvent,
    DetectorCategory,
    DetectorManifest,
    DetectorPhase,
    DetectorSnapshot,
    Evidence,
    SerializedDetectorState,
    make_stable_id,
)
from .signal_reasons import explain_signal


@dataclass(frozen=True)
class PatternConfirmation:
    structure_id: str
    confirmed_index: int
    expires_index: int
    weight: int = 3


class SignalDecisionDetector:
    _DEPENDENCIES = (
        "line.position",
        "structure.trendline_retest",
        "pattern.candle",
        "primitive.volume",
        "regime.channel",
    )

    def __init__(self, *, initial_position: bool = False) -> None:
        # 参数仅为兼容旧调用方；理论信号识别不得读取持仓。
        self._initial_position = initial_position
        self._emitted: set[str] = set()
        self._pattern_confirmations: dict[str, PatternConfirmation] = {}
        self._snapshot = DetectorSnapshot.empty(
            "decision.trade", -1, detector_version="3.3.0"
        )

    @property
    def manifest(self) -> DetectorManifest:
        return DetectorManifest(
            "decision.trade",
            "3.3.0",
            DetectorCategory.DECISION,
            3,
            requires=self._DEPENDENCIES,
            optional_requires=("structure.head_shoulders_bottom",),
        )

    def update(self, bar: Bar, context: DetectionContext) -> DetectorSnapshot:
        decisions: list[DetectionEvent] = []
        self._update_pattern_confirmations(bar.index, context)
        regime = context.require("regime.channel").local_state
        volume = context.require("primitive.volume").local_state
        candle_directions = {
            item.direction for item in context.require("pattern.candle").structures
        }

        sources = context.require("structure.trendline_retest").events
        for source in sources:
            side = self._side_for(
                source,
                regime=regime,
                volume=volume,
                candle_directions=candle_directions,
            )
            if side is None or not source.structure_id:
                continue
            key = f"{side}:{source.event_id}"
            if key in self._emitted:
                continue
            self._emitted.add(key)
            reason = explain_signal(source)
            source_values = {
                item.name: item.actual for item in source.evidence
            }
            confirmations = (
                tuple(sorted(self._pattern_confirmations.values(), key=lambda item: item.structure_id))
                if side == "BUY"
                else ()
            )
            evidence = (
                Evidence("source_event_id", source.event_id, source_ids=(source.event_id,)),
                Evidence("source_event_type", source.event_type),
                Evidence("regime", regime),
                Evidence("volume_state", volume),
                Evidence("candle_directions", tuple(sorted(candle_directions))),
                Evidence("line_side", source_values.get("side")),
                Evidence("line_role", source_values.get("role")),
                Evidence("line_generation", source_values.get("generation")),
                Evidence("confirmation_box_top", source_values.get("box_top")),
                Evidence("reason_code", reason.code),
                Evidence("reason_text", reason.text),
                Evidence("confirming_patterns", tuple(item.structure_id for item in confirmations)),
                Evidence("confirmation_weight", max((item.weight for item in confirmations), default=0)),
            )
            decisions.append(DetectionEvent(
                make_stable_id("decision.trade", side, source.structure_id, source.event_type, bar.index),
                "decision.trade",
                "3.3.0",
                side,
                bar.index,
                bar.index,
                source.structure_id,
                "BULLISH" if side == "BUY" else "BEARISH",
                True,
                reason.text,
                evidence,
            ))

        decisions = self._merge_same_side_decisions(decisions, bar.index)
        decisions = self._resolve_opposite_side_conflict(decisions)
        local = decisions[0].event_type if decisions else "IDLE"
        self._snapshot = DetectorSnapshot(
            "decision.trade",
            "3.3.0",
            bar.index,
            DetectorPhase.CONFIRMED if decisions else DetectorPhase.IDLE,
            local,
            events=tuple(decisions),
            evidence=tuple(item for event in decisions for item in event.evidence),
        )
        return self._snapshot

    @staticmethod
    def _merge_same_side_decisions(
        decisions: list[DetectionEvent],
        index: int,
    ) -> list[DetectionEvent]:
        grouped: dict[str, list[DetectionEvent]] = {}
        for decision in decisions:
            grouped.setdefault(decision.event_type, []).append(decision)

        merged: list[DetectionEvent] = []
        for side, items in grouped.items():
            if len(items) == 1:
                merged.append(items[0])
                continue
            primary = items[0]
            item_values = [
                {evidence.name: evidence.actual for evidence in item.evidence}
                for item in items
            ]
            source_event_ids = tuple(
                values["source_event_id"] for values in item_values
            )
            reason_codes = tuple(values["reason_code"] for values in item_values)
            reason_texts = tuple(values["reason_text"] for values in item_values)
            evidence = primary.evidence + (
                Evidence("source_event_ids", source_event_ids, source_ids=source_event_ids),
                Evidence("reason_codes", reason_codes),
                Evidence("reason_texts", reason_texts),
            )
            merged.append(DetectionEvent(
                make_stable_id(
                    "decision.trade",
                    side,
                    index,
                    *source_event_ids,
                ),
                primary.detector_id,
                primary.detector_version,
                side,
                index,
                index,
                primary.structure_id,
                primary.direction,
                True,
                "；".join(dict.fromkeys(reason_texts)),
                evidence,
            ))
        return merged

    @staticmethod
    def _resolve_opposite_side_conflict(
        decisions: list[DetectionEvent],
    ) -> list[DetectionEvent]:
        if len({item.event_type for item in decisions}) <= 1:
            return decisions
        priority = {
            "BREAK_CONFIRMED_EXIT": 100,
            "BREAK_CONFIRMED_ENTRY": 100,
            "BREAKOUT_PATTERN_CONFIRMED": 90,
            "STRONG_RECLAIM": 80,
            "WEAK_FAILURE": 70,
            "ACTIVE_LINE_REJECTION": 60,
            "ACTIVE_LINE_BOUNCE": 60,
        }

        def rank(item: DetectionEvent) -> tuple[int, int]:
            values = {evidence.name: evidence.actual for evidence in item.evidence}
            reason_codes = values.get("reason_codes") or (
                values.get("source_event_type"),
            )
            strongest = max(priority.get(code, 0) for code in reason_codes)
            return strongest, 1 if item.event_type == "SELL" else 0

        primary = max(decisions, key=rank)
        suppressed = tuple(
            item for item in decisions if item.event_id != primary.event_id
        )
        evidence = primary.evidence + (
            Evidence("suppressed_event_ids", tuple(item.event_id for item in suppressed)),
            Evidence("suppressed_sides", tuple(item.event_type for item in suppressed)),
            Evidence("conflict_resolution", "CONFIRMED_BREAK_PRIORITY"),
        )
        return [DetectionEvent(
            primary.event_id,
            primary.detector_id,
            primary.detector_version,
            primary.event_type,
            primary.occurred_at_index,
            primary.known_at_index,
            primary.structure_id,
            primary.direction,
            primary.confirmed,
            primary.reason,
            evidence,
        )]

    def _update_pattern_confirmations(
        self,
        index: int,
        context: DetectionContext,
    ) -> None:
        self._pattern_confirmations = {
            structure_id: item
            for structure_id, item in self._pattern_confirmations.items()
            if item.expires_index >= index
        }
        snapshot = context.upstream.get("structure.head_shoulders_bottom")
        if snapshot is None:
            return
        for event in snapshot.events:
            if not event.structure_id:
                continue
            if event.event_type == "NECKLINE_BREAK_CONFIRMED":
                self._pattern_confirmations[event.structure_id] = PatternConfirmation(
                    event.structure_id,
                    index,
                    index + 3,
                    3,
                )
            elif event.event_type in {
                "NECKLINE_BREAK_FAILED",
                "HEAD_LOW_BROKEN_BEFORE_NECKLINE",
            }:
                self._pattern_confirmations.pop(event.structure_id, None)

    @staticmethod
    def _side_for(source: DetectionEvent, *, regime: str, volume: str, candle_directions: set[str]) -> str | None:
        event_type = source.event_type
        if source.detector_id != "structure.trendline_retest":
            return None
        if event_type not in {
            "STRONG_RECLAIM",
            "WEAK_FAILURE",
            "BREAK_CONFIRMED_EXIT",
            "BREAK_CONFIRMED_ENTRY",
            "BREAKOUT_PATTERN_CONFIRMED",
            "ACTIVE_LINE_BOUNCE",
            "ACTIVE_LINE_REJECTION",
        }:
            return None
        if regime == "BOX" and event_type not in {
            "BREAK_CONFIRMED_ENTRY",
            "BREAK_CONFIRMED_EXIT",
        }:
            return None
        values = {item.name: item.actual for item in source.evidence}
        line_side = values.get("side")
        if event_type == "BREAK_CONFIRMED_EXIT" and line_side == "SUPPORT":
            return "SELL"
        if event_type == "BREAK_CONFIRMED_ENTRY" and line_side == "RESISTANCE":
            return "BUY"
        if (
            event_type == "BREAKOUT_PATTERN_CONFIRMED"
            and line_side == "RESISTANCE"
            and regime in {"UP_CHANNEL", "UP_TRANSITION"}
        ):
            return "BUY"
        if (
            event_type == "ACTIVE_LINE_BOUNCE"
            and line_side == "SUPPORT"
            and regime in {"UP_CHANNEL", "UP_TRANSITION"}
        ):
            return "BUY"
        if (
            event_type == "ACTIVE_LINE_REJECTION"
            and line_side == "RESISTANCE"
            and regime in {"DOWN_CHANNEL", "DOWN_TRANSITION"}
        ):
            return "SELL"
        if line_side == "SUPPORT":
            if event_type == "STRONG_RECLAIM" and regime == "UP_CHANNEL":
                return "BUY"
            if event_type == "WEAK_FAILURE":
                return "SELL"
        if line_side == "RESISTANCE":
            if event_type == "STRONG_RECLAIM" and regime == "DOWN_CHANNEL":
                return "SELL"
            if event_type == "WEAK_FAILURE":
                return "BUY"
        return None

    def snapshot(self) -> DetectorSnapshot:
        return self._snapshot

    def export_state(self) -> SerializedDetectorState:
        return SerializedDetectorState(
            "decision.trade",
            "3.3.0",
            3,
            {
                "emitted": tuple(sorted(self._emitted)),
                "pattern_confirmations": tuple(
                    asdict(item)
                    for item in sorted(
                        self._pattern_confirmations.values(),
                        key=lambda value: value.structure_id,
                    )
                ),
            },
        )

    def restore_state(self, state: SerializedDetectorState) -> None:
        self._emitted = set(state.payload["emitted"])
        self._pattern_confirmations = {
            item["structure_id"]: PatternConfirmation(**item)
            for item in state.payload.get("pattern_confirmations", ())
        }

    def reset(self) -> None:
        self._emitted.clear()
        self._pattern_confirmations.clear()
        self._snapshot = DetectorSnapshot.empty(
            "decision.trade", -1, detector_version="3.3.0"
        )

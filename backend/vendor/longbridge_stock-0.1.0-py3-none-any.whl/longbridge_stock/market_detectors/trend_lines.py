from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum

from longbridge_stock.dow_trend_replay import Bar

from .models import (
    DetectionContext,
    DetectionEvent,
    DetectorCategory,
    DetectorManifest,
    DetectorPhase,
    DetectorSnapshot,
    DetectedStructure,
    Evidence,
    SerializedDetectorState,
    make_stable_id,
)


_VERSION = "2.1.0"


class LineLifecycleState(str, Enum):
    CANDIDATE = "CANDIDATE"
    ACTIVE = "ACTIVE"
    PARENT_ACTIVE = "PARENT_ACTIVE"
    BREAK_OBSERVING = "BREAK_OBSERVING"
    INVALIDATED = "INVALIDATED"
    HISTORICAL = "HISTORICAL"


@dataclass(frozen=True)
class LinePoint:
    index: int
    price: float
    source_id: str
    confirmed_index: int


@dataclass
class LineRecord:
    line_id: str
    trend_id: str
    side: str
    role: str
    generation: int
    first: LinePoint
    second: LinePoint
    created_index: int
    known_at_index: int
    parent_line_id: str | None
    state: LineLifecycleState = LineLifecycleState.ACTIVE
    is_controlling: bool = False
    touch_count: int = 2
    break_count: int = 0
    first_break_index: int | None = None
    break_confirmed_index: int | None = None
    invalidated_index: int | None = None

    def value_at(self, index: int) -> float:
        slope = (self.second.price - self.first.price) / (
            self.second.index - self.first.index
        )
        return self.first.price + slope * (index - self.first.index)

    @property
    def slope(self) -> float:
        return (self.second.price - self.first.price) / (
            self.second.index - self.first.index
        )


@dataclass
class DirectionalLineState:
    side: str
    points: list[LinePoint]
    lines: list[LineRecord]
    minor_points: list[LinePoint] | None = None
    current_control_id: str | None = None
    trend_id: str | None = None
    candidate_points: list[LinePoint] | None = None
    rebuild_after_index: int = -1

    def __post_init__(self) -> None:
        if self.minor_points is None:
            self.minor_points = []
        if self.candidate_points is None:
            self.candidate_points = []

    def current(self) -> LineRecord | None:
        if self.current_control_id is None:
            return None
        return next(
            (line for line in self.lines if line.line_id == self.current_control_id),
            None,
        )


class UpTrendLineDetector(DirectionalLineState):
    """上涨方向的独立线账本，保留原公开类型名。"""

    def __init__(self) -> None:
        super().__init__("SUPPORT", [], [], [])


class DownTrendLineDetector(DirectionalLineState):
    """下降方向的独立线账本，保留原公开类型名。"""

    def __init__(self) -> None:
        super().__init__("RESISTANCE", [], [], [])


class TrendLineDetector:
    def __init__(self, *, tolerance_ratio: float = 0.003) -> None:
        self.tolerance_ratio = tolerance_ratio
        self.up = UpTrendLineDetector()
        self.down = DownTrendLineDetector()
        self.active_direction: str | None = None
        self.market_control_id: str | None = None
        self._snapshot = DetectorSnapshot.empty("line.trend", -1, detector_version=_VERSION)

    @property
    def manifest(self) -> DetectorManifest:
        return DetectorManifest(
            "line.trend",
            _VERSION,
            DetectorCategory.LINE_STRUCTURE,
            3,
            requires=("pivot.causal", "pattern.candle", "primitive.volume"),
            critical=True,
        )

    def update(self, bar: Bar, context: DetectionContext) -> DetectorSnapshot:
        events: list[DetectionEvent] = []
        for item in context.require("pivot.causal").structures:
            if item.pattern_type not in {"PIVOT_LOW", "PIVOT_HIGH"}:
                continue
            price = float(next(e.actual for e in item.evidence if e.name == "price"))
            point = LinePoint(
                item.end_index,
                price,
                item.structure_id,
                item.known_at_index,
            )
            scale = next(
                (e.actual for e in item.evidence if e.name == "scale"),
                "MAJOR",
            )
            direction = "UP" if item.pattern_type == "PIVOT_LOW" else "DOWN"
            state = self.up if direction == "UP" else self.down
            if scale == "MINOR":
                self._add_minor_point(
                    state, direction, point, context, events
                )
            else:
                self._add_point(state, direction, point, context, events)

        for state in (self.up, self.down):
            control = state.current()
            if control is not None:
                self._update_control_line(
                    state,
                    control,
                    bar,
                    context,
                    events,
                )

        self._select_market_control(bar.index)

        structures = tuple(
            self._structure(line, bar.index, self.market_control_id)
            for line in self.up.lines + self.down.lines
        )
        local_state = "ACTIVE" if self.market_control_id else "IDLE"
        phase = DetectorPhase.CONFIRMED if structures else DetectorPhase.IDLE
        self._snapshot = DetectorSnapshot(
            "line.trend",
            _VERSION,
            bar.index,
            phase,
            local_state,
            structures,
            tuple(events),
        )
        return self._snapshot

    def _add_point(
        self,
        state: DirectionalLineState,
        direction: str,
        point: LinePoint,
        context: DetectionContext,
        events: list[DetectionEvent],
    ) -> None:
        if state.points and point.index <= state.points[-1].index:
            return
        state.points.append(point)

        if state.current() is None:
            eligible = [
                item for item in state.points
                if item.index > state.rebuild_after_index
            ]
            if len(eligible) < 2:
                return
            first, second = eligible[-2:]
            valid = second.price > first.price if direction == "UP" else second.price < first.price
            if not valid:
                return
            trend_id = make_stable_id(
                "trend", _VERSION, context.symbol, context.timeframe,
                direction, first.source_id, second.source_id,
            )
            line = self._make_line(
                state,
                first,
                second,
                role="MAIN",
                generation=0,
                parent=None,
                trend_id=trend_id,
                context=context,
            )
            state.lines.append(line)
            state.current_control_id = line.line_id
            state.trend_id = trend_id
            state.candidate_points = [second]
            events.extend([
                self._event(line, "LINE_CREATED", point.confirmed_index),
                self._event(line, "NEW_MAIN_TREND_CONFIRMED", point.confirmed_index),
                self._event(line, "LINE_CONTROL_ACQUIRED", point.confirmed_index),
            ])
            self._try_create_acceleration(
                state, point.confirmed_index, context, events
            )
            return
        control = state.current()
        if control is None:
            return

        main = next(
            (line for line in state.lines if line.trend_id == state.trend_id and line.role == "MAIN"),
            None,
        )
        if main and self._should_reanchor_main(main, state, point, direction):
            self._reanchor_main(
                state, direction, point, context, events
            )
            return
        if main and self._near_line(main, point):
            main.touch_count += 1

        self._add_acceleration_point(state, point, context, events)

    def _add_minor_point(
        self,
        state: DirectionalLineState,
        direction: str,
        point: LinePoint,
        context: DetectionContext,
        events: list[DetectionEvent],
    ) -> None:
        assert state.minor_points is not None
        if state.minor_points and point.index <= state.minor_points[-1].index:
            return
        state.minor_points.append(point)
        if state.current() is None:
            return
        self._add_acceleration_point(state, point, context, events)

    def _should_reanchor_main(
        self,
        main: LineRecord,
        state: DirectionalLineState,
        point: LinePoint,
        direction: str,
    ) -> bool:
        if len(state.points) < 2 or self._near_line(main, point):
            return False
        previous = state.points[-2]
        directional_pair = (
            point.price > previous.price
            if direction == "UP"
            else point.price < previous.price
        )
        projected = main.value_at(point.index)
        crossed_inside = (
            point.price < projected * (1 - self.tolerance_ratio)
            if direction == "UP"
            else point.price > projected * (1 + self.tolerance_ratio)
        )
        return directional_pair and crossed_inside

    def _reanchor_main(
        self,
        state: DirectionalLineState,
        direction: str,
        point: LinePoint,
        context: DetectionContext,
        events: list[DetectionEvent],
    ) -> None:
        previous = state.points[-2]
        old_trend_id = state.trend_id
        for line in state.lines:
            if line.trend_id == old_trend_id and line.state not in {
                LineLifecycleState.INVALIDATED,
                LineLifecycleState.HISTORICAL,
            }:
                line.state = LineLifecycleState.HISTORICAL
                line.is_controlling = False
                line.invalidated_index = point.confirmed_index
        trend_id = make_stable_id(
            "trend",
            _VERSION,
            context.symbol,
            context.timeframe,
            direction,
            previous.source_id,
            point.source_id,
        )
        line = self._make_line(
            state,
            previous,
            point,
            role="MAIN",
            generation=0,
            parent=None,
            trend_id=trend_id,
            context=context,
        )
        state.lines.append(line)
        state.current_control_id = line.line_id
        state.trend_id = trend_id
        state.candidate_points = [point]
        events.extend([
            self._event(line, "LINE_REPLACED", point.confirmed_index),
            self._event(line, "LINE_CONTROL_ACQUIRED", point.confirmed_index),
        ])

    def _add_acceleration_point(
        self,
        state: DirectionalLineState,
        point: LinePoint,
        context: DetectionContext,
        events: list[DetectionEvent],
    ) -> None:
        control = state.current()
        if control is None or point.index <= control.second.index:
            return
        assert state.candidate_points is not None
        if any(item.index == point.index for item in state.candidate_points):
            return
        state.candidate_points.append(point)
        self._try_create_acceleration(
            state, point.confirmed_index, context, events
        )

    def _try_create_acceleration(
        self,
        state: DirectionalLineState,
        known_at_index: int,
        context: DetectionContext,
        events: list[DetectionEvent],
    ) -> None:
        control = state.current()
        assert state.candidate_points is not None
        if control is None or len(state.candidate_points) < 2:
            return
        first = control.second
        second = state.candidate_points[-1]
        if not self._is_acceleration(control, first, second):
            state.candidate_points = [control.second]
            return
        control.is_controlling = False
        control.state = LineLifecycleState.PARENT_ACTIVE
        line = self._make_line(
            state,
            first,
            second,
            role="ACCELERATION",
            generation=control.generation + 1,
            parent=control,
            trend_id=control.trend_id,
            context=context,
        )
        line.created_index = known_at_index
        line.known_at_index = known_at_index
        state.lines.append(line)
        state.current_control_id = line.line_id
        state.candidate_points = [second]
        events.extend([
            self._event(line, "LINE_CREATED", known_at_index),
            self._event(line, "LINE_CONTROL_ACQUIRED", known_at_index),
        ])

    def _update_control_line(
        self,
        state: DirectionalLineState,
        line: LineRecord,
        bar: Bar,
        context: DetectionContext,
        events: list[DetectionEvent],
    ) -> None:
        if bar.index <= line.known_at_index:
            return
        value = line.value_at(bar.index)
        support = line.side == "SUPPORT"
        outside = (
            bar.close < value * (1 - self.tolerance_ratio)
            if support
            else bar.close > value * (1 + self.tolerance_ratio)
        )
        wick = (
            bar.low < value * (1 - self.tolerance_ratio)
            if support
            else bar.high > value * (1 + self.tolerance_ratio)
        )
        if not outside:
            if line.break_count:
                line.break_count = 0
                line.first_break_index = None
                line.state = LineLifecycleState.ACTIVE
                events.append(self._event(line, "LINE_RECLAIMED", bar.index))
            elif wick:
                events.append(self._event(line, "WICK_PENETRATION", bar.index))
            return

        line.break_count += 1
        line.state = LineLifecycleState.BREAK_OBSERVING
        if line.break_count == 1:
            line.first_break_index = bar.index
            events.append(self._event(line, "FIRST_CLOSE_BREAK", bar.index))
            return

        if line.break_count < 2:
            return
        line.break_confirmed_index = bar.index
        line.invalidated_index = bar.index
        line.is_controlling = False
        line.state = LineLifecycleState.INVALIDATED
        events.extend([
            self._event(line, "LINE_BREAK_CONFIRMED", bar.index),
            self._event(line, "LINE_INVALIDATED", bar.index),
        ])
        if line.parent_line_id:
            parent = next(item for item in state.lines if item.line_id == line.parent_line_id)
            parent.state = LineLifecycleState.ACTIVE
            parent.is_controlling = True
            parent.break_count = 0
            parent.first_break_index = None
            state.current_control_id = parent.line_id
            state.candidate_points = [parent.second]
            events.append(self._event(parent, "LINE_CONTROL_FALLBACK", bar.index))
            return

        assert state.candidate_points is not None
        state.candidate_points = []
        events.append(self._event(line, "MAIN_TREND_ENDED", bar.index))
        for item in state.lines:
            if item.trend_id == line.trend_id and item.state != LineLifecycleState.INVALIDATED:
                item.state = LineLifecycleState.HISTORICAL
                item.is_controlling = False
                item.invalidated_index = bar.index
        state.current_control_id = None
        state.trend_id = None
        state.rebuild_after_index = bar.index

    def _make_line(
        self,
        state: DirectionalLineState,
        first: LinePoint,
        second: LinePoint,
        *,
        role: str,
        generation: int,
        parent: LineRecord | None,
        trend_id: str,
        context: DetectionContext,
    ) -> LineRecord:
        line_id = make_stable_id(
            "line.trend",
            _VERSION,
            context.symbol,
            context.timeframe,
            trend_id,
            role,
            generation,
            first.source_id,
            second.source_id,
        )
        return LineRecord(
            line_id=line_id,
            trend_id=trend_id,
            side=state.side,
            role=role,
            generation=generation,
            first=first,
            second=second,
            created_index=second.confirmed_index,
            known_at_index=second.confirmed_index,
            parent_line_id=parent.line_id if parent else None,
            is_controlling=True,
        )

    def _is_acceleration(
        self,
        parent: LineRecord,
        first: LinePoint,
        second: LinePoint,
    ) -> bool:
        if (
            first.index != parent.second.index
            or first.price != parent.second.price
            or first.source_id != parent.second.source_id
        ):
            return False
        if second.index <= first.index:
            return False
        first_valid = (
            first.price >= parent.value_at(first.index)
            if parent.side == "SUPPORT"
            else first.price <= parent.value_at(first.index)
        )
        second_valid = (
            second.price >= parent.value_at(second.index)
            if parent.side == "SUPPORT"
            else second.price <= parent.value_at(second.index)
        )
        candidate_slope = (second.price - first.price) / (
            second.index - first.index
        )
        steeper = (
            candidate_slope > parent.slope
            if parent.side == "SUPPORT"
            else candidate_slope < parent.slope
        )
        return first_valid and second_valid and steeper

    def _near_line(self, line: LineRecord, point: LinePoint) -> bool:
        expected = line.value_at(point.index)
        return abs(point.price - expected) / max(abs(expected), 1e-9) <= 0.03

    def _select_market_control(self, index: int) -> None:
        controls = [
            line
            for state in (self.up, self.down)
            if (line := state.current()) is not None
            and line.is_controlling
            and line.state not in {
                LineLifecycleState.INVALIDATED,
                LineLifecycleState.HISTORICAL,
                LineLifecycleState.CANDIDATE,
            }
        ]
        if not controls:
            self.market_control_id = None
            self.active_direction = None
            return
        previous = next(
            (
                line
                for line in self.up.lines + self.down.lines
                if line.line_id == self.market_control_id
            ),
            None,
        )
        control = next(
            (line for line in controls if line.line_id == self.market_control_id),
            None,
        )
        if control is None and previous is not None and previous.state not in {
            LineLifecycleState.INVALIDATED,
            LineLifecycleState.HISTORICAL,
        }:
            same_side = self.up if previous.side == "SUPPORT" else self.down
            successor = same_side.current()
            if successor in controls:
                control = successor
        if control is None:
            control = max(
                controls,
                key=lambda line: (
                    line.known_at_index,
                    line.created_index,
                    line.generation,
                    line.second.index,
                ),
            )
        if previous is not None and previous.side != control.side:
            self._close_direction_epoch(previous.side, index)
        self.market_control_id = control.line_id
        self.active_direction = "UP" if control.side == "SUPPORT" else "DOWN"

    def _close_direction_epoch(self, side: str, index: int) -> None:
        state = self.up if side == "SUPPORT" else self.down
        for line in state.lines:
            if line.state in {
                LineLifecycleState.ACTIVE,
                LineLifecycleState.PARENT_ACTIVE,
                LineLifecycleState.BREAK_OBSERVING,
            }:
                line.state = LineLifecycleState.HISTORICAL
                line.is_controlling = False
                line.invalidated_index = index
        state.current_control_id = None
        state.trend_id = None
        state.candidate_points = []
        state.rebuild_after_index = index

    @staticmethod
    def _event(line: LineRecord, event_type: str, index: int) -> DetectionEvent:
        direction = "BEARISH" if line.side == "SUPPORT" else "BULLISH"
        evidence = (
            Evidence("line_id", line.line_id),
            Evidence("side", line.side),
            Evidence("role", line.role),
            Evidence("generation", line.generation),
            Evidence("anchor_indexes", (line.first.index, line.second.index)),
            Evidence("anchor_prices", (line.first.price, line.second.price)),
            Evidence("first_break_index", line.first_break_index),
        )
        return DetectionEvent(
            make_stable_id(line.line_id, event_type, index),
            "line.trend",
            _VERSION,
            event_type,
            index,
            index,
            line.line_id,
            direction,
            True,
            event_type,
            evidence,
        )

    @staticmethod
    def _structure(
        line: LineRecord,
        end: int,
        market_control_id: str | None,
    ) -> DetectedStructure:
        is_market_controlling = (
            line.is_controlling and line.line_id == market_control_id
        )
        evidence = (
            Evidence("trend_id", line.trend_id),
            Evidence("side", line.side),
            Evidence("role", line.role),
            Evidence("generation", line.generation),
            Evidence("anchor_indexes", (line.first.index, line.second.index)),
            Evidence("anchor_confirmed_indexes", (line.first.confirmed_index, line.second.confirmed_index)),
            Evidence("anchor_prices", (line.first.price, line.second.price)),
            Evidence("parent_line_id", line.parent_line_id),
            Evidence("is_direction_controlling", line.is_controlling),
            Evidence("is_market_controlling", is_market_controlling),
            Evidence("is_controlling", is_market_controlling),
            Evidence("touch_count", line.touch_count),
            Evidence("line_value", line.value_at(end)),
            Evidence("break_count", line.break_count),
            Evidence("break_confirmed_index", line.break_confirmed_index),
            Evidence("invalidated_index", line.invalidated_index),
        )
        phase = (
            DetectorPhase.INVALIDATED
            if line.state in {LineLifecycleState.INVALIDATED, LineLifecycleState.HISTORICAL}
            else DetectorPhase.CANDIDATE
            if line.state == LineLifecycleState.CANDIDATE
            else DetectorPhase.OBSERVING
            if line.state == LineLifecycleState.BREAK_OBSERVING
            else DetectorPhase.CONFIRMED
        )
        return DetectedStructure(
            line.line_id,
            "TREND_LINE",
            "BULLISH" if line.side == "SUPPORT" else "BEARISH",
            phase,
            line.state.value,
            line.first.index,
            end,
            line.known_at_index,
            "STRONG" if line.touch_count >= 3 else "NORMAL",
            evidence,
            "line.trend",
            _VERSION,
            source_ids=(line.first.source_id, line.second.source_id),
        )

    def snapshot(self) -> DetectorSnapshot:
        return self._snapshot

    def export_state(self) -> SerializedDetectorState:
        return SerializedDetectorState(
            "line.trend",
            _VERSION,
            3,
            {
                "active_direction": self.active_direction,
                "market_control_id": self.market_control_id,
                "up": self._state_payload(self.up),
                "down": self._state_payload(self.down),
            },
        )

    @staticmethod
    def _state_payload(state: DirectionalLineState) -> dict[str, object]:
        return {
            "side": state.side,
            "points": [asdict(item) for item in state.points],
            "minor_points": [asdict(item) for item in state.minor_points or []],
            "lines": [
                {**asdict(item), "state": item.state.value}
                for item in state.lines
            ],
            "current_control_id": state.current_control_id,
            "trend_id": state.trend_id,
            "candidate_points": [asdict(item) for item in state.candidate_points or []],
            "rebuild_after_index": state.rebuild_after_index,
        }

    def restore_state(self, state: SerializedDetectorState) -> None:
        def restore_direction(payload: object) -> DirectionalLineState:
            value = dict(payload)  # type: ignore[arg-type]
            points = [LinePoint(**item) for item in value["points"]]
            lines = []
            for raw in value["lines"]:
                item = dict(raw)
                item["first"] = LinePoint(**item["first"])
                item["second"] = LinePoint(**item["second"])
                item["state"] = LineLifecycleState(item["state"])
                lines.append(LineRecord(**item))
            return DirectionalLineState(
                side=str(value["side"]),
                points=points,
                lines=lines,
                minor_points=[
                    LinePoint(**item) for item in value.get("minor_points", [])
                ],
                current_control_id=value["current_control_id"],
                trend_id=value["trend_id"],
                candidate_points=[LinePoint(**item) for item in value["candidate_points"]],
                rebuild_after_index=int(value["rebuild_after_index"]),
            )

        self.active_direction = state.payload["active_direction"]
        self.market_control_id = state.payload.get("market_control_id")
        self.up = restore_direction(state.payload["up"])
        self.down = restore_direction(state.payload["down"])

    def reset(self) -> None:
        self.up = UpTrendLineDetector()
        self.down = DownTrendLineDetector()
        self.active_direction = None
        self.market_control_id = None
        self._snapshot = DetectorSnapshot.empty("line.trend", -1, detector_version=_VERSION)

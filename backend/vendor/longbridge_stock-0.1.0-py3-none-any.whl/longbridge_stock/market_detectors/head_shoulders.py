from __future__ import annotations

from dataclasses import asdict, dataclass, replace

from longbridge_stock.dow_trend_replay import Bar

from .head_shoulders_bottom_candidates import (
    BottomCandidate,
    BottomPivot,
    candidate_geometry,
    generate_bottom_candidates,
)
from .models import (
    DetectionContext,
    DetectionEvent,
    DetectorCategory,
    DetectorManifest,
    DetectorPhase,
    DetectorSnapshot,
    DetectedStructure,
    Evidence,
    SerializedDetectorState,
    make_stable_id,
)


_VERSION = "2.0.0"
_TERMINAL_STATES = {"COMPLETED", "FAILED", "INVALIDATED"}


@dataclass(frozen=True)
class BottomPatternState:
    candidate: BottomCandidate
    local_state: str = "WAIT_NECKLINE_BREAK"
    confirmed_index: int | None = None
    retest_deadline_index: int | None = None
    below_neckline_closes: int = 0
    invalidation_reason: str | None = None


@dataclass(frozen=True)
class HeadShouldersBottomLedgerState:
    pivots: tuple[BottomPivot, ...] = ()
    patterns: tuple[BottomPatternState, ...] = ()
    emitted_event_ids: tuple[str, ...] = ()
    known_candidate_ids: tuple[str, ...] = ()


class HeadShouldersBottomDetector:
    def __init__(
        self,
        *,
        neckline_tolerance_ratio: float = 0.03,
        max_span_bars: int = 120,
        max_patterns: int = 64,
    ) -> None:
        self.neckline_tolerance_ratio = neckline_tolerance_ratio
        self.max_span_bars = max_span_bars
        self.max_patterns = max_patterns
        self._state = HeadShouldersBottomLedgerState()
        self._snapshot = DetectorSnapshot.empty(
            "structure.head_shoulders_bottom", -1, detector_version=_VERSION
        )

    @property
    def manifest(self) -> DetectorManifest:
        return DetectorManifest(
            "structure.head_shoulders_bottom",
            _VERSION,
            DetectorCategory.PRICE_STRUCTURE,
            2,
            requires=("pivot.causal", "primitive.volume"),
            optional_requires=("structure.box",),
        )

    def update(self, bar: Bar, context: DetectionContext) -> DetectorSnapshot:
        pivots = self._merge_pivots(
            self._state.pivots,
            self._current_pivots(context.require("pivot.causal"), bar),
            bar.index,
        )
        patterns = {item.candidate.candidate_id: item for item in self._state.patterns}
        known_candidate_ids = set(self._state.known_candidate_ids)
        candidates = self._select_candidates(
            generate_bottom_candidates(
                pivots,
                self.max_span_bars,
                as_of_index=bar.index,
            )
        )
        for candidate in candidates:
            current = patterns.get(candidate.candidate_id)
            if current is not None:
                patterns[candidate.candidate_id] = replace(
                    current,
                    candidate=candidate,
                )
            elif candidate.candidate_id not in known_candidate_ids:
                patterns[candidate.candidate_id] = BottomPatternState(candidate)
                known_candidate_ids.add(candidate.candidate_id)

        emitted = set(self._state.emitted_event_ids)
        events: list[DetectionEvent] = []
        updated: list[BottomPatternState] = []
        expanding = context.require("primitive.volume").local_state == "VOLUME_EXPANSION"
        breakout_candidate_ids: set[str] = set()
        if expanding:
            eligible = [
                state
                for state in patterns.values()
                if state.local_state == "WAIT_NECKLINE_BREAK"
                and bar.index > state.candidate.right_shoulder.confirmed_index
                and bar.index <= state.candidate.right_shoulder.confirmed_index + 20
                and bar.low >= state.candidate.head.price
                and bar.close > self._neckline_at(state.candidate, bar.index)
            ]
            if eligible:
                best = max(eligible, key=lambda item: self._quality(item.candidate))
                breakout_candidate_ids.add(best.candidate.candidate_id)
        for state in patterns.values():
            next_state, event_type = self._advance_pattern(
                state,
                bar,
                state.candidate.candidate_id in breakout_candidate_ids,
            )
            updated.append(next_state)
            if event_type is None:
                continue
            event = self._event(next_state, event_type, bar.index)
            if event.event_id not in emitted:
                emitted.add(event.event_id)
                events.append(event)

        updated = sorted(
            updated,
            key=lambda item: (
                item.candidate.right_shoulder.index,
                item.candidate.anchor_indexes,
            ),
        )[-self.max_patterns :]
        self._state = HeadShouldersBottomLedgerState(
            pivots=pivots,
            patterns=tuple(updated),
            emitted_event_ids=tuple(sorted(emitted)),
            known_candidate_ids=tuple(sorted(known_candidate_ids)),
        )
        structures = tuple(self._structure(item, bar.index) for item in updated)
        local_state = self._local_state(updated, pivots)
        phase = self._phase(local_state)
        self._snapshot = DetectorSnapshot(
            self.manifest.detector_id,
            self.manifest.version,
            bar.index,
            phase,
            local_state,
            structures,
            tuple(events),
            tuple(evidence for item in structures for evidence in item.evidence),
        )
        return self._snapshot

    def _advance_pattern(
        self,
        state: BottomPatternState,
        bar: Bar,
        expanding: bool,
    ) -> tuple[BottomPatternState, str | None]:
        if state.local_state in _TERMINAL_STATES:
            return state, None
        candidate = state.candidate
        neckline = self._neckline_at(candidate, bar.index)
        if state.local_state == "WAIT_NECKLINE_BREAK":
            if bar.index <= candidate.right_shoulder.confirmed_index:
                return state, None
            if bar.index > candidate.right_shoulder.confirmed_index + 20:
                return replace(
                    state,
                    local_state="INVALIDATED",
                    invalidation_reason="NECKLINE_BREAK_EXPIRED",
                ), None
            if bar.low < candidate.head.price:
                return (
                    replace(
                        state,
                        local_state="INVALIDATED",
                        invalidation_reason="HEAD_LOW_BROKEN_BEFORE_NECKLINE",
                    ),
                    "HEAD_LOW_BROKEN_BEFORE_NECKLINE",
                )
            if bar.close > neckline and expanding:
                return (
                    replace(
                        state,
                        local_state="CONFIRMED",
                        confirmed_index=bar.index,
                        retest_deadline_index=bar.index + 10,
                    ),
                    "NECKLINE_BREAK_CONFIRMED",
                )
            return state, None

        if state.local_state == "CONFIRMED":
            if bar.index <= (state.confirmed_index or -1):
                return state, None
            if (
                state.retest_deadline_index is not None
                and bar.index > state.retest_deadline_index
            ):
                return state, None
            touched = (
                abs(bar.low - neckline) / max(abs(neckline), 1e-9)
                <= self.neckline_tolerance_ratio
            )
            if touched and bar.close >= neckline:
                return replace(state, local_state="COMPLETED"), "NECKLINE_RETEST_COMPLETED"
            below = state.below_neckline_closes + 1 if bar.close < neckline else 0
            if (
                bar.close < neckline * (1 - self.neckline_tolerance_ratio)
                or below >= 2
            ):
                return (
                    replace(
                        state,
                        local_state="FAILED",
                        below_neckline_closes=below,
                        invalidation_reason="NECKLINE_BREAK_FAILED",
                    ),
                    "NECKLINE_BREAK_FAILED",
                )
            return replace(state, below_neckline_closes=below), None
        return state, None

    @staticmethod
    def _current_pivots(snapshot: DetectorSnapshot, bar: Bar) -> tuple[BottomPivot, ...]:
        pivots = []
        for item in snapshot.structures:
            if item.pattern_type not in {"PIVOT_LOW", "PIVOT_HIGH"}:
                continue
            values = {e.name: e.actual for e in item.evidence}
            pivots.append(BottomPivot(
                kind=item.pattern_type.removeprefix("PIVOT_"),
                index=item.end_index,
                confirmed_index=item.known_at_index,
                price=float(values["price"]),
                volume=float(values.get("volume", bar.volume)),
                scale=str(values.get("scale", "STRUCTURAL")),
                source_id=item.structure_id,
                scale_confirmed_index=item.known_at_index,
            ))
        return tuple(pivots)

    @staticmethod
    def _merge_pivots(
        existing: tuple[BottomPivot, ...],
        incoming: tuple[BottomPivot, ...],
        index: int,
    ) -> tuple[BottomPivot, ...]:
        cutoff = index - 120
        merged = {
            (item.kind, item.index, item.source_id, item.scale): item
            for item in existing
            if item.index >= cutoff
        }
        for item in incoming:
            merged[(item.kind, item.index, item.source_id, item.scale)] = item
        return tuple(sorted(
            merged.values(),
            key=lambda item: (item.index, item.confirmed_index, item.kind, item.source_id),
        ))

    @staticmethod
    def _select_candidates(
        candidates: tuple[BottomCandidate, ...],
    ) -> tuple[BottomCandidate, ...]:
        selected: dict[tuple[int, int], BottomCandidate] = {}
        for candidate in candidates:
            geometry = candidate_geometry(candidate)
            shoulder_floor = min(
                candidate.left_shoulder.price,
                candidate.right_shoulder.price,
            )
            head_depth = (
                shoulder_floor - candidate.head.price
            ) / max(shoulder_floor, 1e-9)
            if not (
                geometry.shoulder_gap_ratio <= 0.20
                and 0.35 <= geometry.span_ratio <= 3.0
                and head_depth >= 0.08
            ):
                continue
            key = (candidate.head.index, candidate.right_shoulder.index)
            current = selected.get(key)
            if current is None or HeadShouldersBottomDetector._quality(candidate) > HeadShouldersBottomDetector._quality(current):
                selected[key] = candidate
        ranked = sorted(
            selected.values(),
            key=lambda item: (
                item.right_shoulder.index,
                HeadShouldersBottomDetector._quality(item),
            ),
            reverse=True,
        )[:16]
        return tuple(sorted(ranked, key=lambda item: item.anchor_indexes))

    @staticmethod
    def _quality(candidate: BottomCandidate) -> tuple[float, int, int, int, float, float]:
        geometry = candidate_geometry(candidate)
        shoulder_floor = min(
            candidate.left_shoulder.price,
            candidate.right_shoulder.price,
        )
        head_depth = (shoulder_floor - candidate.head.price) / max(shoulder_floor, 1e-9)
        scale_rank = {"STRUCTURAL": 0, "MAJOR": 1}
        return (
            float(candidate.left_shoulder.index),
            scale_rank[candidate.right_shoulder.scale],
            scale_rank[candidate.head.scale],
            scale_rank[candidate.second_neck.scale],
            -geometry.shoulder_gap_ratio,
            -abs(geometry.span_ratio - 1.0) + head_depth,
        )

    @staticmethod
    def _neckline_at(candidate: BottomCandidate, index: int) -> float:
        first, second = candidate.first_neck, candidate.second_neck
        distance = second.index - first.index
        slope = (second.price - first.price) / distance if distance else 0.0
        return first.price + slope * (index - first.index)

    def _structure(self, state: BottomPatternState, end: int) -> DetectedStructure:
        candidate = state.candidate
        geometry = candidate_geometry(candidate)
        points = (
            ("left_shoulder", candidate.left_shoulder),
            ("first_neck", candidate.first_neck),
            ("head", candidate.head),
            ("second_neck", candidate.second_neck),
            ("right_shoulder", candidate.right_shoulder),
        )
        evidence = tuple(
            Evidence(name, point.price, source_ids=(point.source_id,))
            for name, point in points
        ) + (
            Evidence("anchor_indexes", candidate.anchor_indexes),
            Evidence("anchor_prices", tuple(point.price for _, point in points)),
            Evidence("neckline_value", self._neckline_at(candidate, end)),
            Evidence("neckline_slope", self._neckline_at(candidate, end + 1) - self._neckline_at(candidate, end)),
            Evidence("shoulder_gap_ratio", geometry.shoulder_gap_ratio),
            Evidence("span_ratio", geometry.span_ratio),
            Evidence("confirmation_weight", 3),
            Evidence("invalidation_reason", state.invalidation_reason),
        )
        return DetectedStructure(
            candidate.candidate_id,
            candidate.pattern_type,
            "BULLISH",
            self._phase(state.local_state),
            state.local_state,
            candidate.left_shoulder.index,
            end,
            state.confirmed_index or candidate.right_shoulder.confirmed_index,
            "STRONG" if geometry.strong else "NORMAL",
            evidence,
            self.manifest.detector_id,
            self.manifest.version,
            source_ids=tuple(point.source_id for _, point in points),
            invalidation="break below head before confirmation or failed neckline retest",
        )

    def _event(
        self,
        state: BottomPatternState,
        event_type: str,
        index: int,
    ) -> DetectionEvent:
        candidate = state.candidate
        evidence = (
            Evidence("anchor_indexes", candidate.anchor_indexes),
            Evidence("anchor_prices", tuple(
                point.price for point in (
                    candidate.left_shoulder,
                    candidate.first_neck,
                    candidate.head,
                    candidate.second_neck,
                    candidate.right_shoulder,
                )
            )),
            Evidence("confirmation_weight", 3),
        )
        return DetectionEvent(
            make_stable_id(candidate.candidate_id, event_type, index),
            self.manifest.detector_id,
            self.manifest.version,
            event_type,
            index,
            index,
            candidate.candidate_id,
            "BULLISH",
            True,
            "head shoulders bottom lifecycle changed",
            evidence,
        )

    @staticmethod
    def _local_state(
        patterns: list[BottomPatternState],
        pivots: tuple[BottomPivot, ...],
    ) -> str:
        priority = {
            "CONFIRMED": 5,
            "WAIT_NECKLINE_BREAK": 4,
            "COMPLETED": 3,
            "FAILED": 2,
            "INVALIDATED": 1,
        }
        if patterns:
            return max(patterns, key=lambda item: (
                priority[item.local_state], item.candidate.right_shoulder.index
            )).local_state
        lows = [item for item in pivots if item.kind == "LOW"]
        highs = [item for item in pivots if item.kind == "HIGH"]
        if len(lows) >= 3 and len(highs) >= 2 and lows[-1].price <= min(item.price for item in lows[:-1]):
            return "INVALIDATED"
        return "SEEK_LEFT_SHOULDER"

    @staticmethod
    def _phase(local_state: str) -> DetectorPhase:
        return {
            "WAIT_NECKLINE_BREAK": DetectorPhase.CANDIDATE,
            "CONFIRMED": DetectorPhase.CONFIRMED,
            "COMPLETED": DetectorPhase.COMPLETED,
            "FAILED": DetectorPhase.FAILED,
            "INVALIDATED": DetectorPhase.INVALIDATED,
        }.get(local_state, DetectorPhase.IDLE)

    def snapshot(self) -> DetectorSnapshot:
        return self._snapshot

    def export_state(self) -> SerializedDetectorState:
        return SerializedDetectorState(
            self.manifest.detector_id,
            self.manifest.version,
            2,
            asdict(self._state),
        )

    def restore_state(self, state: SerializedDetectorState) -> None:
        if state.detector_id != self.manifest.detector_id or state.detector_version != self.manifest.version or state.state_schema_version != 2:
            raise ValueError("incompatible head shoulders bottom state")
        payload = state.payload
        pivots = tuple(BottomPivot(**item) for item in payload["pivots"])
        patterns = []
        for item in payload["patterns"]:
            raw_candidate = item["candidate"]
            candidate = BottomCandidate(
                candidate_id=raw_candidate["candidate_id"],
                left_shoulder=BottomPivot(**raw_candidate["left_shoulder"]),
                first_neck=BottomPivot(**raw_candidate["first_neck"]),
                head=BottomPivot(**raw_candidate["head"]),
                second_neck=BottomPivot(**raw_candidate["second_neck"]),
                right_shoulder=BottomPivot(**raw_candidate["right_shoulder"]),
                pattern_type=raw_candidate.get("pattern_type", "HEAD_SHOULDERS_BOTTOM"),
            )
            patterns.append(BottomPatternState(
                candidate=candidate,
                local_state=item["local_state"],
                confirmed_index=item["confirmed_index"],
                retest_deadline_index=item["retest_deadline_index"],
                below_neckline_closes=item["below_neckline_closes"],
                invalidation_reason=item["invalidation_reason"],
            ))
        self._state = HeadShouldersBottomLedgerState(
            pivots=pivots,
            patterns=tuple(patterns),
            emitted_event_ids=tuple(payload["emitted_event_ids"]),
            known_candidate_ids=tuple(payload.get("known_candidate_ids", ())),
        )

    def reset(self) -> None:
        self._state = HeadShouldersBottomLedgerState()
        self._snapshot = DetectorSnapshot.empty(
            self.manifest.detector_id, -1, detector_version=self.manifest.version
        )

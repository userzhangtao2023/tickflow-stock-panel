from __future__ import annotations

from longbridge_stock.dow_pivot_detector import (
    CausalPivotDetector,
    CausalStructuralPivotDetector,
    PivotDetectorConfig,
)
from longbridge_stock.dow_trend_replay import Bar

from .models import (
    DetectionContext,
    DetectionEvent,
    DetectorCategory,
    DetectorManifest,
    DetectorPhase,
    DetectorSnapshot,
    DetectedStructure,
    Evidence,
    SerializedDetectorState,
    make_stable_id,
)


_VERSION = "1.2.0"


class PivotDetectorAdapter:
    def __init__(
        self,
        detector: CausalPivotDetector | None = None,
        *,
        minor_detector: CausalPivotDetector | None = None,
        structural_detector: CausalStructuralPivotDetector | None = None,
    ) -> None:
        self.detector = detector or CausalPivotDetector()
        self.minor_detector = minor_detector or CausalPivotDetector(
            PivotDetectorConfig(
                atr_multiplier=0.8,
                range_multiplier=1.0,
                min_reversal_ratio=0.02,
                max_reversal_ratio=0.10,
                min_separation=2,
            )
        )
        self.structural_detector = (
            structural_detector or CausalStructuralPivotDetector()
        )
        self._seen: set[str] = set()
        self._snapshot = DetectorSnapshot.empty(
            "pivot.causal", -1, detector_version=_VERSION
        )

    @property
    def manifest(self) -> DetectorManifest:
        return DetectorManifest(
            "pivot.causal",
            _VERSION,
            DetectorCategory.PRIMITIVE,
            1,
            critical=True,
        )

    def update(self, bar: Bar, context: DetectionContext) -> DetectorSnapshot:
        structures: list[DetectedStructure] = []
        events: list[DetectionEvent] = []
        for scale, detector in (
            ("MAJOR", self.detector),
            ("MINOR", self.minor_detector),
            ("STRUCTURAL", self.structural_detector),
        ):
            for pivot in detector.detect(context.history):
                if pivot.confirmed_index != bar.index:
                    continue
                structure_id = make_stable_id(
                    "pivot.causal",
                    _VERSION,
                    context.symbol,
                    context.timeframe,
                    scale,
                    pivot.kind,
                    pivot.bar_index,
                    pivot.confirmed_index,
                )
                if structure_id in self._seen:
                    continue
                self._seen.add(structure_id)
                evidence = (
                    Evidence("price", pivot.price),
                    Evidence("reversal_ratio", pivot.reversal_ratio),
                    Evidence("scale", scale),
                )
                structures.append(DetectedStructure(
                    structure_id,
                    f"PIVOT_{pivot.kind}",
                    "NEUTRAL",
                    DetectorPhase.CONFIRMED,
                    "CONFIRMED",
                    pivot.bar_index,
                    pivot.bar_index,
                    pivot.confirmed_index,
                    "NORMAL",
                    evidence,
                    "pivot.causal",
                    _VERSION,
                ))
                events.append(DetectionEvent(
                    make_stable_id(structure_id, "PIVOT_CONFIRMED", bar.index),
                    "pivot.causal",
                    _VERSION,
                    "PIVOT_CONFIRMED",
                    pivot.bar_index,
                    pivot.confirmed_index,
                    structure_id,
                    "NEUTRAL",
                    True,
                    f"{scale.lower()} {pivot.kind.lower()} pivot confirmed",
                    evidence,
                ))
        phase = DetectorPhase.CONFIRMED if structures else DetectorPhase.IDLE
        local_state = "CONFIRMED" if structures else "IDLE"
        self._snapshot = DetectorSnapshot(
            "pivot.causal",
            _VERSION,
            bar.index,
            phase,
            local_state,
            tuple(structures),
            tuple(events),
        )
        return self._snapshot

    def snapshot(self) -> DetectorSnapshot:
        return self._snapshot

    def export_state(self) -> SerializedDetectorState:
        return SerializedDetectorState(
            "pivot.causal", _VERSION, 1, {"seen": tuple(sorted(self._seen))}
        )

    def restore_state(self, state: SerializedDetectorState) -> None:
        self._seen = set(state.payload["seen"])

    def reset(self) -> None:
        self._seen.clear()
        self._snapshot = DetectorSnapshot.empty(
            "pivot.causal", -1, detector_version=_VERSION
        )

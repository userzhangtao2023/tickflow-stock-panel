from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from hashlib import sha256
from types import MappingProxyType
from typing import Any, Literal, Mapping, Sequence

from longbridge_stock.dow_trend_replay import Bar


Direction = Literal["BULLISH", "BEARISH", "NEUTRAL"]
Quality = Literal["WEAK", "NORMAL", "STRONG"]


class DetectorCategory(str, Enum):
    PRIMITIVE = "PRIMITIVE"
    CANDLE_PATTERN = "CANDLE_PATTERN"
    PRICE_STRUCTURE = "PRICE_STRUCTURE"
    LINE_STRUCTURE = "LINE_STRUCTURE"
    RETEST_STRUCTURE = "RETEST_STRUCTURE"
    REGIME = "REGIME"
    DECISION = "DECISION"


class DetectorPhase(str, Enum):
    IDLE = "IDLE"
    CANDIDATE = "CANDIDATE"
    CONFIRMED = "CONFIRMED"
    OBSERVING = "OBSERVING"
    COMPLETED = "COMPLETED"
    INVALIDATED = "INVALIDATED"
    FAILED = "FAILED"
    ERROR = "ERROR"


@dataclass(frozen=True)
class DetectorManifest:
    detector_id: str
    version: str
    category: DetectorCategory
    state_schema_version: int
    requires: tuple[str, ...] = ()
    optional_requires: tuple[str, ...] = ()
    supported_timeframes: tuple[str, ...] = ("ANY",)
    warmup_bars: int = 0
    critical: bool = False

    def __post_init__(self) -> None:
        if not self.detector_id or self.detector_id.lower() != self.detector_id:
            raise ValueError("detector_id must be non-empty lowercase text")
        if self.state_schema_version < 1:
            raise ValueError("state_schema_version must be at least 1")
        if self.warmup_bars < 0:
            raise ValueError("warmup_bars cannot be negative")
        if len(set(self.requires)) != len(self.requires):
            raise ValueError("requires cannot contain duplicates")


@dataclass(frozen=True)
class Evidence:
    name: str
    actual: Any = None
    threshold: Any = None
    passed: bool = True
    source_ids: tuple[str, ...] = ()


@dataclass(frozen=True)
class DetectedStructure:
    structure_id: str
    pattern_type: str
    direction: Direction
    phase: DetectorPhase
    local_state: str
    start_index: int
    end_index: int
    known_at_index: int
    quality: Quality
    evidence: tuple[Evidence, ...]
    detector_id: str
    detector_version: str
    source_ids: tuple[str, ...] = ()
    invalidation: str | None = None


@dataclass(frozen=True)
class DetectionEvent:
    event_id: str
    detector_id: str
    detector_version: str
    event_type: str
    occurred_at_index: int
    known_at_index: int
    structure_id: str | None
    direction: Direction
    confirmed: bool
    reason: str
    evidence: tuple[Evidence, ...] = ()


@dataclass(frozen=True)
class DetectorSnapshot:
    detector: str
    detector_version: str
    bar_index: int
    phase: DetectorPhase
    local_state: str
    structures: tuple[DetectedStructure, ...] = ()
    events: tuple[DetectionEvent, ...] = ()
    evidence: tuple[Evidence, ...] = ()
    error: str | None = None

    @classmethod
    def empty(
        cls,
        detector: str,
        bar_index: int,
        *,
        detector_version: str = "1.0.0",
        local_state: str = "IDLE",
    ) -> "DetectorSnapshot":
        return cls(
            detector=detector,
            detector_version=detector_version,
            bar_index=bar_index,
            phase=DetectorPhase.IDLE,
            local_state=local_state,
        )


@dataclass(frozen=True)
class DetectionContext:
    symbol: str
    timeframe: str
    history: Sequence[Bar]
    current_bar_index: int
    upstream: Mapping[str, DetectorSnapshot] = field(default_factory=dict)
    position: Any | None = None

    def __post_init__(self) -> None:
        history = tuple(self.history)
        if not history:
            raise ValueError("history cannot be empty")
        if self.current_bar_index != len(history) - 1:
            raise ValueError("history must end at current_bar_index")
        object.__setattr__(self, "history", history)
        object.__setattr__(
            self, "upstream", MappingProxyType(dict(self.upstream))
        )

    @property
    def current_bar(self) -> Bar:
        return self.history[-1]

    def require(self, detector_id: str) -> DetectorSnapshot:
        try:
            return self.upstream[detector_id]
        except KeyError as exc:
            raise KeyError(f"required detector snapshot unavailable: {detector_id}") from exc


@dataclass(frozen=True)
class SerializedDetectorState:
    detector_id: str
    detector_version: str
    state_schema_version: int
    payload: Mapping[str, Any]

    def __post_init__(self) -> None:
        object.__setattr__(self, "payload", MappingProxyType(dict(self.payload)))


def make_stable_id(*parts: object) -> str:
    normalized = "|".join(str(part) for part in parts)
    digest = sha256(normalized.encode("utf-8")).hexdigest()[:16]
    prefix = ":".join(str(part) for part in parts[:2])
    return f"{prefix}:{digest}"

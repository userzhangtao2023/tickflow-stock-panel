from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from .orchestrator import UnifiedDetectionSnapshot


@dataclass(frozen=True)
class ReplayLineState:
    bar_index: int
    state: str
    is_controlling: bool


@dataclass(frozen=True)
class ReplayLineEpisode:
    structure_id: str
    first_seen_index: int
    known_at_index: int
    side: str
    role: str
    generation: int
    anchor_indexes: tuple[int, int]
    anchor_prices: tuple[float, float]
    states: tuple[ReplayLineState, ...]
    invalidated_index: int | None


def build_line_replay_ledger(
    snapshots: Sequence[UnifiedDetectionSnapshot],
) -> tuple[ReplayLineEpisode, ...]:
    """Build an immutable line history using only each replay frame's knowledge."""
    episodes: dict[str, dict[str, object]] = {}
    for frame in snapshots:
        line_snapshot = frame.snapshots.get("line.trend")
        if line_snapshot is None:
            continue
        for structure in line_snapshot.structures:
            values = {item.name: item.actual for item in structure.evidence}
            episode = episodes.setdefault(
                structure.structure_id,
                {
                    "structure_id": structure.structure_id,
                    "first_seen_index": frame.bar_index,
                    "known_at_index": structure.known_at_index,
                    "side": str(values["side"]),
                    "role": str(values["role"]),
                    "generation": int(values["generation"]),
                    "anchor_indexes": tuple(int(value) for value in values["anchor_indexes"]),
                    "anchor_prices": tuple(float(value) for value in values["anchor_prices"]),
                    "states": [],
                    "invalidated_index": None,
                },
            )
            state = ReplayLineState(
                frame.bar_index,
                structure.local_state,
                bool(values.get("is_controlling", False)),
            )
            episode["states"].append(state)
            if (
                episode["invalidated_index"] is None
                and structure.local_state in {"INVALIDATED", "HISTORICAL"}
            ):
                episode["invalidated_index"] = frame.bar_index

    result = []
    for values in episodes.values():
        result.append(ReplayLineEpisode(
            structure_id=values["structure_id"],
            first_seen_index=values["first_seen_index"],
            known_at_index=values["known_at_index"],
            side=values["side"],
            role=values["role"],
            generation=values["generation"],
            anchor_indexes=values["anchor_indexes"],
            anchor_prices=values["anchor_prices"],
            states=tuple(values["states"]),
            invalidated_index=values["invalidated_index"],
        ))
    return tuple(sorted(result, key=lambda item: (item.first_seen_index, item.structure_id)))

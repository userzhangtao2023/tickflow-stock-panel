from __future__ import annotations

from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Any


def log_realtime_profit_training(
    *,
    mlflow_module: Any | None = None,
    tracking_uri: str | None,
    experiment_name: str,
    run_name: str,
    params: Mapping[str, Any],
    metrics: Mapping[str, Any],
    tags: Mapping[str, Any],
    artifact_paths: Iterable[str | Path],
) -> dict[str, Any]:
    return log_algorithm_run(
        mlflow_module=mlflow_module,
        tracking_uri=tracking_uri,
        experiment_name=experiment_name,
        run_name=run_name,
        params=params,
        metrics=metrics,
        tags=tags,
        artifact_paths=artifact_paths,
    )


def log_algorithm_run(
    *,
    mlflow_module: Any | None = None,
    tracking_uri: str | None,
    experiment_name: str,
    run_name: str,
    params: Mapping[str, Any],
    metrics: Mapping[str, Any],
    tags: Mapping[str, Any],
    artifact_paths: Iterable[str | Path],
) -> dict[str, Any]:
    mlflow = mlflow_module if mlflow_module is not None else _load_mlflow()
    if mlflow is None:
        return {"enabled": False, "reason": "mlflow_not_installed"}
    if tracking_uri:
        mlflow.set_tracking_uri(str(tracking_uri))
    mlflow.set_experiment(experiment_name)
    with mlflow.start_run(run_name=run_name) as run:
        normalized_tags = {str(key): str(value) for key, value in tags.items() if value is not None}
        if normalized_tags:
            mlflow.set_tags(normalized_tags)
        normalized_params = _flat_params(params)
        if normalized_params:
            mlflow.log_params(normalized_params)
        normalized_metrics = _flat_numeric_metrics(metrics)
        if normalized_metrics:
            mlflow.log_metrics(normalized_metrics)
        for path in artifact_paths:
            artifact = Path(path)
            if artifact.exists():
                mlflow.log_artifact(str(artifact))
    return {
        "enabled": True,
        "run_id": str(run.info.run_id),
        "tracking_uri": str(tracking_uri or ""),
        "experiment_name": experiment_name,
    }


def extract_numeric_metrics(values: Mapping[str, Any], *, max_metrics: int = 100) -> dict[str, float]:
    metrics = _flat_numeric_metrics(values)
    if len(metrics) <= max_metrics:
        return metrics
    return dict(list(metrics.items())[:max_metrics])


def _load_mlflow() -> Any | None:
    try:
        import mlflow  # type: ignore
    except Exception:
        return None
    return mlflow


def _flat_params(values: Mapping[str, Any]) -> dict[str, Any]:
    output: dict[str, Any] = {}
    for key, value in values.items():
        if value is None:
            continue
        if isinstance(value, (str, int, float, bool)):
            output[str(key)] = value
        else:
            output[str(key)] = str(value)
    return output


def _flat_numeric_metrics(values: Mapping[str, Any], *, prefix: str = "") -> dict[str, float]:
    output: dict[str, float] = {}
    for key, value in values.items():
        name = f"{prefix}.{key}" if prefix else str(key)
        if isinstance(value, bool):
            continue
        if isinstance(value, (int, float)):
            output[name] = float(value)
        elif isinstance(value, Mapping):
            output.update(_flat_numeric_metrics(value, prefix=name))
    return output

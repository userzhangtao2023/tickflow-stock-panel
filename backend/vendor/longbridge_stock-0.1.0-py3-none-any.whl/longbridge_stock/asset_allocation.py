from __future__ import annotations

import re
from math import floor
from typing import Any, Iterable


DEFAULT_RESERVE_CASH_PCT = 0.20
DEFAULT_CORE_LONG_PCT = 0.45
DEFAULT_OPTION_INCOME_PCT = 0.30
DEFAULT_HEDGE_PCT = 0.10
DEFAULT_TACTICAL_PCT = 0.05
DEFAULT_SINGLE_SYMBOL_PCT = 0.10


def build_allocation_budget(
    *,
    account: dict[str, Any],
    positions: Iterable[dict[str, Any]],
    markets: Iterable[str] | None = None,
    reserve_cash_pct: float = DEFAULT_RESERVE_CASH_PCT,
    core_long_pct: float = DEFAULT_CORE_LONG_PCT,
    option_income_pct: float = DEFAULT_OPTION_INCOME_PCT,
    hedge_pct: float = DEFAULT_HEDGE_PCT,
    tactical_pct: float = DEFAULT_TACTICAL_PCT,
    single_symbol_pct: float = DEFAULT_SINGLE_SYMBOL_PCT,
) -> dict[str, Any]:
    net_assets = _num(account.get("net_assets") or account.get("total_asset"))
    buy_power = _num(account.get("buy_power"))
    init_margin = _num(account.get("init_margin"))
    exposures = _position_exposures(positions, markets=markets)
    status = _account_status(net_assets=net_assets, buy_power=buy_power, init_margin=init_margin)

    limits = {
        "core_long": _limit(net_assets, core_long_pct, exposures["core_long"], enabled=True),
        "option_income": _limit(net_assets, option_income_pct, exposures["option_income"], enabled=status != "blocked"),
        "hedge": _limit(net_assets, hedge_pct, exposures["hedge"], enabled=True),
        "tactical": _limit(net_assets, tactical_pct, exposures["tactical"], enabled=status == "normal"),
    }
    return {
        "status": status,
        "net_assets": round(net_assets, 2),
        "buy_power": round(buy_power, 2),
        "init_margin": round(init_margin, 2),
        "init_margin_ratio": round(init_margin / net_assets, 4) if net_assets > 0 else 0.0,
        "buy_power_ratio": round(buy_power / net_assets, 4) if net_assets > 0 else 0.0,
        "reserve_cash": round(net_assets * reserve_cash_pct, 2),
        "single_symbol_limit": round(net_assets * single_symbol_pct, 2),
        "symbol_exposure": {key: round(value, 2) for key, value in exposures["by_symbol"].items()},
        "strategy_limits": limits,
    }


def cap_contracts_by_allocation(
    *,
    requested_contracts: int,
    strategy: str,
    underlying_symbol: str,
    strike_price: float,
    budget: dict[str, Any],
) -> int:
    requested = max(0, int(requested_contracts))
    if requested <= 0:
        return 0
    strategy_key = "option_income" if strategy in {"Sell Put", "Covered Call"} else "tactical"
    strategy_limit = (budget.get("strategy_limits") or {}).get(strategy_key) or {}
    if not strategy_limit.get("enabled", True):
        return 0

    contract_notional = _num(strike_price) * 100
    if contract_notional <= 0:
        return 0
    remaining_strategy = _num(strategy_limit.get("remaining"))
    current_symbol = _num((budget.get("symbol_exposure") or {}).get(underlying_symbol))
    remaining_symbol = _num(budget.get("single_symbol_limit")) - current_symbol
    max_by_budget = floor(min(remaining_strategy, remaining_symbol) / contract_notional)
    return min(requested, max(0, max_by_budget))


def _limit(net_assets: float, pct: float, current: float, *, enabled: bool) -> dict[str, Any]:
    target = net_assets * pct
    return {
        "target": round(target, 2),
        "current": round(current, 2),
        "remaining": round(max(target - current, 0.0), 2),
        "enabled": enabled,
    }


def _position_exposures(positions: Iterable[dict[str, Any]], *, markets: Iterable[str] | None = None) -> dict[str, Any]:
    core_long = 0.0
    option_income = 0.0
    hedge = 0.0
    tactical = 0.0
    by_symbol: dict[str, float] = {}
    allowed_markets = {str(market).upper() for market in markets or []}
    for row in positions:
        symbol = str(row.get("symbol") or "").strip().upper()
        quantity = _num(row.get("quantity"))
        market_price = _num(row.get("market_price") or row.get("last_price") or row.get("cost_price"))
        if not symbol or quantity == 0:
            continue
        if allowed_markets and _market_of(symbol, row) not in allowed_markets:
            continue
        if _looks_like_us_option(symbol):
            underlying = _option_underlying(symbol)
            strike = _option_strike(symbol)
            notional = strike * 100 * abs(quantity) if strike > 0 else market_price * 100 * abs(quantity)
            mark_value = market_price * 100 * abs(quantity)
            exposure = notional + mark_value if quantity < 0 else mark_value
            if quantity < 0:
                option_income += exposure
            else:
                hedge += exposure
            if underlying:
                by_symbol[underlying] = by_symbol.get(underlying, 0.0) + exposure
            continue

        exposure = abs(quantity) * market_price
        if quantity > 0:
            core_long += exposure
        else:
            hedge += exposure
        by_symbol[symbol] = by_symbol.get(symbol, 0.0) + exposure
    return {
        "core_long": core_long,
        "option_income": option_income,
        "hedge": hedge,
        "tactical": tactical,
        "by_symbol": by_symbol,
    }


def _account_status(*, net_assets: float, buy_power: float, init_margin: float) -> str:
    init_margin_ratio = init_margin / net_assets if net_assets > 0 else 0.0
    buy_power_ratio = buy_power / net_assets if net_assets > 0 else 0.0
    if init_margin_ratio >= 0.85 or buy_power_ratio < 0.12:
        return "blocked"
    if init_margin_ratio >= 0.70 or buy_power_ratio < 0.22:
        return "caution"
    return "normal"


def _looks_like_us_option(symbol: str) -> bool:
    core = symbol.removesuffix(".US")
    return bool(re.search(r"\d{6}[CP]\d+$", core))


def _option_underlying(symbol: str) -> str:
    core = symbol.removesuffix(".US")
    match = re.match(r"^([A-Z]+)\d{6}[CP]\d+$", core)
    return f"{match.group(1)}.US" if match else ""


def _option_strike(symbol: str) -> float:
    core = symbol.removesuffix(".US")
    match = re.search(r"[CP](\d+)$", core)
    return int(match.group(1)) / 1000.0 if match else 0.0


def _market_of(symbol: str, row: dict[str, Any]) -> str:
    market = str(row.get("market") or "").strip().upper()
    if market:
        return market
    if "." in symbol:
        return symbol.rsplit(".", 1)[-1]
    return ""


def _num(value: Any) -> float:
    if value is None or value == "":
        return 0.0
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0

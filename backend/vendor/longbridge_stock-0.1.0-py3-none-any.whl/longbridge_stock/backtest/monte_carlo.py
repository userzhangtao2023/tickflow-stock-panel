from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class MonteCarloBacktestResult:
    paths: pd.DataFrame
    terminal_returns: pd.Series
    max_drawdowns: pd.Series
    metrics: dict[str, float | int]


def run_monte_carlo_backtest(
    daily: pd.DataFrame | pd.Series,
    simulations: int = 1000,
    horizon_days: int | None = None,
    seed: int | None = 42,
    initial_equity: float = 1.0,
) -> MonteCarloBacktestResult:
    """Bootstrap historical daily net returns into Monte Carlo equity paths."""
    if simulations <= 0:
        raise ValueError("simulations must be positive")
    if initial_equity <= 0:
        raise ValueError("initial_equity must be positive")

    returns = _return_series(daily)
    if returns.empty:
        raise ValueError("daily returns are empty")
    horizon = horizon_days or len(returns)
    if horizon <= 0:
        raise ValueError("horizon_days must be positive")

    rng = np.random.default_rng(seed)
    sampled = rng.choice(returns.to_numpy(dtype=float), size=(horizon, simulations), replace=True)
    equity = initial_equity * np.cumprod(1.0 + sampled, axis=0)
    paths = pd.DataFrame(equity, index=pd.RangeIndex(1, horizon + 1, name="step"))
    paths.columns = [f"simulation_{index + 1}" for index in range(simulations)]

    terminal_returns = pd.Series(paths.iloc[-1].to_numpy() / initial_equity - 1.0, name="terminal_return")
    max_drawdowns = pd.Series(_max_drawdowns(equity), name="max_drawdown")
    return MonteCarloBacktestResult(
        paths=paths,
        terminal_returns=terminal_returns,
        max_drawdowns=max_drawdowns,
        metrics=_metrics(terminal_returns, max_drawdowns, simulations, horizon),
    )


def _return_series(daily: pd.DataFrame | pd.Series) -> pd.Series:
    if isinstance(daily, pd.Series):
        series = daily
    elif "net_return" in daily.columns:
        series = daily["net_return"]
    elif "return" in daily.columns:
        series = daily["return"]
    else:
        raise KeyError("daily must be a Series or contain a net_return column")
    return pd.to_numeric(series, errors="coerce").replace([np.inf, -np.inf], np.nan).dropna()


def _max_drawdowns(equity: np.ndarray) -> np.ndarray:
    running_max = np.maximum.accumulate(equity, axis=0)
    drawdowns = equity / running_max - 1.0
    return drawdowns.min(axis=0)


def _metrics(
    terminal_returns: pd.Series,
    max_drawdowns: pd.Series,
    simulations: int,
    horizon_days: int,
) -> dict[str, float | int]:
    terminal_p05 = float(terminal_returns.quantile(0.05))
    tail = terminal_returns[terminal_returns <= terminal_p05]
    cvar_95 = float(-(tail.mean())) if not tail.empty else float(-terminal_p05)
    return {
        "simulations": simulations,
        "horizon_days": horizon_days,
        "terminal_return_mean": float(terminal_returns.mean()),
        "terminal_return_median": float(terminal_returns.median()),
        "terminal_return_p05": terminal_p05,
        "terminal_return_p95": float(terminal_returns.quantile(0.95)),
        "loss_probability": float((terminal_returns < 0).mean()),
        "var_95": float(max(0.0, -terminal_p05)),
        "cvar_95": float(max(0.0, cvar_95)),
        "max_drawdown_median": float(max_drawdowns.median()),
        "max_drawdown_p05": float(max_drawdowns.quantile(0.05)),
    }

from __future__ import annotations

from datetime import datetime, time as day_time
from typing import Iterable
from zoneinfo import ZoneInfo


SHANGHAI_TZ = ZoneInfo("Asia/Shanghai")
NEW_YORK_TZ = ZoneInfo("America/New_York")

TRADING_SESSIONS = {
    "cn": ((day_time(9, 30), day_time(11, 30)), (day_time(13, 0), day_time(15, 0))),
    "hk": ((day_time(9, 30), day_time(12, 0)), (day_time(13, 0), day_time(16, 0))),
    "us": ((day_time(9, 30), day_time(16, 0)),),
}

MARKET_TIMEZONES = {
    "cn": SHANGHAI_TZ,
    "hk": SHANGHAI_TZ,
    "us": NEW_YORK_TZ,
}


def is_trading_time(now: datetime, markets: Iterable[str]) -> bool:
    for market in markets:
        market_key = market.lower()
        sessions = TRADING_SESSIONS.get(market_key)
        timezone = MARKET_TIMEZONES.get(market_key, SHANGHAI_TZ)
        current = now.astimezone(timezone) if now.tzinfo else now.replace(tzinfo=SHANGHAI_TZ).astimezone(timezone)
        if current.weekday() >= 5:
            continue
        current_time = current.time()
        if sessions and any(start <= current_time <= end for start, end in sessions):
            return True
    return False


def has_market_opened_today(now: datetime, markets: Iterable[str]) -> bool:
    for market in markets:
        market_key = market.lower()
        sessions = TRADING_SESSIONS.get(market_key)
        timezone = MARKET_TIMEZONES.get(market_key, SHANGHAI_TZ)
        current = now.astimezone(timezone) if now.tzinfo else now.replace(tzinfo=SHANGHAI_TZ).astimezone(timezone)
        if current.weekday() >= 5 or not sessions:
            continue
        first_open = min(start for start, _ in sessions)
        if current.time() >= first_open:
            return True
    return False


def markets_from_symbols(symbols: Iterable[str]) -> list[str]:
    markets: list[str] = []
    seen: set[str] = set()
    for symbol in symbols:
        market = market_from_symbol(symbol)
        if market and market not in seen:
            markets.append(market)
            seen.add(market)
    return markets


def market_from_symbol(symbol: str) -> str:
    suffix = symbol.rsplit(".", 1)[-1].lower() if "." in symbol else ""
    return "cn" if suffix in {"sh", "sz"} else suffix


def filter_symbols_for_trading_time(symbols: Iterable[str], now: datetime) -> list[str]:
    active: list[str] = []
    for symbol in symbols:
        normalized = str(symbol).strip().upper()
        market = market_from_symbol(normalized)
        if market and is_trading_time(now, [market]):
            active.append(normalized)
    return active

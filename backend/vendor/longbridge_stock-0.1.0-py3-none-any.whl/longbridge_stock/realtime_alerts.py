from __future__ import annotations

import json
import os
import subprocess
import time
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Any, Callable, Iterable

from longbridge_stock.market_sessions import SHANGHAI_TZ, is_trading_time
from longbridge_stock.realtime_analysis import fetch_realtime_model_pool

DEFAULT_STATE_PATH = Path("/home/alwin/data/longbridge/realtime_alert_state.json")
DEFAULT_OPENCLAW_BIN = "/home/alwin/.npm-global/bin/openclaw"
DEFAULT_TARGETS = "qqbot=qqbot:c2c:0F91F8A6B3A8E055F16F79D4454EC06D,wecom=ZhangTao"


@dataclass(frozen=True)
class RealtimeAlertConfig:
    markets: list[str]
    buy_score: float = 75.0
    strong_buy_score: float = 85.0
    limit: int = 80
    pool: str = "all"
    max_alerts_per_run: int = 10

    @classmethod
    def from_markets(cls, markets: Iterable[str]) -> "RealtimeAlertConfig":
        return cls(markets=[market.strip().lower() for market in markets if market.strip()])


@dataclass(frozen=True)
class RealtimeAlert:
    alert_type: str
    symbol: str
    market: str
    name: str
    title: str
    message: str
    score: float | None
    signal: str

    @property
    def dedupe_key(self) -> str:
        return f"{self.market}:{self.symbol}:{self.alert_type}"


@dataclass(frozen=True)
class OpenClawTarget:
    channel: str
    target: str

    def build_command(self, openclaw_bin: str, message: str) -> list[str]:
        command = [
            openclaw_bin,
            "message",
            "send",
        ]
        if self.channel == "qqbot":
            command.extend(["--account", "default"])
        command.extend(
            [
            "--channel",
            self.channel,
            "--target",
            self.target,
            "--message",
            message,
            "--json",
            ]
        )
        return command


class AlertState:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self._data = self._load()

    def should_send(self, alert: RealtimeAlert, trade_date: str) -> bool:
        sent = self._data.get("sent", {})
        return f"{trade_date}:{alert.dedupe_key}" not in sent

    def mark_sent(self, alert: RealtimeAlert, trade_date: str) -> None:
        sent = self._data.setdefault("sent", {})
        sent[f"{trade_date}:{alert.dedupe_key}"] = {
            "sentAt": datetime.now(SHANGHAI_TZ).isoformat(),
            "title": alert.title,
        }
        self._save()

    def _load(self) -> dict[str, Any]:
        if not self.path.exists():
            return {"sent": {}}
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {"sent": {}}

    def _save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self._data, ensure_ascii=False, indent=2), encoding="utf-8")


class OpenClawNotifier:
    def __init__(
        self,
        targets: list[OpenClawTarget],
        openclaw_bin: str = DEFAULT_OPENCLAW_BIN,
        ssh_target: str | None = None,
        runner: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
    ) -> None:
        self.targets = targets
        self.openclaw_bin = openclaw_bin
        self.ssh_target = ssh_target
        self.runner = runner
        self.timeout_seconds = float(os.getenv("OPENCLAW_SEND_TIMEOUT_SECONDS", "90"))

    def send(self, message: str) -> list[dict[str, Any]]:
        results = []
        failures = []
        for target in self.targets:
            command = target.build_command(self.openclaw_bin, message)
            run_command = ["ssh", self.ssh_target, *command] if self.ssh_target else command
            completed = self.runner(run_command, capture_output=True, text=True, timeout=self.timeout_seconds)
            error = completed.stderr.strip() or completed.stdout.strip()
            results.append(
                {
                    "channel": target.channel,
                    "target": target.target,
                    "returncode": completed.returncode,
                    "stdout": completed.stdout.strip(),
                    "stderr": completed.stderr.strip(),
                }
            )
            if completed.returncode != 0:
                failures.append(f"{target.channel}:{target.target}: {error or 'OpenClaw send failed'}")
        if failures:
            raise RuntimeError("; ".join(failures))
        return results


class RealtimeAlertMonitor:
    def __init__(
        self,
        dsn: str,
        config: RealtimeAlertConfig,
        notifier: OpenClawNotifier,
        state: AlertState,
    ) -> None:
        self.dsn = dsn
        self.config = config
        self.notifier = notifier
        self.state = state

    def run_once(self, now: datetime | None = None) -> dict[str, Any]:
        current = now or datetime.now(SHANGHAI_TZ)
        if not is_trading_time(current, self.config.markets):
            return {"status": "outside_trading_time", "sent": 0, "checked": 0}
        alerts: list[RealtimeAlert] = []
        checked = 0
        for market in self.config.markets:
            rows = fetch_realtime_model_pool(self.dsn, market=market, pool=self.config.pool, limit=self.config.limit)
            checked += len(rows)
            alerts.extend(build_realtime_alerts(rows, self.config))
        alerts.sort(key=lambda alert: alert.score if alert.score is not None else -1, reverse=True)
        trade_date = current.date().isoformat()
        sent = 0
        skipped = 0
        deferred = 0
        errors: list[str] = []
        for alert in alerts:
            if not self.state.should_send(alert, trade_date):
                skipped += 1
                continue
            if sent >= self.config.max_alerts_per_run:
                deferred += 1
                continue
            try:
                self.notifier.send(alert.message)
            except Exception as exc:
                errors.append(f"{alert.dedupe_key}: {exc}")
                continue
            self.state.mark_sent(alert, trade_date)
            sent += 1
        return {
            "status": "ok",
            "checked": checked,
            "alerts": len(alerts),
            "sent": sent,
            "skipped": skipped,
            "deferred": deferred,
            "errors": errors,
        }

    def run_forever(self, interval_seconds: int) -> None:
        if interval_seconds <= 0:
            raise ValueError("interval_seconds must be positive")
        while True:
            started = time.monotonic()
            result = self.run_once()
            print(json.dumps(result, ensure_ascii=False), flush=True)
            time.sleep(max(0, interval_seconds - (time.monotonic() - started)))


def build_realtime_alerts(rows: Iterable[dict[str, Any]], config: RealtimeAlertConfig) -> list[RealtimeAlert]:
    allowed_markets = {market.upper() for market in config.markets}
    alerts: list[RealtimeAlert] = []
    for row in rows:
        market = str(row.get("market") or "").upper()
        if market not in allowed_markets:
            continue
        alert_type = _alert_type(row, config)
        if not alert_type:
            continue
        alerts.append(_build_alert(row, alert_type))
    return alerts


def parse_openclaw_targets(raw: str | None = None) -> list[OpenClawTarget]:
    value = raw or os.getenv("OPENCLAW_ALERT_TARGETS", DEFAULT_TARGETS)
    targets: list[OpenClawTarget] = []
    for item in value.split(","):
        if not item.strip():
            continue
        channel, sep, target = item.partition("=")
        if not sep or not channel.strip() or not target.strip():
            raise ValueError(f"Invalid OpenClaw target entry: {item}")
        targets.append(OpenClawTarget(channel=channel.strip(), target=target.strip()))
    if not targets:
        raise ValueError("At least one OpenClaw target is required")
    return targets


def build_default_notifier(targets: str | None = None) -> OpenClawNotifier:
    return OpenClawNotifier(
        targets=parse_openclaw_targets(targets),
        openclaw_bin=os.getenv("OPENCLAW_BIN", DEFAULT_OPENCLAW_BIN),
        ssh_target=os.getenv("OPENCLAW_SSH_TARGET") or None,
    )


def today_trade_date(now: datetime | None = None) -> date:
    current = now or datetime.now(SHANGHAI_TZ)
    return current.astimezone(SHANGHAI_TZ).date() if current.tzinfo else current.date()


def _alert_type(row: dict[str, Any], config: RealtimeAlertConfig) -> str | None:
    signal = str(row.get("signal") or "")
    score = _number(row.get("realtimeScore"))
    if signal == "capital_accumulation" and score is not None:
        if score >= config.strong_buy_score:
            return "strong_buy"
        if score >= config.buy_score:
            return "buy"
    if signal in {"main_fund_outflow", "retail_chase_risk"}:
        return "risk"
    return None


def _build_alert(row: dict[str, Any], alert_type: str) -> RealtimeAlert:
    symbol = str(row.get("symbol") or "-")
    market = str(row.get("market") or "").upper()
    name = str(row.get("name") or symbol)
    signal = str(row.get("signal") or "")
    score = _number(row.get("realtimeScore"))
    label = {"strong_buy": "强买点", "buy": "买点", "risk": "风险/卖点"}.get(alert_type, "信号")
    title = f"{market} {symbol} {name} {label}"
    message = "\n".join(
        [
            f"[长桥实时{label}] {market} {symbol} {name}",
            f"信号：{row.get('signalLabel') or signal}",
            f"实时分：{_fmt(score)}",
            f"涨跌幅：{_fmt(row.get('changePercentage'))}%",
            f"现价：{_fmt(row.get('lastDone'))}",
            f"主力净流入：{_fmt(row.get('largeNet'))}",
            f"总净流入：{_fmt(row.get('totalNet'))}",
            f"行情分钟：{row.get('quoteMinute') or '-'}",
            f"资金分钟：{row.get('capitalMinute') or '-'}",
        ]
    )
    return RealtimeAlert(
        alert_type=alert_type,
        symbol=symbol,
        market=market,
        name=name,
        title=title,
        message=message,
        score=score,
        signal=signal,
    )


def _number(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _fmt(value: Any) -> str:
    number = _number(value)
    if number is None:
        return "-"
    return f"{number:.2f}"

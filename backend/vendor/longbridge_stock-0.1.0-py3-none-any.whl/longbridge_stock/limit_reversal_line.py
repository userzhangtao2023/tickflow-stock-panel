from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd
import psycopg


DEFAULT_DSN = "dbname=longbridge_stock user=alwin host=/var/run/postgresql"
LIMIT_UP_THRESHOLD = 0.098
GAIN_EVENT_THRESHOLD = 0.10
ZERO_HIGH_MIN = 0.01
ZERO_PULLBACK_MIN = 0.02
MAX_PATTERN_DAYS = 8
MAX_RED_WAIT_DAYS = 6
HORIZONS = (1, 3, 5, 10)


@dataclass(frozen=True)
class LimitReversalRule:
    limit_up_threshold: float = LIMIT_UP_THRESHOLD
    zero_high_min: float = ZERO_HIGH_MIN
    zero_pullback_min: float = ZERO_PULLBACK_MIN
    max_pattern_days: int = MAX_PATTERN_DAYS
    max_red_wait_days: int = MAX_RED_WAIT_DAYS


@dataclass(frozen=True)
class LimitReversalBacktest:
    rule: dict[str, Any]
    coverage: dict[str, Any]
    next_open_entry: dict[str, Any]
    red_close_entry: dict[str, Any]
    report_path: str | None = None
    candidates_path: str | None = None


def backtest_limit_reversal_lines(
    *,
    dsn: str = DEFAULT_DSN,
    start_date: str | None = None,
    end_date: str | None = None,
    output_dir: str | Path | None = None,
    rule: LimitReversalRule = LimitReversalRule(),
) -> LimitReversalBacktest:
    bars = load_cn_daily_bars(dsn=dsn, start_date=start_date, end_date=end_date)
    patterns, coverage = find_limit_reversal_patterns(bars, rule=rule)
    report = LimitReversalBacktest(
        rule=_rule_payload(rule),
        coverage={
            **coverage,
            "bar_rows": int(len(bars)),
            "symbols": int(bars["symbol"].nunique()),
            "start": str(bars["trade_date"].min().date()) if not bars.empty else start_date,
            "end": str(bars["trade_date"].max().date()) if not bars.empty else end_date,
        },
        next_open_entry=summarize_entry(patterns, "next_open"),
        red_close_entry=summarize_entry(patterns, "red_close"),
    )
    if output_dir:
        output = Path(output_dir)
        output.mkdir(parents=True, exist_ok=True)
        suffix = str(report.coverage.get("end") or "latest").replace("-", "")
        report_path = output / f"limit_reversal_line_backtest_{suffix}.json"
        candidates_path = output / f"limit_reversal_line_patterns_{suffix}.csv"
        report_path.write_text(json.dumps(asdict(report), ensure_ascii=False, indent=2), encoding="utf-8")
        patterns.to_csv(candidates_path, index=False)
        report = LimitReversalBacktest(
            rule=report.rule,
            coverage=report.coverage,
            next_open_entry=report.next_open_entry,
            red_close_entry=report.red_close_entry,
            report_path=str(report_path),
            candidates_path=str(candidates_path),
        )
    return report


def current_limit_reversal_candidates(
    *,
    dsn: str = DEFAULT_DSN,
    as_of_date: str | None = None,
    lookback_days: int = 90,
    limit: int = 50,
    rule: LimitReversalRule = LimitReversalRule(),
) -> pd.DataFrame:
    with psycopg.connect(dsn) as conn:
        if as_of_date:
            end_date = pd.Timestamp(as_of_date).date().isoformat()
        else:
            with conn.cursor() as cur:
                cur.execute("select max(trade_date) from lb_daily_bars where market = 'cn'")
                end_date = str(cur.fetchone()[0])
        start = (pd.Timestamp(end_date) - pd.Timedelta(days=lookback_days * 2)).date().isoformat()
    bars = load_cn_daily_bars(dsn=dsn, start_date=start, end_date=end_date)
    patterns, _coverage = find_limit_reversal_patterns(bars, rule=rule)
    if patterns.empty:
        return patterns
    latest = pd.Timestamp(end_date).date().isoformat()
    candidates = patterns.loc[patterns["red_date"] == latest].copy()
    if candidates.empty:
        return candidates
    candidates = candidates.sort_values(
        ["days_limit_to_line3", "zero_pullback", "red_return"],
        ascending=[True, False, False],
    ).head(limit)
    names = _load_symbol_names(dsn, candidates["symbol"].dropna().astype(str).tolist())
    candidates.insert(1, "name", candidates["symbol"].map(names).fillna(""))
    cleaned = candidates.replace([np.inf, -np.inf], np.nan)
    return cleaned.astype(object).where(pd.notna(cleaned), None)


def current_limit_reversal_watchlist(
    *,
    dsn: str = DEFAULT_DSN,
    markets: Iterable[str] = ("cn", "hk", "us"),
    as_of_date: str | None = None,
    event_start_date: str | None = None,
    lookback_days: int = 45,
    event_threshold: float = GAIN_EVENT_THRESHOLD,
    limit: int = 300,
    rule: LimitReversalRule | None = None,
) -> pd.DataFrame:
    target_rule = rule or LimitReversalRule(limit_up_threshold=event_threshold)
    market_list = [market.strip().lower() for market in markets if market.strip()]
    if not market_list:
        return pd.DataFrame()
    with psycopg.connect(dsn) as conn:
        if as_of_date:
            end_date = pd.Timestamp(as_of_date).date().isoformat()
        else:
            with conn.cursor() as cur:
                cur.execute("select max(trade_date) from lb_daily_bars where market = any(%s)", (market_list,))
                end_date = str(cur.fetchone()[0])
    start = (pd.Timestamp(end_date) - pd.Timedelta(days=lookback_days * 2)).date().isoformat()
    event_start = event_start_date or (pd.Timestamp(end_date) - pd.Timedelta(days=lookback_days)).date().isoformat()
    bars = load_daily_bars(dsn=dsn, markets=market_list, start_date=start, end_date=end_date)
    patterns, _coverage = find_limit_reversal_watch_patterns(
        bars,
        event_start_date=event_start,
        event_end_date=end_date,
        rule=target_rule,
    )
    if patterns.empty:
        return patterns
    pending = patterns.loc[patterns["stage"] == "LINE123_OK"].copy()
    if pending.empty:
        return pending
    names = _load_symbol_names(dsn, pending["symbol"].dropna().astype(str).tolist())
    pending["name"] = pending["symbol"].map(names).fillna(pending.get("name", ""))
    pending = pending.sort_values(
        ["line3_date", "market", "symbol", "event_date"],
        ascending=[False, True, True, False],
    )
    cleaned = pending.head(limit).replace([np.inf, -np.inf], np.nan)
    return cleaned.astype(object).where(pd.notna(cleaned), None)


def load_cn_daily_bars(*, dsn: str, start_date: str | None, end_date: str | None) -> pd.DataFrame:
    return load_daily_bars(dsn=dsn, markets=["cn"], start_date=start_date, end_date=end_date)


def load_daily_bars(
    *,
    dsn: str,
    markets: Iterable[str],
    start_date: str | None,
    end_date: str | None,
) -> pd.DataFrame:
    market_list = [market.strip().lower() for market in markets if market.strip()]
    if not market_list:
        return pd.DataFrame()
    where = [
        "market = any(%s)",
        "open is not null",
        "high is not null",
        "low is not null",
        "close is not null",
    ]
    params: list[Any] = [market_list]
    if start_date:
        where.append("trade_date >= %s")
        params.append(start_date)
    if end_date:
        where.append("trade_date <= %s")
        params.append(end_date)
    query = f"""
        select symbol, market, trade_date, open::float8 as open, high::float8 as high,
               low::float8 as low, close::float8 as close, volume::float8 as volume,
               turnover::float8 as turnover
        from lb_daily_bars
        where {" and ".join(where)}
        order by market, symbol, trade_date
    """
    with psycopg.connect(dsn) as conn:
        frame = pd.read_sql_query(query, conn, params=params)
    if frame.empty:
        return frame
    frame["trade_date"] = pd.to_datetime(frame["trade_date"])
    frame = frame.sort_values(["market", "symbol", "trade_date"]).reset_index(drop=True)
    frame["prev_close"] = frame.groupby(["market", "symbol"])["close"].shift(1)
    frame["pct_change"] = frame["close"] / frame["prev_close"] - 1
    frame["close_position"] = (frame["close"] - frame["low"]) / (frame["high"] - frame["low"]).replace(0, np.nan)
    frame["red"] = frame["close"] > frame["open"]
    return frame


def find_limit_reversal_watch_patterns(
    bars: pd.DataFrame,
    *,
    event_start_date: str,
    event_end_date: str,
    rule: LimitReversalRule = LimitReversalRule(limit_up_threshold=GAIN_EVENT_THRESHOLD),
) -> tuple[pd.DataFrame, dict[str, int]]:
    records: list[dict[str, Any]] = []
    coverage = {
        "event_count": 0,
        "zero_events": 0,
        "line123_events": 0,
        "red_buy_signals": 0,
    }
    if bars.empty:
        return pd.DataFrame(), coverage
    for (market, symbol), group in bars.groupby(["market", "symbol"], sort=False):
        group = group.reset_index(drop=True)
        for idx, row in group.iterrows():
            event_date = _date_text(row["trade_date"])
            if event_date < event_start_date or event_date > event_end_date:
                continue
            if not np.isfinite(row["pct_change"]) or row["pct_change"] < rule.limit_up_threshold:
                continue
            coverage["event_count"] += 1
            record = _watch_record_base(market, symbol, group, idx)
            zero_idx = idx + 1
            if zero_idx >= len(group):
                record["note"] = "no next daily bar yet"
                records.append(record)
                continue
            zero = group.iloc[zero_idx]
            high_vs_event_close = _safe_ratio(zero["high"], row["close"]) - 1
            zero_pullback = _safe_ratio(zero["high"], zero["close"]) - 1
            record.update(
                {
                    "zero_date": _date_text(zero["trade_date"]),
                    "zero_high_pct": _json_float(high_vs_event_close * 100),
                    "zero_pullback_pct": _json_float(zero_pullback * 100),
                }
            )
            if not _is_zero_line(
                high_vs_limit_close=high_vs_event_close,
                zero_pullback=zero_pullback,
                zero_close_position=zero["close_position"],
                zero_close=zero["close"],
                zero_open=zero["open"],
                rule=rule,
            ):
                record["stage"] = "NO_ZERO"
                record["note"] = "next bar not high-pullback zero line"
                records.append(record)
                continue
            coverage["zero_events"] += 1
            record["stage"] = "ZERO_OK"
            line_indexes = _find_line123(group, limit_idx=idx, zero_idx=zero_idx, rule=rule)
            if line_indexes is None:
                record["note"] = "zero ok, waiting/lacking consecutive lower lows"
                records.append(record)
                continue
            coverage["line123_events"] += 1
            line1_idx, line2_idx, line3_idx = line_indexes
            record.update(
                {
                    "stage": "LINE123_OK",
                    "line1_date": _date_text(group.iloc[line1_idx]["trade_date"]),
                    "line2_date": _date_text(group.iloc[line2_idx]["trade_date"]),
                    "line3_date": _date_text(group.iloc[line3_idx]["trade_date"]),
                    "line1_low": _json_float(group.iloc[line1_idx]["low"]),
                    "line2_low": _json_float(group.iloc[line2_idx]["low"]),
                    "line3_low": _json_float(group.iloc[line3_idx]["low"]),
                    "days_event_to_line3": int(line3_idx - idx),
                }
            )
            red_idx = _find_red_line(group, line3_idx=line3_idx, rule=rule)
            if red_idx is None:
                record["note"] = "line123 ok, waiting red candle confirmation"
                records.append(record)
                continue
            coverage["red_buy_signals"] += 1
            record.update(
                {
                    "stage": "FULL_RED_OK",
                    "red_date": _date_text(group.iloc[red_idx]["trade_date"]),
                    "entry_next_date": _date_text(group.iloc[red_idx + 1]["trade_date"]) if red_idx + 1 < len(group) else None,
                    "note": "complete pattern",
                }
            )
            records.append(record)
    return pd.DataFrame(records), coverage


def find_limit_reversal_patterns(
    bars: pd.DataFrame,
    *,
    rule: LimitReversalRule = LimitReversalRule(),
) -> tuple[pd.DataFrame, dict[str, int]]:
    records: list[dict[str, Any]] = []
    coverage = {
        "limit_up_events": 0,
        "zero_events": 0,
        "line123_events": 0,
        "red_buy_signals": 0,
    }
    if bars.empty:
        return pd.DataFrame(), coverage

    for symbol, group in bars.groupby("symbol", sort=False):
        group = group.reset_index(drop=True)
        for idx, row in group.iterrows():
            if not np.isfinite(row["pct_change"]) or row["pct_change"] < rule.limit_up_threshold:
                continue
            coverage["limit_up_events"] += 1
            zero_idx = idx + 1
            if zero_idx >= len(group):
                continue
            zero = group.iloc[zero_idx]
            high_vs_limit_close = _safe_ratio(zero["high"], row["close"]) - 1
            zero_pullback = _safe_ratio(zero["high"], zero["close"]) - 1
            zero_close_position = zero["close_position"]
            if not _is_zero_line(
                high_vs_limit_close=high_vs_limit_close,
                zero_pullback=zero_pullback,
                zero_close_position=zero_close_position,
                zero_close=zero["close"],
                zero_open=zero["open"],
                rule=rule,
            ):
                continue
            coverage["zero_events"] += 1

            line_indexes = _find_line123(group, limit_idx=idx, zero_idx=zero_idx, rule=rule)
            if line_indexes is None:
                continue
            coverage["line123_events"] += 1
            line1_idx, line2_idx, line3_idx = line_indexes

            red_idx = _find_red_line(group, line3_idx=line3_idx, rule=rule)
            if red_idx is None:
                continue
            coverage["red_buy_signals"] += 1
            records.append(_pattern_record(group, symbol, idx, zero_idx, line1_idx, line2_idx, line3_idx, red_idx))

    return pd.DataFrame(records), coverage


def summarize_entry(patterns: pd.DataFrame, prefix: str) -> dict[str, Any]:
    if patterns.empty:
        return {}
    summary: dict[str, Any] = {}
    for horizon in HORIZONS:
        max_ret = pd.to_numeric(patterns.get(f"{prefix}_max_return_{horizon}d"), errors="coerce")
        close_ret = pd.to_numeric(patterns.get(f"{prefix}_close_return_{horizon}d"), errors="coerce")
        min_ret = pd.to_numeric(patterns.get(f"{prefix}_min_return_{horizon}d"), errors="coerce")
        valid = max_ret.notna() & close_ret.notna()
        if int(valid.sum()) == 0:
            continue
        summary[f"{horizon}d"] = {
            "samples": int(valid.sum()),
            "touch_3pct": float((max_ret[valid] >= 0.03).mean()),
            "touch_5pct": float((max_ret[valid] >= 0.05).mean()),
            "touch_10pct": float((max_ret[valid] >= 0.10).mean()),
            "avg_max_return": float(max_ret[valid].mean()),
            "median_max_return": float(max_ret[valid].median()),
            "avg_close_return": float(close_ret[valid].mean()),
            "median_close_return": float(close_ret[valid].median()),
            "close_positive_rate": float((close_ret[valid] > 0).mean()),
            "close_5pct_rate": float((close_ret[valid] >= 0.05).mean()),
            "max_drawdown_avg": float(min_ret[valid].mean()),
            "drawdown_worse_5pct": float((min_ret[valid] <= -0.05).mean()),
        }
    return summary


def summary_to_dict(summary: LimitReversalBacktest) -> dict[str, Any]:
    return asdict(summary)


def _is_zero_line(
    *,
    high_vs_limit_close: float,
    zero_pullback: float,
    zero_close_position: float,
    zero_close: float,
    zero_open: float,
    rule: LimitReversalRule,
) -> bool:
    if not np.isfinite(high_vs_limit_close) or high_vs_limit_close < rule.zero_high_min:
        return False
    weak_close = (
        (np.isfinite(zero_pullback) and zero_pullback >= rule.zero_pullback_min)
        or (np.isfinite(zero_close_position) and zero_close_position <= 0.45)
        or zero_close <= zero_open
    )
    return bool(weak_close)


def _find_line123(group: pd.DataFrame, *, limit_idx: int, zero_idx: int, rule: LimitReversalRule) -> tuple[int, int, int] | None:
    max_line3_idx = min(len(group) - 1, limit_idx + rule.max_pattern_days)
    for line1_idx in range(zero_idx + 1, max_line3_idx - 1):
        line2_idx = line1_idx + 1
        line3_idx = line1_idx + 2
        if line3_idx > max_line3_idx:
            break
        if (
            group.iloc[line1_idx]["low"] < group.iloc[line1_idx - 1]["low"]
            and group.iloc[line2_idx]["low"] < group.iloc[line1_idx]["low"]
            and group.iloc[line3_idx]["low"] < group.iloc[line2_idx]["low"]
        ):
            return line1_idx, line2_idx, line3_idx
    return None


def _find_red_line(group: pd.DataFrame, *, line3_idx: int, rule: LimitReversalRule) -> int | None:
    end = min(len(group), line3_idx + 1 + rule.max_red_wait_days)
    for idx in range(line3_idx + 1, end):
        if bool(group.iloc[idx]["red"]):
            return idx
    return None


def _pattern_record(
    group: pd.DataFrame,
    symbol: str,
    limit_idx: int,
    zero_idx: int,
    line1_idx: int,
    line2_idx: int,
    line3_idx: int,
    red_idx: int,
) -> dict[str, Any]:
    limit_row = group.iloc[limit_idx]
    zero = group.iloc[zero_idx]
    red = group.iloc[red_idx]
    entry_next_idx = red_idx + 1
    entry_next_open = float(group.iloc[entry_next_idx]["open"]) if entry_next_idx < len(group) else np.nan
    entry_red_close = float(red["close"])
    record: dict[str, Any] = {
        "symbol": symbol,
        "limit_date": _date_text(limit_row["trade_date"]),
        "limit_close": float(limit_row["close"]),
        "limit_pct": float(limit_row["pct_change"]),
        "zero_date": _date_text(zero["trade_date"]),
        "zero_high_return_vs_limit_close": float(_safe_ratio(zero["high"], limit_row["close"]) - 1),
        "zero_pullback": float(_safe_ratio(zero["high"], zero["close"]) - 1),
        "zero_close_position": _json_float(zero["close_position"]),
        "line1_date": _date_text(group.iloc[line1_idx]["trade_date"]),
        "line2_date": _date_text(group.iloc[line2_idx]["trade_date"]),
        "line3_date": _date_text(group.iloc[line3_idx]["trade_date"]),
        "line1_low": float(group.iloc[line1_idx]["low"]),
        "line2_low": float(group.iloc[line2_idx]["low"]),
        "line3_low": float(group.iloc[line3_idx]["low"]),
        "red_date": _date_text(red["trade_date"]),
        "red_return": float(_safe_ratio(red["close"], red["open"]) - 1),
        "red_close": entry_red_close,
        "entry_next_date": _date_text(group.iloc[entry_next_idx]["trade_date"]) if entry_next_idx < len(group) else None,
        "entry_next_open": _json_float(entry_next_open),
        "days_limit_to_line3": int(line3_idx - limit_idx),
        "days_line3_to_red": int(red_idx - line3_idx),
        "drawdown_line3_from_zero_low": float(_safe_ratio(group.iloc[line3_idx]["low"], group.iloc[zero_idx]["low"]) - 1),
        "volume_ratio_zero_vs_limit": _json_float(_safe_ratio(zero["volume"], limit_row["volume"])),
    }
    for horizon in HORIZONS:
        _add_forward_returns(
            record,
            group,
            prefix="next_open",
            entry_idx=entry_next_idx,
            entry_price=entry_next_open,
            horizon=horizon,
        )
        _add_forward_returns(
            record,
            group,
            prefix="red_close",
            entry_idx=red_idx + 1,
            entry_price=entry_red_close,
            horizon=horizon,
        )
    return record


def _watch_record_base(market: str, symbol: str, group: pd.DataFrame, idx: int) -> dict[str, Any]:
    row = group.iloc[idx]
    return {
        "market": str(market),
        "symbol": str(symbol),
        "name": "",
        "event_date": _date_text(row["trade_date"]),
        "event_pct": _json_float(float(row["pct_change"]) * 100),
        "event_close": _json_float(row["close"]),
        "days_after": int(len(group) - idx - 1),
        "stage": "EVENT_ONLY",
        "zero_date": None,
        "line1_date": None,
        "line2_date": None,
        "line3_date": None,
        "red_date": None,
        "entry_next_date": None,
        "note": "",
    }


def _add_forward_returns(
    record: dict[str, Any],
    group: pd.DataFrame,
    *,
    prefix: str,
    entry_idx: int,
    entry_price: float,
    horizon: int,
) -> None:
    future = group.iloc[entry_idx : min(len(group), entry_idx + horizon)]
    if len(future) == horizon and np.isfinite(entry_price) and entry_price > 0:
        record[f"{prefix}_max_return_{horizon}d"] = float(future["high"].max() / entry_price - 1)
        record[f"{prefix}_close_return_{horizon}d"] = float(future.iloc[-1]["close"] / entry_price - 1)
        record[f"{prefix}_min_return_{horizon}d"] = float(future["low"].min() / entry_price - 1)
    else:
        record[f"{prefix}_max_return_{horizon}d"] = None
        record[f"{prefix}_close_return_{horizon}d"] = None
        record[f"{prefix}_min_return_{horizon}d"] = None


def _load_symbol_names(dsn: str, symbols: list[str]) -> dict[str, str]:
    if not symbols:
        return {}
    with psycopg.connect(dsn) as conn, conn.cursor() as cur:
        cur.execute("select symbol, name from lb_symbols where symbol = any(%s)", (symbols,))
        return {str(symbol): str(name or "") for symbol, name in cur.fetchall()}


def _rule_payload(rule: LimitReversalRule) -> dict[str, Any]:
    return {
        **asdict(rule),
        "zero_day": "涨停后的第2个交易日",
        "zero_condition": "最高价较涨停日收盘至少高1%，且收盘从高点明显回落或弱收盘",
        "line_condition": "0线之后寻找连续三个低点下移的1/2/3线，3线需在涨停后8个交易日内完成",
        "buy_signal": "3线后第一根收红K线确认；默认按下一交易日开盘价买入回测",
    }


def _safe_ratio(numerator: Any, denominator: Any) -> float:
    try:
        top = float(numerator)
        bottom = float(denominator)
    except (TypeError, ValueError):
        return np.nan
    if not np.isfinite(top) or not np.isfinite(bottom) or bottom == 0:
        return np.nan
    return top / bottom


def _json_float(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if np.isfinite(number) else None


def _date_text(value: Any) -> str:
    return pd.Timestamp(value).date().isoformat()

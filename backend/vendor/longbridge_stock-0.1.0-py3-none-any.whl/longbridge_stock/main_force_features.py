from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta
from math import isfinite
from typing import Any, Iterable


def build_main_force_features(
    capital_rows: Iterable[dict[str, Any]],
    flow_rows: Iterable[dict[str, Any]],
    *,
    as_of: str | datetime | None = None,
    windows_minutes: tuple[int, ...] = (15, 30, 240),
) -> list[dict[str, Any]]:
    grouped_capital: dict[str, list[dict[str, Any]]] = defaultdict(list)
    grouped_flow: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in capital_rows:
        symbol = _symbol(row)
        snapshot_time = _dt(row.get("snapshot_minute"))
        if symbol and snapshot_time is not None:
            grouped_capital[symbol].append({**row, "_time": snapshot_time})
    for row in flow_rows:
        symbol = _symbol(row)
        flow_time = _dt(row.get("flow_time"))
        if symbol and flow_time is not None:
            grouped_flow[symbol].append({**row, "_time": flow_time})

    output: list[dict[str, Any]] = []
    for symbol, rows in grouped_capital.items():
        rows.sort(key=lambda item: item["_time"])
        latest_time = _dt(as_of) if as_of is not None else rows[-1]["_time"]
        if latest_time is None:
            continue
        latest = _latest_at_or_before(rows, latest_time)
        if latest is None:
            continue
        flows = sorted(grouped_flow.get(symbol, []), key=lambda item: item["_time"])
        for window in windows_minutes:
            baseline_time = latest_time - timedelta(minutes=max(1, int(window)))
            baseline = _first_at_or_after(rows, baseline_time, before=latest_time)
            if baseline is None or baseline is latest:
                continue
            feature = _feature_row(symbol, latest, baseline, latest_time=latest_time, window_minutes=int(window), flows=flows)
            output.append(feature)
    return sorted(output, key=lambda item: (item["market"], item["symbol"], item["window_minutes"]))


def _feature_row(
    symbol: str,
    latest: dict[str, Any],
    baseline: dict[str, Any],
    *,
    latest_time: datetime,
    window_minutes: int,
    flows: list[dict[str, Any]],
) -> dict[str, Any]:
    large_in_delta = _delta(latest, baseline, "large_in")
    large_out_delta = _delta(latest, baseline, "large_out")
    large_net_delta = _delta(latest, baseline, "large_net")
    medium_net_delta = _delta(latest, baseline, "medium_net")
    small_net_delta = _delta(latest, baseline, "small_net")
    total_in_delta = _delta(latest, baseline, "total_in")
    total_out_delta = _delta(latest, baseline, "total_out")
    total_net_delta = _delta(latest, baseline, "total_net")
    total_activity = max(0.0, large_in_delta) + max(0.0, large_out_delta)
    all_activity = max(0.0, total_in_delta) + max(0.0, total_out_delta)
    large_participation = _safe_div(total_activity, all_activity)
    large_net_inflow_ratio = _safe_div(large_net_delta, total_in_delta)
    large_net_total_ratio = _safe_div(large_net_delta, abs(total_net_delta))
    flow_start = latest_time - timedelta(minutes=window_minutes)
    flow_values = [_num(row.get("inflow")) for row in flows if flow_start <= row["_time"] <= latest_time]
    flow_sum = sum(flow_values)
    score, state, evidence = _score_state(
        large_net_delta=large_net_delta,
        total_net_delta=total_net_delta,
        small_net_delta=small_net_delta,
        large_participation_ratio=large_participation,
        large_net_inflow_ratio=large_net_inflow_ratio,
        flow_sum=flow_sum,
    )
    return {
        "symbol": symbol,
        "market": str(latest.get("market") or _market_from_symbol(symbol)).lower(),
        "feature_time": _dt_text(latest_time),
        "window_minutes": window_minutes,
        "start_time": _dt_text(baseline["_time"]),
        "end_time": _dt_text(latest.get("_time") or latest_time),
        "large_in_delta": _round(large_in_delta),
        "large_out_delta": _round(large_out_delta),
        "large_net_delta": _round(large_net_delta),
        "medium_net_delta": _round(medium_net_delta),
        "small_net_delta": _round(small_net_delta),
        "total_in_delta": _round(total_in_delta),
        "total_out_delta": _round(total_out_delta),
        "total_net_delta": _round(total_net_delta),
        "large_participation_ratio": _round(large_participation),
        "large_net_inflow_ratio": _round(large_net_inflow_ratio),
        "large_net_total_ratio": _round(large_net_total_ratio),
        "flow_sum": _round(flow_sum),
        "flow_points": len(flow_values),
        "main_force_score": _round(score),
        "main_force_state": state,
        "evidence": evidence,
    }


def _score_state(
    *,
    large_net_delta: float,
    total_net_delta: float,
    small_net_delta: float,
    large_participation_ratio: float | None,
    large_net_inflow_ratio: float | None,
    flow_sum: float,
) -> tuple[float, str, list[str]]:
    score = 50.0
    evidence: list[str] = []
    large_ratio = large_net_inflow_ratio or 0.0
    participation = large_participation_ratio or 0.0
    score += max(-30.0, min(30.0, large_ratio * 100.0))
    score += max(0.0, min(15.0, participation * 50.0))
    if total_net_delta > 0:
        score += 8.0
        evidence.append("total_net_inflow")
    elif total_net_delta < 0:
        score -= 8.0
        evidence.append("total_net_outflow")
    if flow_sum > 0:
        score += 5.0
        evidence.append("recent_flow_inflow")
    elif flow_sum < 0:
        score -= 5.0
        evidence.append("recent_flow_outflow")
    if large_net_delta > 0 and small_net_delta < 0:
        score += 5.0
        evidence.append("small_outflow_with_large_inflow")
    if large_net_delta < 0 and small_net_delta > 0:
        score -= 5.0
        evidence.append("small_inflow_with_large_outflow")

    score = max(0.0, min(100.0, score))
    if large_net_delta > 0 and total_net_delta > 0 and score >= 65.0:
        state = "accumulation"
    elif large_net_delta < 0 and total_net_delta < 0:
        state = "distribution"
    elif large_net_delta * total_net_delta < 0:
        state = "divergence"
    else:
        state = "neutral"
    return score, state, evidence


def _latest_at_or_before(rows: list[dict[str, Any]], point: datetime) -> dict[str, Any] | None:
    candidates = [row for row in rows if row["_time"] <= point]
    return candidates[-1] if candidates else None


def _first_at_or_after(rows: list[dict[str, Any]], point: datetime, *, before: datetime) -> dict[str, Any] | None:
    candidates = [row for row in rows if point <= row["_time"] < before]
    return candidates[0] if candidates else None


def _symbol(row: dict[str, Any]) -> str:
    return str(row.get("symbol") or "").strip().upper()


def _market_from_symbol(symbol: str) -> str:
    suffix = symbol.rsplit(".", 1)[-1].lower() if "." in symbol else ""
    return "cn" if suffix in {"sh", "sz"} else suffix


def _delta(latest: dict[str, Any], baseline: dict[str, Any], key: str) -> float:
    return _num(latest.get(key)) - _num(baseline.get(key))


def _safe_div(left: float, right: float) -> float | None:
    return None if right == 0 else left / right


def _num(value: Any) -> float:
    if value is None or value == "":
        return 0.0
    number = float(value)
    return number if isfinite(number) else 0.0


def _round(value: float | None, digits: int = 6) -> float | None:
    return None if value is None else round(float(value), digits)


def _dt(value: Any) -> datetime | None:
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value.replace(tzinfo=None)
    text = str(value).replace("T", " ").replace("+08:00", "")
    if "." in text:
        text = text.split(".", 1)[0]
    try:
        return datetime.fromisoformat(text)
    except ValueError:
        return None


def _dt_text(value: datetime) -> str:
    return value.isoformat(sep=" ")

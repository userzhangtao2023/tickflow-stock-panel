from __future__ import annotations

import importlib.util
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml

from longbridge_stock.config import DataConfig, ExperimentConfig


@dataclass(frozen=True)
class QlibWorkflowSpec:
    handler: str = "Alpha158"
    model: str = "LGBModel"
    strategy: str = "TopkDropoutStrategy"
    prediction_only: bool = False
    topk: int = 30
    n_drop: int = 5
    account: int = 100_000_000
    open_cost: float = 0.0005
    close_cost: float = 0.0015
    min_cost: float = 5
    deal_price: str = "close"
    limit_threshold: float = 0.095
    model_kwargs: dict[str, Any] | None = None


@dataclass(frozen=True)
class QlibCoreStep:
    key: str
    title: str
    component: str
    purpose: str
    output: str


@dataclass(frozen=True)
class QlibCapability:
    key: str
    title: str
    category: str
    component: str
    status: str
    purpose: str
    output: str
    next_action: str


@dataclass(frozen=True)
class RemoteQlibRun:
    run_id: str
    host: str
    remote_dir: str
    config_path: str
    log_path: str
    pid: str


@dataclass(frozen=True)
class RemoteQlibRunStatus:
    run_id: str
    host: str
    running: bool
    pid: str | None
    log_tail: str
    remote_dir: str


@dataclass(frozen=True)
class RemoteQlibRunSummary:
    run_id: str
    host: str
    running: bool
    pid: str | None
    remote_dir: str


@dataclass(frozen=True)
class QlibEnvironmentStatus:
    pyqlib_installed: bool
    lightgbm_installed: bool
    qrun_available: bool
    host: str = "local"

    @property
    def ready(self) -> bool:
        return self.pyqlib_installed and self.lightgbm_installed and self.qrun_available


def qlib_environment_status(remote_host: str | None = None, remote_user: str | None = None) -> QlibEnvironmentStatus:
    remote_host = remote_host or os.getenv("QLIB_REMOTE_HOST")
    remote_user = remote_user or os.getenv("QLIB_REMOTE_USER")
    if remote_host:
        return _remote_qlib_environment_status(remote_host, remote_user)
    pyqlib_installed = importlib.util.find_spec("qlib") is not None
    return QlibEnvironmentStatus(
        pyqlib_installed=pyqlib_installed,
        lightgbm_installed=importlib.util.find_spec("lightgbm") is not None,
        qrun_available=shutil.which("qrun") is not None or _python_qrun_available(pyqlib_installed),
    )


def qlib_core_steps() -> list[QlibCoreStep]:
    return [
        QlibCoreStep(
            "data",
            "数据标准化",
            "Qlib Provider",
            "把长桥行情整理为 calendars / instruments / features 的统一格式。",
            "所有模型和回测都从同一个稳定数据接口读取。",
        ),
        QlibCoreStep(
            "features",
            "因子工程",
            "Alpha158 / Alpha360",
            "批量生成价格、成交量、均线、波动、相关性等可训练特征。",
            "每日每只股票的一组特征矩阵。",
        ),
        QlibCoreStep(
            "dataset",
            "样本切分",
            "DatasetH",
            "按 train / valid / test 切分，避免训练过程使用未来数据。",
            "标准训练集、验证集、测试集。",
        ),
        QlibCoreStep(
            "model",
            "模型训练",
            "LGBModel",
            "让模型从历史特征中学习预测收益的非线性权重。",
            "每只股票每天的预测分数。",
        ),
        QlibCoreStep(
            "signal",
            "信号分析",
            "SignalRecord / SigAnaRecord",
            "记录预测信号，并计算 IC、Rank IC 等信号有效性指标。",
            "可复盘的预测信号和有效性报告。",
        ),
        QlibCoreStep(
            "portfolio",
            "组合回测",
            "TopkDropoutStrategy / PortAnaRecord",
            "用预测分数选 TopK、换仓、扣成本，并和基准比较。",
            "收益、回撤、换手、超额收益等组合表现。",
        ),
        QlibCoreStep(
            "records",
            "实验记录",
            "Qlib Recorder / MLflow",
            "把配置、模型、信号、回测产物沉淀为可对比实验记录。",
            "可追踪、可复跑、可横向比较的实验资产。",
        ),
    ]


def qlib_capability_registry() -> list[QlibCapability]:
    return [
        QlibCapability(
            "provider",
            "Qlib 数据 Provider",
            "data",
            "calendars / instruments / features",
            "ready",
            "把长桥行情永久数据转换为 Qlib 可复用的数据目录。",
            "统一的日频行情、交易日历和股票池。",
            "继续补齐 HK / US / CN 全市场日线质量检查。",
        ),
        QlibCapability(
            "alpha158",
            "Alpha158 标准特征",
            "feature",
            "qlib.contrib.data.handler.Alpha158",
            "ready",
            "生成 Qlib 最常用的 158 组价格、成交量、均线、波动等特征。",
            "模型训练特征矩阵。",
            "作为默认生产特征集接入模型批次。",
        ),
        QlibCapability(
            "alpha360",
            "Alpha360 标准特征",
            "feature",
            "qlib.contrib.data.handler.Alpha360",
            "ready",
            "生成更宽的历史窗口特征，适合做模型对照实验。",
            "更高维度的训练特征矩阵。",
            "用于和 Alpha158 做 IC、收益、回撤对比。",
        ),
        QlibCapability(
            "dataset_h",
            "DatasetH 样本切分",
            "dataset",
            "qlib.data.dataset.DatasetH",
            "ready",
            "按 train / valid / test 切分样本，降低未来函数风险。",
            "标准训练集、验证集、测试集。",
            "把不同市场的切分方案保存成模板。",
        ),
        QlibCapability(
            "lgb_model",
            "LightGBM 模型",
            "model",
            "qlib.contrib.model.gbdt.LGBModel",
            "ready",
            "训练非线性树模型，是当前最稳定的默认生产模型。",
            "每日每只股票的预测分。",
            "作为 HK / US / CN 默认模型批次。",
        ),
        QlibCapability(
            "linear_model",
            "线性模型",
            "model",
            "qlib.contrib.model.linear.LinearModel",
            "ready",
            "作为低复杂度对照组，判断复杂模型是否真的带来增益。",
            "线性预测分和基准模型表现。",
            "纳入模型排行榜。",
        ),
        QlibCapability(
            "signal_record",
            "预测信号记录",
            "record",
            "SignalRecord",
            "ready",
            "保存模型预测结果，供回测、解释和线上评分复用。",
            "pred.pkl / signal record。",
            "把最新 pred 写回 stock_scores.model_score。",
        ),
        QlibCapability(
            "signal_analysis",
            "信号有效性分析",
            "analysis",
            "SigAnaRecord",
            "ready",
            "计算 IC、Rank IC、Long/Short 等预测有效性指标。",
            "信号分析报告。",
            "接入因子分析和模型训练页面。",
        ),
        QlibCapability(
            "portfolio_analysis",
            "组合回测分析",
            "backtest",
            "PortAnaRecord",
            "ready",
            "把模型信号转成组合，计算收益、回撤、换手和风险。",
            "portfolio analysis report。",
            "接入策略回测页面。",
        ),
        QlibCapability(
            "multi_pass_portfolio_analysis",
            "多轮组合分析",
            "backtest",
            "MultiPassPortAnaRecord",
            "ready",
            "对多个回测配置或交易假设做批量组合分析。",
            "多组回测对照结果。",
            "用于参数敏感性实验。",
        ),
        QlibCapability(
            "topk_dropout",
            "TopK Dropout 策略",
            "strategy",
            "TopkDropoutStrategy",
            "ready",
            "每期保留高分股票并换出低分持仓，控制换手。",
            "可执行持仓组合。",
            "作为默认组合策略。",
        ),
        QlibCapability(
            "soft_topk",
            "Soft TopK 策略",
            "strategy",
            "SoftTopkStrategy",
            "ready",
            "用更平滑的权重方式构建组合，降低边界股票跳进跳出。",
            "更平滑的组合持仓。",
            "作为组合模拟对照策略。",
        ),
        QlibCapability(
            "online_prediction",
            "在线预测",
            "production",
            "prediction-only qrun",
            "ready",
            "跳过组合回测，只生成最新预测并写回评分表。",
            "最新 model_score。",
            "接入每日/每周自动刷新任务。",
        ),
        QlibCapability(
            "reinforcement_learning",
            "强化学习交易",
            "advanced",
            "Qlib RL",
            "planned",
            "建模连续交易决策，适合更复杂的执行和调仓问题。",
            "RL 策略训练与模拟结果。",
            "先完成监督学习和回测闭环，再接入 RL。",
        ),
        QlibCapability(
            "rd_agent",
            "RD-Agent 自动研究",
            "advanced",
            "Qlib + RD-Agent",
            "planned",
            "让 AI 自动生成因子、改模型、跑实验并总结结果。",
            "自动研究任务和实验建议。",
            "接入现有 LLM 配置后作为研究助手。",
        ),
    ]


def build_qlib_workflow_config(
    data_config: DataConfig,
    experiment: ExperimentConfig,
    spec: QlibWorkflowSpec | None = None,
) -> dict[str, Any]:
    spec = spec or QlibWorkflowSpec(topk=experiment.backtest.top_k, close_cost=experiment.backtest.cost_rate)
    train_start = experiment.train_start_time or experiment.start_time
    train_end = experiment.train_end_time or experiment.end_time
    valid_start = experiment.valid_start_time or train_start
    valid_end = experiment.valid_end_time or train_end
    test_start = experiment.test_start_time or valid_start
    test_end = experiment.test_end_time or experiment.end_time

    data_handler_config = {
        "start_time": experiment.start_time,
        "end_time": experiment.end_time,
        "fit_start_time": train_start,
        "fit_end_time": train_end,
        "instruments": data_config.market,
    }
    config: dict[str, Any] = {
        "qlib_init": {
            "provider_uri": _posix_path(data_config.provider_uri),
            "region": data_config.region,
        },
        "market": data_config.market,
        "benchmark": data_config.benchmark,
        "data_handler_config": data_handler_config,
        "task": {
            "model": _model_config(spec.model, spec.model_kwargs),
            "dataset": {
                "class": "DatasetH",
                "module_path": "qlib.data.dataset",
                "kwargs": {
                    "handler": {
                        "class": spec.handler,
                        "module_path": "qlib.contrib.data.handler",
                        "kwargs": data_handler_config,
                    },
                    "segments": {
                        "train": [train_start, train_end],
                        "valid": [valid_start, valid_end],
                        "test": [test_start, test_end],
                    },
                },
            },
            "record": [
                {
                    "class": "SignalRecord",
                    "module_path": "qlib.workflow.record_temp",
                    "kwargs": {"model": "<MODEL>", "dataset": "<DATASET>"},
                },
                {
                    "class": "SigAnaRecord",
                    "module_path": "qlib.workflow.record_temp",
                    "kwargs": {"ana_long_short": False, "ann_scaler": 252},
                },
            ],
        },
    }
    if not spec.prediction_only:
        port_analysis_config = {
            "strategy": {
                "class": spec.strategy,
                "module_path": "qlib.contrib.strategy",
                "kwargs": _strategy_kwargs(spec),
            },
            "backtest": {
                "start_time": test_start,
                "end_time": test_end,
                "account": spec.account,
                "benchmark": data_config.benchmark,
                "exchange_kwargs": {
                    "limit_threshold": spec.limit_threshold,
                    "deal_price": spec.deal_price,
                    "open_cost": spec.open_cost,
                    "close_cost": spec.close_cost,
                    "min_cost": spec.min_cost,
                },
            },
        }
        config["port_analysis_config"] = port_analysis_config
        config["task"]["record"].append(
            {
                "class": "PortAnaRecord",
                "module_path": "qlib.workflow.record_temp",
                "kwargs": {"config": port_analysis_config},
            }
        )
    return config


def save_qlib_workflow_config(
    output_path: str | Path,
    data_config: DataConfig,
    experiment: ExperimentConfig,
    spec: QlibWorkflowSpec | None = None,
) -> Path:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    config = build_qlib_workflow_config(data_config, experiment, spec)
    output_path.write_text(yaml.dump(config, Dumper=_NoAliasDumper, allow_unicode=True, sort_keys=False), encoding="utf-8")
    return output_path


def run_qrun(config_path: str | Path, cwd: str | Path | None = None) -> subprocess.CompletedProcess[str]:
    status = qlib_environment_status()
    if not status.ready:
        missing = []
        if not status.pyqlib_installed:
            missing.append("pyqlib")
        if not status.lightgbm_installed:
            missing.append("lightgbm")
        if not status.qrun_available:
            missing.append("qrun")
        raise RuntimeError(f"Qlib native workflow is not ready. Missing: {', '.join(missing)}")
    return subprocess.run(
        [sys.executable, "-m", "qlib.cli.run", str(config_path)],
        cwd=str(cwd) if cwd else None,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
    )


def start_remote_qrun(
    config_path: str | Path,
    remote_host: str | None = None,
    remote_user: str | None = None,
    remote_root: str = "/home/alwin/data/longbridge/qlib_runs",
    experiment_name: str | None = None,
) -> RemoteQlibRun:
    remote_host = remote_host or os.getenv("QLIB_REMOTE_HOST")
    remote_user = remote_user or os.getenv("QLIB_REMOTE_USER")
    if not remote_host:
        raise RuntimeError("QLIB_REMOTE_HOST is required to run Qlib remotely.")
    target = f"{remote_user}@{remote_host}" if remote_user else remote_host
    local_config = Path(config_path)
    if not local_config.exists():
        raise FileNotFoundError(f"Qlib config does not exist: {local_config}")

    run_id = experiment_name or f"qlib_alpha158_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    remote_dir = f"{remote_root.rstrip('/')}/{run_id}"
    remote_config = f"{remote_dir}/workflow.yaml"
    remote_log = f"{remote_dir}/qrun.log"
    _checked_run(["ssh", target, f"mkdir -p {remote_dir!r}"])
    _checked_run(["scp", str(local_config), f"{target}:{remote_config}"])
    command = (
        f"cd {remote_dir!r} && "
        f"nohup /home/alwin/apps/longbridge-stock/.venv/bin/python -m qlib.cli.run {remote_config!r} "
        f"--experiment_name {run_id!r} --uri_folder {remote_dir + '/mlruns'!r} "
        f"> {remote_log!r} 2>&1 < /dev/null & echo $! > {remote_dir + '/qrun.pid'!r}; "
        f"cat {remote_dir + '/qrun.pid'!r}"
    )
    result = _checked_run(["ssh", target, command])
    return RemoteQlibRun(
        run_id=run_id,
        host=target,
        remote_dir=remote_dir,
        config_path=remote_config,
        log_path=remote_log,
        pid=result.stdout.strip().splitlines()[-1],
    )


def start_local_qrun(
    config_path: str | Path,
    local_root: str | Path = "/home/alwin/data/longbridge/qlib_runs",
    experiment_name: str | None = None,
) -> RemoteQlibRun:
    local_config = Path(config_path)
    if not local_config.exists():
        raise FileNotFoundError(f"Qlib config does not exist: {local_config}")

    run_id = experiment_name or f"qlib_alpha158_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    run_dir = Path(local_root) / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    run_config = run_dir / "workflow.yaml"
    run_log = run_dir / "qrun.log"
    run_pid = run_dir / "qrun.pid"
    shutil.copyfile(local_config, run_config)

    with run_log.open("ab") as log_file:
        process = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "qlib.cli.run",
                str(run_config),
                "--experiment_name",
                run_id,
                "--uri_folder",
                str(run_dir / "mlruns"),
            ],
            cwd=str(run_dir),
            stdout=log_file,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
    run_pid.write_text(str(process.pid), encoding="utf-8")
    return RemoteQlibRun(
        run_id=run_id,
        host="local",
        remote_dir=str(run_dir),
        config_path=str(run_config),
        log_path=str(run_log),
        pid=str(process.pid),
    )


def remote_qrun_status(
    run_id: str,
    remote_host: str | None = None,
    remote_user: str | None = None,
    remote_root: str = "/home/alwin/data/longbridge/qlib_runs",
) -> RemoteQlibRunStatus:
    remote_host = remote_host or os.getenv("QLIB_REMOTE_HOST")
    remote_user = remote_user or os.getenv("QLIB_REMOTE_USER")
    if not remote_host:
        raise RuntimeError("QLIB_REMOTE_HOST is required to read Qlib remote status.")
    target = f"{remote_user}@{remote_host}" if remote_user else remote_host
    remote_dir = f"{remote_root.rstrip('/')}/{run_id}"
    probe = (
        f"pid=$(cat {remote_dir + '/qrun.pid'!r} 2>/dev/null || true); "
        "running=0; "
        "if [ -n \"$pid\" ] && kill -0 \"$pid\" 2>/dev/null; then running=1; fi; "
        "echo \"PID:$pid\"; echo \"RUNNING:$running\"; echo \"---LOG---\"; "
        f"tail -80 {remote_dir + '/qrun.log'!r} 2>/dev/null || true"
    )
    result = _checked_run(["ssh", target, probe])
    lines = result.stdout.splitlines()
    pid = next((line.removeprefix("PID:") for line in lines if line.startswith("PID:")), "") or None
    running = next((line.removeprefix("RUNNING:") for line in lines if line.startswith("RUNNING:")), "0") == "1"
    log_index = lines.index("---LOG---") + 1 if "---LOG---" in lines else len(lines)
    return RemoteQlibRunStatus(
        run_id=run_id,
        host=target,
        running=running,
        pid=pid,
        log_tail="\n".join(lines[log_index:]),
        remote_dir=remote_dir,
    )


def list_remote_qrun_runs(
    remote_host: str | None = None,
    remote_user: str | None = None,
    remote_root: str = "/home/alwin/data/longbridge/qlib_runs",
    limit: int = 20,
) -> list[RemoteQlibRunSummary]:
    remote_host = remote_host or os.getenv("QLIB_REMOTE_HOST")
    remote_user = remote_user or os.getenv("QLIB_REMOTE_USER")
    if not remote_host:
        raise RuntimeError("QLIB_REMOTE_HOST is required to list Qlib remote runs.")
    target = f"{remote_user}@{remote_host}" if remote_user else remote_host
    probe = (
        f"root={remote_root!r}; "
        "[ -d \"$root\" ] || exit 0; "
        f"find \"$root\" -mindepth 1 -maxdepth 1 -type d -printf '%T@ %f %p\\n' | sort -nr | head -n {int(limit)} | "
        "while read ts name dir; do "
        "pid=$(cat \"$dir/qrun.pid\" 2>/dev/null || true); "
        "running=0; "
        "if [ -n \"$pid\" ] && kill -0 \"$pid\" 2>/dev/null; then running=1; fi; "
        "printf '%s\\t%s\\t%s\\t%s\\n' \"$name\" \"$running\" \"$pid\" \"$dir\"; "
        "done"
    )
    result = _checked_run(["ssh", target, probe])
    summaries: list[RemoteQlibRunSummary] = []
    for line in result.stdout.splitlines():
        parts = line.split("\t")
        if len(parts) != 4:
            continue
        run_id, running, pid, remote_dir = parts
        summaries.append(
            RemoteQlibRunSummary(
                run_id=run_id,
                host=target,
                running=running == "1",
                pid=pid or None,
                remote_dir=remote_dir,
            )
        )
    return summaries


def _remote_qlib_environment_status(remote_host: str, remote_user: str | None = None) -> QlibEnvironmentStatus:
    target = f"{remote_user}@{remote_host}" if remote_user else remote_host
    python_bin = os.getenv("QLIB_REMOTE_PYTHON", "/home/alwin/apps/longbridge-stock/.venv/bin/python")
    probe = (
        f"{python_bin} - <<'PY'\n"
        "import importlib.util, subprocess, sys\n"
        "pyqlib = importlib.util.find_spec('qlib') is not None\n"
        "lightgbm = importlib.util.find_spec('lightgbm') is not None\n"
        "qrun = subprocess.run([sys.executable, '-m', 'qlib.cli.run', '--help'], "
        "stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0 if pyqlib else False\n"
        "print(f'{int(pyqlib)} {int(lightgbm)} {int(qrun)}')\n"
        "PY"
    )
    try:
        result = subprocess.run(
            ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=8", target, probe],
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=20,
        )
    except (OSError, subprocess.TimeoutExpired):
        return QlibEnvironmentStatus(False, False, False, host=target)
    if result.returncode != 0:
        return QlibEnvironmentStatus(False, False, False, host=target)
    parts = result.stdout.strip().split()
    if len(parts) < 3:
        return QlibEnvironmentStatus(False, False, False, host=target)
    return QlibEnvironmentStatus(parts[0] == "1", parts[1] == "1", parts[2] == "1", host=target)


def _checked_run(command: list[str]) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(command, check=False, capture_output=True, text=True, encoding="utf-8", timeout=120)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or result.stdout.strip() or f"Command failed: {' '.join(command)}")
    return result


def _python_qrun_available(pyqlib_installed: bool) -> bool:
    if not pyqlib_installed:
        return False
    try:
        return (
            subprocess.run(
                [sys.executable, "-m", "qlib.cli.run", "--help"],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=20,
            ).returncode
            == 0
        )
    except (OSError, subprocess.TimeoutExpired):
        return False


def _model_config(model: str, model_kwargs: dict[str, Any] | None = None) -> dict[str, Any]:
    model_kwargs = model_kwargs or {}
    if model == "XGBModel":
        kwargs = {
            "objective": "reg:squarederror",
            "eval_metric": "rmse",
            "eta": 0.05,
            "max_depth": 6,
            "subsample": 0.8,
            "colsample_bytree": 0.8,
            "nthread": 8,
        }
        kwargs.update(model_kwargs)
        return {
            "class": "XGBModel",
            "module_path": "qlib.contrib.model.xgboost",
            "kwargs": kwargs,
        }
    if model == "CatBoostModel":
        kwargs = {
            "loss": "RMSE",
            "learning_rate": 0.05,
            "depth": 6,
            "thread_count": 8,
        }
        kwargs.update(model_kwargs)
        return {
            "class": "CatBoostModel",
            "module_path": "qlib.contrib.model.catboost_model",
            "kwargs": kwargs,
        }
    if model == "LinearModel":
        kwargs = {"estimator": "ridge", "alpha": 100.0}
        kwargs.update(model_kwargs)
        return {
            "class": "LinearModel",
            "module_path": "qlib.contrib.model.linear",
            "kwargs": kwargs,
        }
    if model != "LGBModel":
        raise ValueError(f"Unsupported Qlib model: {model}")
    kwargs = {
        "loss": "mse",
        "colsample_bytree": 0.8879,
        "learning_rate": 0.2,
        "subsample": 0.8789,
        "lambda_l1": 205.6999,
        "lambda_l2": 580.9768,
        "max_depth": 8,
        "num_leaves": 210,
        "num_threads": 20,
    }
    kwargs.update(model_kwargs)
    return {
        "class": "LGBModel",
        "module_path": "qlib.contrib.model.gbdt",
        "kwargs": kwargs,
    }


def _strategy_kwargs(spec: QlibWorkflowSpec) -> dict[str, Any]:
    if spec.strategy == "TopkDropoutStrategy":
        return {"signal": "<PRED>", "topk": spec.topk, "n_drop": spec.n_drop}
    if spec.strategy == "SoftTopkStrategy":
        return {"signal": "<PRED>", "topk": spec.topk}
    raise ValueError(f"Unsupported Qlib strategy: {spec.strategy}")


def _posix_path(path: Path) -> str:
    return path.as_posix()


class _NoAliasDumper(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True

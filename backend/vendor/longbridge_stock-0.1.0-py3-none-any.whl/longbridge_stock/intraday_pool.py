from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from longbridge_stock.capital_pattern import capital_pattern_text
from longbridge_stock.quant_regime import quant_regime_text
from longbridge_stock.symbol_filters import is_etf_like_symbol


@dataclass(frozen=True)
class TradePlan:
    zone_low: float
    zone_high: float
    confirm_price: float
    risk_line: float


@dataclass(frozen=True)
class IntradayCandidate:
    symbol: str
    name: str
    last: float
    change_pct: float
    open: float
    high: float
    low: float
    turnover: float
    turnover_ratio20: float
    close_pos: float
    upside_probability: float | None
    expected_return_5d: float | None
    breakout_score: float | None
    large_net: float | None
    total_net: float | None
    flow_30m: float | None
    news_score: float = 0.0
    news_titles: list[str] | None = None
    decision: str | None = None
    risk_score: float | None = None


@dataclass(frozen=True)
class RankedCandidate:
    symbol: str
    name: str
    score: float
    reason: str
    plan: TradePlan
    source: IntradayCandidate


@dataclass(frozen=True)
class PoolEntry:
    run_time: datetime
    rank: int
    symbol: str
    name: str
    score: float
    reason: str
    last: float
    change_pct: float
    high: float
    low: float
    total_net: float | None
    large_net: float | None
    zone_low: float
    zone_high: float
    confirm_price: float
    risk_line: float
    status: str
    market: str = "hk"
    profit_probability: float | None = None
    is_holding: bool = False
    decision: str | None = None
    risk_score: float | None = None
    output_stage: str | None = None
    observation_only: bool = False
    shape: dict[str, Any] | None = None
    quant_regime: dict[str, Any] | None = None
    shape_adjustment: dict[str, Any] | None = None
    quant_regime_adjustment: dict[str, Any] | None = None
    capital_pattern: dict[str, Any] | None = None


@dataclass(frozen=True)
class BuyTrigger:
    event_type: str
    message: str
    status: str


@dataclass(frozen=True)
class CandidateFilterConfig:
    min_turnover: float = 1_000_000.0
    min_total_net: float | None = None
    min_large_net: float | None = None
    min_flow_30m: float | None = None
    min_close_pos: float | None = None
    max_close_pos: float | None = None
    max_change_pct: float | None = None
    block_double_outflow: bool = True
    block_overextended: bool = True
    block_failed_spike: bool = True


DEFAULT_FILTER_CONFIG = CandidateFilterConfig()
DEFAULT_TAKE_PROFIT_PCT = 0.02
DEFAULT_STOP_LOSS_PCT = 0.025
DEFAULT_MIN_BUY_PROBABILITY = 0.70
DEFAULT_OBSERVATION_MIN_PROBABILITY = 0.55
DEFAULT_MAX_ACTION_CHANGE_PCT = 9.0
DEFAULT_MAX_ACTION_RISK_SCORE = 80.0


def min_buy_probability() -> float:
    raw = os.getenv("TOP3_MIN_BUY_PROBABILITY")
    if not raw:
        return DEFAULT_MIN_BUY_PROBABILITY
    try:
        value = float(raw)
    except ValueError:
        return DEFAULT_MIN_BUY_PROBABILITY
    if value > 1:
        value = value / 100
    return max(0.0, min(1.0, value))


def observation_min_probability() -> float:
    raw = os.getenv("TOP3_OBSERVATION_MIN_PROBABILITY")
    if not raw:
        return DEFAULT_OBSERVATION_MIN_PROBABILITY
    try:
        value = float(raw)
    except ValueError:
        return DEFAULT_OBSERVATION_MIN_PROBABILITY
    if value > 1:
        value = value / 100
    return max(0.0, min(1.0, value))


def max_action_change_pct() -> float:
    return _float_env("TOP3_MAX_ACTION_CHANGE_PCT", DEFAULT_MAX_ACTION_CHANGE_PCT)


def max_action_risk_score() -> float:
    return _float_env("TOP3_MAX_ACTION_RISK_SCORE", DEFAULT_MAX_ACTION_RISK_SCORE)


def _float_env(name: str, default: float) -> float:
    raw = os.getenv(name)
    if not raw:
        return default
    try:
        return float(raw)
    except ValueError:
        return default


def is_actionable_model_signal(
    *,
    decision: str | None,
    risk_score: float | None,
    change_pct: float,
) -> bool:
    if str(decision or "").strip().lower() == "avoid":
        return False
    if risk_score is not None and risk_score >= max_action_risk_score():
        return False
    if change_pct > max_action_change_pct():
        return False
    return True


def rank_intraday_candidates(
    candidates: list[IntradayCandidate],
    *,
    limit: int = 3,
    filter_config: CandidateFilterConfig | None = None,
) -> list[RankedCandidate]:
    ranked: list[RankedCandidate] = []
    config = filter_config or DEFAULT_FILTER_CONFIG
    for candidate in candidates:
        if should_filter_candidate(candidate, config=config):
            continue
        score = score_intraday_candidate(candidate)
        ranked.append(
            RankedCandidate(
                symbol=candidate.symbol,
                name=candidate.name,
                score=score,
                reason=reason_text(candidate),
                plan=build_trade_plan(candidate),
                source=candidate,
            )
        )
    return sorted(ranked, key=lambda item: item.score, reverse=True)[: max(1, limit)]


def should_filter_candidate(candidate: IntradayCandidate, *, config: CandidateFilterConfig | None = None) -> bool:
    config = config or DEFAULT_FILTER_CONFIG
    if is_etf_like_symbol(candidate.symbol, candidate.name):
        return True
    if candidate.last <= 0 or candidate.turnover < config.min_turnover:
        return True
    if config.min_total_net is not None and (candidate.total_net or 0) < config.min_total_net:
        return True
    if config.min_large_net is not None and (candidate.large_net or 0) < config.min_large_net:
        return True
    if config.min_flow_30m is not None and (candidate.flow_30m or 0) < config.min_flow_30m:
        return True
    if config.min_close_pos is not None and candidate.close_pos < config.min_close_pos:
        return True
    if config.max_close_pos is not None and candidate.close_pos > config.max_close_pos:
        return True
    if config.max_change_pct is not None and candidate.change_pct > config.max_change_pct:
        return True
    if config.block_double_outflow and (candidate.total_net or 0) < 0 and (candidate.large_net or 0) < 0:
        return True
    if config.block_overextended and candidate.change_pct >= 10 and candidate.close_pos >= 0.85:
        return True
    if config.block_failed_spike and candidate.high > 0 and candidate.last > 0 and candidate.high / candidate.last > 1.08 and candidate.close_pos < 0.35:
        return True
    return False


def score_intraday_candidate(candidate: IntradayCandidate) -> float:
    score = 0.0
    probability = candidate.upside_probability if candidate.upside_probability is not None else 0.52
    score += probability * 35
    if candidate.expected_return_5d is not None:
        score += clamp(candidate.expected_return_5d * 180, -8, 12)
    if candidate.breakout_score is not None:
        score += candidate.breakout_score * 0.22
    score += clamp(candidate.change_pct * 0.9, -8, 9)
    score += clamp((candidate.turnover_ratio20 - 1.0) * 5, -3, 10)
    score += clamp((candidate.close_pos - 0.5) * 12, -6, 6)
    score += clamp((candidate.total_net or 0) / 250_000, -8, 12)
    score += clamp((candidate.large_net or 0) / 200_000, -8, 10)
    score += clamp((candidate.flow_30m or 0) / 200_000, -6, 8)
    score += candidate.news_score * 2
    if candidate.change_pct > 7:
        score -= (candidate.change_pct - 7) * 2.5
    return round(score, 2)


def build_trade_plan(candidate: IntradayCandidate) -> TradePlan:
    zone_low = max(candidate.low, candidate.last * 0.98)
    zone_high = min(candidate.last * 1.01, max(candidate.open, candidate.last) * 1.01)
    confirm_price = max(candidate.high * 1.002, candidate.last * 1.015)
    risk_line = max(candidate.low * 0.99, candidate.last * (1 - DEFAULT_STOP_LOSS_PCT))
    return TradePlan(
        zone_low=round(min(zone_low, zone_high), 3),
        zone_high=round(max(zone_low, zone_high), 3),
        confirm_price=round(confirm_price, 3),
        risk_line=round(risk_line, 3),
    )


def sector_context_line(quote: dict[str, Any]) -> str:
    industry = str(quote.get("industry") or "").strip()
    if not industry:
        return "行业联动：缺少行业信息"
    change_pct = to_optional_float(quote.get("industry_change_pct"))
    up_ratio = to_optional_float(quote.get("industry_up_ratio"))
    sample_count = quote.get("industry_sample_count")
    linkage = str(quote.get("industry_linkage") or "unknown")
    change_text = "-" if change_pct is None else f"{change_pct:+.2f}%"
    up_text = "-" if up_ratio is None else f"{up_ratio * 100:.0f}%"
    count_text = "-" if sample_count is None else str(sample_count)
    return f"行业联动：{linkage_text(linkage)}；{industry}，平均涨跌 {change_text}，上涨占比 {up_text}，样本 {count_text} 只"


def build_buy_trigger(entry: PoolEntry, quote: dict[str, Any]) -> BuyTrigger | None:
    last = to_float(quote.get("last"))
    if last <= 0:
        return None
    change_pct = to_float(quote.get("change_pct"))
    high = to_float(quote.get("high"))
    low = to_float(quote.get("low"))
    total_net = to_optional_float(quote.get("total_net"))
    large_net = to_optional_float(quote.get("large_net"))
    probability_text = entry_probability_text(entry)
    sector_line = sector_context_line(quote)
    pattern_line = pattern_context_line(quote)
    detail = (
        f"现价 {last:.3f}，涨跌 {change_pct:+.2f}%，日低 {low:.3f}，日高 {high:.3f}\n"
        f"资金净流入 {money_10k(total_net)}，大单净流入 {money_10k(large_net)}"
    )
    if last <= entry.risk_line:
        if not entry.is_holding:
            return None
        return BuyTrigger(
            "risk",
            "\n".join(
                [
                    f"【盘中买点监控｜风险线】{entry.symbol} {entry.name}",
                    detail,
                    sector_line,
                    f"模型获利概率：{probability_text}",
                    f"跌破风险线 {entry.risk_line:g}，先放弃，不接飞刀。",
                    f"理由：价格破位，等重新站回 {entry.zone_low:g} 再观察。",
                ]
            ),
            "risk",
        )
    if (total_net or 0) < 0 and (large_net or 0) < 0 and last < entry.zone_low:
        return BuyTrigger(
            "weak",
            "\n".join(
                [
                    f"【盘中买点监控｜资金转弱】{entry.symbol} {entry.name}",
                    detail,
                    sector_line,
                    f"模型获利概率：{probability_text}",
                    f"跌出计划低吸区 {entry.zone_low:g}-{entry.zone_high:g}，且资金转流出，暂不参与。",
                    f"风险线 {entry.risk_line:g}。",
                    "理由：价格和资金同时转弱。",
                ]
            ),
            "weak",
        )
    has_positive_funds = (total_net or 0) > 0 or (large_net or 0) > 0
    if has_positive_funds and entry.zone_low <= last <= entry.zone_high:
        return BuyTrigger(
            "buy_zone",
            "\n".join(
                [
                    f"【盘中买点监控｜低吸区】{entry.symbol} {entry.name}",
                    detail,
                    sector_line,
                    f"模型获利概率：{probability_text}",
                    f"进入计划低吸区 {entry.zone_low:g}-{entry.zone_high:g}，若盘口承接不破可小仓试。",
                    f"确认价 {entry.confirm_price:g}，风险线 {entry.risk_line:g}。",
                    "理由：回踩低吸区，资金仍有承接。",
                ]
            ),
            "buy_zone",
        )
    if has_positive_funds and last >= entry.confirm_price:
        return BuyTrigger(
            "breakout",
            "\n".join(
                [
                    f"【盘中买点监控｜突破确认】{entry.symbol} {entry.name}",
                    detail,
                    sector_line,
                    f"模型获利概率：{probability_text}",
                    f"现价站上确认价 {entry.confirm_price:g}，可按突破跟随，避免一次性满仓。",
                    f"低吸区 {entry.zone_low:g}-{entry.zone_high:g}，风险线 {entry.risk_line:g}。",
                    "理由：价格突破且资金维持流入。",
                ]
            ),
            "breakout",
        )
    return None

def reason_text(candidate: IntradayCandidate) -> str:
    parts: list[str] = []
    if str(candidate.decision or "").strip().lower() == "rule_fallback":
        parts.append("规则兜底候选")
    elif candidate.upside_probability is not None:
        parts.append(f"模型上涨概率 {candidate.upside_probability * 100:.1f}%")
    if (candidate.total_net or 0) > 0:
        parts.append("资金净流入")
    if (candidate.large_net or 0) > 0:
        parts.append("大单流入")
    if candidate.breakout_score is not None and candidate.breakout_score >= 70:
        parts.append("放量突破分高")
    if candidate.flow_30m and candidate.flow_30m > 0:
        parts.append("30分钟资金流入")
    if candidate.news_score > 0:
        parts.append("新闻偏正")
    return "，".join(parts) if parts else "量价和资金综合靠前"


def format_model_probability(value: float | None) -> str:
    return "缺失" if value is None else f"{value * 100:.1f}%"


def sector_context_line(quote: dict[str, Any]) -> str:
    industry = str(quote.get("industry") or "").strip()
    if not industry:
        return "行业联动：缺少行业信息"
    change_pct = to_optional_float(quote.get("industry_change_pct"))
    up_ratio = to_optional_float(quote.get("industry_up_ratio"))
    sample_count = quote.get("industry_sample_count")
    linkage = str(quote.get("industry_linkage") or "unknown")
    change_text = "-" if change_pct is None else f"{change_pct:+.2f}%"
    up_text = "-" if up_ratio is None else f"{up_ratio * 100:.0f}%"
    count_text = "-" if sample_count is None else str(sample_count)
    return f"行业联动：{linkage_text(linkage)}；{industry}，平均涨跌 {change_text}，上涨占比 {up_text}，样本 {count_text} 只"


def linkage_text(value: str) -> str:
    mapping = {
        "sector_up_linkage": "行业整体上涨联动",
        "sector_down_linkage": "行业整体下跌联动",
        "mild_sector_support": "行业有一定支撑",
        "stock_specific_or_mixed": "偏个股异动，行业联动不明显",
        "missing_quotes": "缺少行业实时行情",
        "missing_peers": "缺少同行样本",
        "insufficient_samples": "同行样本不足",
    }
    return mapping.get(value, "暂无法判断")


def build_buy_trigger(entry: PoolEntry, quote: dict[str, Any]) -> BuyTrigger | None:
    last = to_float(quote.get("last"))
    if last <= 0:
        return None
    change_pct = to_float(quote.get("change_pct"))
    high = to_float(quote.get("high"))
    low = to_float(quote.get("low"))
    total_net = to_optional_float(quote.get("total_net"))
    large_net = to_optional_float(quote.get("large_net"))
    probability_text = entry_probability_text(entry)
    sector_line = sector_context_line(quote)
    price_line = f"现价：{last:.3f}（{change_pct:+.2f}%）  日内：{low:.3f}-{high:.3f}"
    plan_line = f"买点区间：{entry.zone_low:g}-{entry.zone_high:g}"
    control_line = f"确认价：{entry.confirm_price:g}  风险线：{entry.risk_line:g}"
    funds_line = f"资金：净流入 {money_10k(total_net)}，大单 {money_10k(large_net)}"

    if last <= entry.risk_line:
        if not entry.is_holding:
            return None
        return BuyTrigger(
            "risk",
            "\n".join(
                [
                    f"【风险线触发】{entry.symbol} {entry.name}",
                    "结论：跌破风险线，先放弃，不接飞刀。",
                    control_line,
                    price_line,
                    funds_line,
                    sector_line,
                    f"模型获利概率：{probability_text}",
                    f"理由：价格破位，等重新站回 {entry.zone_low:g} 再观察。",
                ]
            ),
            "risk",
        )

    if (total_net or 0) < 0 and (large_net or 0) < 0 and last < entry.zone_low:
        return BuyTrigger(
            "weak",
            "\n".join(
                [
                    f"【资金转弱】{entry.symbol} {entry.name}",
                    "结论：跌出买点区间且资金转弱，暂不参与。",
                    plan_line,
                    control_line,
                    price_line,
                    funds_line,
                    sector_line,
                    f"模型获利概率：{probability_text}",
                    "理由：价格和资金同时转弱。",
                ]
            ),
            "weak",
        )

    if entry.is_holding:
        return None

    has_positive_funds = (total_net or 0) > 0 or (large_net or 0) > 0
    if has_positive_funds and entry.zone_low <= last <= entry.zone_high:
        return BuyTrigger(
            "buy_zone",
            "\n".join(
                [
                    f"【低吸买点】{entry.symbol} {entry.name}",
                    f"重点：{plan_line}",
                    "动作：区间内小仓试；跌破风险线立即放弃。",
                    control_line,
                    price_line,
                    funds_line,
                    sector_line,
                    f"模型获利概率：{probability_text}",
                    "理由：回踩买点区间，资金仍有承接。",
                ]
            ),
            "buy_zone",
        )

    if has_positive_funds and last >= entry.confirm_price:
        return BuyTrigger(
            "breakout",
            "\n".join(
                [
                    f"【突破确认】{entry.symbol} {entry.name}",
                    f"重点：已站上确认价 {entry.confirm_price:g}",
                    "动作：可按突破跟随，避免一次性满仓。",
                    plan_line,
                    control_line,
                    price_line,
                    funds_line,
                    sector_line,
                    f"模型获利概率：{probability_text}",
                    "理由：价格突破且资金保持流入。",
                ]
            ),
            "breakout",
        )
    return None


def money_10k(value: Any) -> str:
    number = to_optional_float(value)
    if number is None:
        return "-"
    amount = number / 10_000
    sign = "+" if amount > 0 else ""
    return f"{sign}{amount:.0f}万"


def build_buy_trigger(entry: PoolEntry, quote: dict[str, Any]) -> BuyTrigger | None:
    last = to_float(quote.get("last"))
    if last <= 0:
        return None
    change_pct = to_float(quote.get("change_pct"))
    high = to_float(quote.get("high"))
    low = to_float(quote.get("low"))
    total_net = to_optional_float(quote.get("total_net"))
    large_net = to_optional_float(quote.get("large_net"))
    probability_text = entry_probability_text(entry)
    sector_line = sector_context_line(quote)
    price_line = f"现价：{last:.3f}（{change_pct:+.2f}%）  日内：{low:.3f}-{high:.3f}"
    buy_line = f"买点区间：{entry.zone_low:g}-{entry.zone_high:g}"
    control_line = f"确认价：{entry.confirm_price:g}  风险线：{entry.risk_line:g}"
    funds_line = f"资金：净流入 {money_10k(total_net)}，大单 {money_10k(large_net)}"

    if last <= entry.risk_line:
        if not entry.is_holding:
            return None
        return BuyTrigger(
            "risk",
            "\n".join(
                [
                    f"【卖出避险】{entry.symbol} {entry.name}",
                    f"价位：已跌破风险线 {entry.risk_line:g}",
                    "风险状态：跌破风控位，按卖出避险处理。",
                    price_line,
                    funds_line,
                    sector_line,
                    f"观察：重新站回 {entry.zone_low:g} 以上再看。",
                ]
            ),
            "risk",
        )

    if (total_net or 0) < 0 and (large_net or 0) < 0 and last < entry.zone_low:
        return BuyTrigger(
            "weak",
            "\n".join(
                [
                    f"【暂不买入】{entry.symbol} {entry.name}",
                    f"价位：跌出买点区间 {entry.zone_low:g}-{entry.zone_high:g}",
                    f"模型获利概率：{probability_text}",
                    control_line,
                    price_line,
                    funds_line,
                    sector_line,
                    "原因：价格和资金同时转弱。",
                ]
            ),
            "weak",
        )

    if entry.is_holding:
        return None

    has_positive_funds = (total_net or 0) > 0 or (large_net or 0) > 0
    if has_positive_funds and entry.zone_low <= last <= entry.zone_high:
        return BuyTrigger(
            "buy_zone",
            "\n".join(
                [
                    f"【低吸买入】{entry.symbol} {entry.name}",
                    f"重点价位：{buy_line}",
                    f"模型获利概率：{probability_text}",
                    f"仓位：小仓试，跌破 {entry.risk_line:g} 立即放弃。",
                    control_line,
                    price_line,
                    funds_line,
                    sector_line,
                    "原因：回踩买点区间，资金仍有承接。",
                ]
            ),
            "buy_zone",
        )

    if has_positive_funds and last >= entry.confirm_price:
        return BuyTrigger(
            "breakout",
            "\n".join(
                [
                    f"【突破跟随买入】{entry.symbol} {entry.name}",
                    f"重点价位：已站上确认价 {entry.confirm_price:g}",
                    f"模型获利概率：{probability_text}",
                    f"回踩买点：{entry.zone_low:g}-{entry.zone_high:g}；风险线：{entry.risk_line:g}",
                    price_line,
                    funds_line,
                    sector_line,
                    "原因：价格突破且资金保持流入。",
                ]
            ),
            "breakout",
        )
    return None


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def to_float(value: Any, default: float = 0.0) -> float:
    parsed = to_optional_float(value)
    return default if parsed is None else parsed


def to_optional_float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def money_10k(number: float | None) -> str:
    if number is None:
        return "-"
    amount = number / 10_000
    sign = "+" if amount > 0 else ""
    return f"{sign}{amount:.0f}万"


def sector_context_line(quote: dict[str, Any]) -> str:
    industry = str(quote.get("industry") or "").strip()
    if not industry:
        return "行业联动：缺少行业信息"
    change_pct = to_optional_float(quote.get("industry_change_pct"))
    up_ratio = to_optional_float(quote.get("industry_up_ratio"))
    sample_count = quote.get("industry_sample_count")
    linkage = str(quote.get("industry_linkage") or "unknown")
    change_text = "-" if change_pct is None else f"{change_pct:+.2f}%"
    up_text = "-" if up_ratio is None else f"{up_ratio * 100:.0f}%"
    count_text = "-" if sample_count is None else str(sample_count)
    return f"行业联动：{linkage_text(linkage)}；{industry}，平均涨跌 {change_text}，上涨占比 {up_text}，样本 {count_text} 只"


def build_buy_trigger(entry: PoolEntry, quote: dict[str, Any]) -> BuyTrigger | None:
    last = to_float(quote.get("last"))
    if last <= 0:
        return None
    change_pct = to_float(quote.get("change_pct"))
    high = to_float(quote.get("high"))
    low = to_float(quote.get("low"))
    total_net = to_optional_float(quote.get("total_net"))
    large_net = to_optional_float(quote.get("large_net"))
    probability_text = entry_probability_text(entry)
    sector_line = sector_context_line(quote)
    buy_line = f"买点区间：{entry.zone_low:g}-{entry.zone_high:g}"
    take_profit_line = f"止盈目标：{last * (1 + DEFAULT_TAKE_PROFIT_PCT):.3f}（约 +{DEFAULT_TAKE_PROFIT_PCT * 100:.1f}%）"
    control_line = f"确认价：{entry.confirm_price:g}  风险线：{entry.risk_line:g}"

    if last <= entry.risk_line:
        if not entry.is_holding:
            return None
        return BuyTrigger(
            "risk",
            "\n".join(
                [
                    f"【卖出避险】{entry.symbol} {entry.name}",
                    *_hk_alert_table(
                        last=last,
                        change_pct=change_pct,
                        low=low,
                        high=high,
                        position=f"已跌破风险线 {entry.risk_line:g}；重新站回 {entry.zone_low:g} 以上再看",
                        probability_text="-",
                        total_net=total_net,
                        large_net=large_net,
                        technical="结构转弱，价格跌破风控位；先按卖出避险处理",
                        risk=f"跌破 {entry.risk_line:g} 已触发；不接飞刀，等重新站回买点区间",
                        sector_line=sector_line,
                    ),
                ]
            ),
            "risk",
        )

    if (total_net or 0) < 0 and (large_net or 0) < 0 and last < entry.zone_low:
        return BuyTrigger(
            "weak",
            "\n".join(
                [
                    f"【暂不买入】{entry.symbol} {entry.name}",
                    *_hk_alert_table(
                        last=last,
                        change_pct=change_pct,
                        low=low,
                        high=high,
                        position=f"跌出买点区间 {entry.zone_low:g}-{entry.zone_high:g}；{control_line}",
                        probability_text=probability_text,
                        total_net=total_net,
                        large_net=large_net,
                        technical="价格和资金同时转弱，形态不支持追买",
                        risk=f"重新站回 {entry.zone_low:g} 且资金转正前先不参与",
                        sector_line=sector_line,
                    ),
                ]
            ),
            "weak",
        )

    has_positive_funds = (total_net or 0) > 0 or (large_net or 0) > 0
    if has_positive_funds and entry.zone_low <= last <= entry.zone_high:
        return BuyTrigger(
            "buy_zone",
            "\n".join(
                [
                    f"【低吸买入】{entry.symbol} {entry.name}",
                    *_hk_alert_table(
                        last=last,
                        change_pct=change_pct,
                        low=low,
                        high=high,
                        position=f"{buy_line}；{control_line}",
                        probability_text=f"{probability_text}; {take_profit_line}",
                        total_net=total_net,
                        large_net=large_net,
                        technical="回踩买点区间，资金仍有承接；形态支持小仓试买",
                        risk=f"跌破 {entry.risk_line:g} 立即放弃",
                        sector_line=sector_line,
                    ),
                ]
            ),
            "buy_zone",
        )

    if has_positive_funds and last >= entry.confirm_price:
        return BuyTrigger(
            "breakout",
            "\n".join(
                [
                    f"【突破跟随买入】{entry.symbol} {entry.name}",
                    *_hk_alert_table(
                        last=last,
                        change_pct=change_pct,
                        low=low,
                        high=high,
                        position=f"已站上确认价 {entry.confirm_price:g}；回踩买点 {entry.zone_low:g}-{entry.zone_high:g}",
                        probability_text=f"{probability_text}; {take_profit_line}",
                        total_net=total_net,
                        large_net=large_net,
                        technical="短线动能转强，站上关键价位，资金保持流入；形态支持小仓试买",
                        risk=f"跌回 {entry.confirm_price:g} 下方或资金转弱，先退出观察",
                        sector_line=sector_line,
                    ),
                ]
            ),
            "breakout",
        )
    return None


def _hk_alert_table(
    *,
    last: float,
    change_pct: float,
    low: float,
    high: float,
    position: str,
    probability_text: str,
    total_net: float | None,
    large_net: float | None,
    technical: str,
    risk: str,
    sector_line: str,
) -> list[str]:
    return [
        "|项目|内容|",
        "|---|---|",
        f"|现价|{last:.3f}（{change_pct:+.2f}%）|",
        f"|位置|日内 {low:.3f}-{high:.3f}; {position}|",
        f"|胜率|{probability_text}|",
        f"|资金|净流入 {money_10k(total_net)}, 大单 {money_10k(large_net)}|",
        f"|技术|{technical}|",
        f"|风控|{risk}|",
        f"|板块|{sector_line.replace('行业联动：', '')}|",
    ]


_build_buy_trigger_long_term_boundary = build_buy_trigger


def build_buy_trigger(entry: PoolEntry, quote: dict[str, Any]) -> BuyTrigger | None:
    if entry.observation_only or entry.output_stage == "observe":
        return None
    trigger = _build_buy_trigger_long_term_boundary(entry, quote)
    if trigger is not None and trigger.event_type in {"buy_zone", "breakout"}:
        probability = entry.profit_probability
        if probability is None or probability < min_buy_probability():
            return None
        if not is_actionable_model_signal(
            decision=entry.decision,
            risk_score=entry.risk_score,
            change_pct=to_float(quote.get("change_pct")),
        ):
            return None
    if entry.is_holding and trigger is not None and trigger.event_type in {"buy_zone", "breakout"}:
        return None
    return trigger


def build_observation_trigger(entry: PoolEntry, quote: dict[str, Any]) -> BuyTrigger | None:
    if entry.is_holding:
        return None
    probability = entry.profit_probability
    if probability is None or probability < observation_min_probability():
        return None
    if not is_actionable_model_signal(
        decision=entry.decision,
        risk_score=entry.risk_score,
        change_pct=to_float(quote.get("change_pct")),
    ):
        return None
    last = to_float(quote.get("last"))
    if last <= 0:
        return None
    change_pct = to_float(quote.get("change_pct"))
    high = to_float(quote.get("high"))
    low = to_float(quote.get("low"))
    total_net = to_optional_float(quote.get("total_net"))
    large_net = to_optional_float(quote.get("large_net"))
    probability_text = f"{entry_probability_text(entry)}; 未达到正式买入线，仅观察"
    sector_line = sector_context_line(quote)
    return BuyTrigger(
        "observe",
        "\n".join(
            [
                f"【{strategy_title(entry)}｜观察暂不买入】{entry.symbol} {entry.name}",
                *_hk_alert_table(
                    last=last,
                    change_pct=change_pct,
                    low=low,
                    high=high,
                    position=f"观察区；未触发正式买入，买点区间 {entry.zone_low:g}-{entry.zone_high:g}",
                    probability_text=probability_text,
                    total_net=total_net,
                    large_net=large_net,
                    technical="模型开始关注，但概率未到正式线；等待放量、突破或回踩确认",
                    risk=f"不建议买入；升到正式线并触发低吸/突破再考虑",
                    sector_line=sector_line,
                ),
            ]
        ),
        "watching",
    )


def money_10k(number: float | None) -> str:
    if number is None:
        return "-"
    sign = "+" if number > 0 else ""
    amount = abs(number)
    if amount >= 10_000:
        return f"{sign}{number / 10_000:.2f}\u4ebf"
    if amount >= 100:
        return f"{sign}{number:.0f}\u4e07"
    return f"{sign}{number:.1f}\u4e07"


# Final alert formatter.  Some older Chinese literals above were stored with
# mojibake; keep this clean override last so runtime alerts stay readable.
def money_10k(number: float | None) -> str:
    if number is None:
        return "-"
    sign = "+" if number > 0 else ""
    amount = abs(number)
    if amount >= 10_000:
        return f"{sign}{amount / 10_000:.2f}亿"
    return f"{sign}{amount:.0f}万"


def format_model_probability(value: float | None) -> str:
    return "缺失" if value is None else f"{value * 100:.1f}%"


def entry_probability_text(entry: PoolEntry) -> str:
    label = "规则兜底分" if str(entry.decision or "").strip().lower() == "rule_fallback" else "模型获利概率"
    return f"{label}：{format_model_probability(entry.profit_probability)}"


def linkage_text(value: str) -> str:
    mapping = {
        "sector_up_linkage": "行业整体上涨联动",
        "sector_down_linkage": "行业整体下跌联动",
        "mild_sector_support": "行业有一定支撑",
        "stock_specific_or_mixed": "偏个股异动，行业联动不明显",
        "missing_quotes": "缺少行业实时行情",
        "missing_peers": "缺少同行样本",
        "insufficient_samples": "同行样本不足",
    }
    return mapping.get(value, "暂无无法判断")


def sector_context_line(quote: dict[str, Any]) -> str:
    industry = str(quote.get("industry") or "").strip()
    region_board = str(quote.get("region_board") or "").strip()
    concepts = concept_list(quote.get("concepts"))
    if not industry:
        board = market_board_text(str(quote.get("symbol") or ""))
        parts = [item for item in (board, region_board, concept_text(concepts)) if item]
        return "；".join(parts) if parts else "缺少行业信息"
    change_pct = to_optional_float(quote.get("industry_change_pct"))
    up_ratio = to_optional_float(quote.get("industry_up_ratio"))
    sample_count = quote.get("industry_sample_count")
    linkage = str(quote.get("industry_linkage") or "unknown")
    change_text = "-" if change_pct is None else f"{change_pct:+.2f}%"
    up_text = "-" if up_ratio is None else f"{up_ratio * 100:.0f}%"
    count_text = "-" if sample_count is None else str(sample_count)
    prefix = f"{linkage_text(linkage)}；{industry}"
    if region_board:
        prefix += f"；{region_board}"
    concept_summary = concept_text(concepts)
    if concept_summary:
        prefix += f"；{concept_summary}"
    return f"{prefix}，平均涨跌 {change_text}，上涨占比 {up_text}，样本 {count_text} 只"


def concept_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    text = str(value or "").strip()
    if not text or text == "-":
        return []
    return [item.strip() for item in text.replace("，", ",").split(",") if item.strip()]


def concept_text(concepts: list[str]) -> str:
    if not concepts:
        return ""
    return "概念：" + "、".join(concepts[:4])


def market_board_text(symbol: str) -> str:
    code = symbol.strip().upper().split(".", 1)[0]
    suffix = symbol.strip().upper().split(".", 1)[1] if "." in symbol.strip().upper() else ""
    if suffix == "SZ" and (code.startswith("300") or code.startswith("301")):
        return "创业板"
    if suffix == "SH" and code.startswith("688"):
        return "科创板"
    if suffix == "SZ":
        return "深市主板"
    if suffix == "SH":
        return "沪市主板"
    return ""


def pattern_context_line(quote: dict[str, Any]) -> str:
    context = quote.get("pattern_context")
    if not isinstance(context, dict) or not context:
        return "暂无指纹候选"
    pattern_type = str(context.get("pattern_type") or "-")
    score = to_optional_float(context.get("score"))
    up_probability = to_optional_float(context.get("up_probability"))
    median_max_return = to_optional_float(context.get("median_max_return"))
    match_count = context.get("match_count")
    risk_flags = context.get("risk_flags") or []
    reasons = context.get("reasons") or []
    parts = [f"形态 {pattern_type}"]
    if score is not None:
        parts.append(f"指纹分 {score:.1f}")
    if up_probability is not None:
        parts.append(f"相似上涨 {up_probability * 100:.0f}%")
    if median_max_return is not None:
        parts.append(f"历史冲高 {median_max_return * 100:+.1f}%")
    if match_count not in (None, ""):
        parts.append(f"样本 {int(to_float(match_count))}")
    tags = [str(item) for item in risk_flags if str(item)] or [str(item) for item in reasons[:2] if str(item)]
    if tags:
        parts.append("标记 " + "、".join(tags[:2]))
    return "；".join(parts)


def _alert_table(
    *,
    last: float,
    change_pct: float,
    low: float,
    high: float,
    position: str,
    probability_text: str,
    total_net: float | None,
    large_net: float | None,
    technical: str,
    pattern_line: str,
    risk: str,
    sector_line: str,
    shape_line: str | None = None,
    quant_regime_line: str | None = None,
    algorithm_line: str | None = None,
    capital_pattern_line: str | None = None,
    trade_type: str | None = None,
) -> list[str]:
    lines = [
        "| 项目 | 内容 |",
        "|---|---|",
        f"| 现价 | {last:.3f}（{change_pct:+.2f}%） |",
        f"| 位置 | 日内 {low:.3f}-{high:.3f}; {position} |",
        f"| 胜率 | {probability_text} |",
        f"| 资金 | 净流入 {money_10k(total_net)}, 大单 {money_10k(large_net)} |",
        f"| 技术 | {technical} |",
        f"| 指纹 | {pattern_line} |",
    ]
    if shape_line:
        lines.append(f"| 形态 | {shape_line} |")
    if quant_regime_line:
        lines.append(f"| 长期 | {quant_regime_line} |")
    if algorithm_line:
        lines.append(f"| 算法 | {algorithm_line} |")
    if capital_pattern_line:
        lines.append(f"| 资金形态 | {capital_pattern_line} |")
    if trade_type:
        lines.append(f"| 类型 | {trade_type} |")
    lines.extend(
        [
            f"| 风控 | {risk} |",
            f"| 板块 | {sector_line} |",
        ]
    )
    return lines


def _build_action_trigger(entry: PoolEntry, quote: dict[str, Any]) -> BuyTrigger | None:
    last = to_float(quote.get("last"))
    if last <= 0:
        return None
    change_pct = to_float(quote.get("change_pct"))
    high = to_float(quote.get("high"))
    low = to_float(quote.get("low"))
    total_net = to_optional_float(quote.get("total_net"))
    large_net = to_optional_float(quote.get("large_net"))
    probability_text = entry_probability_text(entry)
    take_profit_line = f"止盈目标：{last * (1 + DEFAULT_TAKE_PROFIT_PCT):.3f}（约 +{DEFAULT_TAKE_PROFIT_PCT * 100:.1f}%）"
    sector_line = sector_context_line(quote)
    pattern_line = pattern_context_line(quote)

    if last <= entry.risk_line:
        if not entry.is_holding:
            return None
        return BuyTrigger(
            "risk",
            "\n".join(
                [
                    f"【{strategy_title(entry)}｜卖出避险】{entry.symbol} {entry.name}",
                    *_alert_table(
                        last=last,
                        change_pct=change_pct,
                        low=low,
                        high=high,
                        position=f"已跌破风险线 {entry.risk_line:g}；重新站回 {entry.zone_low:g} 以上再看",
                        probability_text="-",
                        total_net=total_net,
                        large_net=large_net,
                        technical="结构转弱，价格跌破风控位；先按卖出避险处理",
                        pattern_line=pattern_line,
                        risk=f"跌破 {entry.risk_line:g} 已触发；不接飞刀，等重新站回买点区间",
                        sector_line=sector_line,
                        shape_line=entry_shape_text(entry),
                        quant_regime_line=entry_quant_regime_text(entry),
                        algorithm_line=entry_algorithm_text(entry),
                        capital_pattern_line=entry_capital_pattern_text(entry),
                    ),
                ]
            ),
            "risk",
        )

    if (total_net or 0) < 0 and (large_net or 0) < 0 and last < entry.zone_low:
        return BuyTrigger(
            "weak",
            "\n".join(
                [
                    f"【{strategy_title(entry)}｜暂不买入】{entry.symbol} {entry.name}",
                    *_alert_table(
                        last=last,
                        change_pct=change_pct,
                        low=low,
                        high=high,
                        position=f"跌出买点区间 {entry.zone_low:g}-{entry.zone_high:g}；确认价 {entry.confirm_price:g}，风险线 {entry.risk_line:g}",
                        probability_text=probability_text,
                        total_net=total_net,
                        large_net=large_net,
                        technical="价格和资金同时转弱，形态不支持追买",
                        pattern_line=pattern_line,
                        risk=f"重新站回 {entry.zone_low:g} 且资金转正前先不参与",
                        sector_line=sector_line,
                        shape_line=entry_shape_text(entry),
                        quant_regime_line=entry_quant_regime_text(entry),
                        algorithm_line=entry_algorithm_text(entry),
                        capital_pattern_line=entry_capital_pattern_text(entry),
                    ),
                ]
            ),
            "weak",
        )

    has_positive_funds = (total_net or 0) > 0 or (large_net or 0) > 0
    if has_positive_funds and entry.zone_low <= last <= entry.zone_high:
        return BuyTrigger(
            "buy_zone",
            "\n".join(
                [
                    f"【{strategy_title(entry)}｜低吸买入】{entry.symbol} {entry.name}",
                    *_alert_table(
                        last=last,
                        change_pct=change_pct,
                        low=low,
                        high=high,
                        position=f"买点区间 {entry.zone_low:g}-{entry.zone_high:g}；确认价 {entry.confirm_price:g}，风险线 {entry.risk_line:g}",
                        probability_text=f"{probability_text}; {take_profit_line}",
                        total_net=total_net,
                        large_net=large_net,
                        technical="回踩买点区间，资金仍有承接；形态支持小仓试买",
                        pattern_line=pattern_line,
                        trade_type="短线冲高型：回测显示常给冲高机会，达到目标后不恋战",
                        risk=f"跌破 {entry.risk_line:g} 立即放弃；冲到 +2% 附近先兑现或抬高止盈",
                        sector_line=sector_line,
                        shape_line=entry_shape_text(entry),
                        quant_regime_line=entry_quant_regime_text(entry),
                        algorithm_line=entry_algorithm_text(entry),
                        capital_pattern_line=entry_capital_pattern_text(entry),
                    ),
                ]
            ),
            "buy_zone",
        )

    if has_positive_funds and last >= entry.confirm_price:
        return BuyTrigger(
            "breakout",
            "\n".join(
                [
                    f"【{strategy_title(entry)}｜突破跟随买入】{entry.symbol} {entry.name}",
                    *_alert_table(
                        last=last,
                        change_pct=change_pct,
                        low=low,
                        high=high,
                        position=f"已站上确认价 {entry.confirm_price:g}；回踩买点 {entry.zone_low:g}-{entry.zone_high:g}",
                        probability_text=f"{probability_text}; {take_profit_line}",
                        total_net=total_net,
                        large_net=large_net,
                        technical="短线动能转强，站上关键价位，资金保持流入；形态支持小仓试买",
                        pattern_line=pattern_line,
                        trade_type="突破冲高型：突破后先看冲高兑现，不默认持有三天",
                        risk=f"跌回 {entry.confirm_price:g} 下方或资金转弱，先退出观察；冲到 +2% 附近先兑现或抬高止盈",
                        sector_line=sector_line,
                        shape_line=entry_shape_text(entry),
                        quant_regime_line=entry_quant_regime_text(entry),
                        algorithm_line=entry_algorithm_text(entry),
                        capital_pattern_line=entry_capital_pattern_text(entry),
                    ),
                ]
            ),
            "breakout",
        )
    return None


def build_observation_trigger(entry: PoolEntry, quote: dict[str, Any]) -> BuyTrigger | None:
    if entry.is_holding:
        return None
    probability = entry.profit_probability
    if probability is None or probability < observation_min_probability():
        return None
    if not is_actionable_model_signal(
        decision=entry.decision,
        risk_score=entry.risk_score,
        change_pct=to_float(quote.get("change_pct")),
    ):
        return None
    last = to_float(quote.get("last"))
    if last <= 0:
        return None
    change_pct = to_float(quote.get("change_pct"))
    high = to_float(quote.get("high"))
    low = to_float(quote.get("low"))
    total_net = to_optional_float(quote.get("total_net"))
    large_net = to_optional_float(quote.get("large_net"))
    sector_line = sector_context_line(quote)
    pattern_line = pattern_context_line(quote)
    return BuyTrigger(
        "observe",
        "\n".join(
            [
                f"【观察池｜暂不买入】{entry.symbol} {entry.name}",
                *_alert_table(
                    last=last,
                    change_pct=change_pct,
                    low=low,
                    high=high,
                    position=f"观察区；未触发正式买入，买点区间 {entry.zone_low:g}-{entry.zone_high:g}",
                    probability_text=f"{entry_probability_text(entry)}; 未达到正式买入线，仅观察",
                    total_net=total_net,
                    large_net=large_net,
                    technical="模型开始关注，但概率未到正式线；等待放量、突破或回踩确认",
                    pattern_line=pattern_line,
                    risk="不建议买入；升到正式线并触发低吸/突破再考虑",
                    sector_line=sector_line,
                    shape_line=entry_shape_text(entry),
                    quant_regime_line=entry_quant_regime_text(entry),
                    algorithm_line=entry_algorithm_text(entry),
                    capital_pattern_line=entry_capital_pattern_text(entry),
                ),
            ]
        ),
        "watching",
    )


def strategy_title(entry: PoolEntry) -> str:
    if entry.is_holding:
        return "持仓盯盘"
    output_stage = str(entry.output_stage or "").strip()
    reason = str(entry.reason or "").lower()
    if output_stage in {"next_day_watch", "shape_observe", "quant_regime_observe"} or "t+1" in reason:
        return "次日上涨候选池"
    if output_stage in {"holding_watch"}:
        return "持仓盯盘"
    if output_stage in {"observe"} or entry.observation_only:
        return "观察池"
    return "盘中动态池"


def build_buy_trigger(entry: PoolEntry, quote: dict[str, Any]) -> BuyTrigger | None:
    if entry.observation_only or entry.output_stage == "observe":
        return None
    trigger = _build_action_trigger(entry, quote)
    if trigger is not None and trigger.event_type in {"buy_zone", "breakout"}:
        probability = entry.profit_probability
        if probability is None or probability < min_buy_probability():
            return None
        if not is_actionable_model_signal(
            decision=entry.decision,
            risk_score=entry.risk_score,
            change_pct=to_float(quote.get("change_pct")),
        ):
            return None
    if entry.is_holding and trigger is not None and trigger.event_type in {"buy_zone", "breakout"}:
        return None
    return trigger


def entry_probability_text(entry: PoolEntry) -> str:
    label = "规则兜底分" if str(entry.decision or "").strip().lower() == "rule_fallback" else "模型获利概率"
    value = format_model_probability(entry.profit_probability)
    return f"{label}：{value}"


def entry_shape_text(entry: PoolEntry) -> str:
    shape = entry.shape if isinstance(entry.shape, dict) else {}
    label = str(shape.get("label") or "").strip()
    parts = [label] if label else []
    transition_risk = to_optional_float(shape.get("hmm_transition_risk"))
    state_prob = to_optional_float(shape.get("hmm_state_prob"))
    momentum = to_optional_float(shape.get("hmm_state_momentum"))
    if transition_risk is not None:
        parts.append(f"转弱风险 {transition_risk * 100:.1f}%")
    if state_prob is not None:
        parts.append(f"状态置信 {state_prob * 100:.1f}%")
    if momentum is not None:
        parts.append(f"形态动量 {momentum * 100:+.1f}%")
    return "；".join(parts) if parts else "缺少形态信息"


def entry_quant_regime_text(entry: PoolEntry) -> str:
    regime = entry.quant_regime if isinstance(entry.quant_regime, dict) else {}
    return quant_regime_text(regime) if regime else ""


def entry_algorithm_text(entry: PoolEntry) -> str:
    parts: list[str] = []
    shape_adjustment = entry.shape_adjustment if isinstance(entry.shape_adjustment, dict) else {}
    quant_adjustment = entry.quant_regime_adjustment if isinstance(entry.quant_regime_adjustment, dict) else {}
    shape_action = str(shape_adjustment.get("action") or "").strip()
    if shape_action:
        parts.append(f"HMM {algorithm_action_text(shape_action)}")
    final_score = to_optional_float(shape_adjustment.get("final_score"))
    if final_score is not None:
        parts.append(f"HMM后分 {final_score:.1f}")
    quant_action = str(quant_adjustment.get("action") or "").strip()
    if quant_action:
        parts.append(f"量化状态 {algorithm_action_text(quant_action)}")
    bonus = to_optional_float(quant_adjustment.get("bonus"))
    penalty = to_optional_float(quant_adjustment.get("penalty"))
    if bonus:
        parts.append(f"加分 +{bonus:.1f}")
    if penalty:
        parts.append(f"扣分 -{penalty:.1f}")
    return "；".join(parts)


def entry_capital_pattern_text(entry: PoolEntry) -> str:
    pattern = entry.capital_pattern if isinstance(entry.capital_pattern, dict) else {}
    if not pattern:
        return ""
    text = str(pattern.get("text") or "").strip()
    if text:
        return text
    return capital_pattern_text(pattern)


def algorithm_action_text(value: str) -> str:
    mapping = {
        "boost": "加分",
        "downgrade": "降级",
        "observe_only": "观察",
        "keep": "保持",
        "neutral": "中性",
    }
    return mapping.get(value, value)

from __future__ import annotations

from collections.abc import Callable

import pandas as pd


FactorFunc = Callable[[pd.DataFrame], pd.Series]


def list_factors() -> list[str]:
    return sorted(FACTOR_REGISTRY)


def compute_factor_set(data: pd.DataFrame, factor_names: list[str]) -> pd.DataFrame:
    missing = [name for name in factor_names if name not in FACTOR_REGISTRY]
    if missing:
        raise KeyError(f"Unknown factors: {', '.join(missing)}")
    factors = {name: FACTOR_REGISTRY[name](data) for name in factor_names}
    return pd.DataFrame(factors).replace([float("inf"), float("-inf")], pd.NA)


def momentum_20(data: pd.DataFrame) -> pd.Series:
    close = _by_instrument(data["close"])
    return close.pct_change(20, fill_method=None)


def mean_reversion_5(data: pd.DataFrame) -> pd.Series:
    close = data["close"]
    ma5 = close.groupby(level="instrument", group_keys=False).transform(lambda series: series.rolling(5, min_periods=5).mean())
    return -(close / ma5 - 1.0)


def volatility_20(data: pd.DataFrame) -> pd.Series:
    returns = _by_instrument(data["close"]).pct_change(fill_method=None)
    return returns.groupby(level="instrument", group_keys=False).transform(lambda series: series.rolling(20, min_periods=10).std())


def volume_change_5(data: pd.DataFrame) -> pd.Series:
    volume = _by_instrument(data["volume"])
    return volume.pct_change(5, fill_method=None)


def _by_instrument(series: pd.Series) -> pd.core.groupby.SeriesGroupBy:
    _ensure_index(series)
    return series.groupby(level="instrument", group_keys=False)


def _ensure_index(series: pd.Series) -> None:
    names = list(series.index.names)
    if names != ["datetime", "instrument"]:
        raise ValueError(f"Expected MultiIndex ['datetime', 'instrument'], got {names}")


FACTOR_REGISTRY: dict[str, FactorFunc] = {
    "momentum_20": momentum_20,
    "mean_reversion_5": mean_reversion_5,
    "volatility_20": volatility_20,
    "volume_change_5": volume_change_5,
}

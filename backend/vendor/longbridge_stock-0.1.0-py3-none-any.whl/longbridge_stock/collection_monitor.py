from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Iterable

import psycopg
from psycopg.types.json import Jsonb


@dataclass(frozen=True)
class DatasetCoverage:
    market: str
    dataset_key: str
    expected_count: int
    collected_count: int
    latest_data_at: datetime | None = None
    fresh_count: int | None = None
    stale_count: int = 0
    missing_count: int | None = None
    freshness_status: str = "ok"


def ensure_monitoring_schema(dsn: str) -> None:
    with psycopg.connect(dsn) as conn:
        _ensure_monitoring_schema(conn)


def heartbeat(
    dsn: str,
    task_key: str,
    *,
    status: str,
    rows_written: int = 0,
    rows_failed: int = 0,
    queue_depth: int = 0,
    latest_error_code: str | None = None,
    latest_error_message: str | None = None,
    last_started_at: datetime | None = None,
    last_finished_at: datetime | None = None,
    last_success_at: datetime | None = None,
    last_write_at: datetime | None = None,
    retry_count: int = 0,
    runtime: dict[str, Any] | None = None,
) -> None:
    now = _now()
    last_error_at = now if latest_error_message else None
    lag_seconds = int((now - last_write_at).total_seconds()) if last_write_at else None
    with psycopg.connect(dsn) as conn:
        _ensure_monitoring_schema(conn)
        conn.execute(
            """
            insert into lb_monitor.sync_tasks
              (task_key, task_name, task_group, priority, owner_service, updated_at)
            values (%s, %s, 'collector', 'P1', %s, now())
            on conflict (task_key) do nothing
            """,
            (task_key, task_key, task_key),
        )
        conn.execute(
            """
            insert into lb_monitor.task_heartbeats
              (task_key, status, heartbeat_at, last_started_at, last_finished_at,
               last_success_at, last_write_at, last_error_at, latest_error_code,
               latest_error_message, rows_written, rows_failed, retry_count,
               queue_depth, lag_seconds, runtime, updated_at)
            values
              (%s, %s, %s, %s, %s, %s, %s,
               %s,
               %s, %s, %s, %s, %s, %s,
               %s,
               %s, now())
            on conflict (task_key) do update set
              status = excluded.status,
              heartbeat_at = excluded.heartbeat_at,
              last_started_at = coalesce(excluded.last_started_at, lb_monitor.task_heartbeats.last_started_at),
              last_finished_at = coalesce(excluded.last_finished_at, lb_monitor.task_heartbeats.last_finished_at),
              last_success_at = coalesce(excluded.last_success_at, lb_monitor.task_heartbeats.last_success_at),
              last_write_at = coalesce(excluded.last_write_at, lb_monitor.task_heartbeats.last_write_at),
              last_error_at = case when excluded.latest_error_message is null then lb_monitor.task_heartbeats.last_error_at else excluded.heartbeat_at end,
              latest_error_code = excluded.latest_error_code,
              latest_error_message = excluded.latest_error_message,
              rows_written = excluded.rows_written,
              rows_failed = excluded.rows_failed,
              retry_count = excluded.retry_count,
              queue_depth = excluded.queue_depth,
              lag_seconds = excluded.lag_seconds,
              runtime = excluded.runtime,
              updated_at = now()
            """,
            (
                task_key,
                status,
                now,
                last_started_at,
                last_finished_at,
                last_success_at,
                last_write_at,
                last_error_at,
                latest_error_code,
                latest_error_message,
                rows_written,
                rows_failed,
                retry_count,
                queue_depth,
                lag_seconds,
                Jsonb(runtime or {}),
            ),
        )


def write_dataset_coverage(dsn: str, rows: Iterable[DatasetCoverage]) -> None:
    now = _now()
    values = list(rows)
    if not values:
        return
    with psycopg.connect(dsn) as conn:
        _ensure_monitoring_schema(conn)
        for row in values:
            fresh = row.fresh_count if row.fresh_count is not None else row.collected_count
            missing = row.missing_count if row.missing_count is not None else max(row.expected_count - row.collected_count, 0)
            conn.execute(
                """
                insert into lb_monitor.dataset_coverage
                  (snapshot_at, market, dataset_key, expected_count, collected_count,
                   fresh_count, stale_count, missing_count, latest_data_at, freshness_status)
                values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    now,
                    row.market,
                    row.dataset_key,
                    row.expected_count,
                    row.collected_count,
                    fresh,
                    row.stale_count,
                    missing,
                    row.latest_data_at,
                    row.freshness_status,
                ),
            )
            conn.execute(
                """
                insert into lb_monitor.collection_dataset_status
                  (market, dataset_key, trade_date, expected_count, collected_count,
                   fresh_count, stale_count, missing_count, latest_data_at,
                   freshness_status, updated_at)
                values (%s, %s, (now() at time zone 'Asia/Shanghai')::date, %s, %s, %s, %s, %s, %s, %s, now())
                on conflict (market, dataset_key, trade_date) do update set
                  expected_count = excluded.expected_count,
                  collected_count = excluded.collected_count,
                  fresh_count = excluded.fresh_count,
                  stale_count = excluded.stale_count,
                  missing_count = excluded.missing_count,
                  latest_data_at = excluded.latest_data_at,
                  freshness_status = excluded.freshness_status,
                  updated_at = now()
                """,
                (
                    row.market,
                    row.dataset_key,
                    row.expected_count,
                    row.collected_count,
                    fresh,
                    row.stale_count,
                    missing,
                    row.latest_data_at,
                    row.freshness_status,
                ),
            )


def emit_event(
    dsn: str,
    task_key: str | None,
    severity: str,
    event_type: str,
    message: str,
    *,
    error_code: str | None = None,
    payload: dict[str, Any] | None = None,
) -> None:
    with psycopg.connect(dsn) as conn:
        _ensure_monitoring_schema(conn)
        conn.execute(
            """
            insert into lb_monitor.sync_task_events
              (task_key, severity, event_type, message, error_code, payload)
            values (%s, %s, %s, %s, %s, %s)
            """,
            (task_key, severity, event_type, message, error_code, Jsonb(payload or {})),
        )


def enqueue_jobs(
    dsn: str,
    jobs: Iterable[dict[str, Any]],
) -> int:
    count = 0
    with psycopg.connect(dsn) as conn:
        _ensure_monitoring_schema(conn)
        for job in jobs:
            conn.execute(
                """
                insert into lb_monitor.collection_jobs
                  (job_key, task_key, market, dataset_key, symbol, priority,
                   status, run_after, max_attempts, payload, updated_at)
                values (%s, %s, %s, %s, %s, %s, 'pending', coalesce(%s, now()), %s, %s, now())
                on conflict (job_key) do update set
                  priority = excluded.priority,
                  run_after = least(lb_monitor.collection_jobs.run_after, excluded.run_after),
                  payload = excluded.payload,
                  updated_at = now()
                """,
                (
                    job["job_key"],
                    job["task_key"],
                    job.get("market"),
                    job["dataset_key"],
                    job.get("symbol"),
                    int(job.get("priority", 100)),
                    job.get("run_after"),
                    int(job.get("max_attempts", 3)),
                    Jsonb(job.get("payload") or {}),
                ),
            )
            count += 1
    return count


def claim_jobs(dsn: str, task_key: str, limit: int = 100) -> list[dict[str, Any]]:
    with psycopg.connect(dsn) as conn:
        _ensure_monitoring_schema(conn)
        rows = conn.execute(
            """
            with picked as (
              select id
              from lb_monitor.collection_jobs
              where task_key = %s
                and status in ('pending', 'retrying')
                and run_after <= now()
                and attempts < max_attempts
              order by priority, run_after, id
              for update skip locked
              limit %s
            )
            update lb_monitor.collection_jobs j
            set status = 'running',
                locked_at = now(),
                heartbeat_at = now(),
                attempts = attempts + 1,
                updated_at = now()
            from picked
            where j.id = picked.id
            returning j.id, j.job_key, j.task_key, j.market, j.dataset_key, j.symbol, j.attempts, j.payload
            """,
            (task_key, limit),
        ).fetchall()
    return [
        {
            "id": row[0],
            "job_key": row[1],
            "task_key": row[2],
            "market": row[3],
            "dataset_key": row[4],
            "symbol": row[5],
            "attempts": row[6],
            "payload": row[7] or {},
        }
        for row in rows
    ]


def complete_job(dsn: str, job_id: int, *, status: str = "success", error: str | None = None) -> None:
    with psycopg.connect(dsn) as conn:
        _ensure_monitoring_schema(conn)
        conn.execute(
            """
            update lb_monitor.collection_jobs
            set status = %s,
                finished_at = now(),
                latest_error = %s,
                updated_at = now()
            where id = %s
            """,
            (status, error, job_id),
        )


def sweep_stale_jobs(dsn: str, timeout_seconds: int = 300) -> int:
    with psycopg.connect(dsn) as conn:
        _ensure_monitoring_schema(conn)
        rows = conn.execute(
            """
            update lb_monitor.collection_jobs
            set status = case when attempts + 1 >= max_attempts then 'timeout' else 'retrying' end,
                run_after = now() + interval '60 seconds',
                latest_error = 'worker heartbeat timeout',
                updated_at = now()
            where status = 'running'
              and coalesce(heartbeat_at, locked_at, updated_at) < now() - (%s || ' seconds')::interval
            returning id
            """,
            (timeout_seconds,),
        ).fetchall()
    return len(rows)


def refresh_collection_alerts(dsn: str, stale_after_seconds: int = 600) -> int:
    with psycopg.connect(dsn) as conn:
        _ensure_monitoring_schema(conn)
        rows = conn.execute(
            """
            with unhealthy as (
              select
                t.task_key,
                t.task_name,
                coalesce(h.status, 'unknown') as status,
                h.heartbeat_at,
                h.latest_error_message,
                greatest(%s::integer, coalesce(t.expected_interval_seconds, %s) * 2) as stale_seconds,
                case
                  when h.task_key is null then 'missing_heartbeat'
                  when h.status in ('error','failed','limited','stale') then 'task_error'
                  when h.heartbeat_at < now() - (greatest(%s::integer, coalesce(t.expected_interval_seconds, %s) * 2) || ' seconds')::interval then 'stale_heartbeat'
                  else null
                end as alert_type
              from lb_monitor.sync_tasks t
              left join lb_monitor.task_heartbeats h on h.task_key = t.task_key
              where t.enabled
            ),
            upserted as (
              insert into lb_monitor.collection_alerts
                (alert_key, severity, status, title, message, last_seen_at, payload)
              select
                task_key || ':' || alert_type,
                case when alert_type = 'task_error' then 'error' else 'warning' end,
                'open',
                task_name || ' 异常',
                case
                  when alert_type = 'missing_heartbeat' then '未收到任务心跳'
                  when alert_type = 'stale_heartbeat' then '任务心跳超时'
                  else coalesce(latest_error_message, status)
                end,
                now(),
                jsonb_build_object(
                  'task_key', task_key,
                  'status', status,
                  'heartbeat_at', heartbeat_at,
                  'stale_seconds', stale_seconds,
                  'alert_type', alert_type
                )
              from unhealthy
              where alert_type is not null
              on conflict (alert_key, status) do update set
                severity = excluded.severity,
                title = excluded.title,
                message = excluded.message,
                last_seen_at = now(),
                payload = excluded.payload
              returning alert_key
            )
            select count(*) from upserted
            """,
            (stale_after_seconds, stale_after_seconds, stale_after_seconds, stale_after_seconds),
        ).fetchone()
        conn.execute(
            """
            with resolved_candidates as (
              select a.id, a.alert_key
              from lb_monitor.collection_alerts a
              where a.status = 'open'
                and a.alert_key like '%%:%%'
                and not exists (
                  select 1
                  from lb_monitor.sync_tasks t
                  left join lb_monitor.task_heartbeats h on h.task_key = t.task_key
                  where t.enabled
                    and a.alert_key = t.task_key || ':' || case
                      when h.task_key is null then 'missing_heartbeat'
                      when h.status in ('error','failed','limited','stale') then 'task_error'
                      when h.heartbeat_at < now() - (greatest(%s::integer, coalesce(t.expected_interval_seconds, %s) * 2) || ' seconds')::interval then 'stale_heartbeat'
                      else null
                    end
                )
            ),
            merged_existing as (
              update lb_monitor.collection_alerts r
              set severity = o.severity,
                  title = o.title,
                  message = o.message,
                  resolved_at = now(),
                  last_seen_at = now(),
                  payload = o.payload
              from lb_monitor.collection_alerts o
              join resolved_candidates c on c.id = o.id
              where r.alert_key = o.alert_key
                and r.status = 'resolved'
              returning o.id
            ),
            deleted_open_duplicates as (
              delete from lb_monitor.collection_alerts o
              using merged_existing m
              where o.id = m.id
              returning o.id
            )
            update lb_monitor.collection_alerts a
            set status = 'resolved',
                resolved_at = now(),
                last_seen_at = now()
            where a.id in (select id from resolved_candidates)
              and a.id not in (select id from deleted_open_duplicates)
            """,
            (stale_after_seconds, stale_after_seconds),
        )
    return int(rows[0] or 0) if rows else 0


def _ensure_monitoring_schema(conn: psycopg.Connection[Any]) -> None:
    conn.execute("create schema if not exists lb_monitor")
    conn.execute(
        """
        create table if not exists lb_monitor.sync_tasks (
          task_key text primary key,
          task_name text not null,
          task_group text not null,
          priority text not null,
          market_scope text[] not null default '{}',
          dataset_scope text[] not null default '{}',
          schedule_text text,
          expected_interval_seconds integer,
          enabled boolean not null default true,
          owner_service text,
          config jsonb not null default '{}'::jsonb,
          created_at timestamptz not null default now(),
          updated_at timestamptz not null default now()
        )
        """
    )
    conn.execute(
        """
        create table if not exists lb_monitor.task_heartbeats (
          task_key text primary key references lb_monitor.sync_tasks(task_key) on delete cascade,
          status text not null,
          heartbeat_at timestamptz not null,
          last_started_at timestamptz,
          last_finished_at timestamptz,
          last_success_at timestamptz,
          last_write_at timestamptz,
          last_error_at timestamptz,
          latest_error_code text,
          latest_error_message text,
          rows_written bigint not null default 0,
          rows_failed bigint not null default 0,
          retry_count integer not null default 0,
          queue_depth integer not null default 0,
          lag_seconds integer,
          runtime jsonb not null default '{}'::jsonb,
          updated_at timestamptz not null default now()
        )
        """
    )
    conn.execute(
        """
        create table if not exists lb_monitor.dataset_coverage (
          snapshot_at timestamptz not null default now(),
          market text not null,
          dataset_key text not null,
          expected_count integer not null default 0,
          collected_count integer not null default 0,
          fresh_count integer not null default 0,
          stale_count integer not null default 0,
          missing_count integer not null default 0,
          latest_data_at timestamptz,
          freshness_status text not null default 'unknown',
          primary key (snapshot_at, market, dataset_key)
        )
        """
    )
    conn.execute(
        """
        create index if not exists idx_lb_monitor_dataset_latest
        on lb_monitor.dataset_coverage (dataset_key, market, snapshot_at desc)
        """
    )
    conn.execute(
        """
        create table if not exists lb_monitor.sync_task_events (
          id bigserial primary key,
          task_key text references lb_monitor.sync_tasks(task_key) on delete set null,
          event_at timestamptz not null default now(),
          severity text not null,
          event_type text not null,
          message text not null,
          error_code text,
          payload jsonb not null default '{}'::jsonb
        )
        """
    )
    conn.execute(
        """
        create index if not exists idx_lb_monitor_events_recent
        on lb_monitor.sync_task_events (event_at desc, severity)
        """
    )
    conn.execute(
        """
        create table if not exists lb_monitor.collection_dataset_status (
          market text not null,
          dataset_key text not null,
          trade_date date not null,
          expected_count integer not null default 0,
          collected_count integer not null default 0,
          fresh_count integer not null default 0,
          stale_count integer not null default 0,
          missing_count integer not null default 0,
          latest_data_at timestamptz,
          last_success_at timestamptz,
          running_count integer not null default 0,
          failed_count integer not null default 0,
          lag_seconds integer,
          freshness_status text not null default 'unknown',
          payload jsonb not null default '{}'::jsonb,
          updated_at timestamptz not null default now(),
          primary key (market, dataset_key, trade_date)
        )
        """
    )
    conn.execute(
        """
        create table if not exists lb_monitor.collection_jobs (
          id bigserial primary key,
          job_key text not null unique,
          task_key text not null,
          market text,
          dataset_key text not null,
          symbol text,
          priority integer not null default 100,
          status text not null default 'pending',
          run_after timestamptz not null default now(),
          locked_at timestamptz,
          heartbeat_at timestamptz,
          finished_at timestamptz,
          attempts integer not null default 0,
          max_attempts integer not null default 3,
          latest_error text,
          payload jsonb not null default '{}'::jsonb,
          created_at timestamptz not null default now(),
          updated_at timestamptz not null default now()
        )
        """
    )
    conn.execute(
        """
        create index if not exists idx_lb_monitor_jobs_ready
        on lb_monitor.collection_jobs (task_key, status, run_after, priority, id)
        """
    )
    conn.execute(
        """
        create table if not exists lb_monitor.collection_alerts (
          id bigserial primary key,
          alert_key text not null,
          severity text not null,
          status text not null default 'open',
          title text not null,
          message text not null,
          first_seen_at timestamptz not null default now(),
          last_seen_at timestamptz not null default now(),
          resolved_at timestamptz,
          payload jsonb not null default '{}'::jsonb,
          unique (alert_key, status)
        )
        """
    )


def _now() -> datetime:
    return datetime.now(timezone.utc).astimezone()

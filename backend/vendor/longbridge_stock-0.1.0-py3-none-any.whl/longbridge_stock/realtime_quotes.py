from __future__ import annotations

import json
import time
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Iterable

from longbridge_stock.collection_monitor import DatasetCoverage, heartbeat, write_dataset_coverage
from longbridge_stock.longbridge_sync import LongbridgeCliClient
from longbridge_stock.market_sessions import filter_symbols_for_trading_time, markets_from_symbols
from longbridge_stock.postgres_store import LongbridgePostgresStore
from longbridge_stock.realtime_symbols import load_realtime_symbols


@dataclass(frozen=True)
class RealtimeQuoteSummary:
    snapshot_minute: datetime
    input_symbols: int
    returned: int
    written: int
    failed_batches: int
    elapsed_seconds: float
    input_by_market: dict[str, int] | None = None
    returned_by_market: dict[str, int] | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "snapshotMinute": self.snapshot_minute.isoformat(),
            "inputSymbols": self.input_symbols,
            "returned": self.returned,
            "written": self.written,
            "failedBatches": self.failed_batches,
            "elapsedSeconds": round(self.elapsed_seconds, 3),
            "inputByMarket": self.input_by_market or {},
            "returnedByMarket": self.returned_by_market or {},
        }


class RealtimeQuoteSync:
    def __init__(
        self,
        dsn: str,
        client: LongbridgeCliClient | None = None,
        store: LongbridgePostgresStore | None = None,
        batch_size: int = 500,
    ) -> None:
        if batch_size <= 0:
            raise ValueError("batch_size must be positive")
        self.dsn = dsn
        self.client = client or LongbridgeCliClient(rate_limit_per_second=5)
        self.store = store or LongbridgePostgresStore(dsn)
        self.batch_size = batch_size

    def load_symbols(
        self,
        markets: Iterable[str],
        limit: int | None = None,
        priority_only: bool = False,
    ) -> list[str]:
        return load_realtime_symbols(
            self.dsn,
            markets,
            client=self.client,
            limit=limit,
            priority_only=priority_only,
        )

    def sync_once(self, symbols: list[str]) -> RealtimeQuoteSummary:
        started = time.monotonic()
        fetched_at = _now()
        snapshot_minute = fetched_at.replace(second=0, microsecond=0)
        returned = 0
        written = 0
        failed_batches = 0
        input_by_market = Counter(_market_from_symbol(symbol) for symbol in symbols)
        returned_by_market: Counter[str] = Counter()
        self.store.ensure_realtime_quote_table()
        for batch in _chunks(symbols, self.batch_size):
            try:
                payload = self.client.quote_many(batch)
            except Exception:
                failed_batches += 1
                for small_batch in _chunks(batch, max(1, self.batch_size // 10)):
                    try:
                        payload = self.client.quote_many(small_batch)
                    except Exception:
                        failed_batches += 1
                        continue
                    rows = _quote_rows(payload)
                    returned += len(rows)
                    returned_by_market.update(_market_from_symbol(str(row.get("symbol") or "")) for row in rows)
                    written += self.store.upsert_realtime_quotes(rows, snapshot_minute, _now())
                continue
            rows = _quote_rows(payload)
            returned += len(rows)
            returned_by_market.update(_market_from_symbol(str(row.get("symbol") or "")) for row in rows)
            written += self.store.upsert_realtime_quotes(rows, snapshot_minute, _now())
        elapsed = time.monotonic() - started
        self._write_monitoring(
            snapshot_minute=snapshot_minute,
            input_by_market=dict(input_by_market),
            returned_by_market=dict(returned_by_market),
            written=written,
            failed_batches=failed_batches,
            elapsed_seconds=elapsed,
        )
        return RealtimeQuoteSummary(
            snapshot_minute=snapshot_minute,
            input_symbols=len(symbols),
            returned=returned,
            written=written,
            failed_batches=failed_batches,
            elapsed_seconds=elapsed,
            input_by_market=dict(input_by_market),
            returned_by_market=dict(returned_by_market),
        )

    def run_forever(self, symbols: list[str], interval_seconds: int) -> None:
        if interval_seconds <= 0:
            raise ValueError("interval_seconds must be positive")
        markets = markets_from_symbols(symbols)
        input_by_market = Counter(_market_from_symbol(symbol) for symbol in symbols)
        while True:
            now = _now()
            active_symbols = filter_symbols_for_trading_time(symbols, now)
            if not active_symbols:
                heartbeat(
                    self.dsn,
                    "realtime_quotes_priority",
                    status="outside_trading_time",
                    rows_written=0,
                    rows_failed=0,
                    queue_depth=0,
                    runtime={
                        "input_by_market": dict(input_by_market),
                        "returned_by_market": {},
                        "elapsed_seconds": 0,
                    },
                )
                print(json.dumps({"status": "outside_trading_time", "markets": markets}, ensure_ascii=False), flush=True)
                time.sleep(min(interval_seconds, 300))
                continue
            summary = self.sync_once(active_symbols)
            print(json.dumps(summary.to_dict(), ensure_ascii=False), flush=True)
            sleep_seconds = max(0, interval_seconds - summary.elapsed_seconds)
            time.sleep(sleep_seconds)

    def _write_monitoring(
        self,
        *,
        snapshot_minute: datetime,
        input_by_market: dict[str, int],
        returned_by_market: dict[str, int],
        written: int,
        failed_batches: int,
        elapsed_seconds: float,
    ) -> None:
        try:
            write_dataset_coverage(
                self.dsn,
                [
                    DatasetCoverage(
                        market=market,
                        dataset_key="realtime_quote",
                        expected_count=expected,
                        collected_count=int(returned_by_market.get(market, 0)),
                        latest_data_at=snapshot_minute,
                        freshness_status="ok" if returned_by_market.get(market, 0) >= expected else "partial",
                    )
                    for market, expected in input_by_market.items()
                ],
            )
            heartbeat(
                self.dsn,
                "realtime_quotes_priority",
                status="running",
                rows_written=written,
                rows_failed=failed_batches,
                last_write_at=snapshot_minute,
                last_success_at=snapshot_minute if written else None,
                runtime={
                    "input_by_market": input_by_market,
                    "returned_by_market": returned_by_market,
                    "elapsed_seconds": round(elapsed_seconds, 3),
                },
            )
        except Exception:
            return


def _quote_rows(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [row for row in payload if isinstance(row, dict) and row.get("symbol")]
    if isinstance(payload, dict) and payload.get("symbol"):
        return [payload]
    return []


def _chunks(items: list[str], size: int) -> Iterable[list[str]]:
    for index in range(0, len(items), size):
        yield items[index : index + size]


def _market_from_symbol(symbol: str) -> str:
    suffix = symbol.rsplit(".", 1)[-1].lower() if "." in symbol else ""
    if suffix in {"sh", "sz"}:
        return "cn"
    return suffix


def _now() -> datetime:
    return datetime.now(timezone.utc).astimezone()
